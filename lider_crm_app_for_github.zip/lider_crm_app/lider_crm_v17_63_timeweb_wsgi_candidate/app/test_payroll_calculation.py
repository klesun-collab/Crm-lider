"""Regression tests for recurring-slot payroll aggregation."""
import sqlite3
import unittest
from payroll_calculation import (
    get_payroll_sessions,
    get_ambiguous_payroll_slot_count,
    summarize_payroll_sessions,
)


class PayrollCalculationTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
          CREATE TABLE clients(id INTEGER PRIMARY KEY, child_name TEXT NOT NULL);
          CREATE TABLE attendance(
            id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL, trainer TEXT,
            lesson_date TEXT NOT NULL, lesson_time TEXT NOT NULL, status TEXT NOT NULL,
            rate_snapshot INTEGER NOT NULL DEFAULT 0, schedule_slot_id INTEGER
          );
          INSERT INTO clients VALUES (1,'Аня'),(2,'Боря'),(3,'Вика'),(4,'Гриша'),(5,'Даша');
        ''')

    def tearDown(self):
        self.db.close()

    def test_recurring_template_counts_once_per_date_not_once_forever(self):
        # Same schedule template (slot 77) recurs on three dates.
        self.db.executemany('INSERT INTO attendance VALUES(?,?,?,?,?,?,?,?)', [
            (1,1,'Анна','2026-10-05','10:00','attended',400,77),
            (2,2,'Анна','2026-10-05','10:00','attended',400,77),
            (3,3,'Анна','2026-10-12','10:00','attended',400,77),
            (4,4,'Анна','2026-10-19','10:00','attended',430,77),
        ])
        sessions = get_payroll_sessions(self.db, '2026-10-01', '2026-10-31')
        self.assertEqual(len(sessions), 3)
        self.assertEqual([r['lesson_date'] for r in sessions], [
            '2026-10-05', '2026-10-12', '2026-10-19'
        ])
        self.assertEqual([r['rate_snapshot'] for r in sessions], [400, 400, 430])
        self.assertEqual(sessions[0]['children_count'], 2)
        totals = summarize_payroll_sessions(sessions)
        self.assertEqual(totals, [{'trainer': 'Анна', 'lessons': 3, 'amount': 1230}])
        self.assertEqual(get_ambiguous_payroll_slot_count(self.db, '2026-10-01', '2026-10-31'), 0)

    def test_only_conflicting_occurrence_is_held_for_review(self):
        self.db.executemany('INSERT INTO attendance VALUES(?,?,?,?,?,?,?,?)', [
            (1,1,'Анна','2026-10-05','10:00','attended',400,77),
            (2,2,'Анна','2026-10-05','10:00','attended',400,77),
            # The same slot template has a conflict on this date only.
            (3,3,'Анна','2026-10-12','10:00','attended',400,77),
            (4,4,'Борис','2026-10-12','10:00','attended',430,77),
            (5,5,'Анна','2026-10-19','10:00','attended',400,77),
        ])
        sessions = get_payroll_sessions(self.db, '2026-10-01', '2026-10-31')
        self.assertEqual([r['lesson_date'] for r in sessions], ['2026-10-05', '2026-10-19'])
        self.assertEqual(get_ambiguous_payroll_slot_count(self.db, '2026-10-01', '2026-10-31'), 1)
        self.assertEqual(sum(r['amount'] for r in summarize_payroll_sessions(sessions)), 800)

    def test_conflicting_rates_on_one_occurrence_are_held(self):
        self.db.executemany('INSERT INTO attendance VALUES(?,?,?,?,?,?,?,?)', [
            (1,1,'Анна','2026-10-05','10:00','attended',400,77),
            (2,2,'Анна','2026-10-05','10:00','attended',430,77),
        ])
        self.assertEqual(get_payroll_sessions(self.db, '2026-10-01', '2026-10-31'), [])
        self.assertEqual(get_ambiguous_payroll_slot_count(self.db, '2026-10-01', '2026-10-31'), 1)

    def test_legacy_rows_are_grouped_by_trainer_date_time(self):
        self.db.executemany('INSERT INTO attendance VALUES(?,?,?,?,?,?,?,?)', [
            (1,1,'Анна','2026-10-05','10:00','attended',400,None),
            (2,2,'Анна','2026-10-05','10:00','attended',400,None),
            (3,3,'Анна','2026-10-05','10:30','attended',400,None),
        ])
        sessions = get_payroll_sessions(self.db, '2026-10-01', '2026-10-31')
        self.assertEqual(len(sessions), 2)
        self.assertEqual([r['children_count'] for r in sessions], [2, 1])

    def test_unattended_rows_never_enter_payroll(self):
        self.db.execute('INSERT INTO attendance VALUES(1,1,?,?,?,?,?,?)',
                        ('Анна','2026-10-05','10:00','missed',400,77))
        self.assertEqual(get_payroll_sessions(self.db, '2026-10-01', '2026-10-31'), [])


if __name__ == '__main__':
    unittest.main()
