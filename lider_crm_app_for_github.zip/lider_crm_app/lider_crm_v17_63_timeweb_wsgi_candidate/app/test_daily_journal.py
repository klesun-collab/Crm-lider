import sqlite3
import unittest
from daily_journal import normalize_journal_date, get_daily_journal, get_daily_finance_summary

class DailyJournalTests(unittest.TestCase):
    def setUp(self):
        self.db=sqlite3.connect(':memory:')
        self.db.row_factory=sqlite3.Row
        self.db.executescript('''
        CREATE TABLE trainers(id INTEGER PRIMARY KEY,name TEXT);
        CREATE TABLE schedule_resources(id INTEGER PRIMARY KEY,name TEXT);
        CREATE TABLE schedule_slots(id INTEGER PRIMARY KEY,slot_date TEXT,slot_time TEXT,duration_minutes INTEGER,capacity INTEGER,kind TEXT,notes TEXT,trainer_id INTEGER,room_id INTEGER,lane_id INTEGER);
        CREATE TABLE clients(id INTEGER PRIMARY KEY,child_name TEXT);
        CREATE TABLE subscriptions(id INTEGER PRIMARY KEY,title TEXT);
        CREATE TABLE bookings(id INTEGER PRIMARY KEY,slot_id INTEGER,client_id INTEGER,status TEXT,booking_type TEXT DEFAULT 'regular');
        CREATE TABLE sales(id INTEGER PRIMARY KEY,amount INTEGER,status TEXT,created_at TEXT);
        CREATE TABLE cash_expenses(id INTEGER PRIMARY KEY,amount INTEGER,expense_date TEXT);
        INSERT INTO trainers VALUES(1,'Тест Тренер');
        INSERT INTO schedule_slots VALUES(1,'2026-10-17','09:00',30,2,'group','',1,NULL,NULL);
        INSERT INTO clients VALUES(1,'Аня');
        INSERT INTO clients VALUES(2,'Боря');
        INSERT INTO bookings VALUES(1,1,1,'booked','regular');
        INSERT INTO bookings VALUES(2,1,2,'attended','regular');
        INSERT INTO sales VALUES(1,1000,'completed','2026-10-17T10:00:00');
        INSERT INTO sales VALUES(2,200,'refund','2026-10-17T11:00:00');
        INSERT INTO cash_expenses VALUES(1,150,'2026-10-17');
        ''')
    def tearDown(self): self.db.close()
    def test_normalize_date(self):
        self.assertEqual(normalize_journal_date('2026-10-17'),'2026-10-17')
        with self.assertRaises(ValueError): normalize_journal_date('17.10.2026')
    def test_journal_aggregates_without_duplicate_slots(self):
        result=get_daily_journal(self.db,'2026-10-17')
        self.assertEqual(result['totals']['slots'],1)
        self.assertEqual(result['totals']['booked'],1)
        self.assertEqual(result['totals']['attended'],1)
        self.assertEqual(result['slots'][0]['booked_names'],'Аня')
        self.assertEqual(result['slots'][0]['occupied_count'],2)
    def test_finance_summary_read_only_aggregates_refunds(self):
        result=get_daily_finance_summary(self.db,'2026-10-17')
        self.assertEqual(result['sales']['gross_sales'],1000)
        self.assertEqual(result['sales']['refunds'],200)
        self.assertEqual(result['sales']['net_sales'],800)
        self.assertEqual(result['expenses']['expenses'],150)
        self.assertEqual(self.db.execute('SELECT COUNT(*) FROM sales').fetchone()[0],2)
    def test_missing_day_is_empty(self):
        result=get_daily_journal(self.db,'2026-10-18')
        self.assertEqual(result['totals']['slots'],0)
        self.assertEqual(len(result['slots']),0)

if __name__=='__main__': unittest.main()
