"""Canonical payroll session aggregation shared by the HTML and CSV reports.

A scheduled slot is a recurring template: its ID can appear on many dates. A
payable training is therefore keyed by slot ID + date + time, not slot ID alone.
Legacy attendance without a slot ID is grouped by trainer + date + time.
Ambiguous trainer/rate snapshots are held for manual review per occurrence.
This module is read-only and never changes payroll or attendance records.
"""
from __future__ import annotations


def get_payroll_sessions(conn, start: str, end: str):
    """Return one row per payable trainer session, excluding ambiguous occurrences."""
    return conn.execute(
        """WITH ambiguous_slots AS (
            SELECT schedule_slot_id, lesson_date, lesson_time
            FROM attendance
            WHERE status='attended' AND lesson_date BETWEEN ? AND ?
              AND schedule_slot_id IS NOT NULL
            GROUP BY schedule_slot_id, lesson_date, lesson_time
            HAVING COUNT(DISTINCT COALESCE(NULLIF(TRIM(trainer),''),'Не указан'))>1
                OR COUNT(DISTINCT rate_snapshot)>1
        )
        SELECT COALESCE(NULLIF(TRIM(a.trainer),''),'Не указан') trainer,
               a.lesson_date, a.lesson_time, a.schedule_slot_id,
               MAX(a.rate_snapshot) rate_snapshot,
               COUNT(DISTINCT a.client_id) children_count,
               GROUP_CONCAT(DISTINCT cl.child_name) children
        FROM attendance a
        JOIN clients cl ON cl.id=a.client_id
        WHERE a.status='attended' AND a.lesson_date BETWEEN ? AND ?
          AND NOT EXISTS (
            SELECT 1 FROM ambiguous_slots bad
            WHERE bad.schedule_slot_id=a.schedule_slot_id
              AND bad.lesson_date=a.lesson_date AND bad.lesson_time=a.lesson_time
          )
        GROUP BY a.schedule_slot_id, a.lesson_date, a.lesson_time,
                 COALESCE(NULLIF(TRIM(a.trainer),''),'Не указан')
        ORDER BY a.lesson_date, a.lesson_time, trainer""",
        (start, end, start, end),
    ).fetchall()


def get_ambiguous_payroll_slot_count(conn, start: str, end: str) -> int:
    """Count conflicting slot occurrences, not reusable schedule template IDs."""
    row = conn.execute(
        """SELECT COUNT(*) n FROM (
            SELECT schedule_slot_id, lesson_date, lesson_time
            FROM attendance
            WHERE status='attended' AND lesson_date BETWEEN ? AND ?
              AND schedule_slot_id IS NOT NULL
            GROUP BY schedule_slot_id, lesson_date, lesson_time
            HAVING COUNT(DISTINCT COALESCE(NULLIF(TRIM(trainer),''),'Не указан'))>1
                OR COUNT(DISTINCT rate_snapshot)>1
        )""",
        (start, end),
    ).fetchone()
    return int(row["n"] if hasattr(row, "keys") else row[0])


def summarize_payroll_sessions(sessions):
    """Aggregate already-deduplicated sessions by trainer without counting children as lessons."""
    totals = {}
    for session in sessions:
        trainer = session["trainer"]
        item = totals.setdefault(trainer, {"trainer": trainer, "lessons": 0, "amount": 0})
        item["lessons"] += 1
        item["amount"] += int(session["rate_snapshot"] or 0)
    return sorted(totals.values(), key=lambda item: item["trainer"])
