"""Read-only operational readiness checks for a Leader CRM deployment."""
from __future__ import annotations

import ipaddress
import os
from datetime import datetime, timezone
from pathlib import Path

REQUIRED_TABLES = {
    "users", "clients", "subscriptions", "subscription_freezes", "attendance_restorations",
    "attendance", "sales", "refund_requests", "cash_expenses", "cash_shifts", "cash_wallets", "wallet_transfers", "cash_expense_categories", "cash_income_categories", "cash_other_income", "loyalty_ledger", "products",
    "stock_movements", "discounts", "audit_log", "settings", "trainers", "schedule_slots",
    "bookings", "leads", "trial_attendance", "tasks", "client_outreach", "marketing_campaigns", "login_attempts",
}


def _is_loopback_host(host: str) -> bool:
    host = str(host or "").strip().lower()
    if host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _check(key: str, title: str, status: str, detail: str) -> dict[str, str]:
    return {"key": key, "title": title, "status": status, "detail": detail}


def build_system_readiness_report(
    conn,
    *,
    db_path: str | os.PathLike,
    backup_dir: str | os.PathLike,
    secret_configured: bool,
    cookie_secure: bool,
    host: str = "127.0.0.1",
    debug: bool = False,
    now: datetime | None = None,
) -> list[dict[str, str]]:
    """Return diagnostic checks without modifying database or filesystem state."""
    checks: list[dict[str, str]] = []

    try:
        integrity_rows = conn.execute("PRAGMA integrity_check").fetchall()
        integrity_ok = len(integrity_rows) == 1 and str(integrity_rows[0][0]).lower() == "ok"
        checks.append(_check("sqlite_integrity", "Целостность SQLite", "ok" if integrity_ok else "error",
                             "PRAGMA integrity_check: ok" if integrity_ok else f"Нарушения: {len(integrity_rows)}; требуется разбор"))
    except Exception as exc:
        checks.append(_check("sqlite_integrity", "Целостность SQLite", "error", f"Проверка не выполнена: {type(exc).__name__}"))

    try:
        fk_rows = conn.execute("PRAGMA foreign_key_check").fetchall()
        checks.append(_check("foreign_keys", "Внешние ключи SQLite", "ok" if not fk_rows else "error",
                             "Нарушений не найдено" if not fk_rows else f"Нарушений: {len(fk_rows)}"))
    except Exception as exc:
        checks.append(_check("foreign_keys", "Внешние ключи SQLite", "error", f"Проверка не выполнена: {type(exc).__name__}"))

    try:
        tables = {str(row[0]) for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        missing = sorted(REQUIRED_TABLES - tables)
        checks.append(_check("schema", "Основные таблицы CRM", "ok" if not missing else "error",
                             "Все основные таблицы присутствуют" if not missing else "Отсутствуют: " + ", ".join(missing)))
    except Exception as exc:
        checks.append(_check("schema", "Основные таблицы CRM", "error", f"Проверка не выполнена: {type(exc).__name__}"))

    path = Path(db_path).expanduser()
    db_exists = path.is_file()
    checks.append(_check("database_file", "Файл базы данных", "ok" if db_exists else "error",
                         "Файл базы найден" if db_exists else "Файл базы не найден по настроенному пути"))
    if db_exists:
        writable = os.access(path, os.W_OK)
        checks.append(_check("database_writable", "Доступ на запись к базе", "ok" if writable else "error",
                             "Процесс может записывать данные" if writable else "Нет доступа на запись к файлу базы"))

    checks.append(_check("stable_secret", "Постоянный секрет сессии", "ok" if secret_configured else "warning",
                         "LIDER_CRM_SECRET задан" if secret_configured else "LIDER_CRM_SECRET не задан: сессии могут перестать работать после перезапуска"))
    checks.append(_check("secure_cookie", "Secure-флаг cookie", "ok" if cookie_secure else "warning",
                         "SESSION_COOKIE_SECURE включён" if cookie_secure else "Включите LIDER_COOKIE_SECURE=1 при работе через HTTPS"))
    checks.append(_check("debug_mode", "Режим отладки", "warning" if debug else "ok",
                         "Отладка включена; не публикуйте приложение" if debug else "Режим отладки выключен"))
    checks.append(_check("bind_host", "Сетевой интерфейс", "info" if _is_loopback_host(host) else "warning",
                         "Доступ только с этого компьютера" if _is_loopback_host(host) else f"Приложение слушает {host}; проверьте firewall, WSGI и HTTPS"))

    directory = Path(backup_dir).expanduser()
    try:
        backups = sorted(directory.glob("lider_crm_full_*.sqlite3"), key=lambda p: p.stat().st_mtime, reverse=True) if directory.is_dir() else []
        if not backups:
            checks.append(_check("backup_freshness", "Резервная копия", "warning", "Не найдена копия в настроенном каталоге"))
        else:
            newest = backups[0]
            manifest = newest.with_name(newest.name + ".manifest.json")
            reference = now or datetime.now(timezone.utc)
            if reference.tzinfo is None:
                reference = reference.replace(tzinfo=timezone.utc)
            modified = datetime.fromtimestamp(newest.stat().st_mtime, timezone.utc)
            age_hours = max(0.0, (reference.astimezone(timezone.utc) - modified).total_seconds() / 3600)
            has_manifest = manifest.is_file()
            manifest_state = "отсутствует"
            manifest_valid = False
            if has_manifest:
                try:
                    from backup_database import verify_backup_manifest
                    verify_backup_manifest(newest)
                    manifest_state = "проверен"
                    manifest_valid = True
                except Exception as exc:
                    manifest_state = f"ошибка проверки ({type(exc).__name__})"
            fresh = age_hours <= 48 and manifest_valid
            status = "ok" if fresh else "warning"
            detail = f"Последняя копия: {newest.name}; возраст {age_hours:.1f} ч; манифест {manifest_state}"
            checks.append(_check("backup_freshness", "Свежесть резервной копии", status, detail))
    except OSError as exc:
        checks.append(_check("backup_freshness", "Свежесть резервной копии", "warning", f"Каталог резервных копий недоступен: {type(exc).__name__}"))

    return checks
