"""Production WSGI entry point. The startup script runs init_db once before Gunicorn."""
from werkzeug.middleware.proxy_fix import ProxyFix
from app import app

# Trust exactly one reverse proxy (the host Nginx) for forwarded host/proto/client IP.
# Keep this service bound to localhost and never expose Gunicorn directly to the internet.
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
