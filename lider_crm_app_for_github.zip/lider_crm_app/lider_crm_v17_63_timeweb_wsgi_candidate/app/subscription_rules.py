"""Small, deterministic subscription rules shared by routes and tests."""


def restoration_status(current_status, remaining_lessons, total_lessons):
    """Validate a missed-lesson restoration and return the resulting status.

    A cancelled subscription must never be revived by restoring a lesson after
    a refund. Frozen subscriptions stay frozen; completed subscriptions become
    active again when a lesson is restored.
    """
    if current_status == "cancelled":
        raise ValueError("Нельзя восстановить занятие в отменённом абонементе")
    if current_status not in ("active", "frozen", "completed"):
        raise ValueError("Недопустимый статус абонемента для восстановления")
    try:
        remaining = int(remaining_lessons)
        total = int(total_lessons)
    except (TypeError, ValueError):
        raise ValueError("Некорректное количество занятий")
    if total < 1 or remaining < 0 or remaining >= total:
        raise ValueError("Нельзя вернуть занятие сверх исходного количества")
    if current_status == "completed":
        return "active"
    return current_status


def extend_expiry_for_freeze(expires_at, start_date, days):
    """Extend a dated subscription expiry, preserving a deliberately unlimited term."""
    from datetime import date, timedelta
    try:
        days = int(days)
        start = date.fromisoformat(str(start_date))
        if days < 1 or days > 90:
            raise ValueError("Срок заморозки должен быть от 1 до 90 дней")
        if not expires_at:
            return ""
        old_expiry = date.fromisoformat(str(expires_at))
    except (TypeError, ValueError) as exc:
        if isinstance(exc, ValueError) and str(exc).startswith("Срок заморозки"):
            raise
        raise ValueError("Некорректная дата окончания абонемента")
    return (max(old_expiry, start) + timedelta(days=days)).isoformat()
