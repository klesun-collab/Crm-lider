import sqlite3
import unittest
from attendance_reports import get_attendance_report_rows, get_one_visit_rows, validate_period


class AttendanceReportTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
          CREATE TABLE clients(id INTEGER PRIMARY KEY, child_name TEXT, parent_name TEXT, phone TEXT, status TEXT);
          CREATE TABLE attendance(id INTEGER PRIMARY KEY, client_id INTEGER, status TEXT, lesson_date TEXT, lesson_time TEXT);
          CREATE TABLE sales(id INTEGER PRIMARY KEY, client_id INTEGER, status TEXT, amount INTEGER, created_at TEXT);
          INSERT INTO clients VALUES(1,'Аня','Мама Ани','70000000001','active');
          INSERT INTO clients VALUES(2,'Боря','Мама Бори','70000000002','inactive');
          INSERT INTO clients VALUES(3,'Вика','Мама Вики','70000000003','archived');
          INSERT INTO attendance VALUES(1,1,'attended','2026-10-02','09:00');
          INSERT INTO attendance VALUES(2,1,'missed','2026-10-09','09:00');
          INSERT INTO attendance VALUES(3,2,'attended','2026-10-03','10:00');
          INSERT INTO attendance VALUES(4,3,'attended','2026-10-04','11:00');
          INSERT INTO sales VALUES(1,1,'completed',1000,'2026-10-02T10:00:00');
          INSERT INTO sales VALUES(2,1,'refund',200,'2026-10-05T10:00:00');
          INSERT INTO sales VALUES(3,2,'completed',500,'2026-10-03T10:00:00');
        ''')

    def tearDown(self):
        self.db.close()

    def test_period_validation(self):
        self.assertEqual(('2026-10-01','2026-10-31'), validate_period('2026-10-01','2026-10-31'))
        with self.assertRaisesRegex(ValueError, 'позже'):
            validate_period('2026-11-01','2026-10-31')
        with self.assertRaises(ValueError):
            validate_period('2026-02-30','2026-03-01')

    def test_attendance_and_sales_aggregates_do_not_multiply_each_other(self):
        rows = get_attendance_report_rows(self.db, '2026-10-01','2026-10-31')
        by_id = {r['client_id']: r for r in rows}
        self.assertEqual(1, by_id[1]['attended_count'])
        self.assertEqual(1, by_id[1]['missed_count'])
        self.assertEqual(1, by_id[1]['completed_sales'])
        self.assertEqual(800, by_id[1]['net_sales'])
        self.assertNotIn(3, by_id, 'Archived clients are excluded from the report')

    def test_one_visit_report_only_includes_clients_with_exactly_one_visit_ever(self):
        rows = get_one_visit_rows(self.db, '2026-10-01','2026-10-31')
        self.assertEqual([2, 1], [r['client_id'] for r in rows])


if __name__ == '__main__':
    unittest.main()
