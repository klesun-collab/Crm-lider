"""Exact display formatting for imported monetary values stored in kopecks."""


def format_rubles_from_kopecks(value):
    """Format integer kopecks as Russian-style rubles without float arithmetic."""
    try:
        amount = int(value or 0)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("Сумма в копейках должна быть целым числом") from exc
    sign = "-" if amount < 0 else ""
    rubles, kopecks = divmod(abs(amount), 100)
    grouped = f"{rubles:,}".replace(",", " ")
    return f"{sign}{grouped},{kopecks:02d}"
