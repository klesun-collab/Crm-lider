import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")
TREE = ast.parse(SOURCE)

class DashboardWorkbenchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "dashboard")
        cls.source = ast.get_source_segment(SOURCE, cls.node)

    def test_dashboard_queries_today_schedule_and_booked_children(self):
        self.assertIn("WHERE sl.slot_date=?", self.source)
        self.assertIn("FROM bookings b JOIN clients cl ON cl.id=b.client_id", self.source)
        self.assertIn("b.status='booked'", self.source)

    def test_dashboard_has_quick_actions(self):
        for path in ("/clients", "/schedule", "/sales", "/attendance", "/leads", "/tasks"):
            self.assertIn(path, self.source)

    def test_dashboard_shows_due_open_tasks_and_pending_refunds(self):
        self.assertIn("FROM tasks WHERE status='open'", self.source)
        self.assertIn("counts['refunds']", self.source)

    def test_dashboard_is_read_only(self):
        self.assertNotIn("INSERT INTO", self.source)
        self.assertNotIn("UPDATE ", self.source)
        self.assertNotIn("DELETE FROM", self.source)

if __name__ == "__main__":
    unittest.main()
