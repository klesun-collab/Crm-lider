"""Read-only schedule integrity checks for the manager dashboard and exports."""
from __future__ import annotations
from datetime import date, datetime

ISSUE_FIELDS = (
    "issue_type", "severity", "slot_id", "slot_date", "slot_time", "trainer",
    "capacity", "booked_count", "booking_id", "client_id", "subscription_id", "details",
)


def _value(row, key, default=None):
    try:
        return row[key]
    except (KeyError, IndexError, TypeError):
        return default


def _issue(kind, severity, slot, trainer, details, *, booked_count="", booking_id="", client_id="", subscription_id=""):
    return {
        "issue_type": kind,
        "severity": severity,
        "slot_id": _value(slot, "slot_id", _value(slot, "id", "")),
        "slot_date": _value(slot, "slot_date", ""),
        "slot_time": _value(slot, "slot_time", ""),
        "trainer": _value(slot, "trainer", _value(slot, "trainer_name", "")),
        "capacity": _value(slot, "capacity", ""),
        "booked_count": booked_count,
        "booking_id": booking_id,
        "client_id": client_id,
        "subscription_id": subscription_id,
        "details": str(details),
    }


def _minutes(value):
    try:
        parsed = datetime.strptime(str(value), "%H:%M")
    except (TypeError, ValueError):
        return None
    return parsed.hour * 60 + parsed.minute


def build_schedule_audit(conn, today=None, limit=1000):
    """Return deterministic, bounded, read-only schedule issues.

    It intentionally reports suspicious legacy data rather than modifying slots,
    bookings, subscriptions, or attendance. A booking's subscription is only
    evaluated when a subscription is explicitly linked to that booking.
    """
    today = str(today or date.today().isoformat())
    try:
        date.fromisoformat(today)
    except ValueError as exc:
        raise ValueError("Дата должна быть в формате ГГГГ-ММ-ДД") from exc
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = 1000
    limit = max(1, min(limit, 5000))
    issues = []

    slots = conn.execute(
        """SELECT ss.id slot_id,ss.trainer_id,ss.slot_date,ss.slot_time,ss.duration_minutes,ss.capacity,
                  t.name trainer,t.active trainer_active
           FROM schedule_slots ss JOIN trainers t ON t.id=ss.trainer_id
           ORDER BY ss.slot_date,ss.slot_time,ss.id LIMIT ?""", (limit * 2,)
    ).fetchall()
    # Legacy/imported bookings may exceed capacity even though current writes are guarded.
    for row in conn.execute(
        """SELECT ss.id slot_id,ss.slot_date,ss.slot_time,ss.capacity,t.name trainer,
                  COUNT(b.id) booked_count
           FROM schedule_slots ss JOIN trainers t ON t.id=ss.trainer_id
           JOIN bookings b ON b.slot_id=ss.id AND b.status='booked'
           GROUP BY ss.id HAVING COUNT(b.id)>ss.capacity
           ORDER BY ss.slot_date,ss.slot_time,ss.id LIMIT ?""", (limit,)
    ).fetchall():
        issues.append(_issue("over_capacity", "high", row, row["trainer"],
                             f"Записей больше вместимости на {row['booked_count'] - row['capacity']}",
                             booked_count=row["booked_count"]))

    # A trainer may have adjacent slots; only positive-duration overlaps are reported.
    valid_slots = []
    for slot in slots:
        start = _minutes(_value(slot, "slot_time"))
        duration = _value(slot, "duration_minutes", 0)
        try:
            duration = int(duration)
        except (TypeError, ValueError):
            duration = 0
        try:
            date.fromisoformat(str(_value(slot, "slot_date", "")))
            valid_date = True
        except ValueError:
            valid_date = False
        if not valid_date:
            issues.append(_issue("invalid_slot_date", "medium", slot, _value(slot, "trainer"),
                                 "Дата слота имеет неверный формат"))
            continue
        if start is None or duration <= 0 or duration > 24 * 60 or start + duration > 24 * 60:
            issues.append(_issue("invalid_slot_time", "medium", slot, _value(slot, "trainer"),
                                 "Некорректное время или длительность слота"))
            continue
        valid_slots.append((slot, start, start + duration))
    by_trainer_day = {}
    for slot, start, end in valid_slots:
        key = (_value(slot, "trainer_id"), _value(slot, "slot_date"))
        by_trainer_day.setdefault(key, []).append((slot, start, end))
    for (trainer_name, slot_date), entries in by_trainer_day.items():
        entries.sort(key=lambda item: (item[1], _value(item[0], "slot_id", 0)))
        for i, (left, left_start, left_end) in enumerate(entries):
            for right, right_start, right_end in entries[i + 1:]:
                if right_start >= left_end:
                    break
                if max(left_start, right_start) < min(left_end, right_end):
                    issues.append(_issue(
                        "trainer_overlap", "high", right, trainer_name,
                        f"Пересекается со слотом #{_value(left, 'slot_id')} ({_value(left, 'slot_time')})"
                    ))

    for slot in slots:
        if not bool(_value(slot, "trainer_active", 1)) and str(_value(slot, "slot_date", "")) >= today:
            issues.append(_issue("inactive_trainer", "medium", slot, _value(slot, "trainer"),
                                 "Будущий слот назначен неактивному тренеру"))

    # Old booked records need a human decision; do not auto-cancel them.
    for row in conn.execute(
        """SELECT b.id booking_id,b.client_id,b.subscription_id,ss.id slot_id,ss.slot_date,
                  ss.slot_time,ss.capacity,t.name trainer
           FROM bookings b JOIN schedule_slots ss ON ss.id=b.slot_id
           JOIN trainers t ON t.id=ss.trainer_id
           WHERE b.status='booked' AND ss.slot_date < ?
           ORDER BY ss.slot_date,ss.slot_time,b.id LIMIT ?""", (today, limit)
    ).fetchall():
        issues.append(_issue("past_booking_open", "medium", row, row["trainer"],
                             "Прошедшая запись всё ещё имеет статус «записан»",
                             booking_id=row["booking_id"], client_id=row["client_id"],
                             subscription_id=row["subscription_id"] or ""))

    # Only explicitly linked subscriptions are checked; null subscription IDs are allowed.
    for row in conn.execute(
        """SELECT b.id booking_id,b.client_id,b.subscription_id,ss.id slot_id,ss.slot_date,
                  ss.slot_time,ss.capacity,t.name trainer,s.client_id subscription_client_id,
                  s.remaining_lessons,s.expires_at,s.status subscription_status
           FROM bookings b JOIN schedule_slots ss ON ss.id=b.slot_id
           JOIN trainers t ON t.id=ss.trainer_id
           LEFT JOIN subscriptions s ON s.id=b.subscription_id
           WHERE b.status='booked' AND b.subscription_id IS NOT NULL
           ORDER BY ss.slot_date,ss.slot_time,b.id LIMIT ?""", (limit,)
    ).fetchall():
        problems = []
        if _value(row, "subscription_client_id") is None:
            problems.append("абонемент не найден")
        elif _value(row, "subscription_client_id") != _value(row, "client_id"):
            problems.append("абонемент принадлежит другому клиенту")
        else:
            try:
                remaining = int(_value(row, "remaining_lessons", 0))
            except (TypeError, ValueError):
                remaining = 0
            if remaining <= 0:
                problems.append("нет оставшихся занятий")
            expiry = str(_value(row, "expires_at") or "")
            if expiry:
                try:
                    date.fromisoformat(expiry)
                except ValueError:
                    problems.append("у абонемента некорректная дата окончания")
                else:
                    if expiry < str(_value(row, "slot_date") or ""):
                        problems.append("абонемент истекает до даты занятия")
            if str(_value(row, "subscription_status") or "") != "active":
                problems.append("статус абонемента: " + str(_value(row, "subscription_status")))
        if problems:
            issues.append(_issue("booking_subscription", "high", row, row["trainer"], "; ".join(problems),
                                 booking_id=row["booking_id"], client_id=row["client_id"],
                                 subscription_id=row["subscription_id"]))

    priority = {"high": 0, "medium": 1, "low": 2}
    issues.sort(key=lambda r: (priority.get(r["severity"], 9), r["slot_date"], r["slot_time"],
                               str(r["slot_id"]), r["issue_type"], str(r["booking_id"])))
    return issues[:limit]
