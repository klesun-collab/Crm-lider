import ast
import unittest
from pathlib import Path
SOURCE = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE = ast.parse(SOURCE)

def fn(name):
    node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment(SOURCE, node)

class SubscriptionIntegrityRouteTests(unittest.TestCase):
    def test_page_and_export_manager_only(self):
        for name in ('subscription_integrity_page', 'subscription_integrity_csv'):
            node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name)
            self.assertIn('manager_required', [ast.unparse(d) for d in node.decorator_list])
    def test_csv_is_safe_and_utf8_bom(self):
        src = fn('subscription_integrity_csv')
        self.assertIn('safe_csv_row', src)
        self.assertIn('text/csv; charset=utf-8', src)
        self.assertIn('\\ufeff', src)
    def test_csv_has_fixed_filename(self):
        self.assertIn('lider_subscription_integrity.csv', fn('subscription_integrity_csv'))
    def test_no_store_headers_for_both_routes(self):
        for name in ('subscription_integrity_page', 'subscription_integrity_csv'):
            self.assertIn('Cache-Control', fn(name))
    def test_routes_call_read_only_audit(self):
        for name in ('subscription_integrity_page', 'subscription_integrity_csv'):
            self.assertIn('build_subscription_integrity_audit', fn(name))
    def test_routes_do_not_mutate_data(self):
        for name in ('subscription_integrity_page', 'subscription_integrity_csv'):
            src = fn(name).upper()
            for verb in ('INSERT INTO', 'UPDATE ', 'DELETE FROM', 'REPLACE INTO'):
                self.assertNotIn(verb, src)
    def test_page_escapes_user_data(self):
        src = fn('subscription_integrity_page')
        for field in ('issue_type','entity_type','record_id','client_id','subscription_id','child_name','phone','details'):
            self.assertIn(f"esc(row['{field}']", src)
    def test_page_links_to_related_sections(self):
        src = fn('subscription_integrity_page')
        for link in ('/subscriptions','/sales','/attendance','/subscription-integrity.csv'):
            self.assertIn(link, src)
    def test_manager_navigation_includes_page(self):
        self.assertIn('/subscription-integrity', fn('page'))
    def test_explanation_says_read_only(self):
        self.assertIn('не исправляются и не удаляются автоматически', fn('subscription_integrity_page'))

if __name__ == '__main__': unittest.main(verbosity=2)
