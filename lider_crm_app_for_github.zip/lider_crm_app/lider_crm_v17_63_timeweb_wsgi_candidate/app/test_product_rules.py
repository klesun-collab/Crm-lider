import unittest
from product_rules import normalize_product_update

class ProductUpdateValidationTests(unittest.TestCase):
    def test_normalizes_name_and_prices(self):
        self.assertEqual(normalize_product_update('  Очки  ','1200','1800','1'), {
            'name':'Очки','purchase_price':1200,'sale_price':1800,'active':1})
    def test_rejects_blank_or_overlong_name(self):
        for name in ('', '   ', 'x'*101):
            with self.subTest(name=name[:4]), self.assertRaises(ValueError):
                normalize_product_update(name,1,2,'1')
    def test_rejects_invalid_or_out_of_range_prices(self):
        for purchase,sale in ((-1,2),(1,-1),('x',2),(1,'x'),(100000001,2),(1,100000001)):
            with self.subTest(purchase=purchase,sale=sale), self.assertRaises(ValueError):
                normalize_product_update('Очки',purchase,sale,'1')
    def test_rejects_invalid_active_flag(self):
        with self.assertRaisesRegex(ValueError,'статус товара'):
            normalize_product_update('Очки',1,2,'yes')

if __name__=='__main__': unittest.main()
