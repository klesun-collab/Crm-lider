import unittest
from datetime import date, timedelta
from recurring_schedule import weekly_dates, MAX_RECURRENCE_DAYS

class WeeklyScheduleTests(unittest.TestCase):
    def test_inclusive_weekdays_and_end_date(self):
        self.assertEqual(weekly_dates('2026-10-19','2026-10-26',[0], '2026-10-16'),
                         ['2026-10-19','2026-10-26'])

    def test_skips_dates_before_today(self):
        self.assertEqual(weekly_dates('2026-10-12','2026-10-19',[0], '2026-10-16'),
                         ['2026-10-19'])

    def test_rejects_period_longer_than_ninety_days(self):
        start = date(2026, 10, 16)
        end = start + timedelta(days=MAX_RECURRENCE_DAYS + 1)
        with self.assertRaisesRegex(ValueError, '90 дней'):
            weekly_dates(start.isoformat(), end.isoformat(), [0], start.isoformat())

    def test_rejects_reversed_dates(self):
        with self.assertRaisesRegex(ValueError, 'раньше'):
            weekly_dates('2026-10-20','2026-10-19',[0], '2026-10-16')

    def test_rejects_no_weekday(self):
        with self.assertRaisesRegex(ValueError, 'Выберите'):
            weekly_dates('2026-10-19','2026-10-26',[], '2026-10-16')

    def test_rejects_period_without_future_matching_day(self):
        with self.assertRaisesRegex(ValueError, 'нет занятий'):
            weekly_dates('2026-10-17','2026-10-18',[0], '2026-10-16')

if __name__ == '__main__':
    unittest.main()


class ShiftStartTimesTests(unittest.TestCase):
    def test_generates_half_hour_slots_excluding_shift_end(self):
        from recurring_schedule import shift_start_times
        self.assertEqual(['09:00','09:30','10:00','10:30'], shift_start_times('09:00','11:00',30))

    def test_sixty_minute_shift_slots(self):
        from recurring_schedule import shift_start_times
        self.assertEqual(['09:00','10:00','11:00'], shift_start_times('09:00','12:00',60))

    def test_rejects_non_divisible_shift(self):
        from recurring_schedule import shift_start_times
        with self.assertRaisesRegex(ValueError, 'делиться'):
            shift_start_times('09:00','10:45',30)

    def test_rejects_overnight_shift(self):
        from recurring_schedule import shift_start_times
        with self.assertRaisesRegex(ValueError, 'позже'):
            shift_start_times('21:00','09:00',30)


class RecurringSlotCreationTests(unittest.TestCase):
    def setUp(self):
        import sqlite3
        self.db = sqlite3.connect(':memory:')
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
          CREATE TABLE schedule_slots(
            id INTEGER PRIMARY KEY, trainer_id INTEGER, slot_date TEXT, slot_time TEXT,
            duration_minutes INTEGER, capacity INTEGER, kind TEXT, notes TEXT,
            UNIQUE(trainer_id,slot_date,slot_time)
          );
        ''')

    def tearDown(self):
        self.db.close()

    def test_creates_all_half_hour_slots_for_selected_dates(self):
        from recurring_schedule import create_recurring_slots
        created, skipped = create_recurring_slots(self.db, 7, ['2026-10-19','2026-10-20'],
            ['09:00','09:30','10:00'], 30, 1, 'individual', '')
        self.assertEqual((6,0),(created,skipped))
        self.assertEqual(6,self.db.execute('SELECT COUNT(*) FROM schedule_slots').fetchone()[0])

    def test_existing_slots_are_skipped_without_duplicate_rows(self):
        from recurring_schedule import create_recurring_slots
        self.db.execute("INSERT INTO schedule_slots(trainer_id,slot_date,slot_time,duration_minutes,capacity,kind,notes) VALUES(7,'2026-10-19','09:00',30,1,'individual','')")
        created, skipped = create_recurring_slots(self.db, 7, ['2026-10-19'], ['09:00','09:30'], 30, 1, 'individual', '')
        self.assertEqual((1,1),(created,skipped))
        self.assertEqual(2,self.db.execute('SELECT COUNT(*) FROM schedule_slots').fetchone()[0])

    def test_overlap_raises_and_caller_can_rollback_entire_batch(self):
        from recurring_schedule import create_recurring_slots
        with self.assertRaisesRegex(ValueError,'пересекается'):
            create_recurring_slots(self.db, 7, ['2026-10-19'], ['09:00','09:30'], 60, 1, 'individual', '')
        self.db.rollback()
        self.assertEqual(0,self.db.execute('SELECT COUNT(*) FROM schedule_slots').fetchone()[0])
