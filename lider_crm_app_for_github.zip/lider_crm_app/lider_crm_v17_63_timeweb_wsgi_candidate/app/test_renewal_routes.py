import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE = ast.parse(SOURCE)


def route_source(name):
    node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment(SOURCE, node), [ast.unparse(d) for d in node.decorator_list]


class RenewalRouteTests(unittest.TestCase):
    def test_worklist_and_export_require_login(self):
        for name in ('subscription_renewals', 'subscription_renewals_csv'):
            source, decorators = route_source(name)
            self.assertIn('login_required', decorators)

    def test_csv_export_is_safe_and_not_cached(self):
        source, _ = route_source('subscription_renewals_csv')
        self.assertIn('safe_csv_row', source)
        self.assertIn('"\\ufeff"', source)
        self.assertIn('Cache-Control', source)
        self.assertIn('text/csv; charset=utf-8', source)
        self.assertIn('normalize_horizon_days', source)

    def test_worklist_has_horizon_choices_and_export_link(self):
        source, _ = route_source('subscription_renewals')
        for days in ('7', '14', '30', '60', '90'):
            self.assertIn(days, source)
        self.assertIn('/renewals.csv?days=', source)

    def test_routes_do_not_create_sales_or_modify_subscriptions(self):
        for name in ('subscription_renewals', 'subscription_renewals_csv'):
            source, _ = route_source(name)
            self.assertNotIn('INSERT INTO sales', source.upper())
            self.assertNotIn('UPDATE subscriptions', source.upper())


if __name__ == '__main__':
    unittest.main()
