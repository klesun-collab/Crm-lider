#!/usr/bin/env python3
"""Create a human-review CSV from GoCRM subscription summary fields.

This utility NEVER writes to the CRM database and NEVER creates subscriptions,
sales, or attendance. Summary strings are ambiguous historical snapshots and
must be reconciled against GoCRM before operational use.
"""
import argparse
import csv
import re
import sys
from pathlib import Path

import pandas as pd

COL_ID = 'Номер клиента'
COL_URL = 'Ссылка на карточку'
COL_CHILD = 'Имя ребенка'
COL_SUMMARY = 'Абонементы (наименование, тип занятия, остаток, стоимость при покупке)'

# Example: Абонемент на 8 занятий №5667 , Индивидуальный, остаток - 6, покупка - 8436 ₽
ENTRY_RE = re.compile(
    r'(?P<title>.*?)\s*№\s*(?P<subscription_no>\d+)\s*,\s*'
    r'(?P<lesson_type>[^,]+?)\s*,\s*остаток\s*-\s*(?P<remaining>-?\d+)\s*,\s*'
    r'покупка\s*-\s*(?P<purchase>[^,;]+)', re.IGNORECASE
)
TOTAL_RE = re.search


def parse_summary(value):
    raw = '' if pd.isna(value) else str(value).strip()
    if not raw:
        return []
    # Summaries commonly contain one entry. Split only where a new named
    # subscription number begins; retain unmatched strings as review rows.
    matches = list(ENTRY_RE.finditer(raw))
    if not matches:
        return [{'raw_summary': raw, 'parse_status': 'needs_manual_parse',
                 'subscription_no': '', 'title': '', 'lesson_type': '',
                 'total_lessons_hint': '', 'remaining_lessons': '',
                 'purchase_rub': '', 'flags': 'Не удалось разобрать формат'}]
    output = []
    for m in matches:
        title = m.group('title').strip(' ,;')
        remain = int(m.group('remaining'))
        purchase_raw = m.group('purchase').strip().replace('\u00a0', ' ').replace('₽', '').replace('руб.', '').strip()
        purchase_raw = purchase_raw.replace(' ', '').replace(',', '.')
        try:
            purchase = f'{float(purchase_raw):.2f}'
        except ValueError:
            purchase = ''
        total_match = re.search(r'на\s+(\d+)\s+заняти', title, re.IGNORECASE)
        total_hint = int(total_match.group(1)) if total_match else ''
        flags = []
        if remain < 0:
            flags.append('Отрицательный остаток')
        if total_hint != '' and remain > total_hint:
            flags.append('Остаток больше количества в названии')
        if not total_hint:
            flags.append('Количество занятий не определено по названию')
        if purchase == '':
            flags.append('Не распознана стоимость покупки')
        if purchase == '0.00':
            flags.append('Нулевая стоимость: проверить бесплатное/служебное занятие')
        output.append({
            'raw_summary': raw, 'parse_status': 'parsed_needs_human_review',
            'subscription_no': m.group('subscription_no'), 'title': title,
            'lesson_type': m.group('lesson_type').strip(),
            'total_lessons_hint': total_hint, 'remaining_lessons': remain,
            'purchase_rub': purchase, 'flags': '; '.join(flags) if flags else 'Сверить с первоисточником'
        })
    return output


def build_review(input_xlsx, output_csv):
    df = pd.read_excel(input_xlsx, dtype=object)
    required = {COL_ID, COL_URL, COL_CHILD, COL_SUMMARY}
    missing = required - set(df.columns)
    if missing:
        raise RuntimeError('Не найдены столбцы: ' + ', '.join(sorted(missing)))
    rows = []
    for source_row, row in enumerate(df.to_dict(orient='records'), start=2):
        parsed = parse_summary(row.get(COL_SUMMARY, ''))
        for item in parsed:
            rows.append({
                'source_excel_row': source_row,
                'source_client_id': '' if pd.isna(row.get(COL_ID)) else str(row.get(COL_ID)).strip(),
                'source_url': '' if pd.isna(row.get(COL_URL)) else str(row.get(COL_URL)).strip(),
                'child_name': '' if pd.isna(row.get(COL_CHILD)) else str(row.get(COL_CHILD)).strip(),
                **item,
                'approved_for_import': 'NO — manual reconciliation required'
            })
    fields = ['source_excel_row', 'source_client_id', 'source_url', 'child_name',
              'subscription_no', 'title', 'lesson_type', 'total_lessons_hint',
              'remaining_lessons', 'purchase_rub', 'flags', 'parse_status',
              'raw_summary', 'approved_for_import']
    out = Path(output_csv)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    stats = {
        'clients_in_source': len(df),
        'clients_with_summary': int(df[COL_SUMMARY].fillna('').astype(str).str.strip().ne('').sum()),
        'review_rows': len(rows),
        'rows_needing_manual_parse': sum(r['parse_status'] == 'needs_manual_parse' for r in rows),
        'output': str(out),
        'database_changed': False,
        'subscriptions_created': 0,
        'sales_created': 0,
        'attendance_created': 0,
    }
    return stats


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--xlsx', required=True, help='Исходная выгрузка GoCRM XLSX')
    ap.add_argument('--out', required=True, help='Путь для CSV ручной сверки')
    args = ap.parse_args()
    try:
        import json
        print(json.dumps(build_review(args.xlsx, args.out), ensure_ascii=False, indent=2))
    except Exception as e:
        print('ОШИБКА:', e, file=sys.stderr)
        return 2
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
