"""Regression checks for default browser security headers."""
from pathlib import Path
import unittest

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")

class SecurityHeaderTests(unittest.TestCase):
    def test_global_response_hook_sets_browser_security_headers(self):
        block = SOURCE.split("def add_security_headers(response):", 1)[1].split("@app.before_request", 1)[0]
        for header, value in (
            ("X-Content-Type-Options", "nosniff"),
            ("X-Frame-Options", "DENY"),
            ("Referrer-Policy", "strict-origin-when-cross-origin"),
            ("Permissions-Policy", "camera=(), microphone=(), geolocation=()"),
            ("Cache-Control", "no-store"),
        ):
            self.assertIn(header, block)
            self.assertIn(value, block)

    def test_hook_is_registered_as_after_request(self):
        self.assertIn("@app.after_request\ndef add_security_headers(response):", SOURCE)

if __name__ == "__main__":
    unittest.main()
