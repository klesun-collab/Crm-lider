"""Exercise real SQLite schema migrations without needing Flask's web server."""
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).parent

class RuntimeSchemaMigrationTests(unittest.TestCase):
    def test_existing_schema_migrates_twice_and_campaign_report_works(self):
        script = r'''import os, sys, types
from pathlib import Path
fl = types.ModuleType('flask')
class DummyFlask:
    def __init__(self,*a,**k): self.config={}; self.secret_key=None
    def _decorator(self,*a,**k): return lambda f:f
    route=get=post=after_request=before_request=context_processor=_decorator
class DummyRequest: method='GET'; endpoint=''
fl.Flask=DummyFlask; fl.request=DummyRequest(); fl.session={}
fl.redirect=lambda *a,**k:None; fl.url_for=lambda *a,**k:''; fl.render_template_string=lambda *a,**k:''
fl.abort=lambda *a,**k: (_ for _ in ()).throw(RuntimeError('abort'))
fl.flash=lambda *a,**k:None; fl.get_flashed_messages=lambda:[]
sys.modules['flask']=fl
werk=types.ModuleType('werkzeug'); sec=types.ModuleType('werkzeug.security')
sec.generate_password_hash=lambda x:x; sec.check_password_hash=lambda a,b:a==b
werk.security=sec; sys.modules['werkzeug']=werk; sys.modules['werkzeug.security']=sec
sys.path.insert(0, os.environ['CRM_SOURCE_DIR'])
import app
app.init_db(); app.init_db()
with app.connect() as c:
    sales_cols={r['name'] for r in c.execute('PRAGMA table_info(sales)')}
    campaign_cols={r['name'] for r in c.execute('PRAGMA table_info(marketing_campaigns)')}
    booking_cols={r['name'] for r in c.execute('PRAGMA table_info(bookings)')}
    assert {'campaign_id','original_sale_id','subscription_id','gross_amount','points_earned','points_redeemed','loyalty_discount_amount'} <= sales_cols
    assert 'cost_amount' in campaign_cols
    assert {'booking_type','lead_id'} <= booking_cols
    sales_cols={r['name'] for r in c.execute('PRAGMA table_info(sales)')}
    expense_cols={r['name'] for r in c.execute('PRAGMA table_info(cash_expenses)')}
    assert 'wallet_id' in sales_cols and 'wallet_id' in expense_cols and 'category_id' in expense_cols
    category_names={r['name'] for r in c.execute('SELECT name FROM cash_expense_categories')}
    assert {'Коммунальные услуги','Химия бассейна','Зарплата','Уборка','Реклама','Ремонт и обслуживание','Прочее'} <= category_names
    wallet_names={r['name'] for r in c.execute('SELECT name FROM cash_wallets')}
    assert {'Наличные','Банковская карта','Перевод','QR'} <= wallet_names
    assert c.execute('SELECT COUNT(*) FROM wallet_transfers').fetchone()[0] == 0
    assert c.execute("SELECT value FROM settings WHERE key='loyalty_enabled'").fetchone()[0]=='0'
    assert c.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='loyalty_ledger'").fetchone()[0]==1
    assert 'trial_attendance' in {r['name'] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    indexes={r['name'] for r in c.execute("SELECT name FROM sqlite_master WHERE type='index'")}
    assert 'idx_one_active_trial_per_lead' in indexes
    c.execute("INSERT INTO clients(child_name,parent_name,phone,created_at) VALUES('Child','Parent','000','2026-01-01')")
    client=c.execute('SELECT last_insert_rowid()').fetchone()[0]
    c.execute("INSERT INTO trainers(name) VALUES('Trial migration trainer')")
    trainer=c.execute('SELECT last_insert_rowid()').fetchone()[0]
    c.execute("INSERT INTO schedule_slots(trainer_id,slot_date,slot_time,duration_minutes,capacity,kind) VALUES(?,?,?,?,?,?)",(trainer,'2026-10-18','10:00',30,1,'individual'))
    slot=c.execute('SELECT last_insert_rowid()').fetchone()[0]
    c.execute("INSERT INTO bookings(slot_id,client_id,subscription_id,created_by,created_at) VALUES(?,?,?,?,?)",(slot,client,None,None,'2026-10-17T10:00:00'))
    assert c.execute("SELECT booking_type FROM bookings WHERE slot_id=?",(slot,)).fetchone()[0]=='regular'
    assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    c.execute("INSERT INTO cash_expenses(expense_date,description,amount,payment_method,created_by_name,created_at) VALUES('2026-01-01','Legacy expense',500,'cash','admin','2026-01-01')")
    c.execute("INSERT INTO marketing_campaigns(name,segment,status,created_at,updated_at,cost_amount) VALUES('Test','general','active','2026-01-01','2026-01-01',1000)")
    campaign=c.execute('SELECT last_insert_rowid()').fetchone()[0]
    c.execute("INSERT INTO sales(client_id,item,amount,payment_method,status,created_at,campaign_id) VALUES(?,?,?,?,?,?,?)",(client,'A',8000,'cash','completed','2026-01-01',campaign))
    first=c.execute('SELECT last_insert_rowid()').fetchone()[0]
    c.execute("INSERT INTO sales(client_id,item,amount,payment_method,status,created_at,campaign_id) VALUES(?,?,?,?,?,?,?)",(client,'B',3000,'cash','completed','2026-01-01',campaign))
    second=c.execute('SELECT last_insert_rowid()').fetchone()[0]
    c.execute("INSERT INTO sales(client_id,item,amount,payment_method,status,created_at,original_sale_id) VALUES(?,?,?,?,?,?,?)",(client,'Refund B',3000,'cash','refund','2026-01-02',second))
    row=c.execute("""SELECT m.cost_amount,
      (SELECT COUNT(*) FROM sales s WHERE s.campaign_id=m.id AND s.status='completed') sale_count,
      (SELECT COALESCE(SUM(s.amount),0) FROM sales s WHERE s.campaign_id=m.id AND s.status='completed') gross_revenue,
      (SELECT COALESCE(SUM(r.amount),0) FROM sales r JOIN sales src ON src.id=r.original_sale_id WHERE r.status='refund' AND src.campaign_id=m.id) refund_total
      FROM marketing_campaigns m WHERE m.id=?""",(campaign,)).fetchone()
    assert tuple(row)==(1000,2,11000,3000), tuple(row)
    assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    # Simulate an older database without wallet tables/columns, then migrate it in place.
    c.execute("DROP INDEX IF EXISTS idx_wallet_transfers_created_at")
    c.execute("DROP INDEX IF EXISTS idx_cash_wallets_name_nocase")
    c.execute("DROP INDEX IF EXISTS idx_sales_wallet_status")
    c.execute("DROP INDEX IF EXISTS idx_cash_expenses_wallet")
    c.execute("DROP INDEX IF EXISTS idx_cash_expenses_category_date")
    c.execute("DROP INDEX IF EXISTS idx_cash_expense_categories_name_nocase")
    c.execute("DROP INDEX IF EXISTS idx_cash_income_categories_name_nocase")
    c.execute("DROP INDEX IF EXISTS idx_cash_other_income_wallet")
    c.execute("DROP INDEX IF EXISTS idx_cash_other_income_category_date")
    c.execute("DROP TABLE cash_other_income")
    c.execute("DROP TABLE cash_income_categories")
    c.execute("DROP INDEX IF EXISTS idx_loyalty_ledger_client_created")
    c.execute("DROP INDEX IF EXISTS idx_loyalty_sale_entry_type")
    c.execute("DROP TABLE loyalty_ledger")
    c.execute("DROP TABLE wallet_transfers")
    c.execute("ALTER TABLE sales DROP COLUMN gross_amount")
    c.execute("ALTER TABLE sales DROP COLUMN points_earned")
    c.execute("ALTER TABLE sales DROP COLUMN points_redeemed")
    c.execute("ALTER TABLE sales DROP COLUMN loyalty_discount_amount")
    c.execute("ALTER TABLE sales DROP COLUMN wallet_id")
    c.execute("ALTER TABLE cash_expenses DROP COLUMN wallet_id")
    c.execute("ALTER TABLE cash_expenses DROP COLUMN category_id")
    c.execute("DROP TABLE cash_wallets")
    c.execute("DROP TABLE cash_expense_categories")
    c.commit()
app.init_db()
with app.connect() as c:
    sales_cols={r['name'] for r in c.execute('PRAGMA table_info(sales)')}
    expense_cols={r['name'] for r in c.execute('PRAGMA table_info(cash_expenses)')}
    assert 'wallet_id' in sales_cols and 'wallet_id' in expense_cols and 'category_id' in expense_cols
    assert c.execute("SELECT COUNT(*) FROM sales").fetchone()[0]==3
    assert c.execute("SELECT COUNT(*) FROM sales WHERE wallet_id IS NOT NULL").fetchone()[0]==0
    assert c.execute("SELECT COUNT(*) FROM cash_expenses").fetchone()[0]==1
    assert c.execute("SELECT COUNT(*) FROM cash_expenses WHERE wallet_id IS NOT NULL OR category_id IS NOT NULL").fetchone()[0]==0
    assert c.execute("SELECT COUNT(*) FROM cash_wallets").fetchone()[0]==4
    assert c.execute("SELECT COUNT(*) FROM cash_expense_categories").fetchone()[0]==7
    assert c.execute("SELECT COUNT(*) FROM cash_income_categories").fetchone()[0]==4
    assert c.execute("SELECT COUNT(*) FROM cash_other_income").fetchone()[0]==0
    assert c.execute("SELECT COUNT(*) FROM loyalty_ledger").fetchone()[0]==0
    assert c.execute("SELECT COUNT(*) FROM sales WHERE gross_amount<>0 OR points_earned<>0 OR points_redeemed<>0 OR loyalty_discount_amount<>0").fetchone()[0]==0
    assert c.execute("SELECT value FROM settings WHERE key='loyalty_enabled'").fetchone()[0]=='0'
    assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    print('runtime-schema-ok')
'''
        with tempfile.TemporaryDirectory() as td:
            env = os.environ.copy()
            env['LIDER_CRM_DB'] = str(Path(td) / 'runtime.sqlite3')
            env['LIDER_CRM_SECRET'] = 'test-secret-for-schema-only'
            env['CRM_SOURCE_DIR'] = str(ROOT)
            result = subprocess.run([sys.executable, '-c', script], env=env, text=True,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('runtime-schema-ok', result.stdout)

if __name__ == '__main__':
    unittest.main()
