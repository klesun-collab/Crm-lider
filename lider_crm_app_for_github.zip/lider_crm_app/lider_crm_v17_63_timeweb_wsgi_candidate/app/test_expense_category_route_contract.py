import ast
import unittest
from pathlib import Path
SOURCE=Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE=ast.parse(SOURCE)
def fn(name): return next(n for n in TREE.body if isinstance(n,ast.FunctionDef) and n.name==name)
class ExpenseCategoryRouteContractTests(unittest.TestCase):
    def test_category_management_is_manager_only_and_audited(self):
        route=fn('expense_categories_page')
        self.assertTrue(any('manager_required' in ast.unparse(d) for d in route.decorator_list))
        text=ast.get_source_segment(SOURCE,route)
        for action in ('cash.expense_category.created','cash.expense_category.updated','cash.expense_category.deactivated'):
            self.assertIn(action,text)
    def test_new_expenses_accept_only_active_category(self):
        route=ast.get_source_segment(SOURCE,fn('cash_add_expense'))
        self.assertIn('cash_expense_categories WHERE id=? AND active=1',route)
        self.assertIn('category_id',route)
    def test_legacy_expenses_are_not_backfilled(self):
        self.assertIn('category_id INTEGER REFERENCES cash_expense_categories',SOURCE)
        self.assertNotIn('UPDATE cash_expenses SET category_id',SOURCE)
    def test_cash_report_shows_category_totals(self):
        route=ast.get_source_segment(SOURCE,fn('cash_journal'))
        self.assertIn('Расходы по категориям',route)
        self.assertIn('expense_category_sums',route)
        self.assertIn('default_expense_category_id',route)
if __name__=='__main__': unittest.main()
