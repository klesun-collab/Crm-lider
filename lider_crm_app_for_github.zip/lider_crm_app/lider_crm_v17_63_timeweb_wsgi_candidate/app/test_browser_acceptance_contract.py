from pathlib import Path
import unittest

ROOT=Path(__file__).parent

class BrowserAcceptanceContractTests(unittest.TestCase):
    def test_browser_acceptance_covers_new_schedule_views_and_admin_pages(self):
        source=(ROOT/"acceptance_audit"/"browser_acceptance.py").read_text(encoding="utf-8")
        for path in ("/contact-log", "/resources", "/schedule?view=list", "/schedule?view=calendar", "/schedule?view=month"):
            self.assertIn(path, source)
        self.assertIn("select[name=\"room_id\"]", source)
        self.assertIn("select[name=\"lane_id\"]", source)

if __name__=="__main__":
    unittest.main()
