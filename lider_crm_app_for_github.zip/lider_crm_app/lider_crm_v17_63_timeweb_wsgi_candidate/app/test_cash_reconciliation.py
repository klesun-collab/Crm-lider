"""Regression tests for cash-shift discrepancy diagnostics."""
import sqlite3
import unittest
from pathlib import Path

ROOT = Path(__file__).parent
SOURCE = (ROOT / "app.py").read_text(encoding="utf-8")
QUERY = """SELECT id,shift_date,expected_cash,actual_cash,cash_difference,
expected_noncash,actual_noncash,noncash_difference,note
FROM cash_shifts
WHERE status='closed' AND (cash_difference!=0 OR noncash_difference!=0)
ORDER BY shift_date DESC,id DESC LIMIT 100"""

class CashReconciliationTests(unittest.TestCase):
    def test_reconciliation_displays_shift_discrepancies(self):
        start = SOURCE.index('def reconciliation():')
        end = SOURCE.index('@app.get("/payroll")', start)
        section = SOURCE[start:end]
        self.assertIn('bad_cash_shifts=c.execute', section)
        self.assertIn('Закрытые смены с расхождениями', section)
        self.assertIn('cash_difference!=0 OR noncash_difference!=0', section)
        self.assertIn('Смен с ненулевой разницей не найдено', section)

    def test_only_closed_shifts_with_difference_are_listed(self):
        db = sqlite3.connect(':memory:')
        db.execute('''CREATE TABLE cash_shifts(
            id INTEGER, shift_date TEXT, expected_cash INTEGER, actual_cash INTEGER,
            cash_difference INTEGER, expected_noncash INTEGER, actual_noncash INTEGER,
            noncash_difference INTEGER, note TEXT, status TEXT)''')
        db.executemany('INSERT INTO cash_shifts VALUES(?,?,?,?,?,?,?,?,?,?)', [
            (1,'2026-10-10',1000,900,-100,2000,2000,0,'Недостача','closed'),
            (2,'2026-10-11',1000,1000,0,2000,1900,-100,'Безнал','closed'),
            (3,'2026-10-12',1000,1000,0,2000,2000,0,'Совпало','closed'),
            (4,'2026-10-13',1000,900,-100,2000,2000,0,'Не закрыта','open'),
        ])
        rows = db.execute(QUERY).fetchall()
        self.assertEqual([r[0] for r in rows], [2, 1])
        db.close()

if __name__ == '__main__':
    unittest.main()
