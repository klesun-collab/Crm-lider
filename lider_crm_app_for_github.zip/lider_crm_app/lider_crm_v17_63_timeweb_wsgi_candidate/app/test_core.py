"""Dependency-free smoke tests for CRM schema and SQLite backup behavior.
Run: python test_core.py
These tests do not replace Flask/browser integration tests.
"""
import ast, pathlib, sqlite3, tempfile, os, unittest

APP = pathlib.Path(__file__).with_name('app.py')
SOURCE = APP.read_text(encoding='utf-8')

class CoreSmokeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        tree = ast.parse(SOURCE)
        init_fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'init_db')
        sql = None
        for n in ast.walk(init_fn):
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'executescript':
                if n.args and isinstance(n.args[0], ast.Constant) and isinstance(n.args[0].value, str):
                    sql = n.args[0].value
                    break
        if sql is None:
            raise RuntimeError('Could not locate schema SQL in init_db')
        cls.db = sqlite3.connect(':memory:')
        cls.db.execute('PRAGMA foreign_keys=ON')
        cls.db.executescript(sql)

    @classmethod
    def tearDownClass(cls):
        cls.db.close()

    def test_expected_tables_exist(self):
        names = {r[0] for r in self.db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        expected = {'users','clients','subscriptions','attendance','sales','cash_expenses','cash_shifts','products','stock_movements','leads','tasks','audit_log','schedule_slots','bookings'}
        self.assertTrue(expected.issubset(names), f'Missing tables: {expected-names}')
        trainer_cols={r[1] for r in self.db.execute("PRAGMA table_info(trainers)")}
        self.assertIn('payroll_rate', trainer_cols)
        attendance_cols={r[1] for r in self.db.execute("PRAGMA table_info(attendance)")}
        self.assertIn('schedule_slot_id', attendance_cols)

    def test_foreign_keys_are_enforced(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute("INSERT INTO subscriptions(client_id,title,total_lessons,remaining_lessons,price,purchased_at) VALUES(999,'test',4,4,100,'2026-01-01')")

    def test_sqlite_backup_round_trip(self):
        self.db.execute("INSERT INTO clients(child_name,parent_name,phone,created_at) VALUES('Тестовый ребёнок','Тестовый родитель','000','2026-01-01')")
        self.db.commit()
        fd, path = tempfile.mkstemp(suffix='.sqlite3'); os.close(fd)
        try:
            from backup_utils import create_verified_sqlite_snapshot
            # Use the same verified snapshot helper as the production backup route.
            source_path = os.path.join(tempfile.gettempdir(), 'lider_crm_test_source.sqlite3')
            try:
                with sqlite3.connect(source_path) as source_copy:
                    self.db.backup(source_copy)
                create_verified_sqlite_snapshot(source_path, path)
            finally:
                if os.path.exists(source_path): os.remove(source_path)
            with sqlite3.connect(path) as restored:
                count = restored.execute("SELECT COUNT(*) FROM clients WHERE phone='000'").fetchone()[0]
                self.assertEqual(count, 1)
                self.assertTrue(restored.execute("SELECT 1 FROM sqlite_master WHERE name='leads'").fetchone())
        finally:
            os.remove(path)

    def test_html_form_renderer_has_regex_dependency(self):
        self.assertRegex(SOURCE, r'import sqlite3, os, json, secrets, re')
        self.assertIn('body = re.sub(', SOURCE)

    def test_subscription_price_rejects_zero_before_sale_insert(self):
        self.assertIn('if total<1 or total>1000 or price<1 or price>100_000_000 or not title or len(title)>100:', SOURCE)
        self.assertIn('name="price" min="1" required', SOURCE)

    def test_schedule_booking_requires_valid_subscription(self):
        self.assertIn('if not sub_id: abort(400,"Для записи из расписания выберите абонемент.', SOURCE)
        self.assertIn('name="subscription_id" required', SOURCE)

    def test_booking_reuses_cancelled_booking_instead_of_duplicate_insert(self):
        self.assertIn('if existing and existing["status"]=="cancelled":', SOURCE)
        self.assertIn("UPDATE bookings SET status='booked',subscription_id=?,created_by=?,created_at=? WHERE id=? AND status='cancelled'", SOURCE)
        self.assertIn('booking.rebooked', SOURCE)

    def test_booking_form_offers_only_slots_with_free_capacity(self):
        self.assertIn('available_slots=[sl for sl in slots if sl["trainer_active"] and sl["booked"] < sl["capacity"]]', SOURCE)
        self.assertIn('Нет свободных мест на выбранную дату', SOURCE)
        self.assertIn('{slot_opts}', SOURCE)

    def test_cancel_booking_returns_to_original_schedule_date(self):
        block=SOURCE.split('def booking_cancel(booking_id):',1)[1].split('@app.route("/attendance"',1)[0]
        self.assertIn('SELECT slot_date,slot_time FROM schedule_slots', block)
        self.assertIn('url_for("schedule",day=slot["slot_date"] if slot else today())', block)

    def test_schedule_has_weekly_overview_and_navigation(self):
        self.assertIn('Неделя:', SOURCE)
        self.assertIn('Предыдущая неделя', SOURCE)
        self.assertIn('Следующая неделя', SOURCE)
        self.assertIn('GROUP BY sl.slot_date', SOURCE)

    def test_weekly_overview_counts_bookings_and_capacity(self):
        self.assertIn('SUM(sl.capacity) total_capacity', SOURCE)
        self.assertIn("status='booked')) booked_count", SOURCE)
        self.assertIn("href='/schedule?day={iso}'", SOURCE)

    def test_trainer_name_can_be_typed_into_schedule(self):
        self.assertIn('name="trainer_name" list="trainer_names" required maxlength="100"', SOURCE)
        self.assertIn('SELECT id FROM trainers WHERE name=? COLLATE NOCASE AND active=1', SOURCE)
        self.assertIn('created_from_schedule', SOURCE)
        self.assertNotIn('name="trainer_id" required', SOURCE)

    def test_trainer_rate_is_free_numeric_input_not_fixed_choices(self):
        self.assertIn('name="payroll_rate" min="0" step="1" value="400" required', SOURCE)
        self.assertIn('placeholder="Введите свою ставку"', SOURCE)
        self.assertNotIn('<select name="payroll_rate">', SOURCE)

    def test_trainer_management_allows_manual_rate_updates(self):
        self.assertIn('@app.route("/trainers", methods=["GET", "POST"])', SOURCE)
        self.assertIn('UPDATE trainers SET name=?, payroll_rate=? WHERE id=?', SOURCE)
        self.assertIn('Ставка применяется к новым начислениям', SOURCE)
        self.assertIn('<a href="/trainers">Тренеры</a>', SOURCE)

    def test_schedule_uses_trainer_payroll_rate_not_group_retail_price(self):
        self.assertIn('payroll_rate INTEGER NOT NULL DEFAULT 400 CHECK(payroll_rate>=0)', SOURCE)
        self.assertIn('SELECT t.name,t.payroll_rate FROM schedule_slots sl', (APP.parent / 'booking_attendance.py').read_text(encoding='utf-8'))
        helper = (APP.parent / 'booking_attendance.py').read_text(encoding='utf-8')
        self.assertIn('rate = int(trainer["payroll_rate"]) if trainer and trainer["payroll_rate"] is not None else 400', helper)
        self.assertIn('ALTER TABLE trainers ADD COLUMN payroll_rate INTEGER NOT NULL DEFAULT 400', SOURCE)

    def test_leads_can_be_converted_to_clients_and_linked(self):
        self.assertIn("if action==\"convert\":", SOURCE)
        self.assertIn("UPDATE leads SET status='converted',client_id=?,updated_at=? WHERE id=?", SOURCE)
        self.assertIn("SELECT id FROM clients WHERE phone=? ORDER BY id LIMIT 1", SOURCE)

    def test_tasks_can_link_to_client_or_lead(self):
        self.assertIn("INSERT INTO tasks(title,client_id,lead_id,due_at,notes,assigned_to,created_by,created_at)", SOURCE)
        self.assertIn("Свяжите задачу либо с клиентом, либо с заявкой", SOURCE)
        self.assertIn("ПРОСРОЧЕНО", SOURCE)

    def test_lead_client_link_is_in_schema_and_migration(self):
        leads_cols={r[1] for r in self.db.execute("PRAGMA table_info(leads)")}
        self.assertIn('client_id', leads_cols)
        self.assertIn('ALTER TABLE leads ADD COLUMN client_id INTEGER REFERENCES clients(id)', SOURCE)


    def test_sales_can_link_to_subscription(self):
        cols={r[1] for r in self.db.execute("PRAGMA table_info(sales)")}
        self.assertIn('subscription_id', cols)
        self.assertIn('subscription_id INTEGER REFERENCES subscriptions(id)', SOURCE)
        self.assertIn('if sale_type=="subscription":', SOURCE)
        self.assertIn('c.execute("UPDATE sales SET subscription_id=? WHERE id=?",(subscription_id,cur.lastrowid))', SOURCE)

    def test_attendance_decrement_is_conditional_and_client_scoped(self):
        self.assertIn("WHERE id=? AND client_id=? AND status='active' AND remaining_lessons>0", SOURCE)
        self.assertIn("if changed.rowcount != 1:", SOURCE)
        self.assertIn("абонемент не принадлежит этому ребёнку", SOURCE)

    def test_attendance_status_transition_is_conditional(self):
        self.assertIn("UPDATE attendance SET status=? WHERE id=? AND status='planned'", SOURCE)
        self.assertIn("Занятие уже обработано", SOURCE)

    def test_subscription_refund_requires_unused_subscription(self):
        self.assertIn('sub["remaining_lessons"]!=sub["total_lessons"]', SOURCE)
        self.assertIn("UPDATE subscriptions SET status='cancelled' WHERE id=?", SOURCE)
        self.assertIn('автоматический полный возврат запрещён', SOURCE)

    def test_payroll_groups_simultaneous_group_children_into_one_trainer_session(self):
        helper = (APP.parent / 'payroll_calculation.py').read_text(encoding='utf-8')
        self.assertIn('from payroll_calculation import get_payroll_sessions', SOURCE)
        self.assertIn("MAX(a.rate_snapshot) rate_snapshot", helper)
        self.assertIn('GROUP BY a.schedule_slot_id, a.lesson_date, a.lesson_time', helper)
        self.assertIn('COUNT(DISTINCT a.client_id) children_count', helper)
        self.assertIn('ALTER TABLE attendance ADD COLUMN schedule_slot_id INTEGER REFERENCES schedule_slots(id)', SOURCE)
        self.assertIn('schedule_slot_id,created_by,created_at)', (APP.parent / 'booking_attendance.py').read_text(encoding='utf-8'))
        self.assertIn("Начисление за тренировку, ₽", SOURCE)

    def test_trainer_roster_is_admin_managed_but_rates_are_manager_only(self):
        self.assertIn('if action == "create":', SOURCE)
        self.assertIn('if action == "toggle":', SOURCE)
        self.assertIn('Ставку тренера может задавать только руководитель', SOURCE)
        self.assertIn('UPDATE trainers SET active=? WHERE id=?', SOURCE)
        self.assertIn('История сохранена', SOURCE)

    def test_financial_and_stock_routes_are_manager_protected(self):
        for route in ('/cash/close-shift', '/cash/opening', '/cash.csv', '/products', '/products/<int:pid>/receive', '/products/<int:pid>/writeoff', '/settings/rates', '/backup/sqlite'):
            segment = SOURCE.split(f'@app.get("{route}")', 1)[-1] if f'@app.get("{route}")' in SOURCE else SOURCE.split(f'@app.post("{route}")', 1)[-1] if f'@app.post("{route}")' in SOURCE else SOURCE.split(f'@app.route("{route}"', 1)[-1]
            self.assertIn('@manager_required', segment[:160], f'{route} should require manager role')


    def test_manager_permission_uses_database_role_not_stale_session(self):
        block = SOURCE.split('def manager_required(fn):', 1)[1].split('def esc(', 1)[0]
        self.assertIn('u=current_user()', block)
        self.assertIn('u["role"]!="manager"', block)
        self.assertNotIn('if session.get("role")!="manager":', block)

    def test_full_backup_checks_sqlite_integrity_before_download(self):
        self.assertIn('create_verified_sqlite_snapshot(DB_PATH, path)', SOURCE)
        with open(os.path.join(os.path.dirname(__file__), 'backup_utils.py'), encoding='utf-8') as helper_file:
            helper = helper_file.read()
        self.assertIn('source.backup(target)', helper)
        self.assertIn('PRAGMA integrity_check', helper)
        self.assertIn('integrity != "ok"', helper)
        self.assertIn('PRAGMA foreign_key_check', helper)
        self.assertIn('response.headers["Cache-Control"] = "no-store"', SOURCE)

    def test_sqlite_backup_preserves_rows_and_passes_integrity_check(self):
        fd, path = tempfile.mkstemp(suffix='.sqlite3'); os.close(fd)
        try:
            self.db.execute("INSERT INTO clients(child_name,parent_name,phone,created_at) VALUES('Ребёнок Б','Родитель Б','001','2026-02-01')")
            self.db.commit()
            from backup_utils import create_verified_sqlite_snapshot
            # Use the same verified snapshot helper as the production backup route.
            source_path = os.path.join(tempfile.gettempdir(), 'lider_crm_test_source.sqlite3')
            try:
                with sqlite3.connect(source_path) as source_copy:
                    self.db.backup(source_copy)
                create_verified_sqlite_snapshot(source_path, path)
            finally:
                if os.path.exists(source_path): os.remove(source_path)
            with sqlite3.connect(path) as restored:
                self.assertEqual(restored.execute('PRAGMA integrity_check').fetchone()[0], 'ok')
                self.assertEqual(restored.execute("SELECT COUNT(*) FROM clients WHERE phone='001'").fetchone()[0], 1)
        finally:
            os.remove(path)


    def test_refund_approval_uses_database_role_not_session_role(self):
        block = SOURCE.split('def refunds():', 1)[1].split('@app.get("/settings")', 1)[0]
        self.assertIn('SELECT role,active FROM users WHERE id=?', block)
        self.assertIn('is_manager = actor["role"] == "manager"', block)
        self.assertIn('if not is_manager: abort(403,"Только руководитель может подтверждать возвраты")', block)
        self.assertNotIn('if session.get("role")!="manager": abort(403,"Только руководитель может подтверждать возвраты")', block)

    def test_refund_request_does_not_modify_sale_until_manager_approval(self):
        block = SOURCE.split('def refunds():', 1)[1].split('@app.get("/settings")', 1)[0]
        request_block = block.split('if action=="request":', 1)[1].split('elif action=="approve":', 1)[0]
        self.assertIn('INSERT INTO refund_requests', request_block)
        self.assertNotIn('UPDATE sales', request_block)
        self.assertNotIn('UPDATE subscriptions', request_block)

    def test_sensitive_role_checks_use_current_database_user(self):
        self.assertIn('def is_current_manager():', SOURCE)
        self.assertIn('u=current_user()', SOURCE.split('def is_current_manager():',1)[1].split('def login_required',1)[0])
        self.assertNotIn('if session.get("role") != "manager": abort(403)', SOURCE)

    def test_manual_attendance_uses_manager_controlled_trainer_rate(self):
        block=SOURCE.split('def attendance():',1)[1].split('@app.post("/attendance/<int:aid>/<status>")',1)[0]
        self.assertIn('date.fromisoformat(lesson_date)', block)
        self.assertIn('datetime.strptime(lesson_time,"%H:%M")', block)
        self.assertIn('SELECT name,payroll_rate FROM trainers WHERE name=? COLLATE NOCASE AND active=1', block)
        self.assertIn('rate=int(trainer["payroll_rate"])', block)
        self.assertNotIn('request.form.get("rate"', block)
        self.assertIn('Выберите действующего тренера из справочника', block)

    def test_restoration_payment_method_is_allowlisted(self):
        block=SOURCE.split('def restore_missed_lesson(attendance_id):',1)[1].split('@app.route("/trainers"',1)[0]
        self.assertIn('payment_method not in ("cash","card","transfer","qr")', block)
        self.assertIn('fee=0 if medical else 500', block)


    def test_attended_and_missed_both_use_same_lesson_deduction_path(self):
        block=SOURCE.split('def attendance_status(aid,status):',1)[1].split('@app.route("/sales"',1)[0]
        self.assertIn('if status not in ("attended","missed")', block)
        self.assertIn('UPDATE subscriptions SET remaining_lessons=remaining_lessons-1', block)
        self.assertIn("UPDATE attendance SET status=? WHERE id=? AND status=\'planned\'", block)
        self.assertNotIn('if status=="attended":', block)

    def test_restore_missed_lesson_increments_only_after_unique_restoration_check(self):
        block=SOURCE.split('def restore_missed_lesson(attendance_id):',1)[1].split('@app.route("/trainers"',1)[0]
        self.assertLess(block.index('SELECT id FROM attendance_restorations'), block.index('remaining_lessons=remaining_lessons+1'))
        self.assertIn('attendance_id INTEGER NOT NULL UNIQUE', SOURCE)

    def test_read_only_reconciliation_report_checks_stock_and_links(self):
        self.assertIn('@app.get("/reconciliation")', SOURCE)
        block=SOURCE.split('def reconciliation():',1)[1].split('@app.get("/payroll")',1)[0]
        self.assertIn('@manager_required', SOURCE.split('@app.get("/reconciliation")',1)[1].split('def reconciliation():',1)[0])
        self.assertIn('LEFT JOIN stock_movements', block)
        self.assertIn("WHEN m.movement_type='purchase' THEN m.quantity", block)
        self.assertIn("WHEN m.movement_type='sale' THEN -m.quantity", block)
        self.assertIn("refund_requests WHERE status='pending'", block)
        self.assertIn('bad_subscriptions=c.execute', block)
        self.assertIn("s.status='active' AND s.remaining_lessons=0", block)
        self.assertIn('Остатки абонементов', block)
        self.assertNotIn('UPDATE products', block)
        self.assertNotIn('UPDATE sales', block)

    def test_client_profile_has_financial_attendance_and_freeze_summary(self):
        block=SOURCE.split('def client_profile(client_id):',1)[1].split('@app.route("/subscriptions"',1)[0]
        self.assertIn('AS net_paid', block)
        self.assertIn('attendance_counts', block)
        self.assertIn('FROM subscription_freezes f JOIN subscriptions s', block)
        self.assertIn('История заморозок', block)
        self.assertIn('Чистые оплаты', block)

    def test_csrf_form_injection_logic_patterns_present(self):
        self.assertIn('def protect_post_requests', SOURCE)
        self.assertIn('secrets.compare_digest', SOURCE)
        self.assertIn('body = re.sub(', SOURCE)
        self.assertIn('name=\"_csrf\"', SOURCE)

if __name__ == '__main__':
    unittest.main(verbosity=2)

    def test_future_slot_edit_requires_future_date_and_no_booking_history(self):
        self.assertIn('elif action=="edit_slot":', SOURCE)
        self.assertIn('if slot["slot_date"]<=today(): abort(400,"Можно менять только занятия с будущей датой")', SOURCE)
        self.assertIn('SELECT 1 FROM bookings WHERE slot_id=? LIMIT 1', SOURCE)
        self.assertIn('SELECT 1 FROM attendance WHERE schedule_slot_id=? LIMIT 1', SOURCE)

    def test_future_slot_edit_is_audited_and_handles_duplicate_time(self):
        self.assertIn('schedule_slot.updated', SOURCE)
        self.assertIn('У этого тренера уже есть слот на выбранные дату и время', SOURCE)
        self.assertIn('Изменить будущий слот', SOURCE)


class InventoryWriteoffGuardTests(unittest.TestCase):
    def test_writeoff_rechecks_stock_in_conditional_update(self):
        block = SOURCE.split('def product_writeoff(pid):', 1)[1].split('@app.get("/reconciliation")', 1)[0]
        self.assertIn('UPDATE products SET stock=stock-? WHERE id=? AND stock>=?', block)
        self.assertIn('if changed.rowcount != 1:', block)
        self.assertIn('Остаток изменился', block)
