import ast
import unittest
from pathlib import Path
SOURCE = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE = ast.parse(SOURCE)
def fn(name):
    return ast.get_source_segment(SOURCE, next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name))
class MarketingCampaignTests(unittest.TestCase):
    def test_campaigns_have_lifecycle_and_metrics(self):
        route=fn('marketing_campaigns')
        self.assertIn('marketing_campaigns', SOURCE)
        self.assertIn("status IN ('draft','active','completed','cancelled')", SOURCE)
        self.assertIn('COUNT(*) FROM client_outreach o WHERE o.campaign_id=m.id', route)
        self.assertIn("o.outcome='returned'", route)
    def test_outreach_can_be_attributed_to_open_campaign_only(self):
        route=fn('client_reactivation')
        self.assertIn("status IN ('draft','active')", route)
        self.assertIn('campaign_id', route)
        self.assertIn('INSERT INTO client_outreach', route)
    def test_campaign_table_in_backup(self):
        route=fn('backup_export')
        self.assertIn('exportable_table_names(c)', route)
        self.assertIn('CREATE TABLE IF NOT EXISTS marketing_campaigns', SOURCE)
    def test_campaign_creation_validates_name_and_segment(self):
        route=fn('marketing_campaigns')
        self.assertIn('if not name: abort(400', route)
        self.assertIn('if segment not in segments: abort(400', route)
if __name__ == '__main__': unittest.main()
