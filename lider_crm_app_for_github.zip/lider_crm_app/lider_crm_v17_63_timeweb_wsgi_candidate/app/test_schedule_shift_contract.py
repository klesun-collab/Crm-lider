from pathlib import Path
import unittest

SOURCE = Path(__file__).with_name('app.py').read_text(encoding='utf-8')


class ScheduleShiftContractTests(unittest.TestCase):
    def test_shift_generation_uses_selected_weekdays_and_time_range(self):
        self.assertIn('shift_start_times(request.form.get("repeat_start_time"', SOURCE)
        self.assertIn('request.form.get("repeat_end_time"', SOURCE)
        self.assertIn('requested=len(dates)*len(slot_times)', SOURCE)
        self.assertIn('"times":slot_times', SOURCE)

    def test_free_future_slot_can_be_deleted_but_history_is_protected(self):
        self.assertIn('elif action=="delete_slot":', SOURCE)
        self.assertIn('Нельзя удалить слот с историей записей', SOURCE)
        self.assertIn('Нельзя удалить слот, связанный с посещением', SOURCE)
        self.assertIn('DELETE FROM schedule_slots WHERE id=?', SOURCE)

    def test_admin_schedule_does_not_grant_payroll_rate_access(self):
        self.assertIn('if not is_current_manager() and supplied_rate:', SOURCE)
        self.assertIn('Менять ставки тренеров может только руководитель', SOURCE)

    def test_inactive_trainer_slots_cannot_be_booked(self):
        self.assertIn('if not slot["trainer_active"]:', SOURCE)
        self.assertIn('available_slots=[sl for sl in slots if sl["trainer_active"]', SOURCE)


if __name__ == '__main__':
    unittest.main()
