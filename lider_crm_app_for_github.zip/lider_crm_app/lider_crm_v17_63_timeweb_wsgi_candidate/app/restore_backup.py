#!/usr/bin/env python3
"""Safely restore a verified CRM SQLite backup to a NEW database path.

The destination must not already exist. This intentionally avoids silently
replacing a live database; stop the CRM and choose a separate path for testing.
"""
from __future__ import annotations

import argparse
import os
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path
from contextlib import closing

from backup_database import _write_manifest, verify_backup_manifest


def _verify_sqlite(path: Path) -> None:
    with closing(sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=10)) as db:
        integrity = db.execute("PRAGMA integrity_check").fetchone()
        if not integrity or integrity[0] != "ok":
            raise RuntimeError("Восстановленная база не прошла integrity_check")
        violations = db.execute("PRAGMA foreign_key_check").fetchall()
        if violations:
            raise RuntimeError(f"В восстановленной базе нарушены внешние ключи: {len(violations)}")


def restore_backup(backup: Path, destination: Path) -> Path:
    backup = backup.expanduser().resolve()
    destination = destination.expanduser().resolve()
    if backup == destination:
        raise ValueError("Путь назначения совпадает с файлом резервной копии")
    if destination.exists():
        raise FileExistsError(f"Файл назначения уже существует; он не будет перезаписан: {destination}")
    if not destination.parent.is_dir():
        raise FileNotFoundError(f"Каталог назначения не существует: {destination.parent}")

    # Verify the source digest and structure before copying any bytes.
    source_manifest = verify_backup_manifest(backup)
    fd, temp_name = tempfile.mkstemp(prefix=".lider_restore_partial_", suffix=".sqlite3", dir=destination.parent)
    temp_path = Path(temp_name)
    reserved_destination = False
    try:
        with os.fdopen(fd, "wb") as target, backup.open("rb") as source:
            shutil.copyfileobj(source, target, length=1024 * 1024)
            target.flush()
            os.fsync(target.fileno())
        try:
            temp_path.chmod(0o600)
        except OSError:
            pass
        if temp_path.stat().st_size != source_manifest["size_bytes"]:
            raise RuntimeError("Размер копии после переноса не совпадает с исходным")
        _verify_sqlite(temp_path)

        # O_EXCL reserves the destination without clobbering a file created by
        # another process between the earlier existence check and publication.
        reserve_fd = os.open(str(destination), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(reserve_fd)
        reserved_destination = True
        os.replace(temp_path, destination)
        reserved_destination = False
        try:
            _write_manifest(destination)
            # Final verification confirms the published file and its new manifest.
            verify_backup_manifest(destination)
        except Exception:
            destination.unlink(missing_ok=True)
            destination.with_name(destination.name + ".manifest.json").unlink(missing_ok=True)
            raise
        return destination
    except Exception:
        if reserved_destination:
            destination.unlink(missing_ok=True)
        raise
    finally:
        temp_path.unlink(missing_ok=True)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--backup", required=True, help="путь к проверенной копии с .manifest.json")
    parser.add_argument("--destination", required=True, help="новый путь для восстановленной SQLite-базы")
    args = parser.parse_args(argv)
    try:
        path = restore_backup(Path(args.backup), Path(args.destination))
    except (OSError, ValueError, RuntimeError, sqlite3.Error) as exc:
        print(f"Ошибка восстановления: {exc}", file=sys.stderr)
        return 1
    print(f"Восстановленная база проверена: {path}")
    print(f"Манифест SHA-256: {path.with_name(path.name + '.manifest.json')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
