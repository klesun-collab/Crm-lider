import sqlite3
import unittest
from subscription_integrity_audit import FIELDS, build_subscription_integrity_audit


class SubscriptionIntegrityAuditTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
        CREATE TABLE clients(id INTEGER PRIMARY KEY, child_name TEXT, phone TEXT, status TEXT);
        CREATE TABLE subscriptions(id INTEGER PRIMARY KEY, client_id INTEGER, title TEXT, total_lessons INTEGER,
          remaining_lessons INTEGER, price INTEGER, purchased_at TEXT, expires_at TEXT, status TEXT);
        CREATE TABLE sales(id INTEGER PRIMARY KEY, client_id INTEGER, subscription_id INTEGER, status TEXT);
        CREATE TABLE attendance(id INTEGER PRIMARY KEY, client_id INTEGER, subscription_id INTEGER, lesson_date TEXT, status TEXT);
        INSERT INTO clients VALUES(1,'Аня','+79990000001','active');
        INSERT INTO clients VALUES(2,'Борис','+79990000002','active');
        INSERT INTO subscriptions VALUES(1,1,'8 занятий',8,5,8000,'2026-01-01','2027-01-01','active');
        INSERT INTO sales VALUES(1,1,1,'completed');
        INSERT INTO attendance VALUES(1,1,1,'2026-10-18','planned');
        ''')

    def tearDown(self):
        self.db.close()

    def issues(self, issue):
        return [x for x in build_subscription_integrity_audit(self.db, '2026-10-17') if x['issue_type'] == issue]

    def test_clean_data_has_no_findings(self):
        self.assertEqual(build_subscription_integrity_audit(self.db, '2026-10-17'), [])

    def test_invalid_date_is_rejected(self):
        with self.assertRaises(ValueError): build_subscription_integrity_audit(self.db, 'tomorrow')

    def test_limit_minimum(self):
        self.assertLessEqual(len(build_subscription_integrity_audit(self.db, '2026-10-17', 0)), 1)

    def test_limit_invalid_falls_back(self):
        self.assertEqual(build_subscription_integrity_audit(self.db, '2026-10-17', 'bad'), [])

    def test_limit_is_capped(self):
        self.assertLessEqual(len(build_subscription_integrity_audit(self.db, '2026-10-17', 100000)), 10000)

    def test_unknown_subscription_status(self):
        self.db.execute("UPDATE subscriptions SET status='weird' WHERE id=1")
        self.assertEqual(self.issues('unknown_subscription_status')[0]['record_id'], 1)

    def test_invalid_total(self):
        self.db.execute('UPDATE subscriptions SET total_lessons=0 WHERE id=1')
        self.assertEqual(len(self.issues('invalid_total_lessons')), 1)

    def test_invalid_remaining_negative(self):
        self.db.execute('UPDATE subscriptions SET remaining_lessons=-1 WHERE id=1')
        self.assertEqual(len(self.issues('invalid_remaining_lessons')), 1)

    def test_remaining_greater_than_total(self):
        self.db.execute('UPDATE subscriptions SET remaining_lessons=9 WHERE id=1')
        self.assertEqual(len(self.issues('remaining_exceeds_total')), 1)

    def test_active_zero_remaining(self):
        self.db.execute('UPDATE subscriptions SET remaining_lessons=0 WHERE id=1')
        self.assertEqual(len(self.issues('active_without_lessons')), 1)

    def test_completed_positive_remaining(self):
        self.db.execute("UPDATE subscriptions SET status='completed' WHERE id=1")
        self.assertEqual(len(self.issues('completed_with_remaining')), 1)

    def test_bad_purchase_date(self):
        self.db.execute("UPDATE subscriptions SET purchased_at='31.12.2025' WHERE id=1")
        self.assertEqual(len(self.issues('invalid_purchase_date')), 1)

    def test_future_purchase_date(self):
        self.db.execute("UPDATE subscriptions SET purchased_at='2027-01-01' WHERE id=1")
        self.assertEqual(len(self.issues('future_purchase_date')), 1)

    def test_bad_expiry_date(self):
        self.db.execute("UPDATE subscriptions SET expires_at='never' WHERE id=1")
        self.assertEqual(len(self.issues('invalid_expiry_date')), 1)

    def test_expired_active_subscription(self):
        self.db.execute("UPDATE subscriptions SET expires_at='2026-01-01' WHERE id=1")
        self.assertEqual(len(self.issues('expired_but_active')), 1)

    def test_future_expiry_is_not_flagged(self):
        self.assertEqual(self.issues('expired_but_active'), [])

    def test_unlimited_expiry_is_not_flagged(self):
        self.db.execute("UPDATE subscriptions SET expires_at='' WHERE id=1")
        self.assertEqual(self.issues('expired_but_active'), [])

    def test_subscription_without_sale_is_low_priority_hint(self):
        self.db.execute("INSERT INTO subscriptions VALUES(2,1,'Старый',4,2,3000,'2025-01-01','','active')")
        row = [x for x in self.issues('subscription_without_linked_sale') if x['record_id'] == 2][0]
        self.assertEqual(row['severity'], 'low')

    def test_sale_client_mismatch(self):
        self.db.execute('INSERT INTO sales VALUES(2,2,1,\'completed\')')
        self.assertEqual(len(self.issues('sale_subscription_client_mismatch')), 1)

    def test_sale_missing_subscription(self):
        self.db.execute('INSERT INTO sales VALUES(2,1,999,\'completed\')')
        self.assertEqual(len(self.issues('sale_missing_subscription')), 1)

    def test_duplicate_completed_sales(self):
        self.db.execute('INSERT INTO sales VALUES(2,1,1,\'completed\')')
        self.assertEqual(len(self.issues('multiple_completed_sales')), 1)

    def test_noncompleted_duplicate_sales_not_flagged(self):
        self.db.execute('INSERT INTO sales VALUES(2,1,1,\'refund\')')
        self.assertEqual(self.issues('multiple_completed_sales'), [])

    def test_attendance_client_mismatch(self):
        self.db.execute("INSERT INTO attendance VALUES(2,2,1,'2026-10-18','attended')")
        self.assertEqual(len(self.issues('attendance_subscription_client_mismatch')), 1)

    def test_attendance_missing_subscription(self):
        self.db.execute("INSERT INTO attendance VALUES(2,1,999,'2026-10-18','attended')")
        self.assertEqual(len(self.issues('attendance_missing_subscription')), 1)

    def test_unknown_attendance_status(self):
        self.db.execute("UPDATE attendance SET status='maybe' WHERE id=1")
        self.assertEqual(len(self.issues('unknown_attendance_status')), 1)

    def test_invalid_attendance_date(self):
        self.db.execute("UPDATE attendance SET lesson_date='yesterday' WHERE id=1")
        self.assertEqual(len(self.issues('invalid_attendance_date')), 1)

    def test_past_planned_attendance(self):
        self.db.execute("UPDATE attendance SET lesson_date='2026-10-01' WHERE id=1")
        self.assertEqual(len(self.issues('past_planned_attendance')), 1)

    def test_future_planned_attendance_is_not_flagged(self):
        self.assertEqual(self.issues('past_planned_attendance'), [])

    def test_cancelled_subscription_with_attendance(self):
        self.db.execute("UPDATE subscriptions SET status='cancelled' WHERE id=1")
        self.db.execute("UPDATE attendance SET status='attended' WHERE id=1")
        self.assertEqual(len(self.issues('attendance_on_cancelled_subscription')), 1)

    def test_cancelled_subscription_with_planned_booking_not_flagged_as_attended(self):
        self.db.execute("UPDATE subscriptions SET status='cancelled' WHERE id=1")
        self.assertEqual(self.issues('attendance_on_cancelled_subscription'), [])

    def test_audit_is_read_only(self):
        before = [self.db.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0] for t in ('clients','subscriptions','sales','attendance')]
        build_subscription_integrity_audit(self.db, '2026-10-17')
        after = [self.db.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0] for t in ('clients','subscriptions','sales','attendance')]
        self.assertEqual(before, after)

    def test_output_has_stable_fields(self):
        self.db.execute('UPDATE subscriptions SET remaining_lessons=10 WHERE id=1')
        rows = build_subscription_integrity_audit(self.db, '2026-10-17')
        self.assertEqual(tuple(rows[0].keys()), FIELDS)

    def test_high_priority_findings_sort_first(self):
        self.db.execute('UPDATE subscriptions SET remaining_lessons=10 WHERE id=1')
        rows = build_subscription_integrity_audit(self.db, '2026-10-17')
        ranks = {'high': 0, 'medium': 1, 'low': 2}
        self.assertEqual([r['severity'] for r in rows], sorted([r['severity'] for r in rows], key=ranks.get))

    def test_client_contact_fields_are_carried_through(self):
        self.db.execute('UPDATE subscriptions SET remaining_lessons=10 WHERE id=1')
        row = self.issues('remaining_exceeds_total')[0]
        self.assertEqual(row['child_name'], 'Аня')
        self.assertEqual(row['phone'], '+79990000001')

    def test_orphan_subscription_is_reported(self):
        self.db.execute("INSERT INTO subscriptions VALUES(2,999,'Legacy',4,2,3000,'2025-01-01','','active')")
        self.assertEqual(len(self.issues('subscription_missing_client')), 1)

    def test_blank_expiry_is_supported(self):
        self.db.execute("UPDATE subscriptions SET expires_at=NULL WHERE id=1")
        self.assertEqual(self.issues('invalid_expiry_date'), [])

    def test_blank_purchase_date_is_not_silently_flagged_as_invalid(self):
        self.db.execute("UPDATE subscriptions SET purchased_at='' WHERE id=1")
        self.assertEqual(self.issues('invalid_purchase_date'), [])

    def test_issue_details_are_nonempty(self):
        self.db.execute('UPDATE subscriptions SET remaining_lessons=10 WHERE id=1')
        self.assertTrue(all(x['details'].strip() for x in build_subscription_integrity_audit(self.db, '2026-10-17')))

    def test_known_severity_levels_only(self):
        self.db.execute('UPDATE subscriptions SET remaining_lessons=10 WHERE id=1')
        self.assertTrue(all(x['severity'] in ('high','medium','low') for x in build_subscription_integrity_audit(self.db, '2026-10-17')))

    def test_empty_tables_are_supported(self):
        for table in ('attendance','sales','subscriptions','clients'):
            self.db.execute(f'DELETE FROM {table}')
        self.assertEqual(build_subscription_integrity_audit(self.db, '2026-10-17'), [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
