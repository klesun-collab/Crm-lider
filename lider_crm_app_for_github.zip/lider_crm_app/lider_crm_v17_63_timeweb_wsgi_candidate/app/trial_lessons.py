"""Safe trial-lesson workflow; never creates a sale or regular subscription use."""
from datetime import datetime

TRIAL_STATUSES = {"booked", "attended", "missed", "cancelled"}


def book_trial(connection, *, lead_id, slot_id, actor_id, created_at, today_date):
    """Book a lead into a schedule slot as a trial, preserving normal capacity rules."""
    if not connection.in_transaction:
        connection.execute("BEGIN IMMEDIATE")
    lead = connection.execute(
        "SELECT l.*, c.id AS linked_client_id, c.status AS client_status "
        "FROM leads l LEFT JOIN clients c ON c.id=l.client_id WHERE l.id=?", (lead_id,)
    ).fetchone()
    if not lead:
        raise ValueError("Заявка не найдена")
    if not lead["linked_client_id"]:
        raise ValueError("Сначала создайте карточку клиента из заявки")
    if lead["client_status"] == "archived":
        raise ValueError("Нельзя записать архивного клиента на пробное занятие")
    if lead["status"] == "lost":
        raise ValueError("Заявка закрыта как несостоявшаяся; проверьте её статус")
    slot = connection.execute(
        "SELECT sl.*, t.active AS trainer_active FROM schedule_slots sl "
        "JOIN trainers t ON t.id=sl.trainer_id WHERE sl.id=?", (slot_id,)
    ).fetchone()
    if not slot:
        raise ValueError("Слот расписания не найден")
    if not slot["trainer_active"]:
        raise ValueError("Нельзя записать на занятие отключённого тренера")
    if slot["slot_date"] < today_date or datetime.fromisoformat(f"{slot['slot_date']}T{slot['slot_time']}") <= datetime.fromisoformat(created_at):
        raise ValueError("Для пробного занятия выберите будущее свободное время")
    prior = connection.execute(
        "SELECT id FROM bookings WHERE lead_id=? AND booking_type='trial' AND status!='cancelled' LIMIT 1",
        (lead_id,),
    ).fetchone()
    if prior:
        raise ValueError("Для этой заявки уже есть пробное занятие в истории; повторная запись не допускается")
    duplicate = connection.execute(
        "SELECT id FROM bookings WHERE slot_id=? AND client_id=? AND status!='cancelled' LIMIT 1",
        (slot_id, lead["linked_client_id"]),
    ).fetchone()
    if duplicate:
        raise ValueError("Клиент уже записан на этот слот")
    occupancy = connection.execute(
        "SELECT COUNT(*) FROM bookings WHERE slot_id=? AND status='booked'", (slot_id,)
    ).fetchone()[0]
    if occupancy >= slot["capacity"]:
        raise ValueError("В слоте нет свободных мест")
    cur = connection.execute(
        "INSERT INTO bookings(slot_id,client_id,subscription_id,created_by,created_at,booking_type,lead_id) "
        "VALUES(?,?,NULL,?,?, 'trial',?)",
        (slot_id, lead["linked_client_id"], actor_id, created_at, lead_id),
    )
    connection.execute("UPDATE leads SET status=CASE WHEN status='converted' THEN status ELSE 'trial_booked' END,updated_at=? WHERE id=?", (created_at, lead_id))
    return {"booking_id": cur.lastrowid, "lead_id": lead_id, "client_id": lead["linked_client_id"], "slot_id": slot_id}


def mark_trial_outcome(connection, *, booking_id, outcome, actor_id, created_at, today_date):
    """Mark trial outcome without consuming a subscription or changing payroll."""
    if outcome not in ("attended", "missed"):
        raise ValueError("Недопустимый результат пробного занятия")
    if not connection.in_transaction:
        connection.execute("BEGIN IMMEDIATE")
    booking = connection.execute(
        "SELECT b.*, sl.slot_date, sl.slot_time, sl.trainer_id, t.name AS trainer_name "
        "FROM bookings b JOIN schedule_slots sl ON sl.id=b.slot_id "
        "JOIN trainers t ON t.id=sl.trainer_id WHERE b.id=? AND b.booking_type='trial' AND b.status='booked'",
        (booking_id,),
    ).fetchone()
    if not booking:
        raise ValueError("Пробная запись уже обработана или не найдена")
    if booking["slot_date"] > today_date:
        raise ValueError("Нельзя отмечать будущее пробное занятие")
    if datetime.fromisoformat(created_at) < datetime.fromisoformat(f"{booking['slot_date']}T{booking['slot_time']}"):
        raise ValueError("Нельзя отмечать результат до начала занятия")
    connection.execute(
        "INSERT INTO trial_attendance(booking_id,lead_id,client_id,lesson_date,lesson_time,trainer,status,created_by,created_at) "
        "VALUES(?,?,?,?,?,?,?,?,?)",
        (booking_id, booking["lead_id"], booking["client_id"], booking["slot_date"], booking["slot_time"], booking["trainer_name"], outcome, actor_id, created_at),
    )
    changed = connection.execute("UPDATE bookings SET status=? WHERE id=? AND status='booked'", (outcome, booking_id))
    if changed.rowcount != 1:
        raise ValueError("Пробная запись уже обработана")
    return {"booking_id": booking_id, "lead_id": booking["lead_id"], "client_id": booking["client_id"], "status": outcome}


def cancel_trial(connection, *, booking_id, created_at, today_date):
    """Cancel a future trial only; history is retained and no finance is touched."""
    if not connection.in_transaction:
        connection.execute("BEGIN IMMEDIATE")
    booking = connection.execute(
        "SELECT b.id,b.lead_id,sl.slot_date,sl.slot_time FROM bookings b "
        "JOIN schedule_slots sl ON sl.id=b.slot_id WHERE b.id=? AND b.booking_type='trial' AND b.status='booked'",
        (booking_id,),
    ).fetchone()
    if not booking:
        raise ValueError("Пробная запись уже обработана или не найдена")
    if datetime.fromisoformat(created_at) >= datetime.fromisoformat(f"{booking['slot_date']}T{booking['slot_time']}"):
        raise ValueError("Нельзя отменить пробную запись после начала занятия")
    connection.execute("UPDATE bookings SET status='cancelled' WHERE id=? AND status='booked'", (booking_id,))
    return {"booking_id": booking_id, "lead_id": booking["lead_id"], "status": "cancelled"}
