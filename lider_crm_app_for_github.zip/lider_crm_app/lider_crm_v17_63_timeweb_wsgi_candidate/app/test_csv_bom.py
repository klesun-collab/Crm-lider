"""Regression checks for UTF-8 BOM in CSV exports."""
from pathlib import Path
import unittest

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")

class CsvBomTests(unittest.TestCase):
    def test_csv_exports_use_real_unicode_bom_not_literal_backslash_text(self):
        self.assertNotIn(r"\\ufeff", SOURCE)
        self.assertGreaterEqual(SOURCE.count(r"\ufeff"), 4)

if __name__ == "__main__":
    unittest.main()
