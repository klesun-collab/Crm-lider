import unittest
from pathlib import Path
from schedule_rules import ensure_no_overlap

class ScheduleOverlapTests(unittest.TestCase):
    def test_adjacent_lessons_are_allowed(self):
        self.assertTrue(ensure_no_overlap('09:30', 30, [
            {'id': 1, 'slot_time': '09:00', 'duration_minutes': 30}
        ]))

    def test_overlapping_lesson_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'пересекается'):
            ensure_no_overlap('09:15', 30, [
                {'id': 1, 'slot_time': '09:00', 'duration_minutes': 30}
            ])

    def test_sixty_minute_lesson_cannot_overlap_second_slot(self):
        with self.assertRaisesRegex(ValueError, 'пересекается'):
            ensure_no_overlap('09:00', 60, [
                {'id': 2, 'slot_time': '09:30', 'duration_minutes': 30}
            ])

    def test_edit_ignores_the_slot_being_edited(self):
        self.assertTrue(ensure_no_overlap('09:15', 30, [
            {'id': 1, 'slot_time': '09:00', 'duration_minutes': 30}
        ], exclude_slot_id=1))

    def test_lesson_cannot_cross_midnight(self):
        with self.assertRaisesRegex(ValueError, 'суток'):
            ensure_no_overlap('23:30', 60, [])

    def test_create_edit_and_recurring_routes_use_overlap_check(self):
        source = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
        helper = Path(__file__).with_name('recurring_schedule.py').read_text(encoding='utf-8')
        self.assertGreaterEqual(source.count('ensure_no_overlap(') + helper.count('ensure_no_overlap('), 3)
        self.assertIn('action in ("repeat_slots", "repeat_shift")', source)
        self.assertIn('shift_start_times(', source)
        self.assertIn('action=="delete_slot"', source)
        self.assertIn('Создать повторяющееся расписание', source)
        self.assertNotIn('Создавать повторяющееся расписание может только руководитель', source)

if __name__ == '__main__':
    unittest.main()
