"""Validation for manager edits to the current product catalogue."""


def normalize_product_update(name, purchase_price, sale_price, active):
    name = str(name or "").strip()
    if not name or len(name) > 100:
        raise ValueError("Название товара обязательно и не должно превышать 100 символов")
    try:
        purchase = int(purchase_price)
        sale = int(sale_price)
    except (TypeError, ValueError) as exc:
        raise ValueError("Закупочная и продажная цены должны быть целыми числами в рублях") from exc
    if purchase < 0 or sale < 0 or purchase > 100_000_000 or sale > 100_000_000:
        raise ValueError("Цена должна быть от 0 до 100 000 000 ₽")
    active_text = str(active)
    if active_text not in ("0", "1"):
        raise ValueError("Неверный статус товара")
    return {"name": name, "purchase_price": purchase, "sale_price": sale, "active": int(active_text)}
