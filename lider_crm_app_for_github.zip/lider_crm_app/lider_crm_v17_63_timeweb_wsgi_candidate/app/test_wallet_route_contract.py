import ast
import unittest
from pathlib import Path
SOURCE=Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE=ast.parse(SOURCE)

def fn(name):
    return next(n for n in TREE.body if isinstance(n,ast.FunctionDef) and n.name==name)

class WalletRouteContractTests(unittest.TestCase):
    def test_wallet_management_is_manager_only_and_audited(self):
        route=fn('wallets_page')
        self.assertTrue(any('manager_required' in ast.unparse(d) for d in route.decorator_list))
        text=ast.get_source_segment(SOURCE,route)
        for action in ('wallet.created','wallet.updated','wallet.deactivated','wallet.transfer','wallet.opening.updated'):
            self.assertIn(action,text)
    def test_sales_use_selected_wallet_method_and_store_wallet_id(self):
        route=ast.get_source_segment(SOURCE,fn('sales'))
        self.assertIn('WHERE id=? AND active=1',route)
        self.assertIn('method=wallet["payment_method"]',route)
        self.assertIn('campaign_id,wallet_id,gross_amount',route)
        self.assertIn('campaign_id or None,wallet_id,gross_amount,points_earned,points_redeemed,loyalty_discount_amount)',route)
    def test_expense_uses_wallet_and_refund_inherits_original_wallet(self):
        expense=ast.get_source_segment(SOURCE,fn('cash_add_expense'))
        refunds=ast.get_source_segment(SOURCE,fn('refunds'))
        self.assertIn('created_at,wallet_id,category_id)',expense)
        self.assertIn('sale["wallet_id"]',refunds)
    def test_old_financial_rows_are_not_automatically_assigned_to_wallets(self):
        self.assertIn('legacy financial rows are never backfilled automatically',SOURCE)
        self.assertNotIn('UPDATE sales SET wallet_id',SOURCE)
        self.assertNotIn('UPDATE cash_expenses SET wallet_id',SOURCE)
    def test_wallet_transfers_are_not_sales_or_expenses(self):
        route=ast.get_source_segment(SOURCE,fn('wallets_page'))
        self.assertIn('INSERT INTO wallet_transfers',route)
        self.assertIn('Начальный остаток нельзя менять после первой операции',route)
        self.assertIn('Нельзя отключить последний активный счёт/кошелёк',route)
        self.assertNotIn('INSERT INTO sales',route)
        self.assertNotIn('INSERT INTO cash_expenses',route)

if __name__=='__main__': unittest.main()
