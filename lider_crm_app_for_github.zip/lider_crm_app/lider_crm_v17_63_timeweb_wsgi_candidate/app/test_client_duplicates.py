"""Regression tests for cautious duplicate detection and private exports."""
import ast
import re
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")
TREE = ast.parse(SOURCE)

def fn(name):
    node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment(SOURCE, node)

class ClientDuplicateFeatureTests(unittest.TestCase):
    def test_name_normalization_handles_case_spacing_and_yo(self):
        namespace = {"re": re}
        exec(compile(ast.Module(body=[next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "normalize_client_match")], type_ignores=[]), "app.py", "exec"), namespace)
        normalize = namespace["normalize_client_match"]
        self.assertEqual(normalize("  Ёжов   ИВАН-2 "), "ежов иван 2")
        self.assertEqual(normalize(""), "")

    def test_phone_normalization_matches_8_and_7_prefixes(self):
        namespace = {}
        node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "normalize_phone_match")
        exec(compile(ast.Module(body=[node], type_ignores=[]), "app.py", "exec"), namespace)
        normalize = namespace["normalize_phone_match"]
        self.assertEqual(normalize("8 (918) 123-45-67"), "79181234567")
        self.assertEqual(normalize("+7 918 123 45 67"), "79181234567")
        self.assertEqual(normalize("9181234567"), "79181234567")

    def test_short_and_non_russian_phone_numbers_are_rejected(self):
        namespace = {}
        node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "normalize_phone_match")
        exec(compile(ast.Module(body=[node], type_ignores=[]), "app.py", "exec"), namespace)
        normalize = namespace["normalize_phone_match"]
        self.assertEqual(normalize("12345"), "")
        self.assertEqual(normalize("+1 202 555 0199"), "")

    def test_report_is_read_only_and_uses_separate_normalizers(self):
        source = fn("client_duplicates")
        self.assertIn("normalize_client_match(row[\"child_name\"])", source)
        self.assertIn("normalize_phone_match(row[\"phone\"])", source)
        self.assertIn("SELECT id,child_name,parent_name,phone,status,created_at FROM clients", source)
        for verb in ("INSERT INTO clients", "UPDATE clients", "DELETE FROM clients"):
            self.assertNotIn(verb, source)

    def test_csv_export_is_manager_only_and_not_cached(self):
        source = fn("client_duplicates")
        self.assertIn('if request.args.get("format") == "csv":', source)
        self.assertIn('if not is_current_manager(): abort(403', source)
        self.assertIn('response.headers["Cache-Control"] = "no-store"', source)
        self.assertIn('response.headers["Pragma"] = "no-cache"', source)
        self.assertIn('if is_current_manager() else', source)
        self.assertIn("safe_csv_row", source)

    def test_clients_page_links_to_duplicate_report(self):
        self.assertIn("/client-duplicates", fn("clients"))

if __name__ == "__main__":
    unittest.main()
