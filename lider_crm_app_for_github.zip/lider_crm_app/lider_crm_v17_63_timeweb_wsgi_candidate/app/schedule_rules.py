"""Validation helpers for pool lesson slots."""
from datetime import date, datetime


def validate_slot_details(slot_date, slot_time, capacity, duration, kind, today_date=None):
    """Validate and normalize the fields shared by create/edit slot actions."""
    try:
        parsed_date = date.fromisoformat(str(slot_date))
        datetime.strptime(str(slot_time), "%H:%M")
        capacity = int(capacity)
        duration = int(duration)
    except (TypeError, ValueError):
        raise ValueError("Проверьте дату, время, вместимость и длительность занятия")
    today_date = today_date or date.today().isoformat()
    if parsed_date.isoformat() != str(slot_date) or parsed_date.isoformat() < today_date:
        raise ValueError("Нельзя создавать или переносить занятие на прошедшую дату")
    if capacity < 1 or capacity > 100:
        raise ValueError("Вместимость должна быть от 1 до 100 детей")
    if duration not in (30, 60):
        raise ValueError("Длительность занятия должна быть 30 или 60 минут")
    if kind not in ("individual", "group"):
        raise ValueError("Выберите индивидуальное или групповое занятие")
    return parsed_date.isoformat(), str(slot_time), capacity, duration, kind


def ensure_no_overlap(slot_time, duration_minutes, existing_slots, exclude_slot_id=None):
    """Reject overlapping appointments for one trainer on one date.

    Adjacent lessons are allowed (09:00–09:30 followed by 09:30–10:00).
    existing_slots may contain sqlite rows or mappings with slot_time,
    duration_minutes and optionally id fields.
    """
    try:
        start = datetime.strptime(str(slot_time), "%H:%M")
        start_minute = start.hour * 60 + start.minute
        duration = int(duration_minutes)
    except (TypeError, ValueError):
        raise ValueError("Проверьте время и длительность занятия")
    if duration not in (30, 60):
        raise ValueError("Длительность занятия должна быть 30 или 60 минут")
    end_minute = start_minute + duration
    if end_minute > 24 * 60:
        raise ValueError("Занятие не может выходить за пределы суток")
    for slot in existing_slots:
        try:
            if exclude_slot_id is not None and int(slot["id"]) == int(exclude_slot_id):
                continue
            other_start_dt = datetime.strptime(str(slot["slot_time"]), "%H:%M")
            other_start = other_start_dt.hour * 60 + other_start_dt.minute
            other_duration = int(slot["duration_minutes"])
        except (TypeError, ValueError, KeyError, IndexError):
            raise ValueError("Не удалось проверить существующие занятия тренера")
        other_end = other_start + other_duration
        if start_minute < other_end and other_start < end_minute:
            raise ValueError(f"Время пересекается с другим занятием тренера ({slot['slot_time']})")
    return True
