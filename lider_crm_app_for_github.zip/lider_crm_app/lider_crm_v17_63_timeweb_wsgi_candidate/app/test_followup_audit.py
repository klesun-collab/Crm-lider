import sqlite3
import unittest
from followup_audit import FIELDS, build_followup_audit


class FollowupAuditTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
        CREATE TABLE users(id INTEGER PRIMARY KEY,username TEXT);
        CREATE TABLE clients(id INTEGER PRIMARY KEY,parent_name TEXT,child_name TEXT,phone TEXT);
        CREATE TABLE leads(id INTEGER PRIMARY KEY,parent_name TEXT,child_name TEXT,phone TEXT,status TEXT,next_contact TEXT,assigned_to INTEGER,client_id INTEGER);
        CREATE TABLE tasks(id INTEGER PRIMARY KEY,title TEXT,due_at TEXT,status TEXT,notes TEXT,client_id INTEGER,lead_id INTEGER,assigned_to INTEGER);
        INSERT INTO users VALUES(1,'admin');
        INSERT INTO clients VALUES(1,'Мама','Аня','+79990000001');
        INSERT INTO leads VALUES(1,'Папа','Борис','+79990000002','new','2026-10-16',1,NULL);
        INSERT INTO leads VALUES(2,'Мама','Вика','+79990000003','new','2026-10-17',1,NULL);
        INSERT INTO leads VALUES(3,'Мама','Лена','+79990000004','converted','',1,NULL);
        INSERT INTO leads VALUES(4,'Мама','Катя','+79990000005','lost','2026-10-15',1,NULL);
        INSERT INTO leads VALUES(5,'Папа','Игорь','+79990000006','converted','',1,1);
        INSERT INTO tasks VALUES(1,'Перезвонить','2026-10-16T10:00:00','open','срочно',NULL,1,1);
        INSERT INTO tasks VALUES(2,'Будущая задача','2026-10-20T10:00:00','open','',1,NULL,1);
        INSERT INTO tasks VALUES(3,'Готово','2026-10-16T10:00:00','done','',1,NULL,1);
        ''')

    def tearDown(self):
        self.db.close()

    def test_overdue_and_due_today_leads_are_reported_but_closed_are_not(self):
        rows = [r for r in build_followup_audit(self.db, '2026-10-17', '2026-10-17T12:00:00') if r['issue_type']=='lead_followup_due']
        self.assertEqual([r['record_id'] for r in rows], [1, 2])
        self.assertEqual(rows[0]['severity'], 'high')
        self.assertEqual(rows[1]['severity'], 'medium')

    def test_converted_lead_without_client_is_flagged(self):
        rows = [r for r in build_followup_audit(self.db, '2026-10-17') if r['issue_type']=='converted_lead_without_client']
        self.assertEqual([r['record_id'] for r in rows], [3])

    def test_overdue_open_task_reported_and_completed_task_ignored(self):
        rows = [r for r in build_followup_audit(self.db, '2026-10-17', '2026-10-17T12:00:00') if r['issue_type']=='task_overdue']
        self.assertEqual([r['record_id'] for r in rows], [1])
        self.assertEqual(rows[0]['parent_name'], 'Папа')
        self.assertEqual(rows[0]['phone'], '+79990000002')

    def test_invalid_dates_and_limit_are_handled(self):
        with self.assertRaises(ValueError):
            build_followup_audit(self.db, 'bad')
        with self.assertRaises(ValueError):
            build_followup_audit(self.db, '2026-10-17', 'bad')
        self.assertLessEqual(len(build_followup_audit(self.db, '2026-10-17', limit=1)), 1)

    def test_output_fields_stay_stable(self):
        rows = build_followup_audit(self.db, '2026-10-17')
        self.assertTrue(rows)
        self.assertEqual(tuple(rows[0].keys()), FIELDS)


if __name__ == '__main__':
    unittest.main()
