"""Tests for read-only deployment readiness checks."""
from datetime import datetime, timezone
from pathlib import Path
import sqlite3
import tempfile
import unittest
import os
import time

from system_readiness import build_system_readiness_report, REQUIRED_TABLES
from backup_database import create_backup, manifest_path_for

ROOT = Path(__file__).parent


def make_db():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    for table in REQUIRED_TABLES:
        conn.execute(f'CREATE TABLE "{table}" (id INTEGER PRIMARY KEY)')
    conn.commit()
    return conn


class SystemReadinessTests(unittest.TestCase):
    def test_healthy_local_configuration_reports_core_checks_ok(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            db_path = root / "crm.sqlite3"
            db_path.touch()
            backup_dir = root / "backups"
            source_db = root / "source.sqlite3"
            with sqlite3.connect(source_db) as source:
                for table in sorted(REQUIRED_TABLES):
                    source.execute(f'CREATE TABLE "{table}" (id INTEGER PRIMARY KEY)')
            backup = create_backup(source_db, backup_dir)
            conn = make_db()
            report = build_system_readiness_report(conn, db_path=db_path, backup_dir=backup_dir,
                secret_configured=True, cookie_secure=True, host="127.0.0.1", now=datetime.now(timezone.utc))
            statuses = {item["key"]: item["status"] for item in report}
            for key in ("sqlite_integrity", "foreign_keys", "schema", "database_file", "database_writable", "stable_secret", "secure_cookie", "debug_mode"):
                self.assertEqual(statuses[key], "ok", key)
            self.assertEqual(statuses["bind_host"], "info")
            self.assertEqual(statuses["backup_freshness"], "ok")
            conn.close()

    def test_missing_tables_are_reported_without_mutating_database(self):
        conn = sqlite3.connect(":memory:")
        conn.execute("CREATE TABLE clients(id INTEGER PRIMARY KEY)")
        before = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        with tempfile.TemporaryDirectory() as temp:
            report = build_system_readiness_report(conn, db_path=Path(temp)/"missing.db", backup_dir=Path(temp)/"backups",
                secret_configured=False, cookie_secure=False)
        schema = next(item for item in report if item["key"] == "schema")
        self.assertEqual(schema["status"], "error")
        self.assertIn("users", schema["detail"])
        self.assertEqual(before, conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall())
        conn.close()

    def test_public_bind_and_insecure_runtime_are_warnings(self):
        conn = make_db()
        with tempfile.TemporaryDirectory() as temp:
            report = build_system_readiness_report(conn, db_path=Path(temp)/"missing.db", backup_dir=Path(temp)/"backups",
                secret_configured=False, cookie_secure=False, host="0.0.0.0", debug=True)
        statuses = {item["key"]: item["status"] for item in report}
        self.assertEqual(statuses["stable_secret"], "warning")
        self.assertEqual(statuses["secure_cookie"], "warning")
        self.assertEqual(statuses["debug_mode"], "warning")
        self.assertEqual(statuses["bind_host"], "warning")
        self.assertEqual(statuses["backup_freshness"], "warning")
        conn.close()

    def test_backup_older_than_48_hours_is_flagged(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            db_path = root / "crm.sqlite3"
            db_path.touch()
            backup_dir = root / "backups"
            source_db = root / "source.sqlite3"
            with sqlite3.connect(source_db) as source:
                for table in sorted(REQUIRED_TABLES):
                    source.execute(f'CREATE TABLE "{table}" (id INTEGER PRIMARY KEY)')
            backup = create_backup(source_db, backup_dir)
            old_time = time.time() - 72 * 3600
            os.utime(backup, (old_time, old_time))
            os.utime(backup.with_name(backup.name + ".manifest.json"), (old_time, old_time))
            conn = make_db()
            report = build_system_readiness_report(conn, db_path=db_path, backup_dir=backup_dir,
                secret_configured=True, cookie_secure=True, now=datetime.now(timezone.utc))
            check = next(item for item in report if item["key"] == "backup_freshness")
            self.assertEqual(check["status"], "warning")
            conn.close()

    def test_tampered_backup_manifest_is_not_reported_as_ready(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            db_path = root / "crm.sqlite3"
            db_path.touch()
            source_db = root / "source.sqlite3"
            with sqlite3.connect(source_db) as source:
                for table in sorted(REQUIRED_TABLES):
                    source.execute(f'CREATE TABLE "{table}" (id INTEGER PRIMARY KEY)')
            backup_dir = root / "backups"
            backup = create_backup(source_db, backup_dir)
            manifest = manifest_path_for(backup)
            manifest.write_text('{"format_version":1,"backup_file":"wrong.sqlite3"}', encoding="utf-8")
            conn = make_db()
            report = build_system_readiness_report(conn, db_path=db_path, backup_dir=backup_dir,
                secret_configured=True, cookie_secure=True)
            check = next(item for item in report if item["key"] == "backup_freshness")
            self.assertEqual(check["status"], "warning")
            self.assertIn("ошибка проверки", check["detail"])
            conn.close()

    def test_report_never_returns_secret_value_or_full_db_path(self):
        conn = make_db()
        with tempfile.TemporaryDirectory() as temp:
            report = build_system_readiness_report(conn, db_path=Path(temp)/"private-crm.sqlite3", backup_dir=Path(temp)/"backups",
                secret_configured=True, cookie_secure=True)
        serialized = repr(report)
        self.assertNotIn("private-crm.sqlite3", serialized)
        self.assertNotIn("secret-value", serialized)
        conn.close()

    def test_manager_only_page_and_export_are_wired(self):
        source = (ROOT / "app.py").read_text(encoding="utf-8")
        self.assertIn("from system_readiness import build_system_readiness_report", source)
        for route in ('@app.get("/system-check")', '@app.get("/system-check.csv")'):
            self.assertIn(route, source)
            block = source.split(route, 1)[1].split("@app.", 1)[0]
            self.assertIn("@manager_required", block)
        self.assertIn('href="/system-check"', source)


if __name__ == "__main__":
    unittest.main()
