import unittest
from user_rules import validate_new_admin, validate_password


class UserRulesTests(unittest.TestCase):
    def test_valid_account(self):
        self.assertEqual(validate_new_admin('admin_2.test', 'a-very-long-pass'), 'admin_2.test')

    def test_username_is_bounded_and_safe(self):
        for username in ('ab', 'admin name', 'администратор', 'x' * 41, '<script>'):
            with self.subTest(username=username), self.assertRaises(ValueError):
                validate_new_admin(username, 'a-very-long-pass')

    def test_password_length_is_bounded(self):
        for password in ('short', 'x' * 257):
            with self.subTest(length=len(password)), self.assertRaises(ValueError):
                validate_new_admin('newadmin', password)


    def test_password_validator_accepts_strong_password_and_rejects_bounds(self):
        self.assertEqual(validate_password('a-very-long-pass'), 'a-very-long-pass')
        for password in ('short', 'x' * 257):
            with self.subTest(length=len(password)), self.assertRaises(ValueError):
                validate_password(password)

    def test_self_service_password_change_verifies_current_password_and_audits(self):
        from pathlib import Path
        source = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
        self.assertIn('@app.route("/account/password", methods=["GET", "POST"])', source)
        self.assertIn('check_password_hash(user["password_hash"],current_password)', source)
        self.assertIn('user.password_changed', source)
        self.assertIn('Новый пароль и подтверждение не совпадают', source)

    def test_settings_page_has_user_creation_and_access_toggle_guards(self):
        from pathlib import Path
        source = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
        self.assertIn('@app.post("/settings/users")', source)
        self.assertIn('Нельзя отключить последнюю активную учётную запись руководителя', source)
        self.assertIn('Нельзя отключить собственную учётную запись', source)
        self.assertIn('audit(c,"user.created"', source)

    def test_password_change_rotates_auth_version_and_logs_out(self):
        from pathlib import Path
        source = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
        self.assertIn('auth_version INTEGER NOT NULL DEFAULT 1', source)
        self.assertIn('auth_version_matches(session.get("auth_version"), user["auth_version"])', source)
        self.assertIn('auth_version=auth_version+1', source)
        self.assertIn('session.clear()\n        flash("Пароль изменён. Войдите заново; остальные сеансы также завершены.")', source)

    def test_first_manager_setup_uses_same_login_and_password_policy(self):
        from pathlib import Path
        source = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
        setup = source.split('def setup():', 1)[1].split('LOGIN_WINDOW_MINUTES', 1)[0]
        self.assertIn('username=validate_new_admin(username,password)', setup)
        self.assertIn('except ValueError as exc:', setup)

    def test_login_oversized_input_is_bounded_only_once(self):
        from pathlib import Path
        source = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
        login = source.split('def login():', 1)[1].split('def login_form():', 1)[0]
        self.assertEqual(login.count('if len(username)>100 or len(password)>1024:'), 1)


if __name__ == '__main__':
    unittest.main()
