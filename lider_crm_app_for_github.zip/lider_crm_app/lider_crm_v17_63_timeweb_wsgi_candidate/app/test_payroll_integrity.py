"""Regression tests for ambiguous payroll data in shared schedule slots."""
import sqlite3
import unittest
from pathlib import Path

ROOT = Path(__file__).parent
SOURCE = (ROOT / "app.py").read_text(encoding="utf-8")

QUERY = """SELECT schedule_slot_id,lesson_date,lesson_time,
        COUNT(*) children_count,COUNT(DISTINCT COALESCE(NULLIF(TRIM(trainer),''),'Не указан')) trainer_count,
        COUNT(DISTINCT rate_snapshot) rate_count,
        GROUP_CONCAT(DISTINCT COALESCE(NULLIF(TRIM(trainer),''),'Не указан')) trainers,
        MIN(rate_snapshot) min_rate,MAX(rate_snapshot) max_rate
    FROM attendance WHERE status='attended' AND schedule_slot_id IS NOT NULL
    GROUP BY schedule_slot_id,lesson_date,lesson_time
    HAVING COUNT(DISTINCT COALESCE(NULLIF(TRIM(trainer),''),'Не указан'))>1 OR COUNT(DISTINCT rate_snapshot)>1
    ORDER BY lesson_date DESC,lesson_time LIMIT 100"""

class PayrollIntegrityTests(unittest.TestCase):
    def test_reconciliation_includes_payroll_slot_check(self):
        start = SOURCE.index('def reconciliation():')
        end = SOURCE.index('@app.get("/payroll")', start)
        section = SOURCE[start:end]
        self.assertIn('bad_payroll_slots=c.execute', section)
        self.assertIn('Неоднозначные данные для зарплаты', section)
        self.assertIn('COUNT(DISTINCT rate_snapshot)>1', section)

    def test_flags_rate_or_trainer_conflicts_but_not_consistent_group(self):
        db = sqlite3.connect(':memory:')
        db.execute('CREATE TABLE attendance(schedule_slot_id INTEGER, lesson_date TEXT, lesson_time TEXT, status TEXT, trainer TEXT, rate_snapshot INTEGER)')
        db.executemany('INSERT INTO attendance VALUES(?,?,?,?,?,?)', [
            (10,'2026-10-12','10:00','attended','Иван',400),
            (10,'2026-10-12','10:00','attended','Иван',400),
            (11,'2026-10-12','10:30','attended','Анна',400),
            (11,'2026-10-12','10:30','attended','Анна',430),
            (12,'2026-10-12','11:00','attended','Сергей',400),
            (12,'2026-10-12','11:00','attended','Пётр',400),
            (13,'2026-10-12','11:30','planned','Ирина',400),
        ])
        rows = db.execute(QUERY).fetchall()
        self.assertEqual({r[0] for r in rows}, {11,12})
        db.close()

if __name__ == '__main__':
    unittest.main()
