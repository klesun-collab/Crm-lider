"""Regression test for sale-to-subscription links on the legacy subscription screen."""
from pathlib import Path
import sqlite3
import unittest

ROOT = Path(__file__).parent
SOURCE = (ROOT / "app.py").read_text(encoding="utf-8")

class SubscriptionSaleLinkTests(unittest.TestCase):
    def test_legacy_subscription_sale_persists_subscription_id(self):
        start = SOURCE.index('@app.route("/subscriptions",methods=["GET","POST"])')
        end = SOURCE.index('@app.route("/subscription/<int:sub_id>/freeze"', start)
        section = SOURCE[start:end]
        self.assertIn('INSERT INTO sales(client_id,item,amount,payment_method,status,created_by,created_at,subscription_id,campaign_id)', section)
        self.assertIn('now(),cur.lastrowid,campaign_id or None))', section)

    def test_schema_accepts_link_and_refund_query_can_find_it(self):
        db = sqlite3.connect(':memory:')
        db.executescript("""
            CREATE TABLE subscriptions(id INTEGER PRIMARY KEY, total_lessons INTEGER, remaining_lessons INTEGER, status TEXT);
            CREATE TABLE sales(id INTEGER PRIMARY KEY, subscription_id INTEGER, status TEXT);
        """)
        sub = db.execute("INSERT INTO subscriptions(total_lessons,remaining_lessons,status) VALUES(8,8,'active')").lastrowid
        db.execute("INSERT INTO sales(subscription_id,status) VALUES(?, 'completed')", (sub,))
        linked = db.execute("SELECT s.id,sub.remaining_lessons,sub.total_lessons,sub.status FROM sales s LEFT JOIN subscriptions sub ON sub.id=s.subscription_id WHERE s.subscription_id=?", (sub,)).fetchone()
        self.assertIsNotNone(linked)
        self.assertEqual(linked[1], linked[2])
        self.assertEqual(linked[3], 'active')
        db.close()

if __name__ == '__main__':
    unittest.main()
