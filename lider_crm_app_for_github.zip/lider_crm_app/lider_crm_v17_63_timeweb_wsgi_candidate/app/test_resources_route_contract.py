from pathlib import Path
import unittest

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")


class ResourceRouteContractTests(unittest.TestCase):
    def test_resource_schema_and_safe_additive_migration_exist(self):
        self.assertIn("CREATE TABLE IF NOT EXISTS schedule_resources", SOURCE)
        self.assertIn('if "room_id" not in slot_cols:', SOURCE)
        self.assertIn("ALTER TABLE schedule_slots ADD COLUMN room_id", SOURCE)
        self.assertIn("ALTER TABLE schedule_slots ADD COLUMN lane_id", SOURCE)

    def test_resource_management_is_authenticated_and_preserves_history(self):
        self.assertIn('@app.route("/resources", methods=["GET", "POST"])', SOURCE)
        start = SOURCE.index("def resources_page():")
        end = SOURCE.index('@app.route("/schedule",methods=["GET","POST"])', start)
        route = SOURCE[start:end]
        self.assertIn("@login_required", SOURCE[SOURCE.rfind('@app.route("/resources"', 0, start):start])
        for action in ('"create"', '"rename"', '"toggle"'):
            self.assertIn(action, route)
        self.assertIn("Нельзя отключить ресурс с назначенными занятиями", route)
        self.assertNotIn("DELETE FROM schedule_resources", route)

    def test_schedule_assigns_resources_and_checks_resource_conflicts(self):
        start = SOURCE.index("def schedule():")
        end = SOURCE.index('@app.route("/booking/<int:booking_id>/attended"', start)
        route = SOURCE[start:end]
        self.assertIn("ensure_resource_no_overlap", route)
        self.assertIn("room_id=room_id,lane_id=lane_id", route)
        self.assertIn("room_name", route)
        self.assertIn("name='room_id'", route)
        self.assertIn("name='repeat_room_id'", route)


if __name__ == "__main__":
    unittest.main()
