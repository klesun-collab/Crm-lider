import sqlite3
import unittest
from trial_lessons import book_trial, mark_trial_outcome, cancel_trial

class TrialLessonTests(unittest.TestCase):
    def setUp(self):
        self.db=sqlite3.connect(':memory:')
        self.db.row_factory=sqlite3.Row
        self.db.executescript('''
        CREATE TABLE clients(id INTEGER PRIMARY KEY, status TEXT NOT NULL);
        CREATE TABLE leads(id INTEGER PRIMARY KEY, client_id INTEGER, status TEXT, updated_at TEXT);
        CREATE TABLE trainers(id INTEGER PRIMARY KEY, name TEXT, active INTEGER);
        CREATE TABLE schedule_slots(id INTEGER PRIMARY KEY, slot_date TEXT, slot_time TEXT, duration_minutes INTEGER, capacity INTEGER, trainer_id INTEGER);
        CREATE TABLE bookings(id INTEGER PRIMARY KEY, slot_id INTEGER, client_id INTEGER, subscription_id INTEGER, created_by INTEGER, created_at TEXT, booking_type TEXT DEFAULT 'regular', lead_id INTEGER, status TEXT DEFAULT 'booked');
        CREATE TABLE trial_attendance(id INTEGER PRIMARY KEY, booking_id INTEGER UNIQUE, lead_id INTEGER, client_id INTEGER, lesson_date TEXT, lesson_time TEXT, trainer TEXT, status TEXT, created_by INTEGER, created_at TEXT);
        CREATE TABLE sales(id INTEGER PRIMARY KEY, amount INTEGER);
        CREATE TABLE subscriptions(id INTEGER PRIMARY KEY, client_id INTEGER, remaining_lessons INTEGER);
        INSERT INTO clients VALUES(1,'active');
        INSERT INTO leads VALUES(1,1,'contacted','2026-10-17');
        INSERT INTO trainers VALUES(1,'Тест тренер',1);
        INSERT INTO schedule_slots VALUES(1,'2026-10-18','10:00',30,2,1);
        ''')
        self.db.commit()
    def tearDown(self): self.db.close()
    def test_book_trial_does_not_create_financial_records(self):
        result=book_trial(self.db,lead_id=1,slot_id=1,actor_id=5,created_at='2026-10-17T09:00:00',today_date='2026-10-17')
        row=self.db.execute('SELECT * FROM bookings WHERE id=?',(result['booking_id'],)).fetchone()
        self.assertEqual(row['booking_type'],'trial')
        self.assertIsNone(row['subscription_id'])
        self.assertEqual(self.db.execute('SELECT status FROM leads WHERE id=1').fetchone()[0],'trial_booked')
        self.assertEqual(self.db.execute('SELECT COUNT(*) FROM trial_attendance').fetchone()[0],0)
        self.assertEqual(self.db.execute('SELECT COUNT(*) FROM sales').fetchone()[0],0)
        self.assertEqual(self.db.execute('SELECT COUNT(*) FROM subscriptions').fetchone()[0],0)
        self.db.commit()
    def test_trial_outcome_is_separate_and_idempotent(self):
        result=book_trial(self.db,lead_id=1,slot_id=1,actor_id=5,created_at='2026-10-17T09:00:00',today_date='2026-10-17')
        outcome=mark_trial_outcome(self.db,booking_id=result['booking_id'],outcome='attended',actor_id=5,created_at='2026-10-18T10:01:00',today_date='2026-10-18')
        self.assertEqual(outcome['status'],'attended')
        self.assertEqual(self.db.execute('SELECT COUNT(*) FROM trial_attendance').fetchone()[0],1)
        self.assertEqual(self.db.execute('SELECT COUNT(*) FROM trial_attendance WHERE status="attended"').fetchone()[0],1)
        self.db.commit()
        with self.assertRaises(ValueError):
            mark_trial_outcome(self.db,booking_id=result['booking_id'],outcome='attended',actor_id=5,created_at='2026-10-18T10:02:00',today_date='2026-10-18')
        self.db.rollback()
    def test_cannot_book_without_client_link_or_into_full_slot(self):
        self.db.execute('INSERT INTO leads VALUES(2,NULL,"contacted","2026-10-17")')
        self.db.commit()
        with self.assertRaisesRegex(ValueError,'создайте карточку клиента'):
            book_trial(self.db,lead_id=2,slot_id=1,actor_id=5,created_at='2026-10-17T09:00:00',today_date='2026-10-17')
        self.db.rollback()
        self.db.execute("INSERT INTO bookings(slot_id,client_id,subscription_id,created_by,created_at,booking_type,status) VALUES(1,1,NULL,5,'x','regular','booked')")
        self.db.execute("INSERT INTO clients VALUES(2,'active')")
        self.db.execute("INSERT INTO leads VALUES(3,2,'contacted','2026-10-17')")
        self.db.execute("INSERT INTO bookings(slot_id,client_id,subscription_id,created_by,created_at,booking_type,status) VALUES(1,2,NULL,5,'x','regular','booked')")
        self.db.commit()
        self.db.execute("INSERT INTO clients VALUES(3,'active')")
        self.db.execute("INSERT INTO leads VALUES(4,3,'contacted','2026-10-17')")
        self.db.commit()
        with self.assertRaisesRegex(ValueError,'нет свободных мест'):
            book_trial(self.db,lead_id=4,slot_id=1,actor_id=5,created_at='2026-10-17T09:00:00',today_date='2026-10-17')
        self.db.rollback()
    def test_cancel_only_before_start_and_keeps_booking_history(self):
        result=book_trial(self.db,lead_id=1,slot_id=1,actor_id=5,created_at='2026-10-17T09:00:00',today_date='2026-10-17')
        self.db.commit()
        cancel_trial(self.db,booking_id=result['booking_id'],created_at='2026-10-17T09:30:00',today_date='2026-10-17')
        self.db.commit()
        self.assertEqual(self.db.execute('SELECT status FROM bookings WHERE id=?',(result['booking_id'],)).fetchone()[0],'cancelled')
        second=book_trial(self.db,lead_id=1,slot_id=1,actor_id=5,created_at='2026-10-17T09:35:00',today_date='2026-10-17')
        self.db.commit()
        with self.assertRaisesRegex(ValueError,'после начала'):
            cancel_trial(self.db,booking_id=second['booking_id'],created_at='2026-10-18T10:01:00',today_date='2026-10-18')
        self.db.rollback()
    def test_cannot_book_disabled_trainer_or_duplicate_trial(self):
        self.db.execute('UPDATE trainers SET active=0 WHERE id=1')
        self.db.commit()
        with self.assertRaisesRegex(ValueError,'отключённого тренера'):
            book_trial(self.db,lead_id=1,slot_id=1,actor_id=5,created_at='2026-10-17T09:00:00',today_date='2026-10-17')
        self.db.rollback()
        self.db.execute('UPDATE trainers SET active=1 WHERE id=1')
        self.db.commit()
        book_trial(self.db,lead_id=1,slot_id=1,actor_id=5,created_at='2026-10-17T09:00:00',today_date='2026-10-17')
        self.db.commit()
        with self.assertRaisesRegex(ValueError,'уже есть пробное'):
            book_trial(self.db,lead_id=1,slot_id=1,actor_id=5,created_at='2026-10-17T09:00:00',today_date='2026-10-17')
        self.db.rollback()

if __name__=='__main__': unittest.main()
