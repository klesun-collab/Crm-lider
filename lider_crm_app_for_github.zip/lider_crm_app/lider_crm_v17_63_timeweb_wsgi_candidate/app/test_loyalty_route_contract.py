import ast
import unittest
from pathlib import Path
SOURCE=Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE=ast.parse(SOURCE)
def fn(name): return next(n for n in TREE.body if isinstance(n,ast.FunctionDef) and n.name==name)
class LoyaltyRouteContractTests(unittest.TestCase):
    def test_loyalty_management_is_manager_only(self):
        route=fn('loyalty_page')
        self.assertTrue(any('manager_required' in ast.unparse(d) for d in route.decorator_list))
        self.assertIn('loyalty.settings.updated',ast.get_source_segment(SOURCE,route))
        self.assertIn('loyalty.adjustment',ast.get_source_segment(SOURCE,route))
    def test_sales_uses_server_side_points_balance_and_writes_ledger(self):
        route=ast.get_source_segment(SOURCE,fn('sales'))
        self.assertIn('calculate_loyalty_redemption',route)
        self.assertIn('calculate_points_earned',route)
        self.assertIn('INSERT INTO loyalty_ledger',route)
        self.assertIn('WHERE client_id=?',route)
    def test_refund_reverses_earned_and_restores_redeemed_points(self):
        route=ast.get_source_segment(SOURCE,fn('refunds'))
        self.assertIn('refund_earn_reversal',route)
        self.assertIn('refund_redeem_restore',route)
    def test_loyalty_defaults_disabled_and_no_historical_backfill(self):
        self.assertIn('("loyalty_enabled", "0")',SOURCE)
        self.assertNotIn('UPDATE sales SET points_earned',SOURCE)
        self.assertNotIn('INSERT INTO loyalty_ledger SELECT',SOURCE)
if __name__=='__main__': unittest.main()
