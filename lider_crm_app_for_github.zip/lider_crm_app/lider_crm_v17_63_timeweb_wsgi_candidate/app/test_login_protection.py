"""Regression checks for persistent login throttling and generic failure responses."""
import pathlib, unittest
SOURCE = pathlib.Path(__file__).with_name('app.py').read_text(encoding='utf-8')

class LoginProtectionTests(unittest.TestCase):
    def test_attempts_are_persisted_and_indexed(self):
        self.assertIn('CREATE TABLE IF NOT EXISTS login_attempts', SOURCE)
        self.assertIn('idx_login_attempts_lookup', SOURCE)

    def test_throttle_uses_username_and_remote_address(self):
        self.assertIn('LOGIN_WINDOW_MINUTES = 15', SOURCE)
        self.assertIn('LOGIN_MAX_FAILURES = 5', SOURCE)
        self.assertIn('LOGIN_MAX_IP_FAILURES = 25', SOURCE)
        self.assertIn('WHERE remote_addr=? AND succeeded=0 AND attempted_at>=?', SOURCE)
        index_source = pathlib.Path(__file__).with_name('db_indexes.py').read_text(encoding='utf-8')
        self.assertIn('idx_login_attempts_ip', index_source)
        self.assertIn('login_is_limited(c, username, remote_addr)', SOURCE)

    def test_success_clears_failures_for_pair(self):
        self.assertIn('DELETE FROM login_attempts WHERE username=? AND remote_addr=? AND succeeded=0', SOURCE)

    def test_limited_response_and_generic_failure(self):
        self.assertIn('Слишком много неудачных попыток. Подождите 15 минут и повторите.', SOURCE)
        self.assertIn('Неверный логин или пароль.', SOURCE)
        self.assertIn('return page("Вход",', SOURCE)

    def test_old_attempts_are_pruned(self):
        self.assertIn('DELETE FROM login_attempts WHERE attempted_at<?', SOURCE)
        self.assertIn('timedelta(days=1)', SOURCE)

if __name__ == '__main__': unittest.main()
