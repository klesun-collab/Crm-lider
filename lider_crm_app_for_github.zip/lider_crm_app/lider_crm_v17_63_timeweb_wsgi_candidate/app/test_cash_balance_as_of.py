"""Behavioral tests for cumulative cash balances in arbitrary report periods."""
import sqlite3
import unittest
from cash_balance import balances_as_of, ensure_opening_balances_editable


class CashBalanceAsOfTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
          CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
          CREATE TABLE cash_shifts(id INTEGER PRIMARY KEY,shift_date TEXT,status TEXT,
            actual_cash INTEGER,actual_noncash INTEGER,closed_at TEXT);
          CREATE TABLE sales(id INTEGER PRIMARY KEY,payment_method TEXT,amount INTEGER,
            status TEXT,created_at TEXT);
          CREATE TABLE cash_expenses(id INTEGER PRIMARY KEY,payment_method TEXT,amount INTEGER,
            created_at TEXT);
          INSERT INTO settings VALUES('opening_cash','1000'),('opening_non_cash','500');
        ''')

    def tearDown(self):
        self.db.close()

    def test_arbitrary_period_end_includes_earlier_transactions(self):
        self.db.executescript('''
          INSERT INTO sales VALUES(1,'cash',200,'completed','2026-10-01T10:00:00');
          INSERT INTO sales VALUES(2,'card',300,'completed','2026-10-02T10:00:00');
          INSERT INTO sales VALUES(3,'cash',50,'refund','2026-10-03T10:00:00');
          INSERT INTO cash_expenses VALUES(1,'cash',40,'2026-10-03T11:00:00');
        ''')
        self.assertEqual(balances_as_of(self.db, '2026-10-10'), (1110, 800))

    def test_latest_physical_close_anchors_balance_and_avoids_double_counting(self):
        self.db.executescript('''
          INSERT INTO sales VALUES(1,'cash',900,'completed','2026-10-01T10:00:00');
          INSERT INTO cash_shifts VALUES(1,'2026-10-02','closed',1200,900,'2026-10-02T18:00:00');
          INSERT INTO sales VALUES(2,'cash',100,'completed','2026-10-03T10:00:00');
          INSERT INTO sales VALUES(3,'qr',200,'completed','2026-10-04T10:00:00');
          INSERT INTO cash_expenses VALUES(1,'cash',30,'2026-10-03T11:00:00');
          INSERT INTO cash_expenses VALUES(2,'card',50,'2026-10-04T11:00:00');
        ''')
        self.assertEqual(balances_as_of(self.db, '2026-10-10'), (1270, 1050))

    def test_transactions_after_requested_period_end_are_excluded(self):
        self.db.execute("INSERT INTO sales VALUES(1,'cash',500,'completed','2026-10-11T10:00:00')")
        self.assertEqual(balances_as_of(self.db, '2026-10-10'), (1000, 500))

    def test_opening_balances_can_be_set_before_first_close(self):
        ensure_opening_balances_editable(self.db)

    def test_opening_balances_are_locked_after_first_close(self):
        self.db.execute("INSERT INTO cash_shifts VALUES(1,'2026-10-02','closed',1200,900,'2026-10-02T18:00:00')")
        with self.assertRaisesRegex(ValueError, 'исторические отчёты'):
            ensure_opening_balances_editable(self.db)


if __name__ == '__main__':
    unittest.main()


class CashOpeningConcurrencyGuardTests(unittest.TestCase):
    def test_opening_balance_route_locks_before_checking_baseline(self):
        from pathlib import Path
        source = (Path(__file__).parent / "app.py").read_text(encoding="utf-8")
        start = source.index('def cash_save_opening():')
        end = source.index('@app.get("/cash.csv")', start)
        section = source[start:end]
        self.assertLess(section.index('c.execute("BEGIN IMMEDIATE")'), section.index('ensure_opening_balances_editable(c)'))
