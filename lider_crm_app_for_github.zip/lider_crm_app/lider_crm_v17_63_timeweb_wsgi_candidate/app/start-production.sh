#!/bin/sh
set -eu

: "${LIDER_CRM_DB:=/data/lider_crm.sqlite3}"
: "${LIDER_CRM_BACKUP_DIR:=/data/backups}"
export LIDER_CRM_DB LIDER_CRM_BACKUP_DIR

if [ "${LIDER_CRM_SECRET:-}" = "" ] || [ "${#LIDER_CRM_SECRET}" -lt 32 ]; then
  echo "ERROR: LIDER_CRM_SECRET must be set to a persistent secret of at least 32 characters." >&2
  exit 1
fi
if [ "${LIDER_COOKIE_SECURE:-0}" != "1" ]; then
  echo "ERROR: LIDER_COOKIE_SECURE=1 is required behind HTTPS." >&2
  exit 1
fi
mkdir -p "$(dirname "$LIDER_CRM_DB")" "$LIDER_CRM_BACKUP_DIR"

# Back up an existing database before startup migrations. Never overwrite the source DB.
if [ -s "$LIDER_CRM_DB" ]; then
  python backup_database.py --source "$LIDER_CRM_DB" --destination "$LIDER_CRM_BACKUP_DIR" --keep "${LIDER_CRM_BACKUP_KEEP:-30}"
fi

python deployment_preflight.py --production
python -c 'from app import init_db; init_db()'
exec gunicorn --bind 0.0.0.0:8000 --workers 1 --threads 4 --timeout 120 --access-logfile - --error-logfile - wsgi:app
