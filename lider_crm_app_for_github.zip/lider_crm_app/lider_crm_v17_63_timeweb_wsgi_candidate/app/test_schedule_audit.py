import sqlite3
import unittest
from schedule_audit import ISSUE_FIELDS, build_schedule_audit


class ScheduleAuditTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.db.row_factory = sqlite3.Row
        self.db.executescript("""
        CREATE TABLE trainers(id INTEGER PRIMARY KEY,name TEXT,active INTEGER);
        CREATE TABLE clients(id INTEGER PRIMARY KEY,child_name TEXT);
        CREATE TABLE subscriptions(id INTEGER PRIMARY KEY,client_id INTEGER,remaining_lessons INTEGER,expires_at TEXT,status TEXT);
        CREATE TABLE schedule_slots(id INTEGER PRIMARY KEY,trainer_id INTEGER,slot_date TEXT,slot_time TEXT,duration_minutes INTEGER,capacity INTEGER);
        CREATE TABLE bookings(id INTEGER PRIMARY KEY,slot_id INTEGER,client_id INTEGER,subscription_id INTEGER,status TEXT);
        INSERT INTO trainers VALUES(1,'Иван',1),(2,'Уволен',0);
        INSERT INTO clients VALUES(1,'Аня'),(2,'Борис');
        INSERT INTO subscriptions VALUES(1,1,4,'2026-12-31','active'),(2,2,0,'2026-10-01','completed');
        """)

    def tearDown(self):
        self.db.close()

    def slot(self, slot_id, trainer=1, day='2026-10-20', time='09:00', duration=30, capacity=1):
        self.db.execute('INSERT INTO schedule_slots VALUES(?,?,?,?,?,?)', (slot_id, trainer, day, time, duration, capacity))

    def booking(self, booking_id, slot_id, client=1, sub=None, status='booked'):
        self.db.execute('INSERT INTO bookings VALUES(?,?,?,?,?)', (booking_id, slot_id, client, sub, status))

    def test_empty_schedule_has_no_issues(self):
        self.assertEqual(build_schedule_audit(self.db, '2026-10-17'), [])

    def test_over_capacity_detected_and_counts_only_booked(self):
        self.slot(1, capacity=1)
        self.booking(1, 1)
        self.booking(2, 1, client=2, status='cancelled')
        issues = build_schedule_audit(self.db, '2026-10-17')
        self.assertEqual([i['issue_type'] for i in issues], [])
        self.booking(3, 1, client=2)
        issues = build_schedule_audit(self.db, '2026-10-17')
        item = next(i for i in issues if i['issue_type'] == 'over_capacity')
        self.assertEqual(item['booked_count'], 2)

    def test_adjacent_slots_are_not_overlap(self):
        self.slot(1, time='09:00', duration=30)
        self.slot(2, time='09:30', duration=30)
        self.assertFalse(any(i['issue_type'] == 'trainer_overlap' for i in build_schedule_audit(self.db, '2026-10-17')))

    def test_real_overlap_is_reported_once_for_later_slot(self):
        self.slot(1, time='09:00', duration=45)
        self.slot(2, time='09:30', duration=30)
        items = [i for i in build_schedule_audit(self.db, '2026-10-17') if i['issue_type'] == 'trainer_overlap']
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]['slot_id'], 2)
        self.assertIn('#1', items[0]['details'])

    def test_different_trainers_can_overlap(self):
        self.slot(1, trainer=1, time='09:00', duration=60)
        self.slot(2, trainer=2, time='09:15', duration=30)
        self.assertFalse(any(i['issue_type'] == 'trainer_overlap' for i in build_schedule_audit(self.db, '2026-10-17')))

    def test_invalid_slot_time_is_flagged_not_crashes(self):
        self.slot(1, time='25:90')
        self.assertTrue(any(i['issue_type'] == 'invalid_slot_time' for i in build_schedule_audit(self.db, '2026-10-17')))

    def test_inactive_trainer_only_flagged_for_today_or_future(self):
        self.slot(1, trainer=2, day='2026-10-18')
        self.slot(2, trainer=2, day='2026-10-16')
        items = [i for i in build_schedule_audit(self.db, '2026-10-17') if i['issue_type'] == 'inactive_trainer']
        self.assertEqual([i['slot_id'] for i in items], [1])

    def test_past_booked_booking_is_flagged_without_auto_cancel(self):
        self.slot(1, day='2026-10-16')
        self.booking(10, 1)
        issues = build_schedule_audit(self.db, '2026-10-17')
        item = next(i for i in issues if i['issue_type'] == 'past_booking_open')
        self.assertEqual(item['booking_id'], 10)
        self.assertEqual(self.db.execute('SELECT status FROM bookings WHERE id=10').fetchone()[0], 'booked')

    def test_wrong_client_subscription_is_flagged(self):
        self.slot(1)
        self.booking(10, 1, client=1, sub=2)
        items = [i for i in build_schedule_audit(self.db, '2026-10-17') if i['issue_type'] == 'booking_subscription']
        self.assertEqual(len(items), 1)
        self.assertIn('другому клиенту', items[0]['details'])

    def test_expired_or_empty_subscription_is_flagged(self):
        self.slot(1, day='2026-10-20')
        self.booking(10, 1, client=2, sub=2)
        items = [i for i in build_schedule_audit(self.db, '2026-10-17') if i['issue_type'] == 'booking_subscription']
        self.assertEqual(len(items), 1)
        self.assertIn('нет оставшихся занятий', items[0]['details'])
        self.assertIn('истекает до даты занятия', items[0]['details'])

    def test_null_subscription_is_not_assumed_invalid(self):
        self.slot(1)
        self.booking(10, 1, sub=None)
        self.assertFalse(any(i['issue_type'] == 'booking_subscription' for i in build_schedule_audit(self.db, '2026-10-17')))

    def test_date_validation_and_limit(self):
        with self.assertRaises(ValueError):
            build_schedule_audit(self.db, 'not-a-date')
        self.slot(1, time='09:00', duration=60)
        self.slot(2, time='09:30', duration=60)
        self.assertLessEqual(len(build_schedule_audit(self.db, '2026-10-17', limit=1)), 1)


    def test_frozen_subscription_is_flagged_as_not_bookable(self):
        self.db.execute("UPDATE subscriptions SET status='frozen' WHERE id=1")
        self.slot(1)
        self.booking(10, 1, client=1, sub=1)
        items = [i for i in build_schedule_audit(self.db, '2026-10-17') if i['issue_type'] == 'booking_subscription']
        self.assertEqual(len(items), 1)
        self.assertIn('статус абонемента: frozen', items[0]['details'])

    def test_two_trainers_with_similar_names_do_not_false_overlap(self):
        self.db.execute("INSERT INTO trainers VALUES(3,'иван',1)")
        self.slot(1, trainer=1, time='09:00', duration=60)
        self.slot(2, trainer=3, time='09:15', duration=30)
        self.assertFalse(any(i['issue_type'] == 'trainer_overlap' for i in build_schedule_audit(self.db, '2026-10-17')))

    def test_invalid_expiration_date_is_flagged(self):
        self.db.execute("UPDATE subscriptions SET expires_at='31.12.2026' WHERE id=1")
        self.slot(1)
        self.booking(10, 1, client=1, sub=1)
        items = [i for i in build_schedule_audit(self.db, '2026-10-17') if i['issue_type'] == 'booking_subscription']
        self.assertEqual(len(items), 1)
        self.assertIn('некорректная дата окончания', items[0]['details'])

    def test_invalid_slot_date_is_flagged(self):
        self.slot(1, day='20.10.2026')
        items = [i for i in build_schedule_audit(self.db, '2026-10-17') if i['issue_type'] == 'invalid_slot_date']
        self.assertEqual(len(items), 1)

    def test_issue_shape_is_stable(self):
        self.slot(1, time='25:90')
        issue = build_schedule_audit(self.db, '2026-10-17')[0]
        self.assertEqual(tuple(issue.keys()), ISSUE_FIELDS)


if __name__ == '__main__':
    unittest.main()
