"""Configurable loyalty settings and deterministic point calculations."""


def normalize_loyalty_settings(enabled, points_per_100, point_value_rubles, max_redeem_percent):
    enabled_text = str(enabled)
    if enabled_text not in ("0", "1"):
        raise ValueError("Неверный статус программы лояльности")
    try:
        earn = int(points_per_100)
        value = int(point_value_rubles)
        max_percent = int(max_redeem_percent)
    except (TypeError, ValueError) as exc:
        raise ValueError("Параметры бонусной программы должны быть целыми числами") from exc
    if not 0 <= earn <= 10000:
        raise ValueError("Начисление должно быть от 0 до 10 000 баллов на 100 ₽")
    if not 1 <= value <= 100000:
        raise ValueError("Стоимость балла должна быть от 1 до 100 000 ₽")
    if not 0 <= max_percent <= 100:
        raise ValueError("Максимальная доля оплаты баллами должна быть от 0 до 100%")
    return {"enabled": int(enabled_text), "points_per_100": earn, "point_value_rubles": value, "max_redeem_percent": max_percent}


def calculate_loyalty_redemption(*, gross_amount, balance, requested_points, point_value_rubles, max_redeem_percent, enabled):
    try:
        gross = int(gross_amount)
        available = int(balance)
        points = int(requested_points)
        point_value = int(point_value_rubles)
        max_percent = int(max_redeem_percent)
    except (TypeError, ValueError) as exc:
        raise ValueError("Проверьте сумму покупки и количество баллов") from exc
    if points < 0:
        raise ValueError("Количество списываемых баллов не может быть отрицательным")
    if points == 0:
        return {"points_redeemed": 0, "discount_amount": 0, "final_amount": gross}
    if not enabled:
        raise ValueError("Программа лояльности отключена")
    if available < points:
        raise ValueError("Недостаточно бонусных баллов у клиента")
    if max_percent <= 0:
        raise ValueError("Оплата бонусными баллами не настроена")
    if gross <= 0 or point_value <= 0:
        raise ValueError("Сумма покупки и стоимость балла должны быть положительными")
    discount = points * point_value
    max_discount = gross * max_percent // 100
    if discount > max_discount:
        raise ValueError("Сумма оплаты баллами превышает установленный лимит")
    final_amount = gross - discount
    if final_amount <= 0:
        raise ValueError("Оплата баллами не может полностью обнулить продажу")
    return {"points_redeemed": points, "discount_amount": discount, "final_amount": final_amount}


def calculate_points_earned(*, paid_amount, points_per_100, enabled):
    try:
        amount = int(paid_amount)
        rate = int(points_per_100)
    except (TypeError, ValueError) as exc:
        raise ValueError("Сумма и ставка начисления должны быть целыми числами") from exc
    if amount < 0 or rate < 0:
        raise ValueError("Сумма и ставка начисления не могут быть отрицательными")
    if not enabled or rate == 0:
        return 0
    return amount * rate // 100
