import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE = ast.parse(SOURCE)

def fn(name):
    return ast.get_source_segment(SOURCE, next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name))

class ReactivationFollowupTests(unittest.TestCase):
    def test_contact_records_followup_and_assignee(self):
        route=fn('client_reactivation')
        self.assertIn('next_contact', route)
        self.assertIn('assigned_to', route)
        self.assertIn('date.fromisoformat(next_contact)', route)
        self.assertIn('SELECT id FROM users WHERE id=? AND active=1', route)

    def test_report_counts_outcomes_and_lists_due_followups(self):
        route=fn('reactivation_report')
        self.assertIn('GROUP BY outcome', route)
        self.assertIn("o.next_contact<=?", route)
        self.assertIn("o.outcome NOT IN ('returned','declined')", route)

    def test_migration_adds_fields_for_existing_database(self):
        self.assertIn('ALTER TABLE client_outreach ADD COLUMN assigned_to', SOURCE)
        self.assertIn('ALTER TABLE client_outreach ADD COLUMN next_contact', SOURCE)

if __name__ == '__main__':
    unittest.main()
