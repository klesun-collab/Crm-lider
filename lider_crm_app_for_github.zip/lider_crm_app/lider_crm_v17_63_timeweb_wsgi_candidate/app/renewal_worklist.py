"""Deterministic, read-only query for subscription renewal follow-up."""
from datetime import date, timedelta


def normalize_horizon_days(value):
    try:
        days = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("Период должен быть числом дней") from exc
    if days < 1 or days > 90:
        raise ValueError("Период должен быть от 1 до 90 дней")
    return days


def build_renewal_worklist(conn, current_date=None, horizon_days=14, limit=500):
    """Return active clients needing renewal attention; does not create sales/tasks."""
    current = str(current_date or date.today().isoformat())
    try:
        date.fromisoformat(current)
    except ValueError as exc:
        raise ValueError("Дата должна быть в формате ГГГГ-ММ-ДД") from exc
    days = normalize_horizon_days(horizon_days)
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = 500
    limit = max(1, min(limit, 2000))
    horizon = (date.fromisoformat(current) + timedelta(days=days)).isoformat()
    rows = conn.execute(
        """SELECT s.id subscription_id,s.client_id,s.title,s.remaining_lessons,s.total_lessons,
                  s.expires_at,s.price,cl.child_name,cl.parent_name,cl.phone,
                  CASE WHEN COALESCE(s.expires_at,'')<>'' AND s.expires_at<? THEN 0
                       WHEN COALESCE(s.expires_at,'')<>'' AND s.expires_at<=? THEN 1
                       WHEN s.remaining_lessons<=1 THEN 2 ELSE 3 END priority
           FROM subscriptions s JOIN clients cl ON cl.id=s.client_id
           WHERE s.status='active' AND cl.status='active'
             AND (s.remaining_lessons<=2 OR (COALESCE(s.expires_at,'')<>'' AND s.expires_at<=?))
           ORDER BY priority,s.expires_at,s.remaining_lessons,cl.child_name,s.id LIMIT ?""",
        (current, horizon, horizon, limit),
    ).fetchall()
    return rows
