import csv
import sqlite3
import tempfile
import unittest
from pathlib import Path

from backup_database import create_backup, manifest_path_for
from backup_inventory import inspect_backup_directory, main, write_inventory_csv


class BackupInventoryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / "source.sqlite3"
        self.backups = self.root / "backups"
        with sqlite3.connect(self.source) as db:
            db.execute("CREATE TABLE clients(id INTEGER PRIMARY KEY, name TEXT)")
            db.executemany("INSERT INTO clients(name) VALUES (?)", [("Alice",), ("Bob",)])

    def tearDown(self):
        self.temp.cleanup()

    def test_inventory_reports_table_and_row_counts_for_valid_backup(self):
        backup = create_backup(self.source, self.backups)
        rows = inspect_backup_directory(self.backups)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["file"], backup.name)
        self.assertEqual(rows[0]["status"], "OK")
        self.assertEqual(rows[0]["table_count"], 1)
        self.assertEqual(rows[0]["row_count"], 2)
        self.assertEqual(len(rows[0]["sha256"]), 64)

    def test_inventory_includes_missing_manifest_as_error_instead_of_skipping(self):
        backup = create_backup(self.source, self.backups)
        manifest_path_for(backup).unlink()
        rows = inspect_backup_directory(self.backups)
        self.assertEqual(rows[0]["status"], "ERROR")
        self.assertIn("Манифест", rows[0]["error"])

    def test_csv_has_utf8_bom_and_expected_columns(self):
        create_backup(self.source, self.backups)
        rows = inspect_backup_directory(self.backups)
        output = write_inventory_csv(rows, self.root / "reports" / "inventory.csv")
        self.assertTrue(output.read_bytes().startswith(b"\xef\xbb\xbf"))
        with output.open(encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            record = next(reader)
        self.assertEqual(record["status"], "OK")
        self.assertEqual(record["row_count"], "2")


    def test_csv_write_uses_unique_atomic_temp_file_and_cleans_it(self):
        create_backup(self.source, self.backups)
        rows = inspect_backup_directory(self.backups)
        output = self.root / 'report.csv'
        output.write_text('old report', encoding='utf-8')
        write_inventory_csv(rows, output)
        self.assertTrue(output.read_bytes().startswith(b'\xef\xbb\xbf'))
        self.assertFalse(list(self.root.glob('.report.csv.*.partial')))

    def test_cli_returns_failure_if_any_backup_is_invalid(self):
        backup = create_backup(self.source, self.backups)
        manifest_path_for(backup).unlink()
        output = self.root / "inventory.csv"
        result = main([str(self.backups), "--output", str(output)])
        self.assertEqual(result, 1)
        self.assertTrue(output.is_file())


    def test_cli_refuses_to_overwrite_backup_or_manifest_with_csv(self):
        backup = create_backup(self.source, self.backups)
        original = backup.read_bytes()
        result = main([str(self.backups), '--output', str(backup)])
        self.assertEqual(result, 2)
        self.assertEqual(backup.read_bytes(), original)
        manifest = manifest_path_for(backup)
        manifest_original = manifest.read_bytes()
        result = main([str(self.backups), '--output', str(manifest)])
        self.assertEqual(result, 2)
        self.assertEqual(manifest.read_bytes(), manifest_original)


    def test_symlinked_backup_is_reported_as_error_without_following_target(self):
        target_dir = self.root / 'external'
        target_dir.mkdir()
        target = create_backup(self.source, target_dir)
        self.backups.mkdir()
        link = self.backups / target.name
        try:
            link.symlink_to(target)
        except (OSError, NotImplementedError):
            self.skipTest('Символические ссылки недоступны в этой среде')
        rows = inspect_backup_directory(self.backups)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['status'], 'ERROR')
        self.assertIn('символической ссылкой', rows[0]['error'])

    def test_nonexistent_directory_fails_cleanly(self):
        result = main([str(self.root / "missing"), "--output", str(self.root / "x.csv")])
        self.assertEqual(result, 2)


if __name__ == "__main__":
    unittest.main()
