import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE = ast.parse(SOURCE)


def function(name):
    node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment(SOURCE, node)


class LeadConversionGuardTests(unittest.TestCase):
    def test_manual_status_update_requires_existing_client_link(self):
        source = function('leads_page')
        self.assertIn('if status=="converted" and not existing_lead["client_id"]', source)
        self.assertIn('сначала используйте действие', source)

    def test_new_lead_cannot_start_in_converted_status(self):
        source = function('leads_page')
        self.assertIn('if status=="converted": abort(400', source)

    def test_manual_dropdown_hides_converted_for_unlinked_leads(self):
        source = function('leads_page')
        self.assertIn('visible_statuses = statuses if r["client_id"] else', source)
        self.assertIn("k != \"converted\"", source)

    def test_actual_convert_action_creates_or_reuses_client_then_links_lead(self):
        source = function('leads_page')
        self.assertIn("UPDATE leads SET status='converted',client_id=?,updated_at=? WHERE id=?", source)
        self.assertIn('if lead["client_id"]:', source)


if __name__ == '__main__':
    unittest.main()
