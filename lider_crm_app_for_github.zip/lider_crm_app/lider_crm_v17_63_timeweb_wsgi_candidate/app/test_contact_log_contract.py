from pathlib import Path
import unittest

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")


class ContactLogContractTests(unittest.TestCase):
    def test_contact_log_is_authenticated_and_read_only(self):
        marker='@app.route("/contact-log")'
        start=SOURCE.index(marker)
        end=SOURCE.index('@app.get("/reactivation/report")', start)
        route=SOURCE[start:end]
        self.assertIn("@login_required", route)
        self.assertIn("FROM client_outreach o JOIN clients cl", route)
        self.assertNotIn("INSERT INTO client_outreach", route)
        self.assertNotIn("UPDATE client_outreach", route)

    def test_contact_log_has_period_outcome_and_search_filters(self):
        start=SOURCE.index('@app.route("/contact-log")')
        end=SOURCE.index('@app.get("/reactivation/report")', start)
        route=SOURCE[start:end]
        for expected in ("start", "end", "outcome", "child_name LIKE", "phone LIKE", "next_contact"):
            self.assertIn(expected, route)

    def test_contact_log_link_is_in_shared_navigation(self):
        self.assertIn('<a href="/contact-log">Журнал контактов</a>', SOURCE)


if __name__ == "__main__":
    unittest.main()
