"""Static regression tests for safe trainer roster management."""
from pathlib import Path
import unittest

SOURCE = (Path(__file__).parent / 'app.py').read_text(encoding='utf-8')
START = SOURCE.index('def trainers_page():')
END = SOURCE.index('@app.route("/schedule"', START)
SECTION = SOURCE[START:END]


class TrainerManagementContractTests(unittest.TestCase):
    def test_trainer_can_be_created_from_roster(self):
        self.assertIn('if action == "create":', SECTION)
        self.assertIn('INSERT INTO trainers(name,payroll_rate,active) VALUES(?,?,1)', SECTION)

    def test_deactivation_is_soft_and_keeps_history(self):
        self.assertIn('if action == "toggle":', SECTION)
        self.assertIn('UPDATE trainers SET active=? WHERE id=?', SECTION)
        self.assertNotIn('DELETE FROM trainers', SECTION)
        self.assertIn('История сохранена', SECTION)

    def test_cannot_deactivate_trainer_with_future_bookings(self):
        self.assertIn("sl.slot_date>=? AND b.status='booked'", SECTION)
        self.assertIn('Сначала перенесите детей на другого тренера', SECTION)

    def test_only_manager_can_change_payroll_rate(self):
        self.assertIn('if is_current_manager():', SECTION)
        self.assertIn('Ставку тренера может задавать только руководитель', SECTION)

    def test_admin_can_add_trainer_without_setting_rate(self):
        self.assertIn('else:\n                    # Admins may maintain the roster but cannot assign payroll rates.', SECTION)


if __name__ == '__main__':
    unittest.main()
