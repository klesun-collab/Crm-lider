"""Regression tests for serialized refund request/approval handling."""
from pathlib import Path
import unittest

SOURCE = (Path(__file__).parent / 'app.py').read_text(encoding='utf-8')


class RefundRequestAtomicityTests(unittest.TestCase):
    def test_refund_post_takes_write_lock_before_check_and_insert(self):
        start = SOURCE.index('def refunds():')
        end = SOURCE.index('@app.get("/settings")', start)
        section = SOURCE[start:end]
        lock = section.index('c.execute("BEGIN IMMEDIATE")')
        check = section.index('existing=c.execute("SELECT id,status FROM refund_requests WHERE sale_id=? AND status IN (\'pending\',\'approved\')')
        insert = section.index('INSERT INTO refund_requests(sale_id,reason,requested_by,created_at)')
        self.assertLess(lock, check)
        self.assertLess(check, insert)

    def test_approval_still_requires_manager_and_pending_request(self):
        start = SOURCE.index('def refunds():')
        end = SOURCE.index('@app.get("/settings")', start)
        section = SOURCE[start:end]
        self.assertIn('if not is_manager: abort(403,"Только руководитель может подтверждать возвраты")', section)
        self.assertIn('req=c.execute("SELECT * FROM refund_requests WHERE id=? AND status=', section)


if __name__ == '__main__':
    unittest.main()


class RefundRejectionTests(unittest.TestCase):
    def test_manager_can_reject_pending_request_with_audit_record(self):
        start = SOURCE.index('def refunds():')
        end = SOURCE.index('@app.get("/settings")', start)
        section = SOURCE[start:end]
        self.assertIn('elif action=="reject":', section)
        self.assertIn('if not is_manager: abort(403,"Только руководитель может отклонять возвраты")', section)
        self.assertIn("SET status='rejected',approved_by=?,resolved_at=?", section)
        self.assertIn('audit(c,"refund.rejected"', section)

    def test_rejected_request_does_not_permanently_block_a_new_request(self):
        self.assertIn("status IN ('pending','approved')", SOURCE)
        self.assertIn("status='rejected'", SOURCE)
