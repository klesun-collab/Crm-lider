"""Tests for non-destructive, manifest-verified SQLite restore."""
import sqlite3
import tempfile
import unittest
from pathlib import Path

from backup_database import create_backup, verify_backup_manifest
from restore_backup import restore_backup


class RestoreBackupTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / "source.sqlite3"
        with sqlite3.connect(self.source) as db:
            db.executescript("""
                PRAGMA foreign_keys=ON;
                CREATE TABLE clients(id INTEGER PRIMARY KEY, name TEXT NOT NULL);
                CREATE TABLE sales(id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL REFERENCES clients(id), amount INTEGER NOT NULL);
                INSERT INTO clients VALUES(1,'Тестовый ребёнок');
                INSERT INTO sales VALUES(10,1,2500);
            """)
        self.backup = create_backup(self.source, self.root / "backups")

    def tearDown(self):
        self.temp.cleanup()

    def test_restores_data_and_publishes_verifiable_manifest(self):
        destination = self.root / "restored.sqlite3"
        result = restore_backup(self.backup, destination)
        self.assertEqual(result, destination.resolve())
        with sqlite3.connect(destination) as db:
            self.assertEqual(db.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            self.assertEqual(db.execute("PRAGMA foreign_key_check").fetchall(), [])
            self.assertEqual(db.execute("SELECT name FROM clients WHERE id=1").fetchone()[0], "Тестовый ребёнок")
            self.assertEqual(db.execute("SELECT amount FROM sales WHERE id=10").fetchone()[0], 2500)
        payload = verify_backup_manifest(destination)
        self.assertEqual(payload["table_counts"], {"clients": 1, "sales": 1})
        self.assertTrue(destination.with_name(destination.name + ".manifest.json").is_file())

    def test_existing_destination_is_never_overwritten(self):
        destination = self.root / "important.sqlite3"
        destination.write_bytes(b"keep this file")
        with self.assertRaisesRegex(FileExistsError, "не будет перезаписан"):
            restore_backup(self.backup, destination)
        self.assertEqual(destination.read_bytes(), b"keep this file")

    def test_tampered_source_backup_is_rejected_before_restore(self):
        with self.backup.open("ab") as stream:
            stream.write(b"tampered")
        destination = self.root / "should_not_exist.sqlite3"
        with self.assertRaisesRegex(RuntimeError, "Размер|SHA-256"):
            restore_backup(self.backup, destination)
        self.assertFalse(destination.exists())

    def test_missing_destination_directory_fails_without_creating_it(self):
        destination = self.root / "missing" / "restored.sqlite3"
        with self.assertRaisesRegex(FileNotFoundError, "Каталог назначения"):
            restore_backup(self.backup, destination)
        self.assertFalse(destination.parent.exists())


if __name__ == "__main__":
    unittest.main()
