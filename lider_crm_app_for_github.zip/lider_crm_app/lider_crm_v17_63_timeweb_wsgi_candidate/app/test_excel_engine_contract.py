"""Release contract for reading the actual GoCRM legacy XLS export and XLSX files."""
from pathlib import Path
import unittest
from unittest.mock import patch
import builtins
import tempfile

BASE = Path(__file__).parent


class ExcelEngineContractTests(unittest.TestCase):
    def test_runtime_requirements_include_legacy_xls_engine(self):
        requirements = (BASE / "requirements.txt").read_text(encoding="utf-8").lower()
        self.assertRegex(requirements, r"(?m)^xlrd\s*>?=?\s*2")

    def test_importer_explicitly_checks_xls_and_xlsx_engines(self):
        source = (BASE / "import_gocrm.py").read_text(encoding="utf-8")
        self.assertIn("suffix == '.xls'", source)
        self.assertIn("import xlrd", source)
        self.assertIn("suffix == '.xlsx'", source)
        self.assertIn("import openpyxl", source)
        self.assertIn("Неподдерживаемый формат", source)

    def test_missing_xls_engine_returns_actionable_error_before_reading_file(self):
        import import_gocrm
        real_import = builtins.__import__
        def blocked_import(name, *args, **kwargs):
            if name == "xlrd":
                raise ImportError("synthetic missing xlrd")
            return real_import(name, *args, **kwargs)
        with tempfile.TemporaryDirectory() as tmp:
            xls_path = Path(tmp) / "sample.xls"
            xls_path.write_bytes(b"not a real workbook")
            with patch("builtins.__import__", side_effect=blocked_import):
                with self.assertRaisesRegex(RuntimeError, "legacy|старого формата"):
                    import_gocrm.run(xls_path, Path(tmp) / "unused.sqlite3", apply=False)

    def test_browser_acceptance_dependency_is_separate_from_runtime(self):
        runtime = (BASE / "requirements.txt").read_text(encoding="utf-8").lower()
        browser = (BASE / "requirements-browser.txt").read_text(encoding="utf-8").lower()
        self.assertNotIn("playwright", runtime)
        self.assertIn("playwright", browser)


if __name__ == "__main__":
    unittest.main()
