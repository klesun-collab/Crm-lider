import sqlite3
import unittest
from renewal_worklist import build_renewal_worklist, normalize_horizon_days


class RenewalWorklistTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
        CREATE TABLE clients(id INTEGER PRIMARY KEY,child_name TEXT,parent_name TEXT,phone TEXT,status TEXT);
        CREATE TABLE subscriptions(id INTEGER PRIMARY KEY,client_id INTEGER,title TEXT,remaining_lessons INTEGER,total_lessons INTEGER,expires_at TEXT,price INTEGER,status TEXT);
        INSERT INTO clients VALUES(1,'Аня','Мама Ани','+79990000001','active');
        INSERT INTO clients VALUES(2,'Борис','Папа Бориса','+79990000002','active');
        INSERT INTO clients VALUES(3,'Вика','Мама Вики','+79990000003','inactive');
        INSERT INTO subscriptions VALUES(1,1,'8 занятий',2,8,'2026-11-20',8000,'active');
        INSERT INTO subscriptions VALUES(2,2,'4 занятия',4,4,'2026-10-20',4000,'active');
        INSERT INTO subscriptions VALUES(3,3,'8 занятий',0,8,'2026-10-18',8000,'active');
        INSERT INTO subscriptions VALUES(4,1,'Заморожен',0,8,'2026-10-18',8000,'frozen');
        ''')

    def tearDown(self):
        self.db.close()

    def test_worklist_includes_low_balance_or_expiring_soon(self):
        rows = build_renewal_worklist(self.db, '2026-10-17', 14)
        self.assertEqual([row['subscription_id'] for row in rows], [2, 1])
        self.assertEqual(rows[0]['priority'], 1)
        self.assertEqual(rows[1]['priority'], 3)

    def test_horizon_changes_expiry_selection(self):
        self.assertEqual([r['subscription_id'] for r in build_renewal_worklist(self.db, '2026-10-17', 2)], [1])
        rows = build_renewal_worklist(self.db, '2026-10-17', 90)
        self.assertEqual([r['subscription_id'] for r in rows], [2, 1])

    def test_inactive_clients_and_frozen_subscriptions_are_excluded(self):
        ids = {r['subscription_id'] for r in build_renewal_worklist(self.db, '2026-10-17', 90)}
        self.assertNotIn(3, ids)
        self.assertNotIn(4, ids)

    def test_horizon_bounds(self):
        for value in (0, -1, 91, 'bad', None):
            with self.assertRaises(ValueError):
                normalize_horizon_days(value)
        self.assertEqual(normalize_horizon_days('30'), 30)

    def test_date_validation_and_limit(self):
        with self.assertRaises(ValueError):
            build_renewal_worklist(self.db, '17-10-2026')
        self.assertLessEqual(len(build_renewal_worklist(self.db, '2026-10-17', 90, 1)), 1)

    def test_empty_expiration_uses_low_balance_only(self):
        self.db.execute("UPDATE subscriptions SET expires_at='' WHERE id=2")
        rows = build_renewal_worklist(self.db, '2026-10-17', 14)
        self.assertEqual({r['subscription_id'] for r in rows}, {1})


if __name__ == '__main__':
    unittest.main()
