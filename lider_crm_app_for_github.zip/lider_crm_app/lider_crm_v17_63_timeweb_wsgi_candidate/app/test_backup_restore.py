import os
import sqlite3
import tempfile
import unittest
from backup_utils import create_verified_sqlite_snapshot


class SQLiteBackupTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.source = os.path.join(self.tmp.name, 'source.sqlite3')
        self.target = os.path.join(self.tmp.name, 'snapshot.sqlite3')
        with sqlite3.connect(self.source) as db:
            db.executescript('''
                PRAGMA foreign_keys=ON;
                CREATE TABLE clients(id INTEGER PRIMARY KEY, name TEXT NOT NULL);
                CREATE TABLE sales(id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL REFERENCES clients(id), amount INTEGER NOT NULL);
                INSERT INTO clients VALUES(1, 'Тестовый клиент');
                INSERT INTO sales VALUES(7, 1, 1200);
            ''')

    def tearDown(self):
        self.tmp.cleanup()

    def test_snapshot_preserves_schema_rows_and_is_integral(self):
        create_verified_sqlite_snapshot(self.source, self.target)
        with sqlite3.connect(self.target) as db:
            self.assertEqual(db.execute('PRAGMA integrity_check').fetchone()[0], 'ok')
            self.assertEqual(db.execute('SELECT name FROM clients WHERE id=1').fetchone()[0], 'Тестовый клиент')
            self.assertEqual(db.execute('SELECT client_id, amount FROM sales WHERE id=7').fetchone(), (1, 1200))
            self.assertTrue(db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='sales'").fetchone())

    def test_snapshot_rejects_foreign_key_violations_and_removes_bad_file(self):
        # Existing source databases can contain legacy FK violations even if SQLite can copy them.
        with sqlite3.connect(self.source) as db:
            db.execute('PRAGMA foreign_keys=OFF')
            db.execute('INSERT INTO sales VALUES(8, 999, 500)')
        with self.assertRaisesRegex(RuntimeError, 'внешних ключей'):
            create_verified_sqlite_snapshot(self.source, self.target)
        self.assertFalse(os.path.exists(self.target))

    def test_existing_target_is_replaced_by_fresh_snapshot(self):
        with sqlite3.connect(self.target) as db:
            db.execute('CREATE TABLE stale(value TEXT)')
            db.execute("INSERT INTO stale VALUES('old')")
        create_verified_sqlite_snapshot(self.source, self.target)
        with sqlite3.connect(self.target) as db:
            self.assertIsNone(db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='stale'").fetchone())


if __name__ == '__main__':
    unittest.main()
