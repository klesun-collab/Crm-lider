"""Regression tests for database-level protection against overbooking."""
import sqlite3
import unittest
from pathlib import Path

ROOT = Path(__file__).parent
SOURCE = (ROOT / "app.py").read_text(encoding="utf-8")

TRIGGERS = """
CREATE TABLE schedule_slots(id INTEGER PRIMARY KEY, capacity INTEGER NOT NULL);
CREATE TABLE bookings(id INTEGER PRIMARY KEY, slot_id INTEGER NOT NULL REFERENCES schedule_slots(id), client_id INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'booked', UNIQUE(slot_id,client_id));
CREATE TRIGGER booking_capacity_insert BEFORE INSERT ON bookings
WHEN NEW.status='booked' AND
 (SELECT COUNT(*) FROM bookings WHERE slot_id=NEW.slot_id AND status='booked') >=
 (SELECT capacity FROM schedule_slots WHERE id=NEW.slot_id)
BEGIN SELECT RAISE(ABORT, 'booking_capacity_full'); END;
CREATE TRIGGER booking_capacity_update BEFORE UPDATE OF status, slot_id ON bookings
WHEN NEW.status='booked' AND (OLD.status!='booked' OR OLD.slot_id!=NEW.slot_id) AND
 (SELECT COUNT(*) FROM bookings WHERE slot_id=NEW.slot_id AND status='booked') >=
 (SELECT capacity FROM schedule_slots WHERE id=NEW.slot_id)
BEGIN SELECT RAISE(ABORT, 'booking_capacity_full'); END;
"""

class BookingCapacityTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        self.db.executescript(TRIGGERS)
        self.db.execute('INSERT INTO schedule_slots VALUES(1, 1)')
        self.db.execute("INSERT INTO bookings(slot_id,client_id,status) VALUES(1,101,'booked')")

    def tearDown(self):
        self.db.close()

    def test_database_rejects_second_active_booking_over_capacity(self):
        with self.assertRaisesRegex(sqlite3.IntegrityError, 'booking_capacity_full'):
            self.db.execute("INSERT INTO bookings(slot_id,client_id,status) VALUES(1,102,'booked')")
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM bookings WHERE status='booked'").fetchone()[0], 1)

    def test_cancelled_booking_can_be_reactivated_only_if_space_exists(self):
        self.db.execute("INSERT INTO bookings(slot_id,client_id,status) VALUES(1,102,'cancelled')")
        with self.assertRaisesRegex(sqlite3.IntegrityError, 'booking_capacity_full'):
            self.db.execute("UPDATE bookings SET status='booked' WHERE client_id=102")
        self.db.execute("UPDATE bookings SET status='cancelled' WHERE client_id=101")
        self.db.execute("UPDATE bookings SET status='booked' WHERE client_id=102")
        self.assertEqual(self.db.execute("SELECT status FROM bookings WHERE client_id=102").fetchone()[0], 'booked')

    def test_app_installs_capacity_triggers_and_handles_capacity_conflict(self):
        self.assertIn('CREATE TRIGGER IF NOT EXISTS booking_capacity_insert', SOURCE)
        self.assertIn('CREATE TRIGGER IF NOT EXISTS booking_capacity_update', SOURCE)
        self.assertIn('На это время уже нет свободных мест', SOURCE)

if __name__ == '__main__':
    unittest.main()
