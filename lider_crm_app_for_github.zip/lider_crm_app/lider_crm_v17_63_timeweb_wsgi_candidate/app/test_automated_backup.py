import os
import sqlite3
from contextlib import redirect_stderr
import io
import tempfile
import unittest
from pathlib import Path

from backup_database import create_backup, main


class AutomatedBackupTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / "source.sqlite3"
        self.backups = self.root / "backups"
        with sqlite3.connect(self.source) as db:
            db.executescript("""
                PRAGMA foreign_keys=ON;
                CREATE TABLE clients(id INTEGER PRIMARY KEY, name TEXT NOT NULL);
                CREATE TABLE sales(id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL REFERENCES clients(id), amount INTEGER NOT NULL);
                INSERT INTO clients VALUES(1,'Ребёнок');
                INSERT INTO sales VALUES(1,1,2500);
            """)

    def tearDown(self):
        self.temp.cleanup()

    def test_creates_verified_snapshot_with_rows_and_schema(self):
        backup = create_backup(self.source, self.backups)
        self.assertTrue(backup.is_file())
        with sqlite3.connect(backup) as db:
            self.assertEqual(db.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            self.assertEqual(db.execute("PRAGMA foreign_key_check").fetchall(), [])
            self.assertEqual(db.execute("SELECT name FROM clients WHERE id=1").fetchone()[0], "Ребёнок")
            self.assertEqual(db.execute("SELECT amount FROM sales WHERE id=1").fetchone()[0], 2500)

    def test_retention_keeps_newest_n_and_only_deletes_our_backup_names(self):
        first = create_backup(self.source, self.backups, keep=5)
        second = create_backup(self.source, self.backups, keep=5)
        third = create_backup(self.source, self.backups, keep=2)
        unrelated = self.backups / "manual_copy.sqlite3"
        unrelated.write_text("keep", encoding="utf-8")
        # Add another valid-looking backup filename older than the three generated ones.
        old = self.backups / "lider_crm_full_20000101_000000_000000Z.sqlite3"
        old.write_bytes(b"old")
        newest = create_backup(self.source, self.backups, keep=2)
        matching = sorted(p for p in self.backups.glob("lider_crm_full_*.sqlite3"))
        self.assertEqual(len(matching), 2)
        self.assertIn(newest, matching)
        self.assertTrue(unrelated.exists())
        self.assertFalse(old.exists())
        self.assertFalse(first.exists())
        self.assertFalse(old.exists())

    def test_rejects_missing_source_and_invalid_retention(self):
        with self.assertRaises(FileNotFoundError):
            create_backup(self.root / "missing.sqlite3", self.backups)
        with self.assertRaises(ValueError):
            create_backup(self.source, self.backups, keep=0)

    def test_cli_returns_error_for_missing_source(self):
        with redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit) as caught:
                main(["--source", str(self.root / "missing.sqlite3"), "--destination", str(self.backups)])
        self.assertEqual(caught.exception.code, 1)

    def test_failed_backup_does_not_publish_partial_file_or_prune_previous_copy(self):
        good = create_backup(self.source, self.backups, keep=1)
        with sqlite3.connect(self.source) as db:
            db.execute("PRAGMA foreign_keys=OFF")
            db.execute("INSERT INTO sales VALUES(99,999,100)")
        with self.assertRaisesRegex(RuntimeError, "внешних ключей"):
            create_backup(self.source, self.backups, keep=1)
        self.assertTrue(good.exists())
        self.assertEqual(list(self.backups.glob("lider_crm_full_*.sqlite3")), [good])
        self.assertEqual(list(self.backups.glob(".lider_crm_partial_*.sqlite3")), [])


if __name__ == "__main__":
    unittest.main()
