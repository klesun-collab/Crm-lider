"""Regression tests for enforcing subscription expiry at booking and attendance."""
import sqlite3
import unittest
from pathlib import Path

ROOT = Path(__file__).parent
SOURCE = (ROOT / "app.py").read_text(encoding="utf-8")

class SubscriptionExpiryTests(unittest.TestCase):
    def test_both_booking_paths_check_expiry_against_slot_date(self):
        self.assertGreaterEqual(SOURCE.count("expires_at>=?)"), 4)
        self.assertIn('expires_at>=?)",(sub_id,client_id,slot["slot_date"])', SOURCE)
        self.assertIn('expires_at>=?)",(sub_id,client_id,slot["slot_date"])', SOURCE)
        self.assertIn("истекает до даты занятия", SOURCE)
        self.assertIn("на дату занятия", SOURCE)

    def test_both_attendance_paths_check_expiry_against_lesson_date(self):
        self.assertIn('expires_at>=?)",(a["subscription_id"],a["client_id"],a["lesson_date"])', SOURCE)
        self.assertIn('expires_at>=?)",(s["id"],a["client_id"],a["lesson_date"])', SOURCE)
        helper = (ROOT / "booking_attendance.py").read_text(encoding="utf-8")
        self.assertIn('expires_at>=?', helper)
        self.assertIn('(booking["subscription_id"], booking["client_id"], slot["slot_date"])', helper)
        self.assertIn("Срок действия абонемента истекает до даты занятия", SOURCE)

    def test_expiry_boundary_inclusive_and_blank_expiry_is_unlimited(self):
        db = sqlite3.connect(":memory:")
        db.execute("CREATE TABLE subscriptions(id INTEGER, expires_at TEXT)")
        db.executemany("INSERT INTO subscriptions VALUES(?,?)", [(1,"2026-10-16"),(2,"2026-10-15"),(3,"")])
        query = "SELECT id FROM subscriptions WHERE COALESCE(expires_at,'')='' OR expires_at>=? ORDER BY id"
        self.assertEqual([r[0] for r in db.execute(query, ("2026-10-16",))], [1,3])
        db.close()

if __name__ == "__main__":
    unittest.main()
