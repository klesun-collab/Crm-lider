"""Tests for deduplicated campaign reach and return metrics."""
import sqlite3
import unittest
from pathlib import Path
import ast

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")
TREE = ast.parse(SOURCE)


def route_source(name):
    node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment(SOURCE, node)


class CampaignUniqueClientTests(unittest.TestCase):
    def test_repeat_contact_attempts_do_not_inflate_unique_clients(self):
        db = sqlite3.connect(":memory:")
        db.executescript("""
            CREATE TABLE client_outreach(id INTEGER PRIMARY KEY, campaign_id INTEGER, client_id INTEGER, outcome TEXT);
            INSERT INTO client_outreach VALUES
                (1, 7, 10, 'no_answer'),
                (2, 7, 10, 'returned'),
                (3, 7, 11, 'returned'),
                (4, 7, 11, 'no_answer'),
                (5, 7, 12, 'no_answer'),
                (6, 8, 10, 'returned');
        """)
        contacted = db.execute("SELECT COUNT(DISTINCT client_id) FROM client_outreach WHERE campaign_id=7").fetchone()[0]
        returned = db.execute("SELECT COUNT(DISTINCT client_id) FROM client_outreach WHERE campaign_id=7 AND outcome='returned'").fetchone()[0]
        attempts = db.execute("SELECT COUNT(*) FROM client_outreach WHERE campaign_id=7").fetchone()[0]
        self.assertEqual(attempts, 5)
        self.assertEqual(contacted, 3)
        self.assertEqual(returned, 2)
        self.assertAlmostEqual(returned * 100 / contacted, 66.6667, places=3)

    def test_campaign_route_uses_distinct_client_counts_and_safe_zero_division(self):
        route = route_source("marketing_campaigns")
        self.assertEqual(route.count("COUNT(DISTINCT o.client_id)"), 2)
        self.assertIn("if unique_contacted else", route)
        self.assertIn("if cost>0 and unique_returned else", route)
        self.assertIn("Cache-Control\":\"no-store\"", route)


if __name__ == "__main__":
    unittest.main()
