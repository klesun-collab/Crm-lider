import unittest
from subscription_rules import restoration_status, extend_expiry_for_freeze


class SubscriptionRestorationRulesTests(unittest.TestCase):
    def test_active_subscription_stays_active(self):
        self.assertEqual(restoration_status('active', 3, 8), 'active')

    def test_frozen_subscription_stays_frozen(self):
        self.assertEqual(restoration_status('frozen', 3, 8), 'frozen')

    def test_completed_subscription_reactivates_after_restoration(self):
        self.assertEqual(restoration_status('completed', 0, 8), 'active')

    def test_cancelled_subscription_cannot_be_revived(self):
        with self.assertRaisesRegex(ValueError, 'отменённом'):
            restoration_status('cancelled', 3, 8)

    def test_rejects_restoration_when_all_lessons_are_already_available(self):
        with self.assertRaisesRegex(ValueError, 'сверх исходного'):
            restoration_status('active', 8, 8)

    def test_rejects_corrupt_negative_remaining_balance(self):
        with self.assertRaises(ValueError):
            restoration_status('active', -1, 8)


    def test_freezing_preserves_subscription_without_expiry(self):
        self.assertEqual(extend_expiry_for_freeze('', '2026-10-16', 30), '')

    def test_freezing_extends_expiry_by_requested_days(self):
        self.assertEqual(extend_expiry_for_freeze('2026-11-01', '2026-10-16', 30), '2026-12-01')

    def test_freezing_past_expiry_uses_freeze_start_as_base(self):
        self.assertEqual(extend_expiry_for_freeze('2026-10-01', '2026-10-16', 30), '2026-11-15')

    def test_freeze_duration_is_bounded(self):
        with self.assertRaises(ValueError):
            extend_expiry_for_freeze('', '2026-10-16', 91)

    def test_route_uses_validated_result_and_checks_client_before_sale(self):
        from pathlib import Path
        source = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
        self.assertIn('restored_status = restoration_status(', source)
        self.assertIn('UPDATE subscriptions SET remaining_lessons=remaining_lessons+1,status=?', source)
        self.assertIn('if not c.execute("SELECT 1 FROM clients WHERE id=?",(client_id,)).fetchone():', source)


if __name__ == '__main__':
    unittest.main()
