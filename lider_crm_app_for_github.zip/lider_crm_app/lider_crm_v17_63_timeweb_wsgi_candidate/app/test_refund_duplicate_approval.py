"""Regression coverage for preventing repeated refunds of a single sale."""
from pathlib import Path
import sqlite3
import unittest

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")


class DuplicateRefundProtectionTests(unittest.TestCase):
    def test_new_request_is_blocked_when_refund_is_pending_or_approved(self):
        block = SOURCE.split('if action=="request":', 1)[1].split('elif action=="approve":', 1)[0]
        self.assertIn("status IN ('pending','approved')", block)
        self.assertIn('Возврат по этой продаже уже одобрен', block)
        self.assertIn('уже есть ожидающий запрос возврата', block)

    def test_approval_checks_both_approved_request_and_existing_compensating_sale(self):
        block = SOURCE.split('elif action=="approve":', 1)[1].split('elif action=="reject":', 1)[0]
        self.assertIn("SELECT 1 FROM refund_requests WHERE sale_id=? AND status='approved' LIMIT 1", block)
        self.assertIn("SELECT 1 FROM sales WHERE original_sale_id=? AND status='refund' LIMIT 1", block)
        self.assertIn('уже есть одобренный или проведённый возврат', block)

    def test_sql_detects_prior_refund_for_same_sale_not_another_sale(self):
        db = sqlite3.connect(':memory:')
        db.executescript('''
            CREATE TABLE sales(id INTEGER PRIMARY KEY, status TEXT, original_sale_id INTEGER);
            CREATE TABLE refund_requests(id INTEGER PRIMARY KEY, sale_id INTEGER, status TEXT);
            INSERT INTO sales VALUES(10,'completed',NULL);
            INSERT INTO sales VALUES(11,'completed',NULL);
            INSERT INTO sales VALUES(12,'refund',10);
            INSERT INTO refund_requests VALUES(20,10,'approved');
            INSERT INTO refund_requests VALUES(21,11,'pending');
        ''')
        self.assertIsNotNone(db.execute("SELECT 1 FROM refund_requests WHERE sale_id=? AND status='approved' LIMIT 1", (10,)).fetchone())
        self.assertIsNotNone(db.execute("SELECT 1 FROM sales WHERE original_sale_id=? AND status='refund' LIMIT 1", (10,)).fetchone())
        self.assertIsNone(db.execute("SELECT 1 FROM refund_requests WHERE sale_id=? AND status='approved' LIMIT 1", (11,)).fetchone())
        self.assertIsNone(db.execute("SELECT 1 FROM sales WHERE original_sale_id=? AND status='refund' LIMIT 1", (11,)).fetchone())
        db.close()


if __name__ == '__main__':
    unittest.main()
