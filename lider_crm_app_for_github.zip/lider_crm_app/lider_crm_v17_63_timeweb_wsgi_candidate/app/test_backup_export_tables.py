import ast
import sqlite3
import unittest
from pathlib import Path

from backup_utils import exportable_table_names


class BackupExportCoverageTests(unittest.TestCase):
    def test_live_schema_tables_are_discovered_dynamically(self):
        source = Path(__file__).with_name("app.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        init_fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "init_db")
        schema_sql = next(
            n.args[0].value for n in ast.walk(init_fn)
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
            and n.func.attr == "executescript" and n.args
            and isinstance(n.args[0], ast.Constant) and isinstance(n.args[0].value, str)
        )
        db = sqlite3.connect(":memory:")
        try:
            db.executescript(schema_sql)
            expected = {row[0] for row in db.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
            self.assertEqual(set(exportable_table_names(db)), expected)
            # A future module's table is included without editing a hard-coded list.
            db.execute("CREATE TABLE future_module_records(id INTEGER PRIMARY KEY, value TEXT)")
            self.assertIn("future_module_records", exportable_table_names(db))
        finally:
            db.close()

    def test_internal_sqlite_tables_are_excluded(self):
        db = sqlite3.connect(":memory:")
        try:
            db.execute("CREATE TABLE app_records(id INTEGER PRIMARY KEY, value TEXT)")
            self.assertEqual(exportable_table_names(db), ["app_records"])
        finally:
            db.close()


if __name__ == "__main__":
    unittest.main()
