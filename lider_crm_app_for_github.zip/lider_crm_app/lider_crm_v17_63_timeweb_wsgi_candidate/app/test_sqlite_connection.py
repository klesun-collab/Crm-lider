import sqlite3
import tempfile
import unittest
from pathlib import Path
from sqlite_connection import connect_sqlite


class ClosingSQLiteConnectionTests(unittest.TestCase):
    def test_context_exit_commits_and_closes_handle(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "crm.sqlite3"
            connection = connect_sqlite(path)
            with connection as db:
                db.execute("CREATE TABLE sample(value TEXT)")
                db.execute("INSERT INTO sample VALUES('saved')")
            with self.assertRaises(sqlite3.ProgrammingError):
                connection.execute("SELECT 1")
            with sqlite3.connect(path) as check:
                self.assertEqual(check.execute("SELECT value FROM sample").fetchone()[0], "saved")

    def test_context_exception_rolls_back_and_closes_handle(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "crm.sqlite3"
            with sqlite3.connect(path) as setup:
                setup.execute("CREATE TABLE sample(value TEXT)")
            connection = connect_sqlite(path)
            with self.assertRaisesRegex(RuntimeError, "force rollback"):
                with connection as db:
                    db.execute("INSERT INTO sample VALUES('must not persist')")
                    raise RuntimeError("force rollback")
            with self.assertRaises(sqlite3.ProgrammingError):
                connection.execute("SELECT 1")
            with sqlite3.connect(path) as check:
                self.assertEqual(check.execute("SELECT COUNT(*) FROM sample").fetchone()[0], 0)

    def test_foreign_keys_are_enabled_by_default(self):
        with tempfile.TemporaryDirectory() as temp:
            connection = connect_sqlite(Path(temp) / "crm.sqlite3")
            with connection as db:
                self.assertEqual(db.execute("PRAGMA foreign_keys").fetchone()[0], 1)


if __name__ == "__main__":
    unittest.main()
