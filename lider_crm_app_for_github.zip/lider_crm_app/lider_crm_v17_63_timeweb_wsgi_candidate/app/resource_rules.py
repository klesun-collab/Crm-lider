"""Validation helpers for physical rooms and pool lanes assigned to lesson slots."""
from schedule_rules import ensure_no_overlap

RESOURCE_TYPES = {"room", "lane"}


def validate_resource(name, resource_type):
    name = str(name or "").strip()
    resource_type = str(resource_type or "").strip().lower()
    if not name or len(name) > 80:
        raise ValueError("Укажите название помещения/дорожки длиной до 80 символов")
    if any(ord(ch) < 32 for ch in name):
        raise ValueError("Название не должно содержать управляющие символы")
    if resource_type not in RESOURCE_TYPES:
        raise ValueError("Выберите тип: помещение или дорожка")
    return name, resource_type


def ensure_resource_no_overlap(slot_time, duration_minutes, existing_slots, exclude_slot_id=None):
    """Reject overlapping use of one physical resource; adjacent slots are allowed."""
    try:
        ensure_no_overlap(slot_time, duration_minutes, existing_slots, exclude_slot_id=exclude_slot_id)
    except ValueError as exc:
        message = str(exc)
        if "пересекается" in message:
            raise ValueError(message.replace("Время пересекается с другим занятием тренера", "Ресурс уже занят другим занятием")) from exc
        raise
    return True


def resource_name_conflicts(name, existing_names):
    """Unicode-aware duplicate check; SQLite NOCASE only folds ASCII letters."""
    candidate = str(name or "").strip().casefold()
    return any(str(existing or "").strip().casefold() == candidate for existing in existing_names)
