"""Regression contracts for administrator-managed waitlist integration."""
from pathlib import Path
import unittest

SOURCE = (Path(__file__).parent / "app.py").read_text(encoding="utf-8")


class WaitlistContractTests(unittest.TestCase):
    def test_waitlist_schema_is_migrated_idempotently(self):
        self.assertIn("CREATE TABLE IF NOT EXISTS waitlist_entries", SOURCE)
        self.assertIn("idx_waitlist_status_preference", SOURCE)
        self.assertIn("booking_id INTEGER REFERENCES bookings(id)", SOURCE)

    def test_waitlist_is_admin_managed_authenticated_route(self):
        self.assertIn('@app.route("/waitlist", methods=["GET", "POST"])', SOURCE)
        self.assertIn('def waitlist_page():', SOURCE)
        self.assertIn('<a href="/waitlist">Лист ожидания</a>', SOURCE)

    def test_booking_from_waitlist_checks_capacity_and_subscription_owner(self):
        start = SOURCE.index('def waitlist_page():')
        end = SOURCE.index('@app.route("/schedule",methods=["GET","POST"])', start)
        route = SOURCE[start:end]
        self.assertIn('c.execute("BEGIN IMMEDIATE")', route)
        self.assertIn('if slot["booked"] >= slot["capacity"]:', route)
        self.assertIn('WHERE id=? AND client_id=? AND status=\'active\'', route)
        self.assertIn("booking_capacity_full", route)
        self.assertIn("UPDATE waitlist_entries SET status='booked'", route)

    def test_waitlist_never_creates_financial_operations_or_decrements_balance(self):
        start = SOURCE.index('def waitlist_page():')
        end = SOURCE.index('@app.route("/schedule",methods=["GET","POST"])', start)
        route = SOURCE[start:end]
        self.assertNotIn("INSERT INTO sales", route)
        self.assertNotIn("UPDATE subscriptions SET remaining_lessons=remaining_lessons-1", route)
        self.assertIn("Запись в лист ожидания не списывает занятие и не создаёт оплату", route)

    def test_status_cannot_be_manually_changed_after_booking(self):
        start = SOURCE.index('def waitlist_page():')
        end = SOURCE.index('@app.route("/schedule",methods=["GET","POST"])', start)
        route = SOURCE[start:end]
        self.assertIn('if entry["status"] == "booked":', route)
        self.assertIn("статус нельзя менять вручную", route)


if __name__ == "__main__":
    unittest.main()
