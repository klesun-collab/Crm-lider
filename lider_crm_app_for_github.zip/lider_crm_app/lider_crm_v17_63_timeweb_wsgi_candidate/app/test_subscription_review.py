import tempfile
import unittest
from pathlib import Path
import pandas as pd
from prepare_subscription_review import parse_summary, build_review, COL_ID, COL_URL, COL_CHILD, COL_SUMMARY

class SubscriptionReviewTests(unittest.TestCase):
    def test_parses_known_subscription_summary_but_flags_for_review(self):
        rows = parse_summary('Абонемент на 8 занятий №5667 , Индивидуальный, остаток - 6, покупка - 8436 ₽')
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['subscription_no'], '5667')
        self.assertEqual(rows[0]['total_lessons_hint'], 8)
        self.assertEqual(rows[0]['remaining_lessons'], 6)
        self.assertEqual(rows[0]['purchase_rub'], '8436.00')
        self.assertIn('Сверить', rows[0]['flags'])

    def test_flags_negative_and_zero_purchase(self):
        row = parse_summary('Разовое занятие №855 , Индивидуальный, остаток - -1, покупка - 0')[0]
        self.assertIn('Отрицательный остаток', row['flags'])
        self.assertIn('Нулевая стоимость', row['flags'])

    def test_unknown_format_is_not_dropped(self):
        row = parse_summary('старый формат без понятных полей')[0]
        self.assertEqual(row['parse_status'], 'needs_manual_parse')
        self.assertEqual(row['raw_summary'], 'старый формат без понятных полей')

    def test_build_csv_does_not_touch_database_or_approve_rows(self):
        with tempfile.TemporaryDirectory() as td:
            xlsx = Path(td) / 'synthetic.xlsx'
            out = Path(td) / 'review.csv'
            pd.DataFrame([{COL_ID:'123', COL_URL:'https://example.invalid/123', COL_CHILD:'Test',
                           COL_SUMMARY:'Абонемент на 4 занятия №1234 , Индивидуальный, остаток - 2, покупка - 2000 ₽'}]).to_excel(xlsx, index=False)
            stats = build_review(xlsx, out)
            result = pd.read_csv(out, dtype=str).iloc[0]
            self.assertFalse(stats['database_changed'])
            self.assertEqual(stats['subscriptions_created'], 0)
            self.assertIn('NO', result['approved_for_import'])
            self.assertEqual(result['remaining_lessons'], '2')

if __name__ == '__main__': unittest.main(verbosity=2)
