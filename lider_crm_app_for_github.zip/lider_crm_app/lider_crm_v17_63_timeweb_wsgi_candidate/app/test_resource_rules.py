import sqlite3
import unittest
from resource_rules import ensure_resource_no_overlap, validate_resource, resource_name_conflicts
from recurring_schedule import create_recurring_slots


class ResourceValidationTests(unittest.TestCase):
    def test_validates_name_and_type(self):
        self.assertEqual(("Большой бассейн", "room"), validate_resource("  Большой бассейн  ", "room"))
        self.assertEqual(("Дорожка 1", "lane"), validate_resource("Дорожка 1", "lane"))
        for name, kind in (("", "room"), ("x" * 81, "room"), ("Дорожка", "other")):
            with self.assertRaises(ValueError):
                validate_resource(name, kind)

    def test_resource_name_conflicts_are_unicode_case_insensitive(self):
        self.assertTrue(resource_name_conflicts("Бассейн", ["бассейн"]))
        self.assertTrue(resource_name_conflicts("  Дорожка 1 ", ["Дорожка 1"]))
        self.assertFalse(resource_name_conflicts("Бассейн 2", ["Бассейн"]))

    def test_resource_overlap_rejects_intersection_and_allows_adjacent_slots(self):
        existing = [{"id": 1, "slot_time": "09:00", "duration_minutes": 30}]
        with self.assertRaisesRegex(ValueError, "Ресурс уже занят"):
            ensure_resource_no_overlap("09:15", 30, existing)
        self.assertTrue(ensure_resource_no_overlap("09:30", 30, existing))

    def test_recurring_schedule_rejects_resource_collision_atomically(self):
        db = sqlite3.connect(":memory:")
        db.row_factory = sqlite3.Row
        db.executescript("""
            CREATE TABLE schedule_slots(
              id INTEGER PRIMARY KEY, trainer_id INTEGER NOT NULL, slot_date TEXT NOT NULL,
              slot_time TEXT NOT NULL, duration_minutes INTEGER NOT NULL DEFAULT 30,
              capacity INTEGER NOT NULL DEFAULT 1, kind TEXT NOT NULL DEFAULT 'individual',
              notes TEXT DEFAULT '', room_id INTEGER, lane_id INTEGER,
              UNIQUE(trainer_id,slot_date,slot_time));
            INSERT INTO schedule_slots(trainer_id,slot_date,slot_time,duration_minutes,capacity,kind,notes,room_id,lane_id)
            VALUES(99,'2026-10-19','09:00',60,1,'individual','',4,2);
        """)
        with self.assertRaisesRegex(ValueError, "Ресурс уже занят"):
            create_recurring_slots(db, 7, ["2026-10-19"], ["09:00", "09:30"], 30, 1, "individual", "", room_id=4, lane_id=2)
        self.assertEqual(1, db.execute("SELECT COUNT(*) FROM schedule_slots").fetchone()[0])
        db.close()

    def test_recurring_schedule_assigns_resource_when_available(self):
        db = sqlite3.connect(":memory:")
        db.row_factory = sqlite3.Row
        db.executescript("""
            CREATE TABLE schedule_slots(
              id INTEGER PRIMARY KEY, trainer_id INTEGER NOT NULL, slot_date TEXT NOT NULL,
              slot_time TEXT NOT NULL, duration_minutes INTEGER NOT NULL DEFAULT 30,
              capacity INTEGER NOT NULL DEFAULT 1, kind TEXT NOT NULL DEFAULT 'individual',
              notes TEXT DEFAULT '', room_id INTEGER, lane_id INTEGER,
              UNIQUE(trainer_id,slot_date,slot_time));
        """)
        created, skipped = create_recurring_slots(db, 7, ["2026-10-19"], ["09:00", "09:30"], 30, 1, "individual", "", room_id=4, lane_id=2)
        self.assertEqual((2, 0), (created, skipped))
        self.assertEqual([(4, 2), (4, 2)], [tuple(r) for r in db.execute("SELECT room_id,lane_id FROM schedule_slots ORDER BY slot_time")])
        db.close()


if __name__ == "__main__":
    unittest.main()
