"""Unit tests for the read-only deployment preflight checker."""
from pathlib import Path
import unittest
import deployment_preflight

BASE = Path(__file__).parent


class DeploymentPreflightTests(unittest.TestCase):
    def test_current_package_has_no_unprotected_application_routes(self):
        source = (BASE / "app.py").read_text(encoding="utf-8")
        self.assertEqual([], deployment_preflight.route_security_issues(source))

    def test_production_mode_requires_stable_secret_and_secure_cookie(self):
        modules = {name: True for name in deployment_preflight.REQUIRED_MODULES}
        env = {"LIDER_CRM_SECRET": "short", "LIDER_COOKIE_SECURE": "0"}
        checks = deployment_preflight.collect_checks(BASE, modules=modules, env=env, production=True)
        statuses = {title: ok for title, ok, _ in checks}
        self.assertFalse(statuses["Постоянный секрет production"])
        self.assertFalse(statuses["Secure cookie production"])
        env["LIDER_CRM_SECRET"] = "x" * 48
        env["LIDER_COOKIE_SECURE"] = "1"
        checks = deployment_preflight.collect_checks(BASE, modules=modules, env=env, production=True)
        statuses = {title: ok for title, ok, _ in checks}
        self.assertTrue(statuses["Постоянный секрет production"])
        self.assertTrue(statuses["Secure cookie production"])

    def test_release_manifest_verifies_current_package(self):
        # The package-level verifier is a standalone script.
        import verify_release
        checked, failures = verify_release.verify(BASE)
        self.assertGreater(checked, 100)
        self.assertEqual([], failures)

    def test_missing_xlrd_is_reported_as_blocker(self):
        modules = {name: True for name in deployment_preflight.REQUIRED_MODULES}
        modules["xlrd"] = False
        checks = deployment_preflight.collect_checks(BASE, modules=modules, env={}, production=False)
        self.assertIn(("Зависимость xlrd", False, "не установлена; выполните установку requirements.txt"), checks)

    def test_preflight_requires_resource_rules_module(self):
        source = (Path(__file__).parent / "deployment_preflight.py").read_text(encoding="utf-8")
        self.assertIn("resource_rules.py", source)


if __name__ == "__main__":
    unittest.main()
