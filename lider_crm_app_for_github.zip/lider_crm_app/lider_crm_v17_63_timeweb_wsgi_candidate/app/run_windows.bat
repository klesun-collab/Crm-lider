@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo CRM environment not found. Run setup_and_run_windows.bat first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" deployment_preflight.py
if errorlevel 1 (
  echo Preflight failed. Fix the listed issues before starting CRM.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" app.py
if errorlevel 1 pause
