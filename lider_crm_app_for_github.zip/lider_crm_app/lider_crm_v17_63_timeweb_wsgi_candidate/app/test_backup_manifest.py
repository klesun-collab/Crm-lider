"""Integrity and tamper-detection tests for SHA-256 backup manifests."""
import contextlib
import hashlib
import io
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from backup_database import (
    create_backup,
    main,
    manifest_path_for,
    verify_backup_manifest,
)


def _sha_for_test(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class BackupManifestTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / "source database.sqlite3"
        self.backups = self.root / "secure backups"
        with sqlite3.connect(self.source) as db:
            db.executescript("""
                PRAGMA foreign_keys=ON;
                CREATE TABLE clients(id INTEGER PRIMARY KEY, name TEXT NOT NULL);
                CREATE TABLE sales(id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL REFERENCES clients(id), amount INTEGER NOT NULL);
                INSERT INTO clients VALUES(1, 'Ребёнок');
                INSERT INTO sales VALUES(1, 1, 2400);
            """)

    def tearDown(self):
        self.temp.cleanup()

    def test_backup_publishes_manifest_with_digest_and_can_be_verified(self):
        backup = create_backup(self.source, self.backups)
        manifest = manifest_path_for(backup)
        self.assertTrue(manifest.is_file())
        payload = verify_backup_manifest(backup)
        self.assertEqual(payload["backup_file"], backup.name)
        self.assertEqual(payload["sqlite_integrity_check"], "ok")
        self.assertEqual(payload["foreign_key_violations"], 0)
        self.assertEqual(payload["size_bytes"], backup.stat().st_size)
        self.assertEqual(len(payload["sha256"]), 64)
        self.assertEqual(payload["table_counts"], {"clients": 1, "sales": 1})
        with sqlite3.connect(backup) as db:
            self.assertEqual(db.execute("SELECT amount FROM sales WHERE id=1").fetchone()[0], 2400)

    def test_tampered_backup_is_rejected_by_size_or_digest(self):
        backup = create_backup(self.source, self.backups)
        with backup.open("ab") as stream:
            stream.write(b"tampered")
        with self.assertRaisesRegex(RuntimeError, "Размер|SHA-256"):
            verify_backup_manifest(backup)

    def test_manifest_tampering_is_rejected(self):
        backup = create_backup(self.source, self.backups)
        manifest = manifest_path_for(backup)
        payload = json.loads(manifest.read_text(encoding="utf-8"))
        payload["sha256"] = "0" * 64
        manifest.write_text(json.dumps(payload), encoding="utf-8")
        with self.assertRaisesRegex(RuntimeError, "SHA-256"):
            verify_backup_manifest(backup)

    def test_cli_verify_mode_returns_success_for_valid_backup(self):
        backup = create_backup(self.source, self.backups)
        self.assertEqual(main(["--verify", str(backup)]), 0)

    def test_retention_removes_manifest_for_pruned_backup(self):
        first = create_backup(self.source, self.backups, keep=2)
        second = create_backup(self.source, self.backups, keep=2)
        third = create_backup(self.source, self.backups, keep=1)
        self.assertFalse(first.exists())
        self.assertFalse(manifest_path_for(first).exists())
        self.assertFalse(second.exists())
        self.assertFalse(manifest_path_for(second).exists())
        self.assertTrue(third.exists())
        self.assertTrue(manifest_path_for(third).exists())

    def test_manifest_table_count_tampering_is_rejected(self):
        backup = create_backup(self.source, self.backups)
        manifest = manifest_path_for(backup)
        payload = json.loads(manifest.read_text(encoding="utf-8"))
        payload["table_counts"]["sales"] = 999
        manifest.write_text(json.dumps(payload), encoding="utf-8")
        # The digest is still correct; structural verification must catch the edited manifest.
        with self.assertRaisesRegex(RuntimeError, "количество записей"):
            verify_backup_manifest(backup)

    def test_legacy_manifest_without_table_counts_remains_compatible(self):
        backup = create_backup(self.source, self.backups)
        manifest = manifest_path_for(backup)
        payload = json.loads(manifest.read_text(encoding="utf-8"))
        payload.pop("table_counts")
        manifest.write_text(json.dumps(payload), encoding="utf-8")
        self.assertEqual(verify_backup_manifest(backup)["backup_file"], backup.name)


    def test_non_object_manifest_is_rejected_cleanly(self):
        backup = create_backup(self.source, self.backups)
        manifest = manifest_path_for(backup)
        manifest.write_text('[]', encoding='utf-8')
        with self.assertRaisesRegex(ValueError, 'JSON-объектом'):
            verify_backup_manifest(backup)

    def test_invalid_manifest_digest_and_counts_are_rejected_before_database_scan(self):
        backup = create_backup(self.source, self.backups)
        manifest = manifest_path_for(backup)
        payload = json.loads(manifest.read_text(encoding='utf-8'))
        payload['sha256'] = 'not-a-digest'
        manifest.write_text(json.dumps(payload), encoding='utf-8')
        with self.assertRaisesRegex(ValueError, 'SHA-256'):
            verify_backup_manifest(backup)
        payload['sha256'] = _sha_for_test(backup)
        payload['table_counts'] = {'clients': -1}
        manifest.write_text(json.dumps(payload), encoding='utf-8')
        with self.assertRaisesRegex(ValueError, 'количество записей'):
            verify_backup_manifest(backup)

    def test_missing_manifest_is_not_silently_accepted(self):
        backup = create_backup(self.source, self.backups)
        manifest_path_for(backup).unlink()
        with self.assertRaisesRegex(FileNotFoundError, "Манифест"):
            verify_backup_manifest(backup)

    def test_verify_all_checks_every_backup_in_directory(self):
        first = create_backup(self.source, self.backups)
        second = create_backup(self.source, self.backups)
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            result = main(["--verify-all", str(self.backups)])
        self.assertEqual(result, 0)
        self.assertIn("Итог: проверено 2, ошибок 0", output.getvalue())
        self.assertIn(first.name, output.getvalue())
        self.assertIn(second.name, output.getvalue())

    def test_verify_all_returns_failure_when_any_backup_is_tampered(self):
        valid = create_backup(self.source, self.backups)
        tampered = create_backup(self.source, self.backups)
        with tampered.open("ab") as stream:
            stream.write(b"broken")
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            result = main(["--verify-all", str(self.backups)])
        self.assertEqual(result, 1)
        self.assertIn("ОШИБКА", output.getvalue())
        self.assertIn("Итог: проверено 2, ошибок 1", output.getvalue())
        self.assertTrue(valid.exists())

    def test_verify_all_empty_directory_is_not_reported_as_success(self):
        self.backups.mkdir()
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            result = main(["--verify-all", str(self.backups)])
        self.assertEqual(result, 1)
        self.assertIn("нет резервных копий", output.getvalue())


if __name__ == "__main__":
    unittest.main()
