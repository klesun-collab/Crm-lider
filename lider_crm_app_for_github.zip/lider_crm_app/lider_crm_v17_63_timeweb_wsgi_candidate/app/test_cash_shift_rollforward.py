"""Regression checks for cash balances rolling forward between consecutive shifts."""
from pathlib import Path
import unittest

SOURCE = (Path(__file__).parent / "app.py").read_text(encoding="utf-8")

class CashShiftRollForwardTests(unittest.TestCase):
    def test_next_shift_uses_previous_actual_balances(self):
        start = SOURCE.index('def cash_close_shift():')
        end = SOURCE.index('@app.get("/cash")', start)
        section = SOURCE[start:end]
        self.assertIn('previous=c.execute("SELECT * FROM cash_shifts WHERE status=\'closed\' ORDER BY closed_at DESC,id DESC LIMIT 1")', section)
        self.assertIn('opening_cash=previous["actual_cash"]', section)
        self.assertIn('opening_noncash=previous["actual_noncash"]', section)

    def test_next_shift_counts_only_newly_recorded_transactions(self):
        start = SOURCE.index('def cash_close_shift():')
        end = SOURCE.index('@app.get("/cash")', start)
        section = SOURCE[start:end]
        self.assertIn('WHERE created_at>? AND created_at<=? GROUP BY payment_method', section)
        self.assertIn('WHERE created_at>? AND created_at<=? GROUP BY payment_method', section)
        self.assertIn('closing_time=now()', section)
        self.assertIn('transfer_balance_deltas', section)

    def test_prevents_backdated_close_after_a_later_shift(self):
        self.assertIn('if previous and shift_date < previous["shift_date"]:', SOURCE)
        self.assertIn('Нельзя закрыть смену раньше уже закрытой смены', SOURCE)

    def test_timestamps_have_subsecond_precision_for_shift_boundaries(self):
        self.assertIn('def now(): return datetime.now().isoformat(timespec="microseconds")', SOURCE)

    def test_cash_close_serializes_competing_closures(self):
        start = SOURCE.index('def cash_close_shift():')
        end = SOURCE.index('@app.get("/cash")', start)
        self.assertIn('c.execute("BEGIN IMMEDIATE")', SOURCE[start:end])

if __name__ == "__main__":
    unittest.main()
