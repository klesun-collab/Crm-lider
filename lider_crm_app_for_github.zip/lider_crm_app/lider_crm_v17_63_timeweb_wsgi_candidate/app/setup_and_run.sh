#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v python3 >/dev/null 2>&1 || { echo "Python 3.10+ не найден"; exit 1; }
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python deployment_preflight.py
echo "CRM запускается. Откройте http://127.0.0.1:5000/setup"
exec .venv/bin/python app.py
