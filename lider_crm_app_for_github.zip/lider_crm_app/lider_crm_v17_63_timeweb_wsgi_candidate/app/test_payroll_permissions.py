"""Financial and salary pages are restricted to the manager role."""
from pathlib import Path
import re
import unittest

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")


class FinancialPermissionTests(unittest.TestCase):
    def test_sensitive_financial_routes_require_manager(self):
        routes = (
            ('@app.get("/payroll")', '@app.get("/payroll.csv")'),
            ('@app.get("/payroll.csv")', '@app.get("/reports")'),
            ('@app.get("/reports")', '@app.get("/reports.csv")'),
            ('@app.get("/reports.csv")', '@app.route("/leads"'),
            ('@app.get("/cash")', '@app.post("/cash/expense")'),
            ('@app.post("/cash/expense")', '@app.post("/cash/opening")'),
            ('@app.get("/cash.csv")', '@app.route("/discounts"'),
            ('@app.route("/products"', '@app.post("/products/<int:pid>/receive")'),
            ('@app.route("/discounts"', '@app.post("/products/<int:pid>/receive")'),
        )
        for route, next_route in routes:
            with self.subTest(route=route):
                section = SOURCE.split(route, 1)[1].split(next_route, 1)[0]
                decorators = section.split("def ", 1)[0]
                self.assertIn("@manager_required", decorators)
                self.assertNotIn("@login_required", decorators)

    def test_manager_only_navigation_links_are_inside_role_conditionals(self):
        page = SOURCE.split("def page(title, body):", 1)[1].split('@app.route("/setup"', 1)[0]
        nav = page.split('nav = f"""<nav>', 1)[1].split('</nav>"""', 1)[0]
        guarded_blocks = re.findall(r"\{('.*?') if u\['role'\]=='manager' else ''\}", nav, flags=re.DOTALL)
        self.assertTrue(guarded_blocks)
        guarded = "".join(guarded_blocks)
        static_nav = re.sub(r"\{'.*?' if u\['role'\]=='manager' else ''\}", "", nav, flags=re.DOTALL)
        for link in ('/cash', '/products', '/discounts', '/payroll', '/reconciliation', '/backup', '/settings', '/audit', '/reports'):
            with self.subTest(link=link):
                self.assertIn(link, guarded)
                self.assertNotIn(f'<a href="{link}">', static_nav)

    def test_revenue_dashboard_tile_is_manager_only(self):
        dashboard = SOURCE.split('def dashboard():', 1)[1].split('@app.route("/clients"', 1)[0]
        self.assertIn('if is_current_manager():', dashboard)
        self.assertIn('dashboard_cards.append(("Выручка"', dashboard)
        self.assertLess(dashboard.index('if is_current_manager():'), dashboard.index('dashboard_cards.append(("Выручка"'))

    def test_manager_guard_checks_database_role(self):
        guard = SOURCE.split("def manager_required(fn):", 1)[1].split("def normalize_client_match", 1)[0]
        self.assertIn('u["role"]!="manager"', guard)
        self.assertIn('abort(403,"Действие доступно только руководителю")', guard)


if __name__ == "__main__":
    unittest.main()
