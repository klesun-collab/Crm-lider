"""Regression tests for arithmetic consistency of cash shift closeouts."""
import sqlite3
import unittest
from pathlib import Path

from cash_shift_integrity import find_cash_shift_math_mismatches

ROOT = Path(__file__).parent

def make_db():
    db=sqlite3.connect(":memory:")
    db.row_factory=sqlite3.Row
    db.execute("""CREATE TABLE cash_shifts(
      id INTEGER PRIMARY KEY, shift_date TEXT, expected_cash INTEGER, actual_cash INTEGER,
      cash_difference INTEGER, expected_noncash INTEGER, actual_noncash INTEGER,
      noncash_difference INTEGER, note TEXT, status TEXT, closed_at TEXT)""")
    return db

class CashShiftIntegrityTests(unittest.TestCase):
    def test_detects_wrong_saved_difference_even_if_saved_zero(self):
        db=make_db()
        db.execute("INSERT INTO cash_shifts VALUES(1,'2026-10-10',1000,900,0,2000,2000,0,'','closed','2026-10-10 20:00:00')")
        rows=find_cash_shift_math_mismatches(db)
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['calculated_cash_difference'],-100)
        db.close()

    def test_ignores_correct_closed_shift_and_open_shift(self):
        db=make_db()
        db.executemany("INSERT INTO cash_shifts VALUES(?,?,?,?,?,?,?,?,?,?,?)", [
          (1,'2026-10-10',1000,900,-100,2000,1900,-100,'','closed','2026-10-10 20:00:00'),
          (2,'2026-10-11',1000,900,0,2000,1900,0,'','open',''),
        ])
        self.assertEqual(find_cash_shift_math_mismatches(db),[])
        db.close()

    def test_detects_either_payment_channel(self):
        db=make_db()
        db.execute("INSERT INTO cash_shifts VALUES(1,'2026-10-10',1000,1000,0,2000,1700,0,'','closed','2026-10-10 20:00:00')")
        rows=find_cash_shift_math_mismatches(db)
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['calculated_noncash_difference'],-300)
        db.close()

    def test_reconciliation_and_csv_are_manager_only(self):
        source=(ROOT/'app.py').read_text(encoding='utf-8')
        self.assertIn('from cash_shift_integrity import find_cash_shift_math_mismatches',source)
        self.assertIn('find_cash_shift_math_mismatches(c)',source)
        self.assertIn('/reconciliation/cash-shift-mismatches.csv',source)
        self.assertIn('Ошибки арифметики закрытия',source)
        route=source[source.index('@app.get("/reconciliation/cash-shift-mismatches.csv")'):source.index('@app.get("/reconciliation")')]
        self.assertIn('@manager_required',route)

if __name__=='__main__':
    unittest.main()
