"""Regression checks for race-safe first manager account creation."""
from pathlib import Path
import unittest
SOURCE = (Path(__file__).parent / "app.py").read_text(encoding="utf-8")

class SetupAtomicityTests(unittest.TestCase):
    def test_setup_serializes_creation_before_checking_existing_users(self):
        start=SOURCE.index('def setup():')
        end=SOURCE.index('LOGIN_WINDOW_MINUTES', start)
        section=SOURCE[start:end]
        self.assertIn('c.execute("BEGIN IMMEDIATE")', section)
        self.assertLess(section.index('c.execute("BEGIN IMMEDIATE")'), section.index('count=c.execute("SELECT COUNT(*) n FROM users")'))
        self.assertIn('if count:', section)
        self.assertIn('c.execute("INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)"', section)

if __name__ == '__main__': unittest.main()
