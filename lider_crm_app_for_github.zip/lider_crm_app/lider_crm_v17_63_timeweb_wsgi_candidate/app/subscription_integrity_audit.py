"""Read-only integrity audit for subscriptions, sales and attendance links."""
from datetime import date

FIELDS = (
    "issue_type", "severity", "entity_type", "record_id", "client_id",
    "subscription_id", "child_name", "phone", "details",
)
_VALID_SUBSCRIPTION_STATUSES = {"active", "frozen", "completed", "cancelled"}
_VALID_ATTENDANCE_STATUSES = {"planned", "attended", "missed", "cancelled"}


def _parse_iso(value):
    value = str(value or "").strip()
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except (TypeError, ValueError):
        return False


def build_subscription_integrity_audit(conn, current_date=None, limit=3000):
    """Return findings without modifying CRM data. All findings require human review."""
    day = str(current_date or date.today().isoformat())
    try:
        today = date.fromisoformat(day)
    except (TypeError, ValueError) as exc:
        raise ValueError("Дата проверки должна быть в формате ГГГГ-ММ-ДД") from exc
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = 3000
    limit = max(1, min(limit, 10000))
    findings = []

    clients = {r["id"]: r for r in conn.execute("SELECT id,child_name,phone,status FROM clients").fetchall()}
    subscriptions = conn.execute(
        "SELECT id,client_id,title,total_lessons,remaining_lessons,price,purchased_at,expires_at,status FROM subscriptions ORDER BY id"
    ).fetchall()
    subscriptions_by_id = {row["id"]: row for row in subscriptions}

    def add(issue, severity, entity, record_id, client_id, sub_id, details):
        client = clients.get(client_id)
        findings.append({
            "issue_type": issue, "severity": severity, "entity_type": entity,
            "record_id": record_id, "client_id": client_id if client_id is not None else "",
            "subscription_id": sub_id if sub_id is not None else "",
            "child_name": (client["child_name"] or "") if client else "",
            "phone": (client["phone"] or "") if client else "",
            "details": details,
        })

    for s in subscriptions:
        sid, cid = s["id"], s["client_id"]
        status = str(s["status"] or "").strip().casefold()
        total, remaining = s["total_lessons"], s["remaining_lessons"]
        if cid not in clients:
            add("subscription_missing_client", "high", "subscription", sid, cid, sid,
                "Абонемент ссылается на отсутствующую карточку клиента")
        if status not in _VALID_SUBSCRIPTION_STATUSES:
            add("unknown_subscription_status", "high", "subscription", sid, cid, sid,
                "Неизвестный статус абонемента; проверьте историю и первичные данные")
        try:
            total_num, remaining_num = int(total), int(remaining)
        except (TypeError, ValueError):
            total_num, remaining_num = None, None
        if total_num is None or total_num <= 0:
            add("invalid_total_lessons", "high", "subscription", sid, cid, sid,
                "Исходное количество занятий отсутствует или некорректно")
        if remaining_num is None or remaining_num < 0:
            add("invalid_remaining_lessons", "high", "subscription", sid, cid, sid,
                "Остаток занятий отсутствует или отрицательный")
        elif total_num is not None and total_num > 0 and remaining_num > total_num:
            add("remaining_exceeds_total", "high", "subscription", sid, cid, sid,
                "Остаток больше исходного количества занятий")
        if status == "active" and remaining_num == 0:
            add("active_without_lessons", "medium", "subscription", sid, cid, sid,
                "Абонемент активен, но занятий осталось 0")
        if status == "completed" and remaining_num is not None and remaining_num > 0:
            add("completed_with_remaining", "medium", "subscription", sid, cid, sid,
                "Абонемент завершён, хотя остаток занятий положительный")
        purchased = _parse_iso(s["purchased_at"])
        if purchased is False:
            add("invalid_purchase_date", "medium", "subscription", sid, cid, sid,
                "Дата покупки не соответствует формату ГГГГ-ММ-ДД")
        elif purchased and purchased > today:
            add("future_purchase_date", "medium", "subscription", sid, cid, sid,
                "Дата покупки находится в будущем")
        expires = _parse_iso(s["expires_at"])
        if expires is False:
            add("invalid_expiry_date", "medium", "subscription", sid, cid, sid,
                "Дата окончания не соответствует формату ГГГГ-ММ-ДД")
        elif status == "active" and expires and expires < today:
            add("expired_but_active", "medium", "subscription", sid, cid, sid,
                "Дата окончания прошла, но статус абонемента остаётся активным")

    sale_counts = {}
    for sale in conn.execute("SELECT id,client_id,subscription_id,status FROM sales WHERE subscription_id IS NOT NULL ORDER BY id").fetchall():
        sid = sale["subscription_id"]
        sale_counts.setdefault(sid, []).append(sale)
        sub = subscriptions_by_id.get(sid)
        if sub and sale["client_id"] != sub["client_id"]:
            add("sale_subscription_client_mismatch", "high", "sale", sale["id"], sale["client_id"], sid,
                "Продажа и связанный абонемент принадлежат разным клиентам")
        if not sub:
            add("sale_missing_subscription", "high", "sale", sale["id"], sale["client_id"], sid,
                "Продажа ссылается на отсутствующий абонемент")
    for sid, sales in sale_counts.items():
        completed = [x for x in sales if str(x["status"] or "").casefold() == "completed"]
        if len(completed) > 1:
            sub = subscriptions_by_id.get(sid)
            cid = sub["client_id"] if sub else completed[0]["client_id"]
            add("multiple_completed_sales", "medium", "subscription", sid, cid, sid,
                f"К одному абонементу привязано {len(completed)} завершённых продаж; проверьте, не задвоена ли оплата")
    for s in subscriptions:
        if not sale_counts.get(s["id"]):
            add("subscription_without_linked_sale", "low", "subscription", s["id"], s["client_id"], s["id"],
                "Не найдена продажа, связанная с абонементом; для старых записей это может быть нормально")

    for a in conn.execute(
        "SELECT id,client_id,subscription_id,lesson_date,status FROM attendance ORDER BY id"
    ).fetchall():
        cid, sid = a["client_id"], a["subscription_id"]
        sub = subscriptions_by_id.get(sid)
        status = str(a["status"] or "").strip().casefold()
        if sub and sub["client_id"] != cid:
            add("attendance_subscription_client_mismatch", "high", "attendance", a["id"], cid, sid,
                "Посещение и привязанный абонемент принадлежат разным клиентам")
        if not sub:
            add("attendance_missing_subscription", "high", "attendance", a["id"], cid, sid,
                "Посещение ссылается на отсутствующий абонемент")
        if status not in _VALID_ATTENDANCE_STATUSES:
            add("unknown_attendance_status", "high", "attendance", a["id"], cid, sid,
                "Неизвестный статус посещения")
        lesson_date = _parse_iso(a["lesson_date"])
        if lesson_date is False:
            add("invalid_attendance_date", "medium", "attendance", a["id"], cid, sid,
                "Дата посещения записана в неверном формате")
        elif status == "planned" and lesson_date and lesson_date < today:
            add("past_planned_attendance", "medium", "attendance", a["id"], cid, sid,
                "Дата занятия прошла, но посещение осталось в статусе «запланировано»")
        if sub and str(sub["status"] or "").casefold() == "cancelled" and status in ("attended", "missed"):
            add("attendance_on_cancelled_subscription", "high", "attendance", a["id"], cid, sid,
                "У отменённого абонемента есть фактическое посещение или пропуск; проверьте возврат и историю")

    severity_order = {"high": 0, "medium": 1, "low": 2}
    findings.sort(key=lambda x: (severity_order[x["severity"]], x["entity_type"], x["issue_type"], int(x["record_id"])))
    return findings[:limit]
