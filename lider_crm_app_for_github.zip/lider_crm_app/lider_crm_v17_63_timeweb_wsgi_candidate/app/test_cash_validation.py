"""Source-level regression checks for cash date validation."""
import pathlib, unittest
SOURCE = pathlib.Path(__file__).with_name('app.py').read_text(encoding='utf-8')

class CashValidationTests(unittest.TestCase):
    def test_cash_expense_rejects_invalid_date(self):
        self.assertIn('date.fromisoformat(d)', SOURCE)
        self.assertIn('Укажите корректную дату расхода', SOURCE)

    def test_cash_expense_rejects_future_date(self):
        self.assertIn('if d>today(): abort(400,"Нельзя записать кассовый расход за будущую дату")', SOURCE)

    def test_shift_close_rejects_invalid_and_future_date(self):
        self.assertIn('date.fromisoformat(shift_date)', SOURCE)
        self.assertIn('Нельзя закрыть смену за будущую дату', SOURCE)

    def test_cash_csv_checks_date_order(self):
        self.assertIn('if start>end: abort(400,"Начальная дата не может быть позже конечной")', SOURCE)

if __name__ == '__main__': unittest.main()
