"""Regression tests for post-close expenses with earlier business dates."""
import sqlite3
import unittest
from pathlib import Path

from retroactive_cash_audit import find_late_cash_expenses

ROOT = Path(__file__).parent


def make_db():
    db = sqlite3.connect(':memory:')
    db.row_factory = sqlite3.Row
    db.executescript('''
      CREATE TABLE cash_shifts(
        id INTEGER PRIMARY KEY, shift_date TEXT, status TEXT,
        closed_at TEXT);
      CREATE TABLE cash_expenses(
        id INTEGER PRIMARY KEY, expense_date TEXT, description TEXT,
        amount INTEGER, payment_method TEXT, created_by_name TEXT,
        created_at TEXT);
    ''')
    return db


class RetroactiveCashAuditTests(unittest.TestCase):
    def test_finds_expense_entered_after_close_for_closed_business_date(self):
        db = make_db()
        db.execute("INSERT INTO cash_shifts VALUES(1,'2026-10-10','closed','2026-10-10 20:00:00')")
        db.execute("INSERT INTO cash_expenses VALUES(1,'2026-10-10','Химия',1200,'cash','Администратор','2026-10-11 09:00:00')")
        rows = find_late_cash_expenses(db)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['affected_shift_id'], 1)
        self.assertEqual(rows[0]['amount'], 1200)
        db.close()

    def test_does_not_flag_expense_entered_before_close(self):
        db = make_db()
        db.execute("INSERT INTO cash_shifts VALUES(1,'2026-10-10','closed','2026-10-10 20:00:00')")
        db.execute("INSERT INTO cash_expenses VALUES(1,'2026-10-10','Уборка',500,'cash','Администратор','2026-10-10 19:00:00')")
        self.assertEqual(find_late_cash_expenses(db), [])
        db.close()

    def test_does_not_flag_expense_for_future_business_date(self):
        db = make_db()
        db.execute("INSERT INTO cash_shifts VALUES(1,'2026-10-10','closed','2026-10-10 20:00:00')")
        db.execute("INSERT INTO cash_expenses VALUES(1,'2026-10-11','Уборка',500,'cash','Администратор','2026-10-12 09:00:00')")
        self.assertEqual(find_late_cash_expenses(db), [])
        db.close()

    def test_same_expense_is_reported_once_across_multiple_closes(self):
        db = make_db()
        db.executemany("INSERT INTO cash_shifts VALUES(?,?,?,?)", [
            (1,'2026-10-10','closed','2026-10-10 20:00:00'),
            (2,'2026-10-11','closed','2026-10-11 20:00:00'),
        ])
        db.execute("INSERT INTO cash_expenses VALUES(1,'2026-10-10','Химия',1200,'cash','Администратор','2026-10-12 09:00:00')")
        rows = find_late_cash_expenses(db)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['affected_shift_id'], 1)
        db.close()

    def test_same_timestamp_closes_still_report_expense_once(self):
        db = make_db()
        db.executemany("INSERT INTO cash_shifts VALUES(?,?,?,?)", [
            (8, '2026-10-10', 'closed', '2026-10-10 20:00:00'),
            (9, '2026-10-10', 'closed', '2026-10-10 20:00:00'),
        ])
        db.execute("INSERT INTO cash_expenses VALUES(1,'2026-10-10','Химия',1200,'cash','Администратор','2026-10-11 09:00:00')")
        rows = find_late_cash_expenses(db)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['affected_shift_id'], 8)
        db.close()

    def test_earliest_eligible_close_is_selected_by_timestamp_then_id(self):
        db = make_db()
        db.executemany("INSERT INTO cash_shifts VALUES(?,?,?,?)", [
            (4, '2026-10-10', 'closed', '2026-10-10 21:00:00'),
            (3, '2026-10-10', 'closed', '2026-10-10 20:00:00'),
            (2, '2026-10-10', 'closed', '2026-10-10 20:00:00'),
        ])
        db.execute("INSERT INTO cash_expenses VALUES(1,'2026-10-10','Химия',1200,'cash','Администратор','2026-10-11 09:00:00')")
        rows = find_late_cash_expenses(db)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['affected_shift_id'], 2)
        db.close()

    def test_only_closed_shifts_count(self):
        db = make_db()
        db.execute("INSERT INTO cash_shifts VALUES(1,'2026-10-10','open','2026-10-10 20:00:00')")
        db.execute("INSERT INTO cash_expenses VALUES(1,'2026-10-10','Химия',1200,'cash','Администратор','2026-10-11 09:00:00')")
        self.assertEqual(find_late_cash_expenses(db), [])
        db.close()

    def test_limit_is_bounded_and_invalid_values_fall_back(self):
        db = make_db()
        self.assertEqual(find_late_cash_expenses(db, 'not a number'), [])
        self.assertEqual(find_late_cash_expenses(db, 5000), [])
        db.close()

    def test_reconciliation_integrates_late_expense_audit(self):
        source = (ROOT / 'app.py').read_text(encoding='utf-8')
        self.assertIn('from retroactive_cash_audit import find_late_cash_expenses', source)
        self.assertIn('find_late_cash_expenses(c)', source)
        self.assertIn('Расходы, внесённые после закрытия смены', source)
        self.assertIn('/reconciliation/late-expenses.csv', source)


if __name__ == '__main__':
    unittest.main()
