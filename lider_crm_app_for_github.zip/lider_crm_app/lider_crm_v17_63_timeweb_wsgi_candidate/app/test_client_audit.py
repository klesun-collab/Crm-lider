import unittest
from datetime import date
import pandas as pd
from audit_gocrm_clients import audit_dataframe, COLS

class ClientAuditTests(unittest.TestCase):
    def make_df(self):
        return pd.DataFrame([
            {COLS['id']:'1', COLS['name']:'Child A', COLS['phone']:'+7 999', COLS['status']:'Активный',
             COLS['registered']:'01.01.2024', COLS['last_payment_date']:'01.02.2024', COLS['last_payment_amount']:'1000',
             COLS['debt']:'-50', COLS['lifetime']:'5000', COLS['next_lesson']:'01.01.2025',
             COLS['last_visit']:'01.03.2024', COLS['first_visit']:'01.02.2024', COLS['subscription']:'абонемент'},
            {COLS['id']:'1', COLS['name']:'Child B', COLS['phone']:'', COLS['status']:'???',
             COLS['registered']:'', COLS['last_payment_date']:'', COLS['last_payment_amount']:'300',
             COLS['debt']:'100', COLS['lifetime']:'0', COLS['next_lesson']:'',
             COLS['last_visit']:'01.01.2027', COLS['first_visit']:'01.02.2027', COLS['subscription']:''},
        ])
    def test_aggregate_anomalies_without_pii(self):
        report = audit_dataframe(self.make_df(), as_of=date(2026, 10, 16))
        self.assertEqual(report['source_rows'], 2)
        self.assertEqual(report['duplicate_source_ids'], 1)
        self.assertEqual(report['missing_phone'], 1)
        self.assertEqual(report['status_counts']['unknown_or_blank'], 1)
        self.assertEqual(report['negative_debt_rows'], 1)
        self.assertEqual(report['rows_with_first_visit_after_last_visit'], 1)
        self.assertEqual(report['rows_with_last_visit_in_future'], 1)
        self.assertEqual(report['rows_with_next_lesson_in_past'], 1)
        self.assertNotIn('Child A', str(report))
        self.assertFalse(report['database_changed'])
    def test_rejects_missing_columns(self):
        with self.assertRaises(RuntimeError):
            audit_dataframe(pd.DataFrame([{'x': 1}]), as_of=date(2026, 1, 1))

if __name__ == '__main__': unittest.main()
