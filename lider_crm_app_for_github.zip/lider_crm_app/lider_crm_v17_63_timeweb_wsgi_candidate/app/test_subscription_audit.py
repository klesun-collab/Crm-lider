import csv, tempfile, unittest
from pathlib import Path
from audit_subscription_review import run_audit

class SubscriptionAuditTests(unittest.TestCase):
    def test_aggregate_only_and_never_approves_import(self):
        with tempfile.TemporaryDirectory() as td:
            f=Path(td)/'private.csv'
            fields=['source_client_id','subscription_no','lesson_type','remaining_lessons','total_lessons_hint','purchase_rub','flags','child_name','source_url','raw_summary']
            rows=[
              {'source_client_id':'1','subscription_no':'99','lesson_type':'Индивидуальный','remaining_lessons':'2','total_lessons_hint':'8','purchase_rub':'0.00','flags':'Нулевая стоимость','child_name':'PRIVATE NAME','source_url':'https://private.invalid','raw_summary':'secret'},
              {'source_client_id':'2','subscription_no':'99','lesson_type':'Групповой','remaining_lessons':'-1','total_lessons_hint':'','purchase_rub':'','flags':'Отрицательный остаток; Количество занятий не определено по названию','child_name':'OTHER NAME','source_url':'https://private.invalid/2','raw_summary':'secret2'},
            ]
            with f.open('w',newline='',encoding='utf-8-sig') as out:
                w=csv.DictWriter(out,fieldnames=fields); w.writeheader(); w.writerows(rows)
            result=run_audit(f)
            self.assertEqual(result['review_rows'],2)
            self.assertEqual(result['checks']['rows_with_duplicate_subscription_number'],1)
            self.assertEqual(result['checks']['negative_remaining_count'],1)
            self.assertEqual(result['checks']['rows_with_zero_purchase_price'],1)
            self.assertEqual(result['subscriptions_created'],0)
            serialized=str(result)
            self.assertNotIn('PRIVATE NAME',serialized)
            self.assertNotIn('private.invalid',serialized)
            self.assertIn('NONE',result['import_decision'])

if __name__=='__main__': unittest.main(verbosity=2)
