import ast
import unittest
from pathlib import Path
SOURCE=Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE=ast.parse(SOURCE)
class TrialLessonRouteContractTests(unittest.TestCase):
    def test_trial_route_is_login_protected_and_available_in_navigation(self):
        fn=next(n for n in TREE.body if isinstance(n,ast.FunctionDef) and n.name=='trial_lessons_page')
        self.assertTrue(any('login_required' in ast.unparse(d) for d in fn.decorator_list))
        self.assertIn('href="/trial-lessons"',SOURCE)
    def test_trial_flow_does_not_create_sales_or_subscriptions(self):
        fn=next(n for n in TREE.body if isinstance(n,ast.FunctionDef) and n.name=='trial_lessons_page')
        text=ast.get_source_segment(SOURCE,fn)
        self.assertIn('book_trial(',text)
        self.assertIn('mark_trial_outcome(',text)
        self.assertNotIn('INSERT INTO sales',text)
        self.assertNotIn('INSERT INTO subscriptions',text)
    def test_booking_schema_migration_is_additive_and_legacy_defaults_regular(self):
        self.assertIn("ADD COLUMN booking_type TEXT NOT NULL DEFAULT 'regular'",SOURCE)
        self.assertIn("ADD COLUMN lead_id INTEGER REFERENCES leads(id)",SOURCE)
        self.assertIn('CREATE TABLE IF NOT EXISTS trial_attendance',SOURCE)
if __name__=='__main__': unittest.main()
