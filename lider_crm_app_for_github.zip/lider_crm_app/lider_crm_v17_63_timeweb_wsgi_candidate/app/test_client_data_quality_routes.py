import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE = ast.parse(SOURCE)


def fn(name):
    node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment(SOURCE, node)


class ClientDataQualityRouteTests(unittest.TestCase):
    def test_page_and_csv_are_manager_only(self):
        for name in ('client_data_quality_page', 'client_data_quality_csv'):
            node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name)
            self.assertIn('manager_required', [ast.unparse(d) for d in node.decorator_list])

    def test_csv_uses_spreadsheet_safe_cells(self):
        source = fn('client_data_quality_csv')
        self.assertIn('safe_csv_row', source)
        self.assertIn('text/csv; charset=utf-8', source)
        self.assertIn('Cache-Control', source)
        self.assertIn('\\ufeff', source)

    def test_csv_uses_fixed_filename(self):
        self.assertIn('lider_client_data_quality.csv', fn('client_data_quality_csv'))

    def test_page_escapes_every_user_controlled_value(self):
        source = fn('client_data_quality_page')
        for field in ('issue_type', 'entity_type', 'child_name', 'parent_name', 'phone', 'details'):
            self.assertIn(f"esc(row['{field}'])", source)

    def test_page_has_manager_navigation_link(self):
        self.assertIn('/client-data-quality', fn('page'))

    def test_routes_do_not_mutate_business_data(self):
        for name in ('client_data_quality_page', 'client_data_quality_csv'):
            source = fn(name).upper()
            for verb in ('INSERT INTO', 'UPDATE ', 'DELETE FROM', 'REPLACE INTO'):
                self.assertNotIn(verb, source)

    def test_page_links_back_to_clients_and_leads(self):
        source = fn('client_data_quality_page')
        self.assertIn("href='/clients'", source)
        self.assertIn("href='/leads'", source)

    def test_page_has_no_store_cache_headers(self):
        source = fn('client_data_quality_page')
        self.assertIn('Cache-Control', source)
        self.assertIn('Pragma', source)

    def test_route_calls_read_only_helper(self):
        for name in ('client_data_quality_page', 'client_data_quality_csv'):
            self.assertIn('build_client_data_quality_audit', fn(name))

    def test_export_has_fixed_header_not_dynamic_columns(self):
        source = fn('client_data_quality_csv')
        self.assertIn('Тип проблемы', source)
        self.assertIn('Что проверить', source)


if __name__ == '__main__':
    unittest.main()
