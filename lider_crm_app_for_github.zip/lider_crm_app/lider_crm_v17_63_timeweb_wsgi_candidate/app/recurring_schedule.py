"""Pure helpers for safely generating weekly recurring lesson dates."""
from datetime import date, timedelta

MAX_RECURRENCE_DAYS = 90


def weekly_dates(start_date, end_date, weekdays, today_date=None):
    """Return ISO dates matching selected weekdays, bounded to a 90-day window.

    weekdays uses Python weekday numbers: Monday=0 through Sunday=6.
    The end date is inclusive. Past dates are never returned.
    """
    try:
        start = date.fromisoformat(str(start_date))
        end = date.fromisoformat(str(end_date))
        today = date.fromisoformat(str(today_date or date.today().isoformat()))
        selected = {int(day) for day in weekdays}
    except (TypeError, ValueError):
        raise ValueError("Проверьте даты и дни недели повторения")
    if start.isoformat() != str(start_date) or end.isoformat() != str(end_date):
        raise ValueError("Используйте корректные даты в формате ГГГГ-ММ-ДД")
    if end < start:
        raise ValueError("Дата окончания повторения должна быть не раньше даты начала")
    if (end - start).days > MAX_RECURRENCE_DAYS:
        raise ValueError("Повторение можно создать максимум на 90 дней вперёд")
    if end < today:
        raise ValueError("Период повторения уже завершился")
    if not selected or any(day not in range(7) for day in selected):
        raise ValueError("Выберите хотя бы один корректный день недели")
    current = max(start, today)
    dates = []
    while current <= end:
        if current.weekday() in selected:
            dates.append(current.isoformat())
        current += timedelta(days=1)
    if not dates:
        raise ValueError("В выбранном периоде нет занятий для указанных дней недели")
    return dates


def shift_start_times(start_time, end_time, duration_minutes=30):
    """Generate slot start times for a same-day shift; end_time is exclusive."""
    from datetime import datetime, timedelta
    try:
        start = datetime.strptime(str(start_time), "%H:%M")
        end = datetime.strptime(str(end_time), "%H:%M")
        duration = int(duration_minutes)
    except (TypeError, ValueError):
        raise ValueError("Укажите корректное время смены и длительность")
    if start.strftime("%H:%M") != str(start_time) or end.strftime("%H:%M") != str(end_time):
        raise ValueError("Время смены должно быть в формате ЧЧ:ММ")
    if duration not in (30, 60):
        raise ValueError("Длительность занятия должна быть 30 или 60 минут")
    if end <= start:
        raise ValueError("Окончание смены должно быть позже начала в пределах одного дня")
    span = int((end - start).total_seconds() // 60)
    if span % duration:
        raise ValueError("Длительность смены должна делиться на длительность занятия без остатка")
    count = span // duration
    if count < 1 or count > 48:
        raise ValueError("В одной смене допустимо от 1 до 48 слотов")
    return [(start + timedelta(minutes=duration * i)).strftime("%H:%M") for i in range(count)]


def create_recurring_slots(conn, trainer_id, dates, start_times, duration_minutes, capacity, kind, notes="", room_id=None, lane_id=None):
    """Create missing trainer slots, validating overlaps; caller owns transaction.

    Returns (created, skipped_existing). Raises ValueError on an overlap so the
    surrounding SQLite transaction can roll back the whole batch atomically.
    """
    from schedule_rules import ensure_no_overlap
    from resource_rules import ensure_resource_no_overlap
    created = skipped = 0
    slot_columns = {row[1] for row in conn.execute("PRAGMA table_info(schedule_slots)").fetchall()}
    supports_resources = {"room_id", "lane_id"}.issubset(slot_columns)
    if (room_id is not None or lane_id is not None) and not supports_resources:
        raise ValueError("Схема базы не поддерживает помещения/дорожки; выполните обновление CRM")
    for slot_date in dates:
        existing_rows = conn.execute(
            "SELECT id,slot_time,duration_minutes FROM schedule_slots WHERE trainer_id=? AND slot_date=?",
            (trainer_id, slot_date),
        ).fetchall()
        existing = [dict(row) for row in existing_rows]
        for slot_time in start_times:
            if any(row["slot_time"] == slot_time for row in existing):
                skipped += 1
                continue
            ensure_no_overlap(slot_time, duration_minutes, existing)
            if room_id is not None:
                room_rows = conn.execute(
                    "SELECT id,slot_time,duration_minutes FROM schedule_slots WHERE room_id=? AND slot_date=?",
                    (room_id, slot_date),
                ).fetchall()
                ensure_resource_no_overlap(slot_time, duration_minutes, room_rows)
            if lane_id is not None:
                lane_rows = conn.execute(
                    "SELECT id,slot_time,duration_minutes FROM schedule_slots WHERE lane_id=? AND slot_date=?",
                    (lane_id, slot_date),
                ).fetchall()
                ensure_resource_no_overlap(slot_time, duration_minutes, lane_rows)
            if supports_resources:
                cursor = conn.execute(
                    "INSERT OR IGNORE INTO schedule_slots(trainer_id,slot_date,slot_time,duration_minutes,capacity,kind,notes,room_id,lane_id) VALUES(?,?,?,?,?,?,?,?,?)",
                    (trainer_id, slot_date, slot_time, duration_minutes, capacity, kind, notes, room_id, lane_id),
                )
            else:
                cursor = conn.execute(
                    "INSERT OR IGNORE INTO schedule_slots(trainer_id,slot_date,slot_time,duration_minutes,capacity,kind,notes) VALUES(?,?,?,?,?,?,?)",
                    (trainer_id, slot_date, slot_time, duration_minutes, capacity, kind, notes),
                )
            if cursor.rowcount:
                existing.append({"id": cursor.lastrowid, "slot_time": slot_time, "duration_minutes": duration_minutes})
                created += 1
            else:
                skipped += 1
    return created, skipped
