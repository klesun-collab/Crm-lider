"""Regression tests for client duplicate candidate export."""
import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")
TREE = ast.parse(SOURCE)

def fn(name):
    node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment(SOURCE, node)

class ClientDuplicateExportTests(unittest.TestCase):
    def test_csv_export_uses_safe_cells_bom_and_no_store(self):
        route = fn("client_duplicates")
        self.assertIn('request.args.get("format") == "csv"', route)
        self.assertIn('safe_csv_row([index, row["id"]', route)
        self.assertIn('"\\ufeff" + output.getvalue()', route)
        self.assertIn('response.headers["Cache-Control"] = "no-store"', route)
        self.assertIn('text/csv; charset=utf-8', route)

    def test_export_keeps_candidates_manual_and_read_only(self):
        route = fn("client_duplicates")
        self.assertIn("не доказательство дубля", route)
        self.assertNotIn("INSERT INTO clients", route)
        self.assertNotIn("UPDATE clients", route)
        self.assertNotIn("DELETE FROM clients", route)

    def test_duplicate_page_has_csv_link(self):
        self.assertIn("/client-duplicates?format=csv", fn("client_duplicates"))

if __name__ == "__main__":
    unittest.main(verbosity=2)
