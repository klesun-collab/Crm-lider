import unittest
from csv_safety import safe_csv_row, safe_csv_value


class CsvSafetyTests(unittest.TestCase):
    def test_formula_markers_are_neutralized_for_text(self):
        for value in ("=1+1", "+SUM(A1:A2)", "-cmd", "@something", "  =1+1", "\t=1+1", "\n=1+1"):
            with self.subTest(value=value):
                self.assertEqual(safe_csv_value(value), "'" + value)

    def test_ordinary_text_and_numeric_values_are_preserved(self):
        self.assertEqual(safe_csv_value("Иван Петров"), "Иван Петров")
        self.assertEqual(safe_csv_value(""), "")
        self.assertEqual(safe_csv_value(0), 0)
        self.assertEqual(safe_csv_value(-450), -450)
        self.assertEqual(safe_csv_row(["=1+1", -450, "Ирина"]), ["'=1+1", -450, "Ирина"])


if __name__ == "__main__":
    unittest.main()
