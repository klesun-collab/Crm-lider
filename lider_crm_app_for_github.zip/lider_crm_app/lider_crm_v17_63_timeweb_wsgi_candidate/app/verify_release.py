#!/usr/bin/env python3
"""Verify hashes of files listed in RELEASE_MANIFEST.json without modifying them."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys


def verify(root: Path) -> tuple[int, list[str]]:
    manifest_path = root / "RELEASE_MANIFEST.json"
    if not manifest_path.is_file():
        return 0, ["RELEASE_MANIFEST.json отсутствует"]
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return 0, [f"манифест не читается: {type(exc).__name__}"]
    failures = []
    entries = manifest.get("files")
    if not isinstance(entries, list) or not entries:
        return 0, ["в манифесте нет списка файлов"]
    checked = 0
    for item in entries:
        rel = item.get("path", "")
        expected = item.get("sha256", "")
        candidate = (root / rel).resolve()
        if not rel or Path(rel).is_absolute() or root.resolve() not in candidate.parents:
            failures.append(f"небезопасный путь в манифесте: {rel!r}")
            continue
        if not candidate.is_file():
            failures.append(f"файл отсутствует: {rel}")
            continue
        digest = hashlib.sha256(candidate.read_bytes()).hexdigest()
        if digest != expected:
            failures.append(f"SHA-256 не совпадает: {rel}")
        checked += 1
    return checked, failures


def main() -> int:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parent).resolve()
    checked, failures = verify(root)
    for failure in failures:
        print("FAIL | " + failure)
    print(f"Проверено файлов: {checked}; ошибок: {len(failures)}")
    if failures:
        return 1
    print("Хэши релизных файлов совпадают.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
