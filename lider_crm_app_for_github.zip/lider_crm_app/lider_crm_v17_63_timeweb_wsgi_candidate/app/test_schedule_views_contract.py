from pathlib import Path
import unittest

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")


class ScheduleViewsContractTests(unittest.TestCase):
    def test_day_14_day_list_and_month_views_are_available(self):
        self.assertIn('if view not in ("day","list","calendar","month")', SOURCE)
        self.assertIn("range_end=range_start+timedelta(days=13)", SOURCE)
        self.assertIn("Календарь:", SOURCE)
        self.assertIn("Загрузка по", SOURCE)
        self.assertIn("view=calendar", SOURCE)
        self.assertIn("Список на 14 дней", SOURCE)

    def test_calendar_uses_color_coded_lesson_types_and_preserves_day_workflow(self):
        self.assertIn(".slot-chip.group", SOURCE)
        self.assertIn(".slot-chip.individual", SOURCE)
        self.assertIn("href='/schedule?day={iso}'", SOURCE)

    def test_list_can_group_by_trainer_or_physical_resource(self):
        self.assertIn('name=\'group_by\'', SOURCE)
        self.assertIn("row['room_name'],row['lane_name']", SOURCE)


if __name__ == "__main__":
    unittest.main()
