"""Regression checks: logout must not be triggerable by a cross-site GET."""
import pathlib
import unittest

SOURCE = pathlib.Path(__file__).with_name("app.py").read_text(encoding="utf-8")

class LogoutSecurityTests(unittest.TestCase):
    def test_logout_is_post_only_and_requires_authentication(self):
        block = SOURCE.split('@app.post("/logout")', 1)[1].split('@app.get("/")', 1)[0]
        self.assertIn('@login_required', block)
        self.assertNotIn('@app.get("/logout")', SOURCE)
        self.assertIn('session.clear()', block)

    def test_navigation_uses_post_form_for_logout(self):
        self.assertIn('<form method="post" action="/logout"', SOURCE)
        self.assertIn('name="_csrf" value="{csrf}"', SOURCE)

if __name__ == "__main__":
    unittest.main()
