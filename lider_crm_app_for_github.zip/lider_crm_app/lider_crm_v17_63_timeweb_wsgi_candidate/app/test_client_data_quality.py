import sqlite3
import unittest
from client_data_quality import FIELDS, build_client_data_quality_audit, normalize_ru_phone


class ClientDataQualityTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
        CREATE TABLE clients(id INTEGER PRIMARY KEY,child_name TEXT,parent_name TEXT,phone TEXT,birth_date TEXT,status TEXT);
        CREATE TABLE leads(id INTEGER PRIMARY KEY,parent_name TEXT,child_name TEXT,phone TEXT,source TEXT,status TEXT,next_contact TEXT,client_id INTEGER);
        INSERT INTO clients VALUES(1,'Аня','Мама','+7 (999) 000-00-01','2018-04-01','active');
        INSERT INTO clients VALUES(2,'Борис','Мама','8-999-000-00-01','2019-05-01','active');
        INSERT INTO clients VALUES(3,'Вика','Папа','123','2028-01-01','active');
        INSERT INTO clients VALUES(4,'Глеб','Папа','+79990000004','31.12.2018','active');
        INSERT INTO leads VALUES(1,'Мама','Лена','123','','new','',NULL);
        INSERT INTO leads VALUES(2,'Мама','Оля','+79990000006','Авито','converted','',NULL);
        INSERT INTO leads VALUES(3,'Мама','Катя','+79990000007','Сайт','lost','',NULL);
        ''')

    def tearDown(self):
        self.db.close()

    def test_normalizes_russian_phone_variants(self):
        self.assertEqual(normalize_ru_phone('+7 (999) 000-00-01'), '79990000001')
        self.assertEqual(normalize_ru_phone('8-999-000-00-01'), '79990000001')
        self.assertEqual(normalize_ru_phone('9990000001'), '79990000001')

    def test_rejects_short_and_non_russian_numbers_as_match_keys(self):
        for value in ('123', '', '899000001', '+1 202 555 0100'):
            with self.subTest(value=value):
                self.assertEqual(normalize_ru_phone(value), '')

    def test_flags_invalid_phone_without_exposing_digits_as_error(self):
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        invalid = [r for r in rows if r['issue_type'] == 'invalid_client_phone']
        self.assertEqual([r['record_id'] for r in invalid], [3])

    def test_flags_future_birth_date(self):
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        self.assertIn(3, [r['record_id'] for r in rows if r['issue_type'] == 'future_birth_date'])

    def test_flags_unparseable_birth_date(self):
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        self.assertIn(4, [r['record_id'] for r in rows if r['issue_type'] == 'invalid_birth_date'])

    def test_shared_phone_is_review_hint_not_duplicate_claim(self):
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        shared = [r for r in rows if r['issue_type'] == 'shared_phone_review']
        self.assertEqual({r['record_id'] for r in shared}, {1, 2})
        self.assertTrue(all(r['severity'] == 'low' for r in shared))

    def test_open_lead_without_source_is_flagged(self):
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        self.assertIn(1, [r['record_id'] for r in rows if r['issue_type'] == 'lead_without_source'])

    def test_open_lead_without_next_contact_is_flagged(self):
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        self.assertIn(1, [r['record_id'] for r in rows if r['issue_type'] == 'lead_without_next_contact'])

    def test_converted_lead_without_client_is_flagged(self):
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        self.assertIn(2, [r['record_id'] for r in rows if r['issue_type'] == 'converted_lead_without_client'])

    def test_closed_lead_does_not_require_source_or_next_contact(self):
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        for issue in rows:
            if issue['entity_type'] == 'lead' and issue['record_id'] == 3:
                self.assertNotIn(issue['issue_type'], ('lead_without_source', 'lead_without_next_contact'))

    def test_output_schema_is_stable(self):
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        self.assertTrue(rows)
        self.assertEqual(tuple(rows[0].keys()), FIELDS)

    def test_invalid_date_is_rejected(self):
        with self.assertRaises(ValueError):
            build_client_data_quality_audit(self.db, 'yesterday')

    def test_limit_is_clamped_to_at_least_one(self):
        rows = build_client_data_quality_audit(self.db, '2026-10-17', limit=0)
        self.assertLessEqual(len(rows), 1)

    def test_invalid_limit_falls_back_to_default(self):
        self.assertTrue(build_client_data_quality_audit(self.db, '2026-10-17', limit='bad'))

    def test_limit_is_capped(self):
        self.assertLessEqual(len(build_client_data_quality_audit(self.db, '2026-10-17', limit=100000)), 5000)

    def test_audit_is_read_only(self):
        before = (self.db.execute('SELECT COUNT(*) FROM clients').fetchone()[0], self.db.execute('SELECT COUNT(*) FROM leads').fetchone()[0])
        build_client_data_quality_audit(self.db, '2026-10-17')
        after = (self.db.execute('SELECT COUNT(*) FROM clients').fetchone()[0], self.db.execute('SELECT COUNT(*) FROM leads').fetchone()[0])
        self.assertEqual(before, after)

    def test_does_not_flag_blank_birth_date(self):
        self.db.execute("UPDATE clients SET birth_date='' WHERE id=1")
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        self.assertNotIn(1, [r['record_id'] for r in rows if r['issue_type'] in ('invalid_birth_date','future_birth_date','unusually_old_birth_date')])

    def test_does_not_flag_valid_birth_date(self):
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        self.assertNotIn(1, [r['record_id'] for r in rows if r['issue_type'] in ('invalid_birth_date','future_birth_date','unusually_old_birth_date')])

    def test_does_not_flag_unique_valid_phone_as_shared(self):
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        self.assertNotIn(4, [r['record_id'] for r in rows if r['issue_type'] == 'shared_phone_review'])

    def test_severity_sort_places_high_before_medium_before_low(self):
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        ranks = {'high': 0, 'medium': 1, 'low': 2}
        self.assertEqual([r['severity'] for r in rows], sorted((r['severity'] for r in rows), key=ranks.get))

    def test_all_rows_have_stable_fields(self):
        for row in build_client_data_quality_audit(self.db, '2026-10-17'):
            self.assertEqual(tuple(row.keys()), FIELDS)

    def test_issue_records_identify_entity(self):
        for row in build_client_data_quality_audit(self.db, '2026-10-17'):
            self.assertIn(row['entity_type'], ('client', 'lead'))
            self.assertGreater(row['record_id'], 0)

    def test_shared_phone_report_never_says_automatic_merge(self):
        rows = [r for r in build_client_data_quality_audit(self.db, '2026-10-17') if r['issue_type'] == 'shared_phone_review']
        self.assertTrue(all('проверьте' in r['details'].casefold() for r in rows))

    def test_unknown_lead_status_is_treated_as_open_for_review(self):
        self.db.execute("INSERT INTO leads VALUES(4,'Родитель','Ребёнок','+79990000008','','legacy_unknown','',NULL)")
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        self.assertIn(4, [r['record_id'] for r in rows if r['issue_type'] == 'lead_without_next_contact'])

    def test_whitespace_source_is_missing(self):
        self.db.execute("UPDATE leads SET source='   ' WHERE id=1")
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        self.assertIn(1, [r['record_id'] for r in rows if r['issue_type'] == 'lead_without_source'])

    def test_whitespace_next_contact_is_missing(self):
        self.db.execute("UPDATE leads SET next_contact='   ' WHERE id=1")
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        self.assertIn(1, [r['record_id'] for r in rows if r['issue_type'] == 'lead_without_next_contact'])

    def test_phone_normalization_ignores_punctuation(self):
        self.assertEqual(normalize_ru_phone('7.999.000.00.01'), '79990000001')

    def test_valid_8_prefix_matches_7_prefix(self):
        self.assertEqual(normalize_ru_phone('8 999 000 00 01'), normalize_ru_phone('+7 999 000 00 01'))

    def test_invalid_birth_date_is_not_silently_treated_as_missing(self):
        self.db.execute("UPDATE clients SET birth_date='2024-02-30' WHERE id=1")
        rows = build_client_data_quality_audit(self.db, '2026-10-17')
        self.assertIn(1, [r['record_id'] for r in rows if r['issue_type'] == 'invalid_birth_date'])

    def test_issue_details_are_nonempty(self):
        self.assertTrue(all(r['details'].strip() for r in build_client_data_quality_audit(self.db, '2026-10-17')))

    def test_issue_severity_uses_known_levels(self):
        self.assertTrue(all(r['severity'] in ('high','medium','low') for r in build_client_data_quality_audit(self.db, '2026-10-17')))

    def test_audit_handles_empty_tables(self):
        self.db.execute('DELETE FROM clients')
        self.db.execute('DELETE FROM leads')
        self.assertEqual(build_client_data_quality_audit(self.db, '2026-10-17'), [])


if __name__ == '__main__':
    unittest.main()
