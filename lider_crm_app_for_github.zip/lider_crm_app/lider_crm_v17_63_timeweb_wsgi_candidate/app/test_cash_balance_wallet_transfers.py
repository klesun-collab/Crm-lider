import sqlite3
import unittest
from cash_balance import balances_as_of

class CashBalanceWalletTransferTests(unittest.TestCase):
    def setUp(self):
        self.db=sqlite3.connect(':memory:')
        self.db.row_factory=sqlite3.Row
        self.db.executescript('''
        CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE cash_shifts(id INTEGER PRIMARY KEY,shift_date TEXT,status TEXT,actual_cash INTEGER,actual_noncash INTEGER,closed_at TEXT);
        CREATE TABLE sales(id INTEGER PRIMARY KEY,payment_method TEXT,amount INTEGER,status TEXT,created_at TEXT);
        CREATE TABLE cash_expenses(id INTEGER PRIMARY KEY,payment_method TEXT,amount INTEGER,created_at TEXT);
        CREATE TABLE cash_other_income(id INTEGER PRIMARY KEY,payment_method TEXT,amount INTEGER,created_at TEXT);
        CREATE TABLE cash_wallets(id INTEGER PRIMARY KEY,name TEXT,payment_method TEXT);
        CREATE TABLE wallet_transfers(id INTEGER PRIMARY KEY,from_wallet_id INTEGER,to_wallet_id INTEGER,amount INTEGER,created_at TEXT);
        INSERT INTO settings VALUES('opening_cash','1000'),('opening_non_cash','500');
        INSERT INTO cash_wallets VALUES(1,'Cash','cash'),(2,'Card','card'),(3,'QR','qr');
        INSERT INTO wallet_transfers VALUES(1,1,2,300,'2026-10-03T10:00:00');
        INSERT INTO wallet_transfers VALUES(2,2,3,50,'2026-10-03T11:00:00');
        ''')
    def tearDown(self): self.db.close()

    def test_other_income_and_transfers_move_aggregate_balances(self):
        self.db.execute("INSERT INTO cash_other_income VALUES(1,'cash',100,'2026-10-03T12:00:00')")
        self.assertEqual(balances_as_of(self.db,'2026-10-03'),(800,800))

    def test_transfer_after_physical_close_rolls_forward_from_counted_balance(self):
        self.db.execute("INSERT INTO cash_shifts VALUES(1,'2026-10-03','closed',700,800,'2026-10-03T18:00:00')")
        self.db.execute("INSERT INTO wallet_transfers VALUES(3,1,2,100,'2026-10-04T10:00:00')")
        self.db.execute("INSERT INTO cash_other_income VALUES(1,'cash',80,'2026-10-04T11:00:00')")
        self.assertEqual(balances_as_of(self.db,'2026-10-04'),(680,900))

if __name__=='__main__': unittest.main()
