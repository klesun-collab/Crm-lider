"""Validation and read-only balance aggregation for configurable cash wallets."""

PAYMENT_METHODS = {"cash", "card", "transfer", "qr"}


def normalize_wallet(name, payment_method, opening_balance):
    name = str(name or "").strip()
    if not name or len(name) > 100:
        raise ValueError("Название счёта обязательно и не должно превышать 100 символов")
    if payment_method not in PAYMENT_METHODS:
        raise ValueError("Выберите корректную категорию оплаты")
    try:
        opening = int(opening_balance)
    except (TypeError, ValueError) as exc:
        raise ValueError("Начальный остаток должен быть целым числом в рублях") from exc
    if opening < 0 or opening > 1_000_000_000:
        raise ValueError("Начальный остаток должен быть от 0 до 1 000 000 000 ₽")
    return {"name": name, "payment_method": payment_method, "opening_balance": opening}


def normalize_wallet_transfer(from_wallet_id, to_wallet_id, amount, note):
    try:
        source = int(from_wallet_id)
        target = int(to_wallet_id)
        value = int(amount)
    except (TypeError, ValueError) as exc:
        raise ValueError("Выберите счета и укажите сумму перевода") from exc
    note = str(note or "").strip()
    if source < 1 or target < 1 or source == target:
        raise ValueError("Счета перевода должны быть разными")
    if value < 1 or value > 1_000_000_000:
        raise ValueError("Сумма перевода должна быть от 1 до 1 000 000 000 ₽")
    if not note or len(note) > 200:
        raise ValueError("Укажите назначение перевода (до 200 символов)")
    return {"from_wallet_id": source, "to_wallet_id": target, "amount": value, "note": note}


def wallet_balance_rows(connection):
    """Compute wallet balances from immutable source operations and opening balances."""
    rows = connection.execute(
        """SELECT w.*,
           COALESCE((SELECT SUM(CASE WHEN s.status='completed' THEN s.amount WHEN s.status='refund' THEN -s.amount ELSE 0 END)
                     FROM sales s WHERE s.wallet_id=w.id),0) AS net_sales,
           COALESCE((SELECT SUM(i.amount) FROM cash_other_income i WHERE i.wallet_id=w.id),0) AS other_income,
           COALESCE((SELECT SUM(e.amount) FROM cash_expenses e WHERE e.wallet_id=w.id),0) AS expenses,
           COALESCE((SELECT SUM(t.amount) FROM wallet_transfers t WHERE t.to_wallet_id=w.id),0) AS transfers_in,
           COALESCE((SELECT SUM(t.amount) FROM wallet_transfers t WHERE t.from_wallet_id=w.id),0) AS transfers_out,
           EXISTS(SELECT 1 FROM sales s WHERE s.wallet_id=w.id) OR
           EXISTS(SELECT 1 FROM cash_expenses e WHERE e.wallet_id=w.id) OR
           EXISTS(SELECT 1 FROM cash_other_income i WHERE i.wallet_id=w.id) OR
           EXISTS(SELECT 1 FROM wallet_transfers t WHERE t.from_wallet_id=w.id OR t.to_wallet_id=w.id) AS has_operations
           FROM cash_wallets w ORDER BY w.active DESC,w.name COLLATE NOCASE"""
    ).fetchall()
    result = []
    for row in rows:
        item = dict(row)
        item["balance"] = item["opening_balance"] + item["net_sales"] + item["other_income"] - item["expenses"] + item["transfers_in"] - item["transfers_out"]
        result.append(item)
    return result


def unassigned_legacy_totals(connection):
    """Read-only totals for pre-wallet sales/expenses; never backfills legacy records."""
    sales = connection.execute(
        """SELECT payment_method,
           COALESCE(SUM(CASE WHEN status='completed' THEN amount WHEN status='refund' THEN -amount ELSE 0 END),0) amount
           FROM sales WHERE wallet_id IS NULL GROUP BY payment_method"""
    ).fetchall()
    expenses = connection.execute(
        "SELECT payment_method,COALESCE(SUM(amount),0) amount FROM cash_expenses WHERE wallet_id IS NULL GROUP BY payment_method"
    ).fetchall()
    other_income = connection.execute(
        "SELECT payment_method,COALESCE(SUM(amount),0) amount FROM cash_other_income WHERE wallet_id IS NULL GROUP BY payment_method"
    ).fetchall()
    result = {}
    for method in sorted(PAYMENT_METHODS):
        result[method] = {
            "sales": next((r["amount"] for r in sales if r["payment_method"] == method), 0) or 0,
            "other_income": next((r["amount"] for r in other_income if r["payment_method"] == method), 0) or 0,
            "expenses": next((r["amount"] for r in expenses if r["payment_method"] == method), 0) or 0,
        }
    return result


def transfer_balance_deltas(connection, *, lower_bound=None, upper_bound=None, business_date=None):
    """Return aggregate cash/noncash balance changes caused by internal wallet transfers."""
    tables = {r[0] for r in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if not {"wallet_transfers", "cash_wallets"} <= tables:
        return 0, 0
    sql = """SELECT fw.payment_method AS from_method,tw.payment_method AS to_method,t.amount
             FROM wallet_transfers t JOIN cash_wallets fw ON fw.id=t.from_wallet_id
             JOIN cash_wallets tw ON tw.id=t.to_wallet_id WHERE 1=1"""
    args = []
    if lower_bound is not None:
        sql += " AND t.created_at>?"
        args.append(lower_bound)
    if upper_bound is not None:
        sql += " AND t.created_at<=?"
        args.append(upper_bound)
    if business_date is not None:
        sql += " AND substr(t.created_at,1,10)=?"
        args.append(business_date)
    rows = connection.execute(sql, args).fetchall()
    cash_delta = 0
    noncash_delta = 0
    for row in rows:
        amount = int(row["amount"])
        if row["from_method"] == "cash":
            cash_delta -= amount
        else:
            noncash_delta -= amount
        if row["to_method"] == "cash":
            cash_delta += amount
        else:
            noncash_delta += amount
    return cash_delta, noncash_delta
