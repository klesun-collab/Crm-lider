"""Regression tests: ambiguous group sessions must not enter payable totals/CSV."""
import sqlite3
import unittest
from pathlib import Path

ROOT = Path(__file__).parent
SOURCE = (ROOT / "app.py").read_text(encoding="utf-8")

class PayrollAmbiguousHoldTests(unittest.TestCase):
    def test_payroll_and_csv_share_canonical_session_aggregation(self):
        payroll = SOURCE[SOURCE.index('def payroll():'):SOURCE.index('@app.get("/payroll.csv")')]
        csv_route = SOURCE[SOURCE.index('def payroll_csv():'):SOURCE.index('@app.get("/reports")')]
        helper = (ROOT / 'payroll_calculation.py').read_text(encoding='utf-8')
        self.assertIn('Неоднозначные слоты временно исключаются', payroll)
        self.assertIn('get_payroll_sessions(c,start,end)', payroll)
        self.assertIn('get_ambiguous_payroll_slot_count(c,start,end)', payroll)
        self.assertIn('get_payroll_sessions(c,start,end)', csv_route)
        self.assertIn('GROUP BY schedule_slot_id, lesson_date, lesson_time', helper)
        self.assertIn('bad.lesson_date=a.lesson_date AND bad.lesson_time=a.lesson_time', helper)
        self.assertIn('schedule_slot_id, a.lesson_date, a.lesson_time', helper)

    def test_filter_keeps_valid_group_and_legacy_sessions_only(self):
        db = sqlite3.connect(':memory:')
        db.executescript('''
          CREATE TABLE attendance(id INTEGER, client_id INTEGER, trainer TEXT, lesson_date TEXT,
            lesson_time TEXT, status TEXT, rate_snapshot INTEGER, schedule_slot_id INTEGER);
          INSERT INTO attendance VALUES
            (1,1,'Анна','2026-10-01','10:00','attended',400,10),
            (2,2,'Анна','2026-10-01','10:00','attended',400,10),
            (3,3,'Анна','2026-10-01','10:30','attended',400,11),
            (4,4,'Борис','2026-10-01','10:30','attended',430,11),
            (5,5,'Сергей','2026-10-01','11:00','attended',400,NULL);
        ''')
        query = '''SELECT schedule_slot_id, COUNT(*) n FROM attendance a
          WHERE a.status='attended' AND a.lesson_date BETWEEN ? AND ?
          AND (a.schedule_slot_id IS NULL OR a.schedule_slot_id NOT IN (
            SELECT schedule_slot_id FROM attendance WHERE status='attended'
              AND lesson_date BETWEEN ? AND ? AND schedule_slot_id IS NOT NULL
            GROUP BY schedule_slot_id
            HAVING COUNT(DISTINCT COALESCE(NULLIF(TRIM(trainer),''),'Не указан'))>1
                OR COUNT(DISTINCT rate_snapshot)>1))
          GROUP BY schedule_slot_id ORDER BY schedule_slot_id'''
        rows = db.execute(query, ('2026-10-01','2026-10-31','2026-10-01','2026-10-31')).fetchall()
        self.assertEqual(rows, [(None, 1), (10, 2)])
        db.close()

if __name__ == '__main__':
    unittest.main()
