import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")
TREE = ast.parse(SOURCE)

class SubscriptionRenewalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "subscription_renewals")
        cls.source = ast.get_source_segment(SOURCE, cls.node)

    def test_route_is_login_protected_and_read_only(self):
        route = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "subscription_renewals")
        decorators = [ast.unparse(d) for d in route.decorator_list]
        self.assertIn("login_required", decorators)
        self.assertNotIn("INSERT INTO", self.source)
        self.assertNotIn("UPDATE ", self.source)
        self.assertNotIn("DELETE FROM", self.source)

    def test_filters_low_remaining_or_expiring_subscriptions(self):
        helper = Path(__file__).with_name("renewal_worklist.py").read_text(encoding="utf-8")
        self.assertIn("s.remaining_lessons<=2", helper)
        self.assertIn("s.expires_at<=?", helper)
        self.assertIn("s.status='active'", helper)
        self.assertIn("build_renewal_worklist", self.source)

    def test_shows_contact_and_client_card_link(self):
        self.assertIn("tel:{esc(r['phone'])}", self.source)
        self.assertIn("/client/{r['client_id']}", self.source)

    def test_navigation_has_renewals_link(self):
        self.assertIn('href="/renewals">Продления', SOURCE)

if __name__ == "__main__":
    unittest.main()
