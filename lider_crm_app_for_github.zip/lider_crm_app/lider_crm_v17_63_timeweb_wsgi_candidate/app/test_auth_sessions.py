"""Regression tests for account validation and revocable authenticated sessions."""
from pathlib import Path
import sqlite3
import tempfile
import unittest
from user_rules import ensure_auth_version_column, auth_version_matches

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")


class AuthSessionTests(unittest.TestCase):
    def test_existing_user_database_gets_auth_version_migration(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "legacy.sqlite3"
            with sqlite3.connect(path) as db:
                db.execute("CREATE TABLE users(id INTEGER PRIMARY KEY, username TEXT NOT NULL)")
                db.execute("INSERT INTO users(username) VALUES('legacy')")
                self.assertTrue(ensure_auth_version_column(db))
                self.assertFalse(ensure_auth_version_column(db))
                self.assertEqual(db.execute("SELECT auth_version FROM users WHERE id=1").fetchone()[0], 1)

    def test_auth_version_comparison_fails_closed(self):
        self.assertTrue(auth_version_matches(3, 3))
        for old, current in ((2, 3), (None, 1), ("1", 1), (True, 1), (1, False)):
            with self.subTest(old=old, current=current):
                self.assertFalse(auth_version_matches(old, current))

    def test_successful_login_stores_database_auth_version(self):
        login = SOURCE.split('def login():', 1)[1].split('def login_form():', 1)[0]
        self.assertIn('session["auth_version"]=u["auth_version"]', login)

    def test_stale_session_version_is_rejected(self):
        user = SOURCE.split('def current_user():', 1)[1].split('def is_current_manager():', 1)[0]
        self.assertIn('auth_version_matches(session.get("auth_version"), user["auth_version"])', user)

    def test_password_change_revokes_other_sessions(self):
        block = SOURCE.split('def change_password():', 1)[1].split('@app.get("/dashboard")', 1)[0]
        self.assertIn('auth_version=auth_version+1', block)
        self.assertIn('session.clear()', block)
        self.assertIn('остальные сеансы также завершены', block)

    def test_disabling_or_reenabling_account_revokes_old_sessions(self):
        block = SOURCE.split('def manage_users_page():', 1)[1].split('@app.post("/settings/rates")', 1)[0]
        self.assertIn('UPDATE users SET active=?,auth_version=auth_version+1 WHERE id=?', block)

    def test_setup_uses_same_strict_account_validation_as_admin_creation(self):
        setup = SOURCE.split('def setup():', 1)[1].split('LOGIN_WINDOW_MINUTES', 1)[0]
        self.assertIn('username=validate_new_admin(username,password)', setup)
        self.assertIn('except ValueError as exc:', setup)

    def test_login_oversized_input_guard_is_not_duplicated(self):
        login = SOURCE.split('def login():', 1)[1].split('def login_form():', 1)[0]
        self.assertEqual(login.count('if len(username)>100 or len(password)>1024:'), 1)

    def test_audit_log_is_manager_only(self):
        block = SOURCE.split('@app.get("/audit")', 1)[1].split('def audit_page():', 1)[0]
        self.assertIn('@manager_required', block)

    def test_audit_link_only_appears_for_manager(self):
        nav = SOURCE.split('def page(title, body):', 1)[1].split('@app.route("/setup"', 1)[0]
        self.assertIn("'<a href=\"/settings\">Настройки</a><a href=\"/audit\">Журнал аудита</a>' if u['role']=='manager' else ''", nav)


if __name__ == "__main__":
    unittest.main()
