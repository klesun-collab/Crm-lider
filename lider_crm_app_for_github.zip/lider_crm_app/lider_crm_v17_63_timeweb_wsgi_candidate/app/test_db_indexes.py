import ast
import sqlite3
import unittest
from pathlib import Path
from db_indexes import INDEX_DDL, ensure_indexes


class CRMIndexTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        # Minimal post-migration schema containing columns used by the indexes.
        self.db.executescript('''
            CREATE TABLE clients(id INTEGER PRIMARY KEY, phone TEXT, child_name TEXT);
            CREATE TABLE subscriptions(id INTEGER PRIMARY KEY, client_id INTEGER, status TEXT, expires_at TEXT);
            CREATE TABLE attendance(id INTEGER PRIMARY KEY, lesson_date TEXT, status TEXT, schedule_slot_id INTEGER);
            CREATE TABLE sales(id INTEGER PRIMARY KEY, created_at TEXT, status TEXT, client_id INTEGER, product_id INTEGER);
            CREATE TABLE cash_expenses(id INTEGER PRIMARY KEY, expense_date TEXT, created_at TEXT);
            CREATE TABLE cash_shifts(id INTEGER PRIMARY KEY, status TEXT, closed_at TEXT, shift_date TEXT);
            CREATE TABLE schedule_slots(id INTEGER PRIMARY KEY, slot_date TEXT, slot_time TEXT);
            CREATE TABLE bookings(id INTEGER PRIMARY KEY, slot_id INTEGER, status TEXT, client_id INTEGER);
            CREATE TABLE tasks(id INTEGER PRIMARY KEY, status TEXT, due_at TEXT, assigned_to INTEGER);
            CREATE TABLE leads(id INTEGER PRIMARY KEY, status TEXT, next_contact TEXT, phone TEXT);
            CREATE TABLE audit_log(id INTEGER PRIMARY KEY, created_at TEXT, entity TEXT, entity_id INTEGER);
            CREATE TABLE refund_requests(id INTEGER PRIMARY KEY, sale_id INTEGER, status TEXT);
            CREATE TABLE stock_movements(id INTEGER PRIMARY KEY, product_id INTEGER, created_at TEXT);
            CREATE TABLE login_attempts(id INTEGER PRIMARY KEY, username TEXT, remote_addr TEXT, attempted_at TEXT, succeeded INTEGER);
        ''')

    def tearDown(self):
        self.db.close()

    def test_indexes_are_created_idempotently(self):
        ensure_indexes(self.db)
        ensure_indexes(self.db)
        names = {row[0] for row in self.db.execute("SELECT name FROM sqlite_master WHERE type='index'")}
        expected = {statement.split('INDEX IF NOT EXISTS ', 1)[1].split(' ON ', 1)[0] for statement in INDEX_DDL}
        self.assertTrue(expected.issubset(names), sorted(expected - names))

    def test_high_value_queries_can_use_lookup_indexes(self):
        ensure_indexes(self.db)
        plans = [
            self.db.execute("EXPLAIN QUERY PLAN SELECT * FROM clients WHERE phone=?", ('555',)).fetchall(),
            self.db.execute("EXPLAIN QUERY PLAN SELECT * FROM attendance WHERE lesson_date=? AND status=?", ('2026-10-01','attended')).fetchall(),
            self.db.execute("EXPLAIN QUERY PLAN SELECT * FROM sales WHERE created_at BETWEEN ? AND ? AND status=?", ('2026-10-01','2026-10-31','completed')).fetchall(),
            self.db.execute("EXPLAIN QUERY PLAN SELECT * FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? AND status=?", ('2026-10-01','2026-10-31','completed')).fetchall(),
            self.db.execute("EXPLAIN QUERY PLAN SELECT * FROM bookings WHERE slot_id=? AND status=?", (1,'booked')).fetchall(),
        ]
        for plan in plans:
            self.assertTrue(any('USING INDEX' in row[3].upper() or 'USING COVERING INDEX' in row[3].upper() for row in plan), plan)

    def test_indexes_apply_to_actual_application_schema(self):
        source = (Path(__file__).with_name('app.py')).read_text(encoding='utf-8')
        tree = ast.parse(source)
        init_fn = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'init_db')
        schema_sql = None
        for node in ast.walk(init_fn):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'executescript':
                if node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
                    schema_sql = node.args[0].value
                    break
        self.assertIsNotNone(schema_sql)
        app_db = sqlite3.connect(':memory:')
        try:
            app_db.execute('PRAGMA foreign_keys=ON')
            app_db.executescript(schema_sql)
            ensure_indexes(app_db)
            actual = {row[0] for row in app_db.execute("SELECT name FROM sqlite_master WHERE type='index'")}
            expected = {statement.split('INDEX IF NOT EXISTS ', 1)[1].split(' ON ', 1)[0] for statement in INDEX_DDL}
            self.assertTrue(expected.issubset(actual), sorted(expected - actual))
        finally:
            app_db.close()

    def test_index_migration_contains_no_destructive_statements(self):
        self.assertTrue(all(statement.lstrip().upper().startswith('CREATE INDEX IF NOT EXISTS') for statement in INDEX_DDL))
        self.assertFalse(any('DROP ' in statement.upper() or 'DELETE ' in statement.upper() for statement in INDEX_DDL))


if __name__ == '__main__':
    unittest.main()
