import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")
TREE = ast.parse(SOURCE)

class ClientReactivationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.route = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "client_reactivation")
        cls.source = ast.get_source_segment(SOURCE, cls.route)
        cls.decorators = [ast.unparse(d) for d in cls.route.decorator_list]

    def test_route_requires_login_and_has_post_contact_log(self):
        self.assertIn("login_required", self.decorators)
        self.assertIn("INSERT INTO client_outreach", self.source)
        self.assertIn("client.outreach_recorded", self.source)

    def test_candidates_include_former_clients_and_stale_visits(self):
        self.assertIn("('inactive','archived','lost')", self.source)
        self.assertIn("a.status='attended'", self.source)
        self.assertIn("last_visit<cutoff", self.source)

    def test_recent_contacts_hidden_by_default(self):
        self.assertIn("timedelta(days=7)", self.source)
        self.assertIn("if recent_contact and not show_recent", self.source)

    def test_returned_outcome_reactivates_status_only(self):
        self.assertIn("if outcome==\"returned\"", self.source)
        self.assertIn("UPDATE clients SET status='active'", self.source)
        self.assertNotIn("INSERT INTO sales", self.source)
        self.assertNotIn("INSERT INTO subscriptions", self.source)

    def test_navigation_and_backup_include_contact_history(self):
        self.assertIn('href="/reactivation">Возврат клиентов', SOURCE)
        self.assertIn('exportable_table_names(c)', SOURCE)
        self.assertIn('CREATE TABLE IF NOT EXISTS client_outreach', SOURCE)

if __name__ == "__main__":
    unittest.main()
