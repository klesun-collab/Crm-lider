import ast
import sqlite3
from pathlib import Path
import unittest

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")


def initial_schema_script():
    tree = ast.parse(SOURCE)
    init_db = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "init_db")
    return next(
        node.args[0].value for node in ast.walk(init_db)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "executescript"
        and node.args
        and isinstance(node.args[0], ast.Constant)
    )


class ScheduleResourceSchemaIntegrationTests(unittest.TestCase):
    def test_fresh_schema_assigns_room_and_lane_and_returns_both(self):
        db = sqlite3.connect(":memory:")
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.executescript(initial_schema_script())
        trainer = db.execute("INSERT INTO trainers(name,payroll_rate) VALUES('Тестовый тренер',400)").lastrowid
        room = db.execute("INSERT INTO schedule_resources(name,resource_type,created_at,updated_at) VALUES('Бассейн','room','now','now')").lastrowid
        lane = db.execute("INSERT INTO schedule_resources(name,resource_type,created_at,updated_at) VALUES('Дорожка 1','lane','now','now')").lastrowid
        db.execute("INSERT INTO schedule_slots(trainer_id,slot_date,slot_time,duration_minutes,capacity,kind,notes,room_id,lane_id) VALUES(?,?,?,?,?,?,?,?,?)",
                   (trainer,"2026-10-19","09:00",30,1,"individual","",room,lane))
        row = db.execute("""SELECT sl.room_id,sl.lane_id,rm.name room_name,ln.name lane_name
            FROM schedule_slots sl LEFT JOIN schedule_resources rm ON rm.id=sl.room_id
            LEFT JOIN schedule_resources ln ON ln.id=sl.lane_id""").fetchone()
        self.assertEqual((room,lane,"Бассейн","Дорожка 1"), tuple(row))
        self.assertEqual("ok", db.execute("PRAGMA integrity_check").fetchone()[0])
        self.assertEqual([], db.execute("PRAGMA foreign_key_check").fetchall())
        db.close()

    def test_resource_names_are_case_insensitively_unique_per_type(self):
        db = sqlite3.connect(":memory:")
        db.executescript(initial_schema_script())
        db.execute("INSERT INTO schedule_resources(name,resource_type,created_at,updated_at) VALUES('Pool','room','now','now')")
        with self.assertRaises(sqlite3.IntegrityError):
            db.execute("INSERT INTO schedule_resources(name,resource_type,created_at,updated_at) VALUES('pool','room','now','now')")
        db.close()

    def test_additive_migration_preserves_existing_schedule_rows(self):
        db = sqlite3.connect(":memory:")
        db.executescript("""
            CREATE TABLE schedule_resources(id INTEGER PRIMARY KEY, name TEXT, resource_type TEXT);
            CREATE TABLE schedule_slots(id INTEGER PRIMARY KEY, trainer_id INTEGER, slot_date TEXT, slot_time TEXT,
              duration_minutes INTEGER, capacity INTEGER, kind TEXT, notes TEXT);
            INSERT INTO schedule_slots VALUES(5,2,'2026-10-19','09:00',30,1,'individual','legacy');
        """)
        columns={row[1] for row in db.execute("PRAGMA table_info(schedule_slots)")}
        if "room_id" not in columns:
            db.execute("ALTER TABLE schedule_slots ADD COLUMN room_id INTEGER REFERENCES schedule_resources(id)")
        if "lane_id" not in columns:
            db.execute("ALTER TABLE schedule_slots ADD COLUMN lane_id INTEGER REFERENCES schedule_resources(id)")
        row=db.execute("SELECT id,trainer_id,slot_date,slot_time,notes,room_id,lane_id FROM schedule_slots WHERE id=5").fetchone()
        self.assertEqual((5,2,"2026-10-19","09:00","legacy",None,None),row)
        db.close()


if __name__ == "__main__":
    unittest.main()
