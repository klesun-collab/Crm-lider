"""Validation helpers for staff accounts."""
import re


def validate_new_admin(username, password):
    username = str(username or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{3,40}", username):
        raise ValueError("Логин должен содержать 3–40 латинских букв, цифр, точек, дефисов или подчёркиваний")
    validate_password(password)
    return username


def validate_password(password):
    """Require strong but usable password lengths for staff accounts."""
    password = password or ""
    if len(password) < 12 or len(password) > 256:
        raise ValueError("Пароль должен содержать от 12 до 256 символов")
    return password


def ensure_auth_version_column(connection):
    """Idempotently add session-revocation support to older SQLite databases.

    Returns True when this call performed the migration.
    """
    columns = {row[1] for row in connection.execute("PRAGMA table_info(users)").fetchall()}
    if "auth_version" in columns:
        return False
    connection.execute("ALTER TABLE users ADD COLUMN auth_version INTEGER NOT NULL DEFAULT 1")
    return True


def auth_version_matches(session_version, database_version):
    """Fail closed for missing or stale authentication-version claims."""
    return (
        isinstance(session_version, int)
        and not isinstance(session_version, bool)
        and isinstance(database_version, int)
        and not isinstance(database_version, bool)
        and session_version == database_version
    )
