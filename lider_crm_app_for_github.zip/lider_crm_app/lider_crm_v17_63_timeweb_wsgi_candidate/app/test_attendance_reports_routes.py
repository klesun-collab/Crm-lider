from pathlib import Path
import unittest

SOURCE = Path(__file__).with_name('app.py').read_text(encoding='utf-8')


class AttendanceReportRouteTests(unittest.TestCase):
    def test_report_routes_are_login_protected_and_linked_in_navigation(self):
        self.assertIn('@app.get("/attendance-report")\n@login_required', SOURCE)
        self.assertIn('@app.get("/attendance-report.csv")\n@login_required', SOURCE)
        self.assertIn('@app.get("/one-visit")\n@login_required', SOURCE)
        self.assertIn('href="/attendance-report"', SOURCE)
        self.assertIn('href="/one-visit"', SOURCE)

    def test_financial_metrics_are_only_rendered_for_manager(self):
        self.assertIn('report_headers = "<th>Продажи за период</th>', SOURCE)
        self.assertIn('if is_manager:', SOURCE)
        self.assertIn('if is_manager:\n            values += [r["completed_sales"],r["net_sales"]]', SOURCE)

    def test_reports_are_read_only(self):
        section = SOURCE.split('def attendance_report_page():', 1)[1].split('@app.get("/attendance-report.csv")', 1)[0]
        self.assertNotIn('INSERT INTO', section)
        self.assertNotIn('UPDATE ', section)
        self.assertNotIn('DELETE FROM', section)


if __name__ == '__main__':
    unittest.main()
