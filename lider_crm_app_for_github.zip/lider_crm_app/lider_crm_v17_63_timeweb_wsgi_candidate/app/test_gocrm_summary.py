import sqlite3
import unittest
from gocrm_summary import load_gocrm_client_summary


class GoCRMClientSummaryTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.db.row_factory = sqlite3.Row

    def tearDown(self):
        self.db.close()

    def test_missing_import_table_is_supported_on_fresh_install(self):
        self.assertIsNone(load_gocrm_client_summary(self.db, 1))

    def test_missing_client_summary_returns_none(self):
        self.db.execute("""CREATE TABLE gocrm_client_summary(
            client_id INTEGER PRIMARY KEY,source_id TEXT,subscription_summary TEXT,
            last_payment_date TEXT,last_payment_amount_kopecks INTEGER,debt_amount_kopecks INTEGER,
            lifetime_paid_amount_kopecks INTEGER,next_lesson_date TEXT,last_visit_date TEXT,
            first_visit_date TEXT,source_json TEXT)""")
        self.assertIsNone(load_gocrm_client_summary(self.db, 404))

    def test_loads_only_read_only_reconciliation_fields(self):
        self.db.execute("""CREATE TABLE gocrm_client_summary(
            client_id INTEGER PRIMARY KEY,source_id TEXT,subscription_summary TEXT,
            last_payment_date TEXT,last_payment_amount_kopecks INTEGER,debt_amount_kopecks INTEGER,
            lifetime_paid_amount_kopecks INTEGER,next_lesson_date TEXT,last_visit_date TEXT,
            first_visit_date TEXT,source_json TEXT)""")
        self.db.execute("INSERT INTO gocrm_client_summary VALUES(1,'G-100','8 занятий','2026-10-01',12550,-1364402,250000,'2026-10-18','2026-10-15','2025-04-01','secret json')")
        row = load_gocrm_client_summary(self.db, 1)
        self.assertEqual(row["source_id"], "G-100")
        self.assertEqual(row["debt_amount_kopecks"], -1364402)
        self.assertNotIn("source_json", row.keys())


if __name__ == "__main__":
    unittest.main()
