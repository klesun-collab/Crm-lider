"""Static regression contracts for persistent lesson-group rosters."""
from pathlib import Path
import unittest

SOURCE = (Path(__file__).parent / "app.py").read_text(encoding="utf-8")


class GroupRosterContractTests(unittest.TestCase):
    def test_group_tables_and_nav_exist(self):
        self.assertIn("CREATE TABLE IF NOT EXISTS lesson_groups", SOURCE)
        self.assertIn("CREATE TABLE IF NOT EXISTS lesson_group_members", SOURCE)
        self.assertIn('<a href="/groups">Группы</a>', SOURCE)

    def test_group_route_is_authenticated_and_audited(self):
        self.assertIn('@app.route("/groups", methods=["GET", "POST"])', SOURCE)
        start = SOURCE.index('def groups_page():')
        end = SOURCE.index('@app.route("/waitlist", methods=["GET", "POST"])', start)
        route = SOURCE[start:end]
        for action in ("create", "update", "toggle", "add_member", "remove_member"):
            self.assertIn(f'action == "{action}"', route)
        self.assertIn('audit(c, "group.created"', route)
        self.assertIn('audit(c, "group.member_added"', route)

    def test_group_membership_does_not_create_bookings_or_charge_subscriptions(self):
        start = SOURCE.index('def groups_page():')
        end = SOURCE.index('@app.route("/waitlist", methods=["GET", "POST"])', start)
        route = SOURCE[start:end]
        membership_part = route[:route.index('if action == "book_group":')]
        self.assertNotIn("INSERT INTO bookings", membership_part)
        self.assertNotIn("INSERT INTO sales", route)
        self.assertNotIn("remaining_lessons=remaining_lessons-1", route)
        self.assertIn("добавление в группу не создаёт запись и не списывает абонемент", route)

    def test_bulk_group_booking_is_atomic_and_checks_capacity_and_subscriptions(self):
        start = SOURCE.index('def groups_page():')
        end = SOURCE.index('@app.route("/waitlist", methods=["GET", "POST"])', start)
        route = SOURCE[start:end]
        bulk = route[route.index('if action == "book_group":'):route.index('if action == "remove_member":')]
        self.assertIn('c.execute("BEGIN IMMEDIATE")', bulk)
        self.assertIn('slot["kind"] != "group"', bulk)
        self.assertIn('int(slot["capacity"]) - int(slot["booked"]) < len(members)', bulk)
        self.assertIn('subscription_{client_id}', bulk)
        self.assertIn('INSERT INTO bookings', bulk)
        self.assertIn('audit(c, "group.booked_to_slot"', bulk)

    def test_removal_is_soft_and_keeps_membership_history(self):
        start = SOURCE.index('def groups_page():')
        end = SOURCE.index('@app.route("/waitlist", methods=["GET", "POST"])', start)
        route = SOURCE[start:end]
        self.assertIn("UPDATE lesson_group_members SET active=0", route)
        self.assertNotIn("DELETE FROM lesson_group_members", route)


if __name__ == "__main__":
    unittest.main()
