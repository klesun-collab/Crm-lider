import ast
import unittest
from pathlib import Path
SOURCE=Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE=ast.parse(SOURCE)
def fn(name): return next(n for n in TREE.body if isinstance(n,ast.FunctionDef) and n.name==name)
class CashOtherIncomeContractTests(unittest.TestCase):
    def test_other_income_is_manager_only_and_does_not_create_sales_or_expenses(self):
        route=fn('cash_add_other_income')
        self.assertTrue(any('manager_required' in ast.unparse(d) for d in route.decorator_list))
        text=ast.get_source_segment(SOURCE,route)
        self.assertIn('INSERT INTO cash_other_income',text)
        self.assertIn('cash.other_income.created',text)
        self.assertNotIn('INSERT INTO sales',text)
        self.assertNotIn('INSERT INTO cash_expenses',text)
    def test_income_categories_are_manager_only_and_audited(self):
        route=fn('income_categories_page')
        self.assertTrue(any('manager_required' in ast.unparse(d) for d in route.decorator_list))
        text=ast.get_source_segment(SOURCE,route)
        self.assertIn('cash.income_category.created',text)
        self.assertIn('cash.income_category.updated',text)
        self.assertIn('cash.income_category.deactivated',text)
        self.assertIn('Нельзя отключить последнюю активную категорию',text)
    def test_cash_journal_and_closeout_include_other_income(self):
        journal=ast.get_source_segment(SOURCE,fn('cash_journal'))
        close=ast.get_source_segment(SOURCE,fn('cash_close_shift'))
        self.assertIn('cash_other_income',journal)
        self.assertIn('income_category_sums',journal)
        self.assertIn('cash_other_income',close)
        self.assertIn('iby.get',close)
if __name__=='__main__': unittest.main()
