"""Integration tests for the GoCRM importer using synthetic, non-personal test data."""
import ast, pathlib, sqlite3, tempfile, os, unittest
from pathlib import Path
import pandas as pd
import import_gocrm

BASE = pathlib.Path(__file__).parent
APP_SOURCE = (BASE / 'app.py').read_text(encoding='utf-8')
COLUMNS = [
 'Ссылка на карточку','Имя ребенка','ФИО родителя','Дата рождения','Телефон','Источник','Статус','Эл.почта',
 'Комментарий','Заметка','Доп.номер телефона','Алиас статуса','Дата регистрации в системе',
 'Абонементы (наименование, тип занятия, остаток, стоимость при покупке)','Дата последней оплаты',
 'Cумма последней оплаты, ₽','Задолженность, ₽','Всего заплатил, ₽','Дата следующего занятия',
 'Дата последнего посещения','Дата первого посещения','Номер клиента'
]

class ImporterIntegrationTests(unittest.TestCase):
    def setUp(self):
        tree=ast.parse(APP_SOURCE)
        fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='init_db')
        sql=next(n.args[0].value for n in ast.walk(fn) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='executescript' and n.args and isinstance(n.args[0],ast.Constant))
        fd,self.db=tempfile.mkstemp(suffix='.sqlite3'); os.close(fd)
        c=sqlite3.connect(self.db); c.execute('PRAGMA foreign_keys=ON'); c.executescript(sql); c.commit(); c.close()
        self.tmp=tempfile.TemporaryDirectory()
        self.xlsx=os.path.join(self.tmp.name,'synthetic.xlsx')
        self.write_rows([self.row('1001','Тестовый ребёнок','125.50')])

    def tearDown(self):
        os.remove(self.db); self.tmp.cleanup()

    @staticmethod
    def row(client_id, child, paid):
        d={c:'' for c in COLUMNS}
        d.update({'Ссылка на карточку':f'https://example.invalid/{client_id}','Имя ребенка':child,
          'ФИО родителя':'Тестовый родитель','Телефон':'79990000000','Статус':'Активный',
          'Cумма последней оплаты, ₽':paid,'Задолженность, ₽':'-25.25','Всего заплатил, ₽':'125.50',
          'Номер клиента':client_id})
        return d

    def write_rows(self, rows):
        pd.DataFrame(rows,columns=COLUMNS).to_excel(self.xlsx,index=False)

    def test_repeat_import_is_idempotent_and_preserves_created_at(self):
        first=import_gocrm.run(self.xlsx,self.db,True)
        c=sqlite3.connect(self.db)
        before=c.execute("SELECT id,created_at FROM clients WHERE source_system='GoCRM' AND source_id='1001'").fetchone()
        summary=c.execute("SELECT last_payment_amount_kopecks,debt_amount_kopecks FROM gocrm_client_summary WHERE source_id='1001'").fetchone()
        c.close()
        second=import_gocrm.run(self.xlsx,self.db,True)
        c=sqlite3.connect(self.db)
        after=c.execute("SELECT id,created_at FROM clients WHERE source_system='GoCRM' AND source_id='1001'").fetchone()
        count=c.execute('SELECT COUNT(*) FROM clients').fetchone()[0]
        c.close()
        self.assertEqual((first['inserted'],first['updated']),(1,0))
        self.assertEqual((second['inserted'],second['updated']),(0,1))
        self.assertEqual(before,after)
        self.assertEqual(count,1)
        self.assertEqual(summary,(12550,-2525))

    def test_import_creates_verified_preimport_backup(self):
        c=sqlite3.connect(self.db)
        c.execute("INSERT INTO clients(child_name,parent_name,phone,birth_date,address,notes,status,created_at) VALUES(?,?,?,?,?,?,?,?)",
                  ('Existing','Parent','70000000000','','','','active','2020-01-01'))
        c.commit(); c.close()
        result=import_gocrm.run(self.xlsx,self.db,True)
        backup=result.get('preimport_backup')
        self.assertTrue(backup and os.path.exists(backup))
        manifest_path=backup+'.manifest.json'
        self.assertTrue(os.path.exists(manifest_path))
        import hashlib, json
        with open(manifest_path, encoding='utf-8') as stream:
            manifest=json.load(stream)
        with open(backup,'rb') as backup_stream:
            digest=hashlib.sha256(backup_stream.read()).hexdigest()
        self.assertEqual(manifest['sha256'],digest)
        self.assertEqual(manifest['sqlite_integrity_check'],'ok')
        self.assertEqual(manifest['foreign_key_violations'],0)
        from backup_database import verify_backup_manifest
        verified=verify_backup_manifest(Path(backup))
        self.assertEqual(verified['backup_file'],Path(backup).name)
        b=sqlite3.connect(backup)
        self.assertEqual(b.execute('PRAGMA integrity_check').fetchone()[0],'ok')
        self.assertEqual(b.execute('SELECT COUNT(*) FROM clients').fetchone()[0],1)
        b.close()
        # The live database has both the pre-existing and imported client.
        c=sqlite3.connect(self.db)
        self.assertEqual(c.execute('SELECT COUNT(*) FROM clients').fetchone()[0],2)
        c.close()


    def test_malformed_money_is_rejected_instead_of_silently_becoming_zero(self):
        self.write_rows([self.row('1001','Тестовый ребёнок','не число')])
        with self.assertRaisesRegex(ValueError, 'Сумма последней оплаты'):
            import_gocrm.run(self.xlsx,self.db,True)
        c=sqlite3.connect(self.db)
        self.assertEqual(c.execute('SELECT COUNT(*) FROM clients').fetchone()[0],0)
        self.assertNotIn('source_system', {r[1] for r in c.execute('PRAGMA table_info(clients)')})
        c.close()

    def test_failed_import_rolls_back_schema_migration_and_rows(self):
        c=sqlite3.connect(self.db)
        c.execute("CREATE TRIGGER fail_gocrm_insert BEFORE INSERT ON clients WHEN NEW.child_name='Тестовый ребёнок' BEGIN SELECT RAISE(ABORT, 'synthetic failure'); END")
        c.commit(); c.close()
        with self.assertRaisesRegex(sqlite3.IntegrityError, 'synthetic failure'):
            import_gocrm.run(self.xlsx,self.db,True)
        c=sqlite3.connect(self.db)
        self.assertEqual(c.execute('SELECT COUNT(*) FROM clients').fetchone()[0],0)
        self.assertNotIn('source_system', {r[1] for r in c.execute('PRAGMA table_info(clients)')})
        names={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertNotIn('migration_source', names)
        self.assertNotIn('gocrm_client_summary', names)
        c.close()


    def test_invalid_nonempty_date_is_rejected_instead_of_becoming_blank(self):
        row=self.row('1001','Тестовый ребёнок','125.50')
        row['Дата рождения']='31.02.2020'
        self.write_rows([row])
        with self.assertRaisesRegex(ValueError, 'Дата рождения'):
            import_gocrm.run(self.xlsx,self.db,True)
        c=sqlite3.connect(self.db)
        self.assertEqual(c.execute('SELECT COUNT(*) FROM clients').fetchone()[0],0)
        c.close()

    def test_numeric_excel_client_ids_do_not_gain_decimal_suffix(self):
        self.assertEqual(import_gocrm.normalize_source_id(1001.0), '1001')
        self.assertEqual(import_gocrm.normalize_source_id(1001), '1001')
        self.assertEqual(import_gocrm.normalize_source_id('001001'), '001001')
        self.assertEqual(import_gocrm.normalize_source_id(float('nan')), '')

    def test_numeric_excel_ids_import_idempotently_when_pandas_reads_float(self):
        row=self.row('1001','Тестовый ребёнок','125.50')
        row['Номер клиента']=1001.0
        self.write_rows([row])
        first=import_gocrm.run(self.xlsx,self.db,True)
        second=import_gocrm.run(self.xlsx,self.db,True)
        c=sqlite3.connect(self.db)
        ids=c.execute("SELECT source_id FROM clients WHERE source_system='GoCRM'").fetchall()
        c.close()
        self.assertEqual((first['inserted'],second['inserted'],second['updated']),(1,0,1))
        self.assertEqual(ids,[('1001',)])

    def test_date_parser_supports_common_russian_datetime_exports(self):
        self.assertEqual(import_gocrm.iso_date('17.10.2026 12:30', 'Дата'), '2026-10-17')
        self.assertEqual(import_gocrm.iso_date('2026-10-17 12:30:00', 'Дата'), '2026-10-17')


    def test_preimport_backup_refuses_missing_database_path(self):
        with self.assertRaisesRegex(FileNotFoundError, 'База для резервного копирования не найдена'):
            import_gocrm.create_preimport_backup(os.path.join(self.tmp.name, 'absent.sqlite3'))

    def test_preimport_backup_has_restricted_permissions_where_supported(self):
        backup=import_gocrm.create_preimport_backup(self.db)
        mode=os.stat(backup).st_mode & 0o777
        if os.name != 'nt':
            self.assertEqual(mode,0o600)


    def test_missing_required_next_lesson_column_fails_preflight(self):
        row=self.row('1001','Тестовый ребёнок','125.50')
        frame=pd.DataFrame([row],columns=[c for c in COLUMNS if c != 'Дата следующего занятия'])
        frame.to_excel(self.xlsx,index=False)
        with self.assertRaisesRegex(RuntimeError, 'Дата следующего занятия'):
            import_gocrm.run(self.xlsx,self.db,True)
        c=sqlite3.connect(self.db)
        self.assertEqual(c.execute('SELECT COUNT(*) FROM clients').fetchone()[0],0)
        c.close()

    def test_duplicate_source_ids_abort_before_database_changes(self):
        self.write_rows([self.row('1001','Первый','1'),self.row('1001','Второй','2')])
        with self.assertRaisesRegex(RuntimeError,'повторяющиеся номера клиента'):
            import_gocrm.run(self.xlsx,self.db,True)
        c=sqlite3.connect(self.db)
        self.assertEqual(c.execute('SELECT COUNT(*) FROM clients').fetchone()[0],0)
        c.close()

if __name__=='__main__': unittest.main(verbosity=2)
