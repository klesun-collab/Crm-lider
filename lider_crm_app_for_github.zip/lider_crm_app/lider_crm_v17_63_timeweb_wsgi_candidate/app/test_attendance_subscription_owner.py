"""SQLite-level regression tests for attendance/subscription ownership."""
import ast, pathlib, sqlite3, unittest

SOURCE = pathlib.Path(__file__).with_name('app.py').read_text(encoding='utf-8')

class AttendanceSubscriptionOwnerTests(unittest.TestCase):
    def setUp(self):
        tree=ast.parse(SOURCE)
        init_fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='init_db')
        scripts=[]
        for n in ast.walk(init_fn):
            if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='executescript' and n.args and isinstance(n.args[0],ast.Constant) and isinstance(n.args[0].value,str):
                scripts.append(n.args[0].value)
        self.assertGreaterEqual(len(scripts),2)
        self.db=sqlite3.connect(':memory:')
        self.db.execute('PRAGMA foreign_keys=ON')
        self.db.executescript(scripts[0])
        self.db.executescript(scripts[1])
        self.db.execute("INSERT INTO clients(child_name,parent_name,phone,created_at) VALUES('Child A','Parent','111','2026-01-01')")
        self.db.execute("INSERT INTO clients(child_name,parent_name,phone,created_at) VALUES('Child B','Parent','222','2026-01-01')")
        self.db.execute("INSERT INTO subscriptions(client_id,title,total_lessons,remaining_lessons,price,purchased_at) VALUES(1,'A',8,8,800,'2026-01-01')")
        self.db.commit()
    def tearDown(self): self.db.close()
    def test_attendance_can_use_subscription_owned_by_same_child(self):
        self.db.execute("INSERT INTO attendance(client_id,subscription_id,lesson_date,lesson_time,status,created_by,created_at) VALUES(1,1,'2026-01-02','09:00','planned',NULL,'2026-01-01')")
        self.db.commit()
        self.assertEqual(self.db.execute('SELECT COUNT(*) FROM attendance').fetchone()[0],1)
    def test_attendance_cannot_use_another_child_subscription(self):
        with self.assertRaisesRegex(sqlite3.IntegrityError,'attendance_subscription_client_mismatch'):
            self.db.execute("INSERT INTO attendance(client_id,subscription_id,lesson_date,lesson_time,status) VALUES(2,1,'2026-01-02','09:00','planned')")
    def test_existing_attendance_cannot_be_relinked_to_other_child(self):
        self.db.execute("INSERT INTO attendance(client_id,subscription_id,lesson_date,lesson_time,status,created_by,created_at) VALUES(1,1,'2026-01-02','09:00','planned',NULL,'2026-01-01')")
        with self.assertRaisesRegex(sqlite3.IntegrityError,'attendance_subscription_client_mismatch'):
            self.db.execute('UPDATE attendance SET client_id=2 WHERE id=1')
    def test_owner_guard_triggers_are_in_schema(self):
        self.assertIn('attendance_subscription_owner_insert',SOURCE)
        self.assertIn('attendance_subscription_owner_update',SOURCE)

if __name__=='__main__': unittest.main()
