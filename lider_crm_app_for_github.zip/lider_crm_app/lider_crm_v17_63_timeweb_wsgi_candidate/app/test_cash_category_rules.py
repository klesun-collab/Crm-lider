import unittest
from cash_category_rules import normalize_expense_category

class ExpenseCategoryValidationTests(unittest.TestCase):
    def test_trims_name(self):
        self.assertEqual(normalize_expense_category('  Химия бассейна  '),'Химия бассейна')
    def test_rejects_blank_or_too_long_name(self):
        for value in ('', '   ', 'x'*101):
            with self.subTest(value=value[:5]), self.assertRaises(ValueError): normalize_expense_category(value)

if __name__=='__main__': unittest.main()
