import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE = ast.parse(SOURCE)

class ClientQuickBookingTests(unittest.TestCase):
    def test_client_card_offers_quick_booking(self):
        node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == 'client_profile')
        src = ast.get_source_segment(SOURCE, node)
        self.assertIn('Быстрая запись на тренировку', src)
        self.assertIn("action='/client/{client_id}/book'", src)
        self.assertIn("WHERE sl.slot_date>=?", src)
        self.assertIn("r['status']=='active'", src)

    def test_booking_route_validates_ownership_capacity_and_duplicate(self):
        node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == 'client_quick_book')
        src = ast.get_source_segment(SOURCE, node)
        for check in ('WHERE id=? AND client_id=? AND status=\'active\' AND remaining_lessons>0',
                      'if count>=slot["capacity"]', 'status"]=="attended"',
                      'status"]=="booked"', 'audit(c,action,"booking"'):
            self.assertIn(check, src)

    def test_route_is_post_and_login_protected(self):
        node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == 'client_quick_book')
        decorators = '\n'.join(ast.get_source_segment(SOURCE, d) for d in node.decorator_list)
        self.assertIn('login_required', decorators)
        self.assertIn('app.route("/client/<int:client_id>/book", methods=["POST"])', decorators)

if __name__ == '__main__':
    unittest.main()
