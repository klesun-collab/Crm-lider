"""Behavioral tests for atomic attendance/missed transitions from schedule bookings."""
import sqlite3
import unittest
from pathlib import Path

from datetime import datetime
from booking_attendance import mark_booking_outcome, ensure_booking_cancellable

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")


class BookingAttendanceFlowTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.db.row_factory = sqlite3.Row
        self.db.executescript("""
            PRAGMA foreign_keys=ON;
            CREATE TABLE trainers(id INTEGER PRIMARY KEY,name TEXT,payroll_rate INTEGER);
            CREATE TABLE clients(id INTEGER PRIMARY KEY,child_name TEXT);
            CREATE TABLE subscriptions(id INTEGER PRIMARY KEY,client_id INTEGER,status TEXT,
                remaining_lessons INTEGER,total_lessons INTEGER,expires_at TEXT);
            CREATE TABLE schedule_slots(id INTEGER PRIMARY KEY,slot_date TEXT,slot_time TEXT,trainer_id INTEGER);
            CREATE TABLE bookings(id INTEGER PRIMARY KEY,slot_id INTEGER,client_id INTEGER,subscription_id INTEGER,
                status TEXT,created_by INTEGER,created_at TEXT);
            CREATE TABLE attendance(id INTEGER PRIMARY KEY,client_id INTEGER,subscription_id INTEGER,trainer TEXT,
                lesson_date TEXT,lesson_time TEXT,status TEXT,rate_snapshot INTEGER,schedule_slot_id INTEGER,
                created_by INTEGER,created_at TEXT);
            INSERT INTO trainers VALUES(1,'Анна',430);
            INSERT INTO clients VALUES(7,'Тестовый ребёнок');
            INSERT INTO subscriptions VALUES(3,7,'active',2,8,'');
            INSERT INTO schedule_slots VALUES(5,'2026-10-17','10:00',1);
            INSERT INTO bookings VALUES(9,5,7,3,'booked',2,'2026-10-17T09:00:00');
        """)
        self.db.commit()

    def tearDown(self):
        self.db.close()

    def test_attended_booking_creates_one_attendance_and_snapshots_rate(self):
        result = mark_booking_outcome(self.db, 9, "attended", 2, "2026-10-17T10:30:00", "2026-10-17")
        self.db.commit()
        self.assertEqual(result["status"], "attended")
        self.assertEqual(result["rate_snapshot"], 430)
        self.assertEqual(self.db.execute("SELECT status FROM bookings WHERE id=9").fetchone()[0], "attended")
        self.assertEqual(self.db.execute("SELECT remaining_lessons FROM subscriptions WHERE id=3").fetchone()[0], 1)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM attendance WHERE schedule_slot_id=5").fetchone()[0], 1)

    def test_missed_booking_consumes_lesson_and_is_restorable(self):
        result = mark_booking_outcome(self.db, 9, "missed", 2, "2026-10-17T10:30:00", "2026-10-17")
        self.db.commit()
        self.assertEqual(result["status"], "missed")
        self.assertEqual(self.db.execute("SELECT status FROM attendance WHERE id=?", (result["attendance_id"],)).fetchone()[0], "missed")
        self.assertEqual(self.db.execute("SELECT remaining_lessons FROM subscriptions WHERE id=3").fetchone()[0], 1)
        self.assertEqual(self.db.execute("SELECT status FROM bookings WHERE id=9").fetchone()[0], "missed")

    def test_final_lesson_completes_subscription(self):
        self.db.execute("UPDATE subscriptions SET remaining_lessons=1 WHERE id=3")
        self.db.commit()
        mark_booking_outcome(self.db, 9, "attended", 2, "2026-10-17T10:30:00", "2026-10-17")
        self.db.commit()
        row = self.db.execute("SELECT status,remaining_lessons FROM subscriptions WHERE id=3").fetchone()
        self.assertEqual(tuple(row), ("completed", 0))

    def test_future_or_repeated_booking_does_not_spend_lesson(self):
        with self.assertRaisesRegex(ValueError, "будущее занятие"):
            mark_booking_outcome(self.db, 9, "attended", 2, "2026-10-17T09:30:00", "2026-10-16")
        self.db.rollback()
        mark_booking_outcome(self.db, 9, "attended", 2, "2026-10-17T10:30:00", "2026-10-17")
        self.db.commit()
        with self.assertRaisesRegex(ValueError, "уже обработана"):
            mark_booking_outcome(self.db, 9, "missed", 2, "2026-10-17T10:30:00", "2026-10-17")
        self.db.rollback()
        self.assertEqual(self.db.execute("SELECT remaining_lessons FROM subscriptions WHERE id=3").fetchone()[0], 1)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM attendance").fetchone()[0], 1)

    def test_direct_request_cannot_mark_attendance_before_start(self):
        with self.assertRaisesRegex(ValueError, "до начала занятия"):
            mark_booking_outcome(self.db, 9, "attended", 2, "2026-10-17T09:59:59", "2026-10-17")
        self.db.rollback()
        self.assertEqual(self.db.execute("SELECT remaining_lessons FROM subscriptions WHERE id=3").fetchone()[0], 2)
        self.assertEqual(self.db.execute("SELECT status FROM bookings WHERE id=9").fetchone()[0], "booked")

    def test_unavailable_subscription_does_not_change_booking(self):
        self.db.execute("UPDATE subscriptions SET remaining_lessons=0 WHERE id=3")
        self.db.commit()
        with self.assertRaisesRegex(ValueError, "Нет доступного занятия"):
            mark_booking_outcome(self.db, 9, "missed", 2, "2026-10-17T10:30:00", "2026-10-17")
        self.db.rollback()
        self.assertEqual(self.db.execute("SELECT status FROM bookings WHERE id=9").fetchone()[0], "booked")
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM attendance").fetchone()[0], 0)

    def test_booking_can_only_be_cancelled_before_start_time(self):
        self.assertTrue(ensure_booking_cancellable("2026-10-18", "10:00", datetime(2026, 10, 17, 23, 59)))
        with self.assertRaisesRegex(ValueError, "после начала занятия"):
            ensure_booking_cancellable("2026-10-17", "10:00", datetime(2026, 10, 17, 10, 0))
        with self.assertRaisesRegex(ValueError, "некорректная дата или время"):
            ensure_booking_cancellable("not-a-date", "10:00", datetime(2026, 10, 17, 9, 0))

    def test_cancel_route_enforces_start_time_and_ui_switches_actions(self):
        cancel = SOURCE.split('def booking_cancel(booking_id):', 1)[1].split('@app.route("/attendance"', 1)[0]
        self.assertIn('ensure_booking_cancellable(slot["slot_date"],slot["slot_time"])', cancel)
        self.assertIn("datetime.now() < starts_at", SOURCE)
        self.assertIn("Отметьте посещение или пропуск", (Path(__file__).parent / "booking_attendance.py").read_text(encoding="utf-8"))

    def test_schedule_exposes_both_attended_and_missed_actions(self):
        self.assertIn("/booking/{k['booking_id']}/missed", SOURCE)
        self.assertIn("Пропуск / списать", SOURCE)
        self.assertIn("уже отмечен как пропустивший это занятие", SOURCE)
        self.assertIn('state_label={"attended":"посетил","missed":"пропуск","cancelled":"запись отменена"}', SOURCE)
        self.assertIn('@app.route("/booking/<int:booking_id>/missed", methods=["POST"])', SOURCE)
        missed = SOURCE.split('def booking_missed(booking_id):', 1)[1].split('@app.route("/booking/<int:booking_id>/cancel"', 1)[0]
        self.assertIn('mark_booking_outcome(c,booking_id,"missed"', missed)


if __name__ == "__main__":
    unittest.main()
