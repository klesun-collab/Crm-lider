"""SQLite connection helpers with explicit close-on-context-exit semantics."""
import sqlite3


class ClosingConnection(sqlite3.Connection):
    """Match sqlite transaction context behavior and also release the handle."""
    def __exit__(self, exc_type, exc_value, traceback):
        try:
            return super().__exit__(exc_type, exc_value, traceback)
        finally:
            self.close()


def connect_sqlite(path, *, timeout=10, row_factory=sqlite3.Row, foreign_keys=True, wal=False):
    connection = sqlite3.connect(str(path), timeout=timeout, factory=ClosingConnection)
    connection.row_factory = row_factory
    if foreign_keys:
        connection.execute("PRAGMA foreign_keys=ON")
    if wal:
        connection.execute("PRAGMA journal_mode=WAL")
    return connection
