import unittest
from loyalty_rules import normalize_loyalty_settings, calculate_loyalty_redemption, calculate_points_earned

class LoyaltyRuleTests(unittest.TestCase):
    def test_settings_validation(self):
        self.assertEqual(normalize_loyalty_settings('1','2','1','30'), {'enabled':1,'points_per_100':2,'point_value_rubles':1,'max_redeem_percent':30})
        for values in (('yes',1,1,10),('1',-1,1,10),('1',1,0,10),('1',1,1,101),('1','x',1,10)):
            with self.subTest(values=values), self.assertRaises(ValueError): normalize_loyalty_settings(*values)
    def test_program_disabled_means_no_earning_or_redemption(self):
        self.assertEqual(calculate_points_earned(paid_amount=1000,points_per_100=5,enabled=False),0)
        self.assertEqual(calculate_loyalty_redemption(gross_amount=1000,balance=100,requested_points=0,point_value_rubles=1,max_redeem_percent=50,enabled=False), {'points_redeemed':0,'discount_amount':0,'final_amount':1000})
        with self.assertRaisesRegex(ValueError,'отключена'):
            calculate_loyalty_redemption(gross_amount=1000,balance=100,requested_points=1,point_value_rubles=1,max_redeem_percent=50,enabled=False)
    def test_earning_is_based_on_amount_paid(self):
        self.assertEqual(calculate_points_earned(paid_amount=1500,points_per_100=2,enabled=True),30)
        self.assertEqual(calculate_points_earned(paid_amount=1500,points_per_100=0,enabled=True),0)
    def test_redemption_respects_balance_and_limit(self):
        self.assertEqual(calculate_loyalty_redemption(gross_amount=1000,balance=100,requested_points=20,point_value_rubles=1,max_redeem_percent=30,enabled=True), {'points_redeemed':20,'discount_amount':20,'final_amount':980})
        with self.assertRaisesRegex(ValueError,'Недостаточно'):
            calculate_loyalty_redemption(gross_amount=1000,balance=10,requested_points=20,point_value_rubles=1,max_redeem_percent=30,enabled=True)
        with self.assertRaisesRegex(ValueError,'лимит'):
            calculate_loyalty_redemption(gross_amount=1000,balance=1000,requested_points=40,point_value_rubles=1,max_redeem_percent=3,enabled=True)
        with self.assertRaisesRegex(ValueError,'полностью обнулить'):
            calculate_loyalty_redemption(gross_amount=100,balance=100,requested_points=100,point_value_rubles=1,max_redeem_percent=100,enabled=True)

if __name__=='__main__': unittest.main()
