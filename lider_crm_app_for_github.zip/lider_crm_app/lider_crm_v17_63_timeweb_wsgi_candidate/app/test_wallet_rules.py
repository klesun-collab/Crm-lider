import sqlite3
import unittest
from wallet_rules import normalize_wallet, normalize_wallet_transfer, wallet_balance_rows, unassigned_legacy_totals, transfer_balance_deltas

class WalletRuleTests(unittest.TestCase):
    def setUp(self):
        self.db=sqlite3.connect(':memory:')
        self.db.row_factory=sqlite3.Row
        self.db.executescript('''
        CREATE TABLE cash_wallets(id INTEGER PRIMARY KEY,name TEXT,payment_method TEXT,opening_balance INTEGER,active INTEGER,created_at TEXT);
        CREATE TABLE sales(id INTEGER PRIMARY KEY,wallet_id INTEGER,payment_method TEXT,amount INTEGER,status TEXT);
        CREATE TABLE cash_expenses(id INTEGER PRIMARY KEY,wallet_id INTEGER,payment_method TEXT,amount INTEGER);
        CREATE TABLE cash_other_income(id INTEGER PRIMARY KEY,wallet_id INTEGER,payment_method TEXT,amount INTEGER);
        CREATE TABLE wallet_transfers(id INTEGER PRIMARY KEY,from_wallet_id INTEGER,to_wallet_id INTEGER,amount INTEGER,note TEXT,created_by INTEGER,created_at TEXT);
        INSERT INTO cash_wallets VALUES(1,'Наличные','cash',500,1,'2026-10-01');
        INSERT INTO cash_wallets VALUES(2,'Банк','card',100,1,'2026-10-01');
        INSERT INTO cash_wallets VALUES(3,'QR','qr',0,1,'2026-10-01');
        INSERT INTO sales VALUES(1,1,'cash',1000,'completed');
        INSERT INTO sales VALUES(2,1,'cash',200,'refund');
        INSERT INTO sales VALUES(3,NULL,'cash',50,'completed');
        INSERT INTO sales VALUES(4,2,'card',500,'completed');
        INSERT INTO cash_expenses VALUES(1,1,'cash',100);
        INSERT INTO cash_expenses VALUES(2,NULL,'card',30);
        INSERT INTO cash_other_income VALUES(1,2,'card',200);
        INSERT INTO cash_other_income VALUES(2,NULL,'cash',70);
        INSERT INTO wallet_transfers VALUES(1,1,2,300,'Внести в банк',1,'2026-10-03T10:00:00');
        INSERT INTO wallet_transfers VALUES(2,2,3,50,'Перевод в QR',1,'2026-10-03T11:00:00');
        ''')
    def tearDown(self): self.db.close()

    def test_wallet_definition_validation(self):
        self.assertEqual(normalize_wallet(' Банк ','card','100'), {'name':'Банк','payment_method':'card','opening_balance':100})
        for args in (('', 'cash', 0), ('x'*101,'cash',0), ('Касса','invalid',0), ('Касса','cash',-1), ('Касса','cash','x')):
            with self.subTest(args=args), self.assertRaises(ValueError): normalize_wallet(*args)

    def test_transfer_validation(self):
        self.assertEqual(normalize_wallet_transfer('1','2','50',' Между счетами '), {'from_wallet_id':1,'to_wallet_id':2,'amount':50,'note':'Между счетами'})
        for args in (('1','1',50,'перевод'),('x','2',50,'перевод'),('1','2',0,'перевод'),('1','2',50,'')):
            with self.subTest(args=args), self.assertRaises(ValueError): normalize_wallet_transfer(*args)

    def test_wallet_balances_include_sales_refunds_expenses_and_transfers(self):
        rows={r['id']:r for r in wallet_balance_rows(self.db)}
        self.assertEqual(rows[1]['balance'],900) # 500 + (1000-200) - 100 - 300
        self.assertEqual(rows[2]['balance'],1050) # 100 + 500 + 200 + 300 - 50
        self.assertEqual(rows[3]['balance'],50)

    def test_legacy_transactions_remain_unassigned_and_are_reported(self):
        legacy=unassigned_legacy_totals(self.db)
        self.assertEqual(legacy['cash'], {'sales':50,'other_income':70,'expenses':0})
        self.assertEqual(legacy['card'], {'sales':0,'other_income':0,'expenses':30})
        self.assertIsNone(self.db.execute('SELECT wallet_id FROM sales WHERE id=3').fetchone()[0])

    def test_transfer_changes_cash_vs_noncash_not_total_money(self):
        self.assertEqual(transfer_balance_deltas(self.db,upper_bound='2026-10-03T23:59:59'),(-300,300))
        self.assertEqual(transfer_balance_deltas(self.db,business_date='2026-10-03',upper_bound='2026-10-03T23:59:59'),(-300,300))

if __name__=='__main__': unittest.main()
