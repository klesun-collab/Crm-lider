@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher not found. Install Python 3.10+ from python.org and enable Add Python to PATH.
  pause
  exit /b 1
)
py -3 -c "import sys; raise SystemExit(sys.version_info < (3,10))"
if errorlevel 1 (
  echo Python 3.10 or newer is required.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" py -3 -m venv .venv
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" deployment_preflight.py
if errorlevel 1 goto failed
echo.
echo Starting LIDER CRM. Open http://127.0.0.1:5000/setup for first-time setup.
echo Keep this window open while using CRM.
".venv\Scripts\python.exe" app.py
if errorlevel 1 goto failed
exit /b 0
:failed
echo.
echo Setup or startup failed. Copy the error text before closing this window.
pause
exit /b 1
