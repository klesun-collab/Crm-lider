from flask import Flask, request, redirect, url_for, render_template_string, session, abort, flash, get_flashed_messages
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from datetime import datetime, date, timedelta
import sqlite3, os, json, secrets, re, csv, io
from csv_safety import safe_csv_row
from backup_utils import create_verified_sqlite_snapshot, exportable_table_names
from cash_balance import balances_as_of, ensure_opening_balances_editable
from retroactive_cash_audit import find_late_cash_expenses
from cash_shift_integrity import find_cash_shift_math_mismatches
from subscription_rules import restoration_status, extend_expiry_for_freeze
from schedule_rules import validate_slot_details, ensure_no_overlap
from recurring_schedule import weekly_dates, shift_start_times, create_recurring_slots
from schedule_audit import build_schedule_audit, ISSUE_FIELDS as SCHEDULE_AUDIT_FIELDS
from renewal_worklist import build_renewal_worklist, normalize_horizon_days
from followup_audit import build_followup_audit, FIELDS as FOLLOWUP_AUDIT_FIELDS
from client_data_quality import build_client_data_quality_audit, FIELDS as CLIENT_QUALITY_FIELDS
from subscription_integrity_audit import build_subscription_integrity_audit, FIELDS as SUBSCRIPTION_INTEGRITY_FIELDS
from client_retention_report import build_client_retention_report, normalize_period_days as normalize_retention_period
from user_rules import validate_new_admin, validate_password, ensure_auth_version_column, auth_version_matches
from system_readiness import build_system_readiness_report
from booking_attendance import mark_booking_outcome, ensure_booking_cancellable
from money_format import format_rubles_from_kopecks
from gocrm_summary import load_gocrm_client_summary
from attendance_reports import get_attendance_report_rows, get_one_visit_rows, validate_period as validate_attendance_period
from daily_journal import normalize_journal_date, get_daily_journal, get_daily_finance_summary
from trial_lessons import book_trial, mark_trial_outcome, cancel_trial
from product_rules import normalize_product_update
from wallet_rules import normalize_wallet, normalize_wallet_transfer, wallet_balance_rows, unassigned_legacy_totals, transfer_balance_deltas
from cash_category_rules import normalize_expense_category
from loyalty_rules import normalize_loyalty_settings, calculate_loyalty_redemption, calculate_points_earned
from sqlite_connection import connect_sqlite

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("LIDER_CRM_DB", os.path.join(APP_DIR, "lider_crm.sqlite3"))
SECRET_KEY = os.environ.get("LIDER_CRM_SECRET", "")
app = Flask(__name__)
app.secret_key = SECRET_KEY or secrets.token_hex(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_SECURE=os.environ.get("LIDER_COOKIE_SECURE","0")=="1")

@app.after_request
def add_security_headers(response):
    """Apply browser-side security defaults to every CRM response."""
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    # CRM pages contain client records and financial data; do not let shared
    # browser/proxy caches retain authenticated HTML or exports by default.
    if request.endpoint not in ("static",):
        response.headers.setdefault("Cache-Control", "no-store")
    return response


@app.before_request
def protect_post_requests():
    if request.method == "POST":
        token = session.get("_csrf")
        supplied = request.form.get("_csrf", "")
        if not token or not secrets.compare_digest(token, supplied):
            abort(400, "Защита формы: обновите страницу и повторите действие")

@app.context_processor
def inject_csrf():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_urlsafe(32)
    return {"csrf_token": session["_csrf"]}


def connect():
    # Unlike sqlite3's default context manager, ClosingConnection releases the
    # file handle on block exit after commit/rollback; this matters on Windows.
    return connect_sqlite(DB_PATH, timeout=10, row_factory=sqlite3.Row, foreign_keys=True, wal=True)

def now(): return datetime.now().isoformat(timespec="microseconds")
def today(): return date.today().isoformat()

def audit(c, action, entity, entity_id, details):
    c.execute("INSERT INTO audit_log(actor_user_id,actor_role,action,entity,entity_id,details,created_at) VALUES(?,?,?,?,?,?,?)",
      (session.get("uid"), session.get("role"), action, entity, entity_id, json.dumps(details, ensure_ascii=False), now()))

def init_db():
    with connect() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL,
          password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('manager','admin')),
          active INTEGER NOT NULL DEFAULT 1, auth_version INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS clients(
          id INTEGER PRIMARY KEY, child_name TEXT NOT NULL, parent_name TEXT NOT NULL,
          phone TEXT NOT NULL, birth_date TEXT DEFAULT '', address TEXT DEFAULT '',
          notes TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS subscriptions(
          id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL REFERENCES clients(id),
          title TEXT NOT NULL, total_lessons INTEGER NOT NULL CHECK(total_lessons > 0),
          remaining_lessons INTEGER NOT NULL CHECK(remaining_lessons >= 0),
          price INTEGER NOT NULL CHECK(price >= 0), purchased_at TEXT NOT NULL,
          expires_at TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'active',
          created_by INTEGER REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS subscription_freezes(
          id INTEGER PRIMARY KEY, subscription_id INTEGER NOT NULL REFERENCES subscriptions(id),
          start_date TEXT NOT NULL, end_date TEXT NOT NULL, days INTEGER NOT NULL CHECK(days>0),
          reason TEXT NOT NULL, created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS attendance_restorations(
          id INTEGER PRIMARY KEY, attendance_id INTEGER NOT NULL UNIQUE REFERENCES attendance(id),
          reason TEXT NOT NULL, fee INTEGER NOT NULL DEFAULT 0 CHECK(fee>=0),
          sale_id INTEGER REFERENCES sales(id), created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS attendance(
          id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL REFERENCES clients(id),
          subscription_id INTEGER NOT NULL REFERENCES subscriptions(id),
          trainer TEXT DEFAULT '', lesson_date TEXT NOT NULL, lesson_time TEXT NOT NULL,
          status TEXT NOT NULL CHECK(status IN ('planned','attended','missed','cancelled')),
          rate_snapshot INTEGER NOT NULL DEFAULT 0, schedule_slot_id INTEGER REFERENCES schedule_slots(id),
          created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS cash_wallets(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE,
          payment_method TEXT NOT NULL CHECK(payment_method IN ('cash','card','transfer','qr')),
          opening_balance INTEGER NOT NULL DEFAULT 0 CHECK(opening_balance>=0),
          active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
        );
        CREATE UNIQUE INDEX IF NOT EXISTS idx_cash_wallets_name_nocase ON cash_wallets(name COLLATE NOCASE);
        CREATE TABLE IF NOT EXISTS wallet_transfers(
          id INTEGER PRIMARY KEY, from_wallet_id INTEGER NOT NULL REFERENCES cash_wallets(id),
          to_wallet_id INTEGER NOT NULL REFERENCES cash_wallets(id), amount INTEGER NOT NULL CHECK(amount>0),
          note TEXT NOT NULL, created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL,
          CHECK(from_wallet_id<>to_wallet_id)
        );
        CREATE INDEX IF NOT EXISTS idx_wallet_transfers_created_at ON wallet_transfers(created_at);
        CREATE INDEX IF NOT EXISTS idx_wallet_transfers_from ON wallet_transfers(from_wallet_id);
        CREATE INDEX IF NOT EXISTS idx_wallet_transfers_to ON wallet_transfers(to_wallet_id);
        CREATE TABLE IF NOT EXISTS sales(
          id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL REFERENCES clients(id),
          item TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount > 0),
          payment_method TEXT NOT NULL CHECK(payment_method IN ('cash','card','transfer','qr')),
          status TEXT NOT NULL DEFAULT 'completed', created_by INTEGER REFERENCES users(id),
          created_at TEXT NOT NULL, product_id INTEGER REFERENCES products(id), quantity INTEGER NOT NULL DEFAULT 1,
          unit_cost_snapshot INTEGER NOT NULL DEFAULT 0, profit_snapshot INTEGER NOT NULL DEFAULT 0,
          subscription_id INTEGER REFERENCES subscriptions(id), wallet_id INTEGER REFERENCES cash_wallets(id),
          gross_amount INTEGER NOT NULL DEFAULT 0, points_earned INTEGER NOT NULL DEFAULT 0,
          points_redeemed INTEGER NOT NULL DEFAULT 0, loyalty_discount_amount INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS loyalty_ledger(
          id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL REFERENCES clients(id),
          sale_id INTEGER REFERENCES sales(id), entry_type TEXT NOT NULL CHECK(entry_type IN ('earn','redeem','refund_earn_reversal','refund_redeem_restore','adjustment')),
          points_delta INTEGER NOT NULL CHECK(points_delta<>0), note TEXT NOT NULL,
          created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_loyalty_ledger_client_created ON loyalty_ledger(client_id,created_at);
        CREATE UNIQUE INDEX IF NOT EXISTS idx_loyalty_sale_entry_type ON loyalty_ledger(sale_id,entry_type) WHERE sale_id IS NOT NULL;
        CREATE TABLE IF NOT EXISTS refund_requests(
          id INTEGER PRIMARY KEY, sale_id INTEGER NOT NULL REFERENCES sales(id),
          reason TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
          requested_by INTEGER REFERENCES users(id), approved_by INTEGER REFERENCES users(id),
          created_at TEXT NOT NULL, resolved_at TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS cash_expense_categories(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL
        );
        CREATE UNIQUE INDEX IF NOT EXISTS idx_cash_expense_categories_name_nocase ON cash_expense_categories(name COLLATE NOCASE);
        CREATE TABLE IF NOT EXISTS cash_expenses(
          id INTEGER PRIMARY KEY, expense_date TEXT NOT NULL, description TEXT NOT NULL,
          amount INTEGER NOT NULL CHECK(amount>0),
          payment_method TEXT NOT NULL CHECK(payment_method IN ('cash','card','transfer','qr')),
          created_by INTEGER REFERENCES users(id), created_by_name TEXT NOT NULL, created_at TEXT NOT NULL,
          wallet_id INTEGER REFERENCES cash_wallets(id), category_id INTEGER REFERENCES cash_expense_categories(id)
        );
        CREATE TABLE IF NOT EXISTS cash_income_categories(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL
        );
        CREATE UNIQUE INDEX IF NOT EXISTS idx_cash_income_categories_name_nocase ON cash_income_categories(name COLLATE NOCASE);
        CREATE TABLE IF NOT EXISTS cash_other_income(
          id INTEGER PRIMARY KEY, income_date TEXT NOT NULL, description TEXT NOT NULL,
          amount INTEGER NOT NULL CHECK(amount>0), payment_method TEXT NOT NULL CHECK(payment_method IN ('cash','card','transfer','qr')),
          created_by INTEGER REFERENCES users(id), created_by_name TEXT NOT NULL, created_at TEXT NOT NULL,
          wallet_id INTEGER REFERENCES cash_wallets(id), category_id INTEGER REFERENCES cash_income_categories(id)
        );
        CREATE INDEX IF NOT EXISTS idx_cash_other_income_date ON cash_other_income(income_date);
        CREATE INDEX IF NOT EXISTS idx_cash_other_income_wallet ON cash_other_income(wallet_id);
        CREATE TABLE IF NOT EXISTS cash_shifts(
          id INTEGER PRIMARY KEY, shift_date TEXT NOT NULL, opened_by INTEGER REFERENCES users(id),
          opening_cash INTEGER NOT NULL DEFAULT 0, opening_noncash INTEGER NOT NULL DEFAULT 0,
          expected_cash INTEGER NOT NULL DEFAULT 0, expected_noncash INTEGER NOT NULL DEFAULT 0,
          actual_cash INTEGER NOT NULL DEFAULT 0, actual_noncash INTEGER NOT NULL DEFAULT 0,
          cash_difference INTEGER NOT NULL DEFAULT 0, noncash_difference INTEGER NOT NULL DEFAULT 0,
          note TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'closed',
          created_at TEXT NOT NULL, closed_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS products(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, purchase_price INTEGER NOT NULL DEFAULT 0 CHECK(purchase_price>=0),
          sale_price INTEGER NOT NULL CHECK(sale_price>=0), stock INTEGER NOT NULL DEFAULT 0 CHECK(stock>=0),
          active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS stock_movements(
          id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id),
          movement_type TEXT NOT NULL CHECK(movement_type IN ('purchase','sale','writeoff','adjustment')),
          quantity INTEGER NOT NULL CHECK(quantity>0), unit_cost INTEGER NOT NULL DEFAULT 0,
          note TEXT NOT NULL, created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS discounts(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, percent INTEGER NOT NULL CHECK(percent BETWEEN 1 AND 100),
          active INTEGER NOT NULL DEFAULT 1, created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS audit_log(
          id INTEGER PRIMARY KEY, actor_user_id INTEGER, actor_role TEXT,
          action TEXT NOT NULL, entity TEXT NOT NULL, entity_id INTEGER,
          details TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings(
          key TEXT PRIMARY KEY, value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS trainers(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1,
          payroll_rate INTEGER NOT NULL DEFAULT 400 CHECK(payroll_rate>=0)
        );
        CREATE TABLE IF NOT EXISTS schedule_resources(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, resource_type TEXT NOT NULL CHECK(resource_type IN ('room','lane')),
          active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          UNIQUE(resource_type, name)
        );
        CREATE UNIQUE INDEX IF NOT EXISTS idx_schedule_resources_type_name_nocase
          ON schedule_resources(resource_type, name COLLATE NOCASE);
        CREATE TABLE IF NOT EXISTS schedule_slots(
          id INTEGER PRIMARY KEY, trainer_id INTEGER NOT NULL REFERENCES trainers(id),
          slot_date TEXT NOT NULL, slot_time TEXT NOT NULL, duration_minutes INTEGER NOT NULL DEFAULT 30,
          capacity INTEGER NOT NULL DEFAULT 1 CHECK(capacity > 0), kind TEXT NOT NULL DEFAULT 'individual',
          notes TEXT DEFAULT '', room_id INTEGER REFERENCES schedule_resources(id), lane_id INTEGER REFERENCES schedule_resources(id),
          UNIQUE(trainer_id,slot_date,slot_time)
        );
        CREATE TABLE IF NOT EXISTS bookings(
          id INTEGER PRIMARY KEY, slot_id INTEGER NOT NULL REFERENCES schedule_slots(id),
          client_id INTEGER NOT NULL REFERENCES clients(id), subscription_id INTEGER REFERENCES subscriptions(id),
          status TEXT NOT NULL DEFAULT 'booked', created_by INTEGER REFERENCES users(id),
          created_at TEXT NOT NULL, UNIQUE(slot_id,client_id)
        );
        CREATE TABLE IF NOT EXISTS waitlist_entries(
          id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL REFERENCES clients(id),
          preferred_date TEXT DEFAULT '', preferred_time TEXT DEFAULT '',
          preferred_trainer_id INTEGER REFERENCES trainers(id),
          kind TEXT NOT NULL DEFAULT 'individual' CHECK(kind IN ('individual','group')),
          status TEXT NOT NULL DEFAULT 'waiting' CHECK(status IN ('waiting','offered','booked','cancelled')),
          notes TEXT DEFAULT '', booking_id INTEGER REFERENCES bookings(id),
          created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_waitlist_status_preference
          ON waitlist_entries(status, preferred_date, preferred_time);
        CREATE TABLE IF NOT EXISTS lesson_groups(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1,
          notes TEXT DEFAULT '', created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS lesson_group_members(
          id INTEGER PRIMARY KEY, group_id INTEGER NOT NULL REFERENCES lesson_groups(id),
          client_id INTEGER NOT NULL REFERENCES clients(id), active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL, UNIQUE(group_id,client_id)
        );
        CREATE INDEX IF NOT EXISTS idx_group_members_active ON lesson_group_members(group_id,active);
        CREATE TABLE IF NOT EXISTS leads(
          id INTEGER PRIMARY KEY, parent_name TEXT NOT NULL, child_name TEXT DEFAULT '',
          phone TEXT NOT NULL, source TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'new',
          next_contact TEXT DEFAULT '', notes TEXT DEFAULT '', assigned_to INTEGER REFERENCES users(id),
          created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          client_id INTEGER REFERENCES clients(id)
        );
        CREATE TABLE IF NOT EXISTS trial_attendance(
          id INTEGER PRIMARY KEY, booking_id INTEGER NOT NULL UNIQUE REFERENCES bookings(id),
          lead_id INTEGER NOT NULL REFERENCES leads(id), client_id INTEGER NOT NULL REFERENCES clients(id),
          lesson_date TEXT NOT NULL, lesson_time TEXT NOT NULL, trainer TEXT NOT NULL,
          status TEXT NOT NULL CHECK(status IN ('attended','missed')),
          created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS tasks(
          id INTEGER PRIMARY KEY, title TEXT NOT NULL, client_id INTEGER REFERENCES clients(id),
          lead_id INTEGER REFERENCES leads(id), due_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open',
          notes TEXT DEFAULT '', assigned_to INTEGER REFERENCES users(id),
          created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL, completed_at TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS client_outreach(
          id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL REFERENCES clients(id),
          outcome TEXT NOT NULL CHECK(outcome IN ('no_answer','interested','later','declined','returned')),
          notes TEXT DEFAULT '', contacted_by INTEGER REFERENCES users(id), contacted_at TEXT NOT NULL,
          assigned_to INTEGER REFERENCES users(id), next_contact TEXT DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_client_outreach_client_date ON client_outreach(client_id,contacted_at);
        CREATE TABLE IF NOT EXISTS marketing_campaigns(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, segment TEXT NOT NULL DEFAULT 'reactivation',
          status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','active','completed','cancelled')),
          offer TEXT DEFAULT '', notes TEXT DEFAULT '', created_by INTEGER REFERENCES users(id),
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS login_attempts(
          id INTEGER PRIMARY KEY, username TEXT NOT NULL, remote_addr TEXT NOT NULL,
          attempted_at TEXT NOT NULL, succeeded INTEGER NOT NULL DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_login_attempts_lookup ON login_attempts(username, remote_addr, attempted_at);
        """)
        # Loyalty is disabled by default. These are settings only; no historic sales or points are changed.
        for key, value in (("loyalty_enabled", "0"), ("loyalty_points_per_100", "0"), ("loyalty_point_value_rubles", "1"), ("loyalty_max_redeem_percent", "0")):
            c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (key,value))
        # Additive trial lesson fields; legacy bookings remain regular by default.
        booking_cols={r[1] for r in c.execute("PRAGMA table_info(bookings)").fetchall()}
        if "booking_type" not in booking_cols:
            c.execute("ALTER TABLE bookings ADD COLUMN booking_type TEXT NOT NULL DEFAULT 'regular' CHECK(booking_type IN ('regular','trial'))")
        if "lead_id" not in booking_cols:
            c.execute("ALTER TABLE bookings ADD COLUMN lead_id INTEGER REFERENCES leads(id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_bookings_trial_lead ON bookings(lead_id,booking_type,status)")
        # A lead can have only one non-cancelled trial booking at a time.
        c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_one_active_trial_per_lead ON bookings(lead_id) WHERE booking_type='trial' AND lead_id IS NOT NULL AND status!='cancelled'")
        # Add physical room/lane assignment without rewriting existing schedule history.
        slot_cols={r[1] for r in c.execute("PRAGMA table_info(schedule_slots)").fetchall()}
        if "room_id" not in slot_cols:
            c.execute("ALTER TABLE schedule_slots ADD COLUMN room_id INTEGER REFERENCES schedule_resources(id)")
        if "lane_id" not in slot_cols:
            c.execute("ALTER TABLE schedule_slots ADD COLUMN lane_id INTEGER REFERENCES schedule_resources(id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_schedule_slots_room_date ON schedule_slots(room_id,slot_date,slot_time)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_schedule_slots_lane_date ON schedule_slots(lane_id,slot_date,slot_time)")
        # Versioned sessions allow password changes to revoke all previously issued
        # signed-cookie sessions without needing a server-side session store.
        ensure_auth_version_column(c)
        # Enforce slot capacity in the database as well as in the form handler.
        # This closes the race where two simultaneous requests both observe a free place.
        c.executescript("""
        CREATE TRIGGER IF NOT EXISTS booking_capacity_insert
        BEFORE INSERT ON bookings
        WHEN NEW.status='booked' AND
             (SELECT COUNT(*) FROM bookings WHERE slot_id=NEW.slot_id AND status='booked') >=
             (SELECT capacity FROM schedule_slots WHERE id=NEW.slot_id)
        BEGIN
          SELECT RAISE(ABORT, 'booking_capacity_full');
        END;
        CREATE TRIGGER IF NOT EXISTS booking_capacity_update
        BEFORE UPDATE OF status, slot_id ON bookings
        WHEN NEW.status='booked' AND (OLD.status!='booked' OR OLD.slot_id!=NEW.slot_id) AND
             (SELECT COUNT(*) FROM bookings WHERE slot_id=NEW.slot_id AND status='booked') >=
             (SELECT capacity FROM schedule_slots WHERE id=NEW.slot_id)
        BEGIN
          SELECT RAISE(ABORT, 'booking_capacity_full');
        END;
        -- A visit must always belong to the same child as its subscription.
        -- Existing rows are not rewritten; this protects new writes and edits.
        CREATE TRIGGER IF NOT EXISTS attendance_subscription_owner_insert
        BEFORE INSERT ON attendance
        WHEN NOT EXISTS (
          SELECT 1 FROM subscriptions s
          WHERE s.id=NEW.subscription_id AND s.client_id=NEW.client_id
        )
        BEGIN
          SELECT RAISE(ABORT, 'attendance_subscription_client_mismatch');
        END;
        CREATE TRIGGER IF NOT EXISTS attendance_subscription_owner_update
        BEFORE UPDATE OF subscription_id, client_id ON attendance
        WHEN NOT EXISTS (
          SELECT 1 FROM subscriptions s
          WHERE s.id=NEW.subscription_id AND s.client_id=NEW.client_id
        )
        BEGIN
          SELECT RAISE(ABORT, 'attendance_subscription_client_mismatch');
        END;
        """)
        # Migrate older installations without modifying existing sales.
        sales_cols={r[1] for r in c.execute("PRAGMA table_info(sales)").fetchall()}
        for col,definition in (("product_id","INTEGER REFERENCES products(id)"),("quantity","INTEGER NOT NULL DEFAULT 1"),("unit_cost_snapshot","INTEGER NOT NULL DEFAULT 0"),("profit_snapshot","INTEGER NOT NULL DEFAULT 0"),("subscription_id","INTEGER REFERENCES subscriptions(id)"),("original_sale_id","INTEGER REFERENCES sales(id)"),("campaign_id","INTEGER REFERENCES marketing_campaigns(id)"),("wallet_id","INTEGER REFERENCES cash_wallets(id)"),("gross_amount","INTEGER NOT NULL DEFAULT 0"),("points_earned","INTEGER NOT NULL DEFAULT 0"),("points_redeemed","INTEGER NOT NULL DEFAULT 0"),("loyalty_discount_amount","INTEGER NOT NULL DEFAULT 0")):
            if col not in sales_cols:
                c.execute(f"ALTER TABLE sales ADD COLUMN {col} {definition}")
        expense_cols={r[1] for r in c.execute("PRAGMA table_info(cash_expenses)").fetchall()}
        if "wallet_id" not in expense_cols:
            c.execute("ALTER TABLE cash_expenses ADD COLUMN wallet_id INTEGER REFERENCES cash_wallets(id)")
        if "category_id" not in expense_cols:
            c.execute("ALTER TABLE cash_expenses ADD COLUMN category_id INTEGER REFERENCES cash_expense_categories(id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_cash_expense_categories_name_nocase ON cash_expense_categories(name COLLATE NOCASE)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_cash_expenses_category_date ON cash_expenses(category_id,expense_date)")
        if c.execute("SELECT COUNT(*) FROM cash_expense_categories").fetchone()[0] == 0:
            for category_name in ("Коммунальные услуги", "Химия бассейна", "Зарплата", "Уборка", "Реклама", "Ремонт и обслуживание", "Прочее"):
                c.execute("INSERT INTO cash_expense_categories(name,active,created_at) VALUES(?,1,?)", (category_name,now()))
        if c.execute("SELECT COUNT(*) FROM cash_income_categories").fetchone()[0] == 0:
            for category_name in ("Прочие поступления", "Внесение собственных средств", "Возврат подотчётных средств", "Прочее"):
                c.execute("INSERT INTO cash_income_categories(name,active,created_at) VALUES(?,1,?)", (category_name,now()))
        c.execute("CREATE INDEX IF NOT EXISTS idx_sales_wallet_status ON sales(wallet_id,status)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_cash_expenses_wallet ON cash_expenses(wallet_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_cash_other_income_wallet ON cash_other_income(wallet_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_cash_other_income_category_date ON cash_other_income(category_id,income_date)")
        # Defaults are configuration only; legacy financial rows are never backfilled automatically.
        if c.execute("SELECT COUNT(*) FROM cash_wallets").fetchone()[0] == 0:
            for wallet_name, payment_method in (("Наличные", "cash"), ("Банковская карта", "card"), ("Перевод", "transfer"), ("QR", "qr")):
                c.execute("INSERT INTO cash_wallets(name,payment_method,opening_balance,active,created_at) VALUES(?,?,0,1,?)", (wallet_name,payment_method,now()))
        c.execute("CREATE INDEX IF NOT EXISTS idx_sales_campaign_status ON sales(campaign_id,status)")
        # Explicitly link each new compensating refund to its source sale. Older
        # refund rows remain unlinked and are intentionally flagged for manual review.
        c.execute("CREATE INDEX IF NOT EXISTS idx_sales_original_sale_id ON sales(original_sale_id)")
        trainer_cols={r[1] for r in c.execute("PRAGMA table_info(trainers)").fetchall()}
        if "payroll_rate" not in trainer_cols:
            c.execute("ALTER TABLE trainers ADD COLUMN payroll_rate INTEGER NOT NULL DEFAULT 400")
        attendance_cols={r[1] for r in c.execute("PRAGMA table_info(attendance)").fetchall()}
        if "schedule_slot_id" not in attendance_cols:
            c.execute("ALTER TABLE attendance ADD COLUMN schedule_slot_id INTEGER REFERENCES schedule_slots(id)")
        leads_cols={r[1] for r in c.execute("PRAGMA table_info(leads)").fetchall()}
        if "client_id" not in leads_cols:
            c.execute("ALTER TABLE leads ADD COLUMN client_id INTEGER REFERENCES clients(id)")
        outreach_cols={r[1] for r in c.execute("PRAGMA table_info(client_outreach)").fetchall()}
        if "assigned_to" not in outreach_cols:
            c.execute("ALTER TABLE client_outreach ADD COLUMN assigned_to INTEGER REFERENCES users(id)")
        if "next_contact" not in outreach_cols:
            c.execute("ALTER TABLE client_outreach ADD COLUMN next_contact TEXT DEFAULT ''")
        if "campaign_id" not in outreach_cols:
            c.execute("ALTER TABLE client_outreach ADD COLUMN campaign_id INTEGER REFERENCES marketing_campaigns(id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_client_outreach_next_contact ON client_outreach(next_contact,assigned_to)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_client_outreach_campaign ON client_outreach(campaign_id)")
        campaign_cols={r[1] for r in c.execute("PRAGMA table_info(marketing_campaigns)").fetchall()}
        if "cost_amount" not in campaign_cols:
            c.execute("ALTER TABLE marketing_campaigns ADD COLUMN cost_amount INTEGER NOT NULL DEFAULT 0 CHECK(cost_amount>=0)")
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('individual_rate','400')")
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('group_rate','270')")
        # Idempotent indexes are applied after all additive column migrations.
        from db_indexes import ensure_indexes
        ensure_indexes(c)

def current_user():
    if not session.get("uid"): return None
    with connect() as c:
        user=c.execute("SELECT id,username,role,active,auth_version FROM users WHERE id=?",(session["uid"],)).fetchone()
    if not user or not user["active"]:
        return None
    if not auth_version_matches(session.get("auth_version"), user["auth_version"]):
        return None
    return user

def is_current_manager():
    u=current_user()
    return bool(u and u["active"] and u["role"]=="manager")


def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        u=current_user()
        if not u or not u["active"]:
            session.clear()
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

def manager_required(fn):
    @wraps(fn)
    @login_required
    def wrapped(*args, **kwargs):
        # Trust the role read from the database, not a potentially stale session value.
        u=current_user()
        if not u or not u["active"]:
            session.clear()
            return redirect(url_for("login"))
        if u["role"]!="manager": abort(403,"Действие доступно только руководителю")
        session["role"] = u["role"]
        return fn(*args, **kwargs)
    return wrapped

def normalize_client_match(value):
    """Normalize a child name for a cautious duplicate-candidate report."""
    value = str(value or "").strip().casefold().replace("ё", "е")
    return re.sub(r"[\s\-_.]+", " ", value) if value else ""

def normalize_phone_match(value):
    """Normalize Russian phone formats without matching short/incomplete numbers."""
    digits = "".join(ch for ch in str(value or "") if ch.isdigit())
    if len(digits) == 11 and digits[0] == "8":
        digits = "7" + digits[1:]
    elif len(digits) == 10:
        digits = "7" + digits
    # Keep only full Russian-style numbers; incomplete data should not form a group.
    return digits if len(digits) == 11 and digits[0] == "7" else ""

def esc(s):
    from html import escape
    return escape(str(s or ""))

STYLE = """
*{box-sizing:border-box}body{margin:0;background:#f3f6fa;color:#182536;font:15px Arial,sans-serif}
header{background:#173c67;color:white;padding:17px 22px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
header b{font-size:22px}main{max-width:1200px;margin:22px auto;padding:0 16px}
nav{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}nav a{background:#fff;border:1px solid #dce4ee;border-radius:9px;padding:10px 13px;color:#173c67;text-decoration:none}
.card{background:white;border:1px solid #dce4ee;border-radius:12px;padding:16px;margin-bottom:16px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}
h2{margin:0 0 12px;font-size:19px}label{display:block;font-size:13px;margin:10px 0 5px;color:#4b5e73}
input,select,textarea{width:100%;padding:10px;border:1px solid #cbd6e2;border-radius:7px;font:inherit}
button,.btn{display:inline-block;border:0;background:#1768a6;color:white;border-radius:7px;padding:10px 14px;font-weight:600;cursor:pointer;margin-top:12px;text-decoration:none}
.danger{background:#a52d38}.muted{color:#63758a}.notice{padding:12px;border-radius:8px;background:#eaf3fc;margin-bottom:14px}
table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:9px;border-bottom:1px solid #e5ebf1;vertical-align:top}th{color:#53667a;font-size:13px}
.tablewrap{overflow-x:auto}.error{background:#ffe8e8;padding:10px;border-radius:8px}.slot-chip{display:block;border-radius:6px;padding:4px 6px;margin:3px 0;font-size:12px;background:#e6f1ff;border-left:4px solid #2672b8}.slot-chip.group{background:#e6f1ff;border-left-color:#2672b8}.slot-chip.individual{background:#ffe8e8;border-left-color:#b63a45}.slot-chip .muted{font-size:11px}
@media(max-width:600px){header{padding:14px}main{margin:12px auto}td,th{padding:7px;font-size:13px}}
"""

def page(title, body):
    csrf = esc(session.get("_csrf", ""))
    # Add a CSRF token to every POST form, including forms with action attributes.
    # Exact-string replacements miss action forms (e.g. freeze/unfreeze), causing 400s.
    import re
    def add_csrf(match):
        tag = match.group(0)
        if 'name="_csrf"' in tag or "name='_csrf'" in tag:
            return tag
        return tag + f'<input type="hidden" name="_csrf" value="{csrf}">'
    body = re.sub(r"<form\b(?=[^>]*\bmethod=['\"]post['\"])[^>]*>", add_csrf, body, flags=re.IGNORECASE)
    u=current_user()
    flashes_html = "".join(f"<div class='notice'>{esc(message)}</div>" for message in get_flashed_messages())
    nav = ""
    if u:
        nav = f"""<nav><a href="/dashboard">Главная</a><a href="/clients">Клиенты</a><a href="/leads">Заявки</a><a href="/trial-lessons">Пробные занятия</a><a href="/tasks">Мои дела</a><a href="/subscriptions">Абонементы</a><a href="/renewals">Продления</a><a href="/reactivation">Возврат клиентов</a><a href="/contact-log">Журнал контактов</a><a href="/campaigns">Кампании</a><a href="/schedule">Расписание</a><a href="/journal">Электронная тетрадь</a><a href="/resources">Помещения/дорожки</a><a href="/groups">Группы</a><a href="/waitlist">Лист ожидания</a><a href="/trainers">Тренеры</a><a href="/attendance">Посещения</a><a href="/attendance-report">Отчёт посещаемости</a><a href="/one-visit">Одно посещение</a><a href="/sales">Продажи</a><a href="/refunds">Возвраты</a>{'<a href="/reports">Отчёты</a><a href="/payroll">Зарплата</a><a href="/cash">Движение денег</a><a href="/wallets">Счета/кошельки</a><a href="/expense-categories">Категории расходов</a><a href="/income-categories">Категории поступлений</a><a href="/loyalty">Бонусная программа</a><a href="/products">Склад</a><a href="/discounts">Скидки</a><a href="/reconciliation">Сверка</a><a href="/schedule-audit">Проверка расписания</a><a href="/followup-audit">Контроль перезвонов</a><a href="/client-data-quality">Качество базы</a><a href="/subscription-integrity">Проверка абонементов</a><a href="/client-retention">Удержание клиентов</a>' if u['role']=='manager' else ''}{'<a href="/backup">CSV-выгрузка</a><a href="/backup/sqlite">Полная копия БД</a>' if u['role']=='manager' else ''}{'<a href="/settings">Настройки</a><a href="/audit">Журнал аудита</a>' if u['role']=='manager' else ''}{'<a href="/system-check">Готовность системы</a>' if u['role']=='manager' else ''}<a href="/account/password">Сменить пароль</a><form method="post" action="/logout" style="display:inline;margin:0"><button type="submit" class="btn">Выйти ({esc(u['username'])})</button></form></nav>"""
    return render_template_string("""<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{{title}} — Лидер CRM</title><style>"""+STYLE+"""</style></head><body><header><b>Лидер CRM</b><span>""" + (f"Пользователь: {esc(u['username'])} · Роль: {'Руководитель' if u['role']=='manager' else 'Администратор'}" if u else "Вход для сотрудников") + """</span></header><main>"""+flashes_html+nav+"""{{body|safe}}</main></body></html>""", title=title, body=body)

@app.route("/setup", methods=["GET","POST"])
def setup():
    if request.method=="POST":
        username=request.form.get("username","").strip()
        password=request.form.get("password","")
        try:
            username=validate_new_admin(username,password)
        except ValueError as exc:
            return page("Первичная настройка",f"<div class='card error'><h2>Ошибка</h2><p>{esc(exc)}</p><a class='btn' href='/setup'>Назад</a></div>"),400
        # Serialize first-account creation so simultaneous setup requests cannot create
        # multiple manager accounts before either request commits its insert.
        with connect() as c:
            c.execute("BEGIN IMMEDIATE")
            count=c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
            if count:
                return "Первичная настройка уже выполнена. Для безопасности удалите или отключите маршрут /setup перед публикацией.", 403
            c.execute("INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)",
                      (username,generate_password_hash(password),"manager",now()))
        return redirect(url_for("login"))
    with connect() as c:
        count=c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
    if count:
        return "Первичная настройка уже выполнена. Для безопасности удалите или отключите маршрут /setup перед публикацией.", 403
    body="""<div class="card"><h2>Первичная настройка</h2><p>Создайте учётную запись руководителя. Используйте уникальный пароль длиной не менее 12 символов.</p><form method="post">
    <label>Логин</label><input name="username" required minlength="3" autocomplete="username">
    <label>Пароль</label><input name="password" type="password" required minlength="12" autocomplete="new-password">
    <button>Создать руководителя</button></form></div>"""
    return page("Первичная настройка",body)

LOGIN_WINDOW_MINUTES = 15
LOGIN_MAX_FAILURES = 5
LOGIN_MAX_IP_FAILURES = 25


def login_is_limited(c, username, remote_addr, at=None):
    """Throttle repeated guesses for one account and sprays across usernames."""
    at = at or datetime.now()
    cutoff = (at - timedelta(minutes=LOGIN_WINDOW_MINUTES)).isoformat(timespec="seconds")
    count = c.execute("SELECT COUNT(*) n FROM login_attempts WHERE username=? AND remote_addr=? AND succeeded=0 AND attempted_at>=?",
                      (username, remote_addr, cutoff)).fetchone()["n"]
    if count >= LOGIN_MAX_FAILURES:
        return True
    # Pair-only throttling is easy to bypass by cycling usernames. Apply a higher
    # per-address threshold as a second barrier against credential spraying.
    ip_count = c.execute("SELECT COUNT(*) n FROM login_attempts WHERE remote_addr=? AND succeeded=0 AND attempted_at>=?",
                         (remote_addr, cutoff)).fetchone()["n"]
    return ip_count >= LOGIN_MAX_IP_FAILURES

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        username=request.form.get("username","").strip()
        password=request.form.get("password","")
        remote_addr=request.remote_addr or "unknown"
        if len(username)>100 or len(password)>1024:
            # Bound expensive password-hash work and avoid storing attacker-sized inputs.
            username=username[:100]
            password="!invalid-oversized-password!"
        with connect() as c:
            # Keep this bounded; detailed authentication history is not needed beyond one day.
            c.execute("DELETE FROM login_attempts WHERE attempted_at<?", ((datetime.now()-timedelta(days=1)).isoformat(timespec="seconds"),))
            if login_is_limited(c, username, remote_addr):
                return page("Вход","<div class='card error'>Слишком много неудачных попыток. Подождите 15 минут и повторите.</div>"+login_form()),429
            u=c.execute("SELECT * FROM users WHERE username=? AND active=1",(username,)).fetchone()
            if u and check_password_hash(u["password_hash"],password):
                c.execute("INSERT INTO login_attempts(username,remote_addr,attempted_at,succeeded) VALUES(?,?,?,1)",(username,remote_addr,now()))
                c.execute("DELETE FROM login_attempts WHERE username=? AND remote_addr=? AND succeeded=0",(username,remote_addr))
                session.clear(); session["uid"]=u["id"]; session["role"]=u["role"]; session["auth_version"]=u["auth_version"]
                return redirect(url_for("dashboard"))
            c.execute("INSERT INTO login_attempts(username,remote_addr,attempted_at,succeeded) VALUES(?,?,?,0)",(username,remote_addr,now()))
        return page("Вход","<div class='card error'>Неверный логин или пароль.</div>"+login_form()),401
    return page("Вход",login_form())
def login_form():
    return """<div class="card"><h2>Вход для сотрудников</h2><form method="post"><label>Логин</label><input name="username" autocomplete="username" required><label>Пароль</label><input type="password" name="password" autocomplete="current-password" required><button>Войти</button></form></div>"""
@app.post("/logout")
@login_required
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.get("/")
def root(): return redirect(url_for("dashboard") if current_user() else url_for("login"))

@app.route("/account/password", methods=["GET", "POST"])
@login_required
def change_password():
    if request.method == "POST":
        current_password=request.form.get("current_password","")
        new_password=request.form.get("new_password","")
        confirm_password=request.form.get("confirm_password","")
        try:
            validate_password(new_password)
        except ValueError as exc:
            abort(400,str(exc))
        if new_password != confirm_password:
            abort(400,"Новый пароль и подтверждение не совпадают")
        with connect() as c:
            user=c.execute("SELECT id,password_hash,active FROM users WHERE id=?",(session["uid"],)).fetchone()
            if not user or not user["active"]:
                session.clear()
                return redirect(url_for("login"))
            if not check_password_hash(user["password_hash"],current_password):
                abort(400,"Текущий пароль указан неверно")
            if check_password_hash(user["password_hash"],new_password):
                abort(400,"Новый пароль должен отличаться от текущего")
            c.execute("UPDATE users SET password_hash=?,auth_version=auth_version+1 WHERE id=?",(generate_password_hash(new_password),user["id"]))
            audit(c,"user.password_changed","user",user["id"],{"sessions_revoked":True})
        # Revoke this cookie too. The next login creates a fresh session version;
        # all other browsers/devices are rejected by current_user on their next request.
        session.clear()
        flash("Пароль изменён. Войдите заново; остальные сеансы также завершены.")
        return redirect(url_for("login"))
    body="""<div class='card'><h2>Смена пароля</h2><p>Используйте уникальный пароль не короче 12 символов.</p><form method='post'><label>Текущий пароль</label><input type='password' name='current_password' required autocomplete='current-password'><label>Новый пароль</label><input type='password' name='new_password' required minlength='12' maxlength='256' autocomplete='new-password'><label>Повторите новый пароль</label><input type='password' name='confirm_password' required minlength='12' maxlength='256' autocomplete='new-password'><button>Изменить пароль</button></form></div>"""
    return page("Смена пароля",body)


@app.get("/dashboard")
@login_required
def dashboard():
    with connect() as c:
        counts={k:c.execute(q).fetchone()["n"] for k,q in {
          "clients":"SELECT COUNT(*) n FROM clients",
          "subs":"SELECT COUNT(*) n FROM subscriptions WHERE status='active'",
          "sales":"SELECT COUNT(*) n FROM sales WHERE status='completed'",
          "refunds":"SELECT COUNT(*) n FROM refund_requests WHERE status='pending'"}.items()}
        revenue=c.execute("SELECT COALESCE(SUM(CASE WHEN status='completed' THEN amount WHEN status='refund' THEN -amount ELSE 0 END),0) n FROM sales").fetchone()["n"]
        today_slots=c.execute("""SELECT sl.id,sl.slot_time,sl.duration_minutes,sl.capacity,sl.kind,sl.notes,tr.name trainer_name,
            (SELECT COUNT(*) FROM bookings b WHERE b.slot_id=sl.id AND b.status='booked') booked_count,
            (SELECT GROUP_CONCAT(cl.child_name, ', ') FROM bookings b JOIN clients cl ON cl.id=b.client_id WHERE b.slot_id=sl.id AND b.status='booked') child_names
            FROM schedule_slots sl JOIN trainers tr ON tr.id=sl.trainer_id WHERE sl.slot_date=? ORDER BY sl.slot_time, tr.name""",(date.today().isoformat(),)).fetchall()
        open_tasks=c.execute("SELECT COUNT(*) n FROM tasks WHERE status='open' AND substr(due_at,1,10)<=?",(date.today().isoformat(),)).fetchone()["n"]
    body="<div class='grid'>"
    dashboard_cards=[("Клиенты",counts["clients"],"Всего в базе"),("Активные абонементы",counts["subs"],"Не заблокированы и не завершены"),("Продажи",counts["sales"],"Завершённые")]
    if is_current_manager():
        dashboard_cards.append(("Выручка",f"{revenue:,} ₽","По завершённым продажам за вычетом возвратов"))
    dashboard_cards.append(("Возвраты",counts["refunds"],"Ожидают решения руководителя"))
    for title,value,sub in dashboard_cards:
        body+=f"<div class='card'><h2>{title}</h2><p style='font-size:30px;margin:10px 0'>{value}</p><span class='muted'>{sub}</span></div>"
    body+="</div><div class='card'><h2>Быстрые действия</h2><div class='grid'><a class='btn' href='/clients'>Найти / добавить клиента</a><a class='btn' href='/schedule'>Записать на тренировку</a><a class='btn' href='/sales'>Оформить продажу</a><a class='btn' href='/attendance'>Отметить посещение</a><a class='btn' href='/leads'>Обработать заявки</a><a class='btn' href='/tasks'>Задачи администратора</a></div></div>"
    body+="<div class='card'><h2>Расписание на сегодня · "+esc(date.today().strftime('%d.%m.%Y'))+"</h2>"
    if not today_slots:
        body+="<p class='muted'>На сегодня занятия не созданы.</p><a class='btn' href='/schedule'>Открыть расписание</a>"
    else:
        body+="<div class='tablewrap'><table><tr><th>Время</th><th>Тренер</th><th>Тип</th><th>Запись</th><th>Дети</th><th></th></tr>"
        for sl in today_slots:
            occupancy=f"{sl['booked_count']} / {sl['capacity']}"
            kids=esc(sl['child_names'] or 'Пока нет записей')
            body+=f"<tr><td>{esc(sl['slot_time'])}</td><td>{esc(sl['trainer_name'])}</td><td>{esc(sl['kind'])}</td><td>{occupancy}</td><td>{kids}</td><td><a href='/schedule'>Открыть</a></td></tr>"
        body+="</table></div><p><a class='btn' href='/schedule'>Полное расписание</a></p>"
    body+="</div><div class='card'><h2>Контроль дня</h2><p>Просроченные и сегодняшние открытые задачи: <b>"+str(open_tasks)+"</b></p><a class='btn' href='/tasks'>Перейти к задачам</a> <a class='btn' href='/refunds'>Проверить возвраты ("+str(counts['refunds'])+")</a></div>"
    body+="<div class='notice'>Система работает отдельно от WordPress. Перед размещением в интернете нужны HTTPS, постоянный секрет сессии, резервное копирование и проверка безопасности.</div>"
    return page("Главная",body)

@app.route("/clients",methods=["GET","POST"])
@login_required
def clients():
    with connect() as c:
        if request.method=="POST":
            child=request.form.get("child_name","").strip(); parent=request.form.get("parent_name","").strip(); phone=request.form.get("phone","").strip()
            if not child or not parent or not phone: abort(400,"Заполните имя ребёнка, родителя и телефон")
            cur=c.execute("INSERT INTO clients(child_name,parent_name,phone,birth_date,address,notes,created_at) VALUES(?,?,?,?,?,?,?)",
                (child,parent,phone,request.form.get("birth_date",""),request.form.get("address","").strip(),request.form.get("notes","").strip(),now()))
            audit(c,"client.created","client",cur.lastrowid,{"child_name":child,"phone":phone})
            return redirect(url_for("clients"))
        q=request.args.get("q","").strip()
        status=request.args.get("status","").strip()
        if status not in ("active","inactive","archived","lost"): status=""
        sql="SELECT * FROM clients WHERE (child_name LIKE ? OR parent_name LIKE ? OR phone LIKE ?)"
        params=[f"%{q}%",f"%{q}%",f"%{q}%"]
        if status:
            sql+=" AND status=?"; params.append(status)
        sql+=" ORDER BY CASE status WHEN 'active' THEN 0 WHEN 'lost' THEN 1 WHEN 'inactive' THEN 2 ELSE 3 END,child_name LIMIT 500"
        rows=c.execute(sql,params).fetchall()
        status_counts={r["status"]:r["n"] for r in c.execute("SELECT status,COUNT(*) n FROM clients GROUP BY status").fetchall()}
    form="""<div class="card"><h2>Новый клиент</h2><form method="post"><label>Ребёнок *</label><input name="child_name" required><label>Родитель *</label><input name="parent_name" required><label>Телефон *</label><input name="phone" required><label>Дата рождения</label><input type="date" name="birth_date"><label>Адрес / район</label><input name="address"><label>Примечание</label><textarea name="notes"></textarea><button>Сохранить клиента</button></form></div>"""
    labels={"active":"Активный","inactive":"Неактивный","archived":"Архив","lost":"Потеряшка"}
    table="<div class='card'><h2>База клиентов</h2><p><a class='btn' href='/client-duplicates'>Найти возможные дубли</a></p><div class='grid'><a class='btn' href='/clients'>Все: "+str(sum(status_counts.values()))+"</a>"
    for key,label in labels.items(): table+=f"<a class='btn' href='/clients?status={key}'>{label}: {status_counts.get(key,0)}</a>"
    table+="</div><form method='get'><label>Поиск по ребёнку, родителю или телефону</label><input name='q' placeholder='Введите имя или телефон' value='"+esc(q)+"'><input type='hidden' name='status' value='"+esc(status)+"'><button>Найти</button></form><div class='tablewrap'><table><tr><th>Ребёнок</th><th>Родитель</th><th>Телефон</th><th>Дата рождения</th><th>Район / адрес</th><th>Статус</th></tr>"
    for r in rows: table+=f"<tr><td><a href='/client/{r['id']}'>{esc(r['child_name'])}</a></td><td>{esc(r['parent_name'])}</td><td>{esc(r['phone'])}</td><td>{esc(r['birth_date'])}</td><td>{esc(r['address'])}</td><td>{labels.get(r['status'],esc(r['status']))}</td></tr>"
    table+="</table></div></div>"
    return page("Клиенты",form+table)

@app.route("/client-duplicates")
@login_required
def client_duplicates():
    """Report likely duplicate client records; never merge or modify them automatically."""
    with connect() as c:
        rows = c.execute("SELECT id,child_name,parent_name,phone,status,created_at FROM clients ORDER BY id").fetchall()
    buckets = {}
    for row in rows:
        name_key = normalize_client_match(row["child_name"])
        phone_key = normalize_phone_match(row["phone"])
        if name_key and phone_key:
            buckets.setdefault((name_key, phone_key), []).append(row)
    groups = [group for group in buckets.values() if len(group) > 1]
    groups.sort(key=lambda group: (group[0]["child_name"].casefold(), group[0]["id"]))
    if request.args.get("format") == "csv":
        # Contact exports contain personal data; only the current manager may download them.
        if not is_current_manager(): abort(403, "Выгрузка персональных данных доступна только руководителю")
        output = io.StringIO(newline="")
        writer = csv.writer(output, lineterminator="\r\n")
        writer.writerow(["Группа дублей", "ID клиента", "Ребёнок", "Родитель", "Телефон", "Статус", "Создан"])
        for index, group in enumerate(groups, 1):
            for row in group:
                writer.writerow(safe_csv_row([index, row["id"], row["child_name"], row["parent_name"], row["phone"], row["status"], row["created_at"]]))
        response = app.response_class("\ufeff" + output.getvalue(), mimetype="text/csv; charset=utf-8")
        response.headers["Content-Disposition"] = 'attachment; filename="client_duplicate_candidates.csv"'
        response.headers["Cache-Control"] = "no-store"
        return response
    export_link = "<p><a class='btn' href='/client-duplicates?format=csv'>Выгрузить список в CSV</a></p>" if is_current_manager() else "<p class='muted'>CSV-выгрузка доступна руководителю.</p>"
    body = "<div class='card'><p><a href='/clients'>← К базе клиентов</a></p><h2>Возможные дубли клиентов</h2><p class='muted'>Совпадают нормализованные имя ребёнка и телефон. Это подсказки для ручной проверки, а не доказательство дубля: не объединяйте карточки, пока не проверили историю оплат и абонементов.</p>" + export_link
    if not groups:
        body += "<p>Совпадений по имени ребёнка и телефону не найдено.</p>"
    else:
        body += f"<p><strong>Найдено групп: {len(groups)}</strong></p>"
        for index, group in enumerate(groups, 1):
            body += f"<h3>Группа {index}</h3><div class='tablewrap'><table><tr><th>ID</th><th>Ребёнок</th><th>Родитель</th><th>Телефон</th><th>Статус</th><th>Создан</th></tr>"
            for row in group:
                body += f"<tr><td><a href='/client/{row['id']}'>#{row['id']}</a></td><td>{esc(row['child_name'])}</td><td>{esc(row['parent_name'])}</td><td>{esc(row['phone'])}</td><td>{esc(row['status'])}</td><td>{esc(row['created_at'])}</td></tr>"
            body += "</table></div>"
    body += "</div>"
    response = app.make_response(page("Возможные дубли", body))
    response.headers["Cache-Control"] = "no-store"
    response.headers["Pragma"] = "no-cache"
    return response

@app.route("/client/<int:client_id>", methods=["GET", "POST"])
@login_required
def client_profile(client_id):
    """Unified client card with editable contact details and linked history."""
    with connect() as c:
        client=c.execute("SELECT * FROM clients WHERE id=?",(client_id,)).fetchone()
        if not client: abort(404,"Клиент не найден")
        if request.method=="POST":
            child=request.form.get("child_name","").strip()
            parent=request.form.get("parent_name","").strip()
            phone=request.form.get("phone","").strip()
            status=request.form.get("status","active").strip()
            if not child or not parent or not phone: abort(400,"Имя ребёнка, родителя и телефон обязательны")
            if status not in ("active","inactive","archived","lost"): abort(400,"Недопустимый статус клиента")
            c.execute("UPDATE clients SET child_name=?,parent_name=?,phone=?,birth_date=?,address=?,notes=?,status=? WHERE id=?",
              (child,parent,phone,request.form.get("birth_date",""),request.form.get("address","").strip(),request.form.get("notes","").strip(),status,client_id))
            audit(c,"client.updated","client",client_id,{"child_name":child,"status":status})
            return redirect(url_for("client_profile",client_id=client_id))
        subs=c.execute("SELECT * FROM subscriptions WHERE client_id=? ORDER BY id DESC",(client_id,)).fetchall()
        visits=c.execute("SELECT lesson_date,lesson_time,trainer,status,rate_snapshot FROM attendance WHERE client_id=? ORDER BY lesson_date DESC,lesson_time DESC LIMIT 200",(client_id,)).fetchall()
        sales_rows=c.execute("SELECT id,item,amount,payment_method,status,created_at FROM sales WHERE client_id=? ORDER BY id DESC LIMIT 100",(client_id,)).fetchall()
        tasks_rows=c.execute("SELECT title,due_at,status,notes FROM tasks WHERE client_id=? ORDER BY due_at DESC LIMIT 50",(client_id,)).fetchall()
        financial=c.execute("SELECT COALESCE(SUM(CASE WHEN status='completed' THEN amount WHEN status='refund' THEN -amount ELSE 0 END),0) AS net_paid, COALESCE(SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END),0) AS completed_sales, COALESCE(SUM(CASE WHEN status='refund' THEN 1 ELSE 0 END),0) AS refunds FROM sales WHERE client_id=?",(client_id,)).fetchone()
        source_summary=load_gocrm_client_summary(c,client_id)
        attendance_counts={r['status']:r['n'] for r in c.execute("SELECT status,COUNT(*) n FROM attendance WHERE client_id=? GROUP BY status",(client_id,)).fetchall()}
        freeze_rows=c.execute("SELECT f.start_date,f.end_date,f.days,f.reason,f.created_at,s.title FROM subscription_freezes f JOIN subscriptions s ON s.id=f.subscription_id WHERE s.client_id=? ORDER BY f.id DESC LIMIT 100",(client_id,)).fetchall()
        active_subs=sum(1 for r in subs if r['status']=='active')
        remaining_lessons=sum(max(0,int(r['remaining_lessons'])) for r in subs if r['status']=='active')
    status_options="".join(f"<option value='{v}' {'selected' if client['status']==v else ''}>{label}</option>" for v,label in (("active","Активный"),("inactive","Неактивный"),("archived","Архив"),("lost","Потеряшка")))
    body=f"""<div class='card'><p><a href='/clients'>← К списку клиентов</a></p><h2>Карточка клиента №{client_id}</h2>
    <form method='post'><div class='grid'><div><label>Ребёнок *</label><input name='child_name' value='{esc(client['child_name'])}' required></div><div><label>Родитель *</label><input name='parent_name' value='{esc(client['parent_name'])}' required></div><div><label>Телефон *</label><input name='phone' value='{esc(client['phone'])}' required></div><div><label>Дата рождения</label><input type='date' name='birth_date' value='{esc(client['birth_date'])}'></div><div><label>Адрес / район</label><input name='address' value='{esc(client['address'])}'></div><div><label>Статус</label><select name='status'>{status_options}</select></div></div><label>Примечание</label><textarea name='notes'>{esc(client['notes'])}</textarea><button>Сохранить карточку</button></form></div>"""
    body+="<div class='grid'>"
    for label,value,detail in [("Чистые оплаты",f"{financial['net_paid']:,} ₽","Продажи минус оформленные возвраты"),("Продаж",financial['completed_sales'],f"Возвратов: {financial['refunds']}"),("Активные абонементы",active_subs,f"Занятий осталось: {remaining_lessons}"),("Посещения",attendance_counts.get('attended',0),f"Пропуски: {attendance_counts.get('missed',0)} · Запланировано: {attendance_counts.get('planned',0)}")]:
        body+=f"<div class='card'><h3>{label}</h3><p style='font-size:25px;margin:8px 0'>{value}</p><span class='muted'>{detail}</span></div>"
    body+="</div>"
    source_summary_html=""
    if source_summary:
        source_summary_html=("<div class='card'><h2>Сводка из GoCRM — только для сверки</h2>"
            "<p class='muted'>Эти значения перенесены из сводных полей исходной системы. Они не являются кассовыми операциями, не создают абонементы и не меняют локальные продажи. Знак задолженности и методику расчёта нужно сверить с GoCRM.</p>"
            f"<p><b>ID клиента в GoCRM:</b> {esc(source_summary['source_id'])}</p>"
            f"<p><b>Задолженность по выгрузке:</b> {format_rubles_from_kopecks(source_summary['debt_amount_kopecks'])} ₽</p>"
            f"<p><b>Последняя оплата в выгрузке:</b> {esc(source_summary['last_payment_date'] or '—')} · {format_rubles_from_kopecks(source_summary['last_payment_amount_kopecks'])} ₽</p>"
            f"<p><b>Всего оплачено по выгрузке:</b> {format_rubles_from_kopecks(source_summary['lifetime_paid_amount_kopecks'])} ₽</p>"
            f"<p><b>Абонементы по тексту выгрузки:</b> {esc(source_summary['subscription_summary'] or '—')}</p>"
            f"<p><b>Первое / последнее посещение:</b> {esc(source_summary['first_visit_date'] or '—')} / {esc(source_summary['last_visit_date'] or '—')}</p>"
            f"<p><b>Следующее занятие по выгрузке:</b> {esc(source_summary['next_lesson_date'] or '—')}</p></div>")
    body+=source_summary_html
    # Quick booking directly from the client card: only future/today slots with capacity
    # and this child's own active subscriptions are offered.
    with connect() as c:
        quick_slots=c.execute("""SELECT sl.id,sl.slot_date,sl.slot_time,sl.kind,sl.capacity,tr.name trainer_name,
            (SELECT COUNT(*) FROM bookings b WHERE b.slot_id=sl.id AND b.status='booked') booked
            FROM schedule_slots sl JOIN trainers tr ON tr.id=sl.trainer_id
            WHERE sl.slot_date>=? ORDER BY sl.slot_date,sl.slot_time LIMIT 300""",(today(),)).fetchall()
    quick_slots=[r for r in quick_slots if r['booked'] < r['capacity']]
    quick_subs=[r for r in subs if r['status']=='active' and int(r['remaining_lessons'])>0 and (not r['expires_at'] or r['expires_at']>=today())]
    quick_slot_opts="".join(f"<option value='{r['id']}'>{esc(r['slot_date'])} {esc(r['slot_time'])} — {esc(r['trainer_name'])}, {'группа' if r['kind']=='group' else 'индивидуально'}, мест {r['booked']}/{r['capacity']}</option>" for r in quick_slots)
    quick_sub_opts="".join(f"<option value='{r['id']}'>{esc(r['title'])} — осталось {r['remaining_lessons']}</option>" for r in quick_subs)
    body+="<div class='card'><h2>Быстрая запись на тренировку</h2>"
    if quick_slots and quick_subs:
        body+=f"<form method='post' action='/client/{client_id}/book'><label>Свободное занятие</label><select name='slot_id' required>{quick_slot_opts}</select><label>Абонемент этого ребёнка</label><select name='subscription_id' required>{quick_sub_opts}</select><button>Записать ребёнка</button></form>"
    elif not quick_subs:
        body+="<p>Нет активного абонемента с оставшимися занятиями. Сначала оформите продажу абонемента.</p><a class='btn' href='/subscriptions'>Продать абонемент</a>"
    else:
        body+="<p>Нет свободных будущих занятий. Создайте слот в расписании.</p><a class='btn' href='/schedule'>Открыть расписание</a>"
    body+="</div>"
    body+="<div class='card'><h2>Абонементы</h2><div class='tablewrap'><table><tr><th>Название</th><th>Занятий осталось</th><th>Цена</th><th>Куплен</th><th>До</th><th>Статус</th></tr>"
    for r in subs: body+=f"<tr><td>{esc(r['title'])}</td><td>{r['remaining_lessons']} / {r['total_lessons']}</td><td>{r['price']:,} ₽</td><td>{esc(r['purchased_at'])}</td><td>{esc(r['expires_at'])}</td><td>{esc(r['status'])}</td></tr>"
    body+="</table></div></div><div class='card'><h2>История посещений</h2><div class='tablewrap'><table><tr><th>Дата</th><th>Время</th><th>Тренер</th><th>Статус</th><th>Ставка</th></tr>"
    for r in visits: body+=f"<tr><td>{esc(r['lesson_date'])}</td><td>{esc(r['lesson_time'])}</td><td>{esc(r['trainer'])}</td><td>{esc(r['status'])}</td><td>{r['rate_snapshot']} ₽</td></tr>"
    body+="</table></div></div><div class='card'><h2>История оплат и продаж</h2><div class='tablewrap'><table><tr><th>№</th><th>Позиция</th><th>Сумма</th><th>Оплата</th><th>Статус</th><th>Дата</th></tr>"
    for r in sales_rows: body+=f"<tr><td>{r['id']}</td><td>{esc(r['item'])}</td><td>{r['amount']:,} ₽</td><td>{esc(r['payment_method'])}</td><td>{esc(r['status'])}</td><td>{esc(r['created_at'])}</td></tr>"
    body+="</table></div></div><div class='card'><h2>Задачи по клиенту</h2><div class='tablewrap'><table><tr><th>Задача</th><th>Срок</th><th>Статус</th><th>Примечание</th></tr>"
    for r in tasks_rows: body+=f"<tr><td>{esc(r['title'])}</td><td>{esc(r['due_at'])}</td><td>{esc(r['status'])}</td><td>{esc(r['notes'])}</td></tr>"
    body+="</table></div></div>"
    body+="<div class='card'><h2>История заморозок</h2><div class='tablewrap'><table><tr><th>Абонемент</th><th>С</th><th>По</th><th>Дней</th><th>Причина</th><th>Создано</th></tr>"
    for r in freeze_rows: body+=f"<tr><td>{esc(r['title'])}</td><td>{esc(r['start_date'])}</td><td>{esc(r['end_date'])}</td><td>{r['days']}</td><td>{esc(r['reason'])}</td><td>{esc(r['created_at'])}</td></tr>"
    body+="</table></div></div>"
    return page(f"Клиент: {client['child_name']}",body)

@app.route("/client/<int:client_id>/book", methods=["POST"])
@login_required
def client_quick_book(client_id):
    """Create a booking from a client card, validating client-owned subscription and capacity."""
    try:
        slot_id=int(request.form.get("slot_id", "0"))
        sub_id=int(request.form.get("subscription_id", "0"))
    except ValueError:
        abort(400, "Выберите занятие и абонемент")
    with connect() as c:
        client=c.execute("SELECT id FROM clients WHERE id=?",(client_id,)).fetchone()
        if not client: abort(404,"Клиент не найден")
        slot=c.execute("SELECT * FROM schedule_slots WHERE id=?",(slot_id,)).fetchone()
        if not slot: abort(400,"Занятие не найдено")
        if slot["slot_date"] < today(): abort(400,"Нельзя записать на прошедшее занятие")
        sub=c.execute("SELECT * FROM subscriptions WHERE id=? AND client_id=? AND status='active' AND remaining_lessons>0 AND (COALESCE(expires_at,'')='' OR expires_at>=?)",(sub_id,client_id,slot["slot_date"])).fetchone()
        if not sub: abort(400,"Абонемент не подходит ребёнку, закончился или истекает до даты занятия")
        existing=c.execute("SELECT id,status FROM bookings WHERE slot_id=? AND client_id=?",(slot_id,client_id)).fetchone()
        if existing and existing["status"]=="attended": abort(400,"Ребёнок уже посетил это занятие")
        if existing and existing["status"]=="missed": abort(400,"Ребёнок уже отмечен как пропустивший это занятие")
        if existing and existing["status"]=="booked": abort(400,"Ребёнок уже записан на это занятие")
        count=c.execute("SELECT COUNT(*) n FROM bookings WHERE slot_id=? AND status='booked'",(slot_id,)).fetchone()["n"]
        if count>=slot["capacity"]: abort(400,"На это время уже нет свободных мест")
        try:
            if existing and existing["status"]=="cancelled":
                c.execute("UPDATE bookings SET status='booked',subscription_id=?,created_by=?,created_at=? WHERE id=? AND status='cancelled'",(sub_id,session["uid"],now(),existing["id"]))
                booking_id=existing["id"]
                action="booking.rebooked"
            else:
                cur=c.execute("INSERT INTO bookings(slot_id,client_id,subscription_id,created_by,created_at) VALUES(?,?,?,?,?)",(slot_id,client_id,sub_id,session["uid"],now()))
                booking_id=cur.lastrowid
                action="booking.created_from_client"
        except sqlite3.IntegrityError as exc:
            if "booking_capacity_full" in str(exc): abort(400,"На это время уже нет свободных мест")
            abort(400,"Не удалось записать ребёнка: проверьте существующие записи")
        audit(c,action,"booking",booking_id,{"slot_id":slot_id,"client_id":client_id,"subscription_id":sub_id})
    return redirect(url_for("client_profile",client_id=client_id))


@app.route("/subscriptions",methods=["GET","POST"])
@login_required
def subscriptions():
    with connect() as c:
        if request.method=="POST":
            try: client_id=int(request.form["client_id"]); total=int(request.form["total_lessons"]); price=int(request.form["price"])
            except: abort(400,"Проверьте числа и клиента")
            title=request.form.get("title","").strip()
            expires_at=request.form.get("expires_at","").strip()
            payment_method=request.form.get("payment_method","cash")
            try: campaign_id=int(request.form.get("campaign_id") or 0)
            except ValueError: abort(400,"Неверная маркетинговая кампания")
            campaign=c.execute("SELECT id,name FROM marketing_campaigns WHERE id=? AND status IN ('draft','active','completed')",(campaign_id,)).fetchone() if campaign_id else None
            if campaign_id and not campaign: abort(400,"Кампания недоступна для привязки к продаже")
            if total<1 or total>1000 or price<1 or price>100_000_000 or not title or len(title)>100:
                abort(400,"Название — до 100 символов, занятий — от 1 до 1000, цена — от 1 до 100 000 000 ₽")
            if payment_method not in ("cash","card","transfer","qr"): abort(400,"Неверный способ оплаты")
            if expires_at:
                try: date.fromisoformat(expires_at)
                except ValueError: abort(400,"Укажите корректную дату окончания абонемента")
                if expires_at<today(): abort(400,"Срок действия нового абонемента не может быть в прошлом")
            if not c.execute("SELECT id FROM clients WHERE id=?",(client_id,)).fetchone(): abort(400,"Клиент не найден")
            cur=c.execute("INSERT INTO subscriptions(client_id,title,total_lessons,remaining_lessons,price,purchased_at,expires_at,created_by) VALUES(?,?,?,?,?,?,?,?)",
                (client_id,title,total,total,price,today(),expires_at,session["uid"]))
            sale=c.execute("INSERT INTO sales(client_id,item,amount,payment_method,status,created_by,created_at,subscription_id,campaign_id) VALUES(?,?,?,?,?,?,?,?,?)",
                (client_id,title,price,payment_method,"completed",session["uid"],now(),cur.lastrowid,campaign_id or None))
            audit(c,"subscription.created","subscription",cur.lastrowid,{"client_id":client_id,"title":title,"lessons":total,"price":price,"sale_id":sale.lastrowid})
            audit(c,"sale.created","sale",sale.lastrowid,{"client_id":client_id,"item":title,"amount":price,"linked_subscription":cur.lastrowid,"campaign_id":campaign_id or None})
            return redirect(url_for("subscriptions"))
        clients=c.execute("SELECT id,child_name FROM clients ORDER BY child_name").fetchall()
        rows=c.execute("SELECT s.*,c.child_name FROM subscriptions s JOIN clients c ON c.id=s.client_id ORDER BY s.id DESC").fetchall()
        campaigns=c.execute("SELECT id,name,status FROM marketing_campaigns WHERE status IN ('draft','active','completed') ORDER BY CASE status WHEN 'active' THEN 0 WHEN 'draft' THEN 1 ELSE 2 END,name").fetchall()
    options="".join(f"<option value='{r['id']}'>{esc(r['child_name'])}</option>" for r in clients)
    campaign_opts="<option value='0'>Без кампании</option>"+"".join(f"<option value='{r['id']}'>{esc(r['name'])} — {r['status']}</option>" for r in campaigns)
    form=f"""<div class="card"><h2>Продать абонемент</h2><form method="post"><label>Клиент</label><select name="client_id" required>{options}</select><label>Название</label><input name="title" placeholder="Например, 8 занятий" required><label>Количество занятий</label><input type="number" name="total_lessons" min="1" required><label>Цена, ₽</label><input type="number" name="price" min="1" required><label>Действует до</label><input type="date" name="expires_at"><label>Маркетинговая кампания (если продажа связана с акцией)</label><select name="campaign_id">{campaign_opts}</select><label>Оплата</label><select name="payment_method"><option value="cash">Наличные</option><option value="card">Карта</option><option value="transfer">Перевод</option><option value="qr">QR</option></select><button>Продать абонемент</button></form></div>"""
    table="<div class='card'><h2>Абонементы</h2><div class='tablewrap'><table><tr><th>№</th><th>Клиент</th><th>Название</th><th>Остаток</th><th>Цена</th><th>Куплен</th><th>Действует до</th><th>Статус</th><th>Управление</th></tr>"
    for r in rows:
        action=""
        if is_current_manager() and r["status"]=="active":
            action=f"<form method='post' action='/subscription/{r['id']}/freeze'><input type='number' name='days' min='1' max='90' placeholder='Дней' required><input name='reason' placeholder='Причина заморозки' required><button>Заморозить</button></form>"
        elif is_current_manager() and r["status"]=="frozen":
            action=f"<form method='post' action='/subscription/{r['id']}/unfreeze'><button>Разморозить</button></form>"
        table+=f"<tr><td>{r['id']}</td><td>{esc(r['child_name'])}</td><td>{esc(r['title'])}</td><td>{r['remaining_lessons']} / {r['total_lessons']}</td><td>{r['price']} ₽</td><td>{r['purchased_at']}</td><td>{esc(r['expires_at'])}</td><td>{esc(r['status'])}</td><td>{action}</td></tr>"
    return page("Абонементы",form+table+"</table></div></div>")



@app.route("/subscription/<int:sub_id>/freeze", methods=["POST"])
@login_required
def subscription_freeze(sub_id):
    if not is_current_manager(): abort(403)
    try: days=int(request.form.get("days",""))
    except: abort(400,"Укажите количество дней заморозки")
    reason=request.form.get("reason","").strip()
    if days<1 or days>90 or not reason: abort(400,"Укажите причину и срок от 1 до 90 дней")
    with connect() as c:
        sub=c.execute("SELECT * FROM subscriptions WHERE id=?",(sub_id,)).fetchone()
        if not sub or sub["status"]!="active": abort(400,"Заморозить можно только активный абонемент")
        start=today()
        old_exp=sub["expires_at"] or ""
        try:
            from datetime import date as _date, timedelta as _timedelta
            end=(_date.fromisoformat(start)+_timedelta(days=days)).isoformat()
            new_exp=extend_expiry_for_freeze(old_exp,start,days)
        except ValueError as exc: abort(400,str(exc))
        c.execute("INSERT INTO subscription_freezes(subscription_id,start_date,end_date,days,reason,created_by,created_at) VALUES(?,?,?,?,?,?,?)",
                  (sub_id,start,end,days,reason,session["uid"],now()))
        c.execute("UPDATE subscriptions SET status='frozen',expires_at=? WHERE id=?",(new_exp,sub_id))
        audit(c,"subscription.frozen","subscription",sub_id,{"days":days,"reason":reason,"old_expires_at":sub["expires_at"],"new_expires_at":new_exp})
    return redirect(url_for("subscriptions"))

@app.route("/subscription/<int:sub_id>/unfreeze", methods=["POST"])
@login_required
def subscription_unfreeze(sub_id):
    if not is_current_manager(): abort(403)
    with connect() as c:
        sub=c.execute("SELECT * FROM subscriptions WHERE id=? AND status='frozen'",(sub_id,)).fetchone()
        if not sub: abort(400,"Абонемент не найден или не заморожен")
        c.execute("UPDATE subscriptions SET status='active' WHERE id=?",(sub_id,))
        audit(c,"subscription.unfrozen","subscription",sub_id,{"expires_at":sub["expires_at"]})
    return redirect(url_for("subscriptions"))

@app.route("/attendance/<int:attendance_id>/restore", methods=["POST"])
@login_required
def restore_missed_lesson(attendance_id):
    if not is_current_manager(): abort(403)
    reason=request.form.get("reason","").strip()
    medical=request.form.get("medical_certificate")=="yes"
    if not reason: abort(400,"Укажите причину восстановления")
    fee=0 if medical else 500
    payment_method=request.form.get("payment_method","cash")
    if payment_method not in ("cash","card","transfer","qr"):
        abort(400,"Недопустимый способ оплаты")
    with connect() as c:
        a=c.execute("SELECT * FROM attendance WHERE id=?",(attendance_id,)).fetchone()
        if not a or a["status"]!="missed": abort(400,"Восстановить можно только пропущенное занятие")
        if c.execute("SELECT id FROM attendance_restorations WHERE attendance_id=?",(attendance_id,)).fetchone():
            abort(400,"Это занятие уже восстанавливали")
        sub=c.execute("SELECT * FROM subscriptions WHERE id=?",(a["subscription_id"],)).fetchone()
        if not sub: abort(400,"Абонемент не найден")
        try:
            restored_status = restoration_status(sub["status"], sub["remaining_lessons"], sub["total_lessons"])
        except ValueError as exc:
            abort(400, str(exc))
        # Keep frozen subscriptions frozen and never revive a cancelled/refunded one.
        c.execute("UPDATE subscriptions SET remaining_lessons=remaining_lessons+1,status=? WHERE id=?",(restored_status,sub["id"]))
        sale_id=None
        if fee:
            cur=c.execute("INSERT INTO sales(client_id,item,amount,payment_method,status,created_by,created_at) VALUES(?,?,?,?,?,?,?)",
                (a["client_id"],"Восстановление пропуска без справки",fee,payment_method,"completed",session["uid"],now()))
            sale_id=cur.lastrowid
        c.execute("INSERT INTO attendance_restorations(attendance_id,reason,fee,sale_id,created_by,created_at) VALUES(?,?,?,?,?,?)",
                  (attendance_id,reason,fee,sale_id,session["uid"],now()))
        audit(c,"attendance.restored","attendance",attendance_id,{"reason":reason,"medical_certificate":medical,"fee":fee,"subscription_id":sub["id"],"sale_id":sale_id})
    return redirect(url_for("attendance"))

@app.route("/trainers", methods=["GET", "POST"])
@login_required
def trainers_page():
    """Manage trainer directory without deleting historical payroll/attendance links.

    Administrators can create/deactivate trainers and edit names. Only the manager
    can change payroll rates, because rates affect financial reports.
    """
    with connect() as c:
        if request.method == "POST":
            action = request.form.get("action", "update")
            if action == "create":
                name = request.form.get("name", "").strip()
                if not name or len(name) > 100:
                    abort(400, "Укажите имя тренера (до 100 символов)")
                if is_current_manager():
                    try:
                        rate = int(request.form.get("payroll_rate", "400"))
                    except ValueError:
                        abort(400, "Ставка должна быть целым числом")
                    if rate < 0:
                        abort(400, "Ставка не может быть отрицательной")
                else:
                    # Admins may maintain the roster but cannot assign payroll rates.
                    rate_row = c.execute("SELECT value FROM settings WHERE key='individual_rate'").fetchone()
                    try:
                        rate = max(0, int(rate_row["value"])) if rate_row else 400
                    except (ValueError, TypeError):
                        rate = 400
                    if request.form.get("payroll_rate", "").strip():
                        abort(403, "Ставку тренера может задавать только руководитель")
                try:
                    cur = c.execute("INSERT INTO trainers(name,payroll_rate,active) VALUES(?,?,1)", (name, rate))
                except sqlite3.IntegrityError:
                    abort(400, "Тренер с таким именем уже существует")
                audit(c, "trainer.created", "trainer", cur.lastrowid, {"name": name, "payroll_rate": rate})
                flash(f"Тренер «{name}» добавлен.")
                return redirect(url_for("trainers_page"))
            if action == "toggle":
                try:
                    trainer_id = int(request.form.get("trainer_id", "0"))
                except ValueError:
                    abort(400, "Неверный тренер")
                trainer = c.execute("SELECT id,name,active FROM trainers WHERE id=?", (trainer_id,)).fetchone()
                if not trainer:
                    abort(404, "Тренер не найден")
                new_active = 0 if trainer["active"] else 1
                if not new_active:
                    booked = c.execute("""SELECT COUNT(*) n FROM bookings b
                        JOIN schedule_slots sl ON sl.id=b.slot_id
                        WHERE sl.trainer_id=? AND sl.slot_date>=? AND b.status='booked'""",
                        (trainer_id, today())).fetchone()["n"]
                    if booked:
                        abort(400, f"Нельзя отключить тренера: есть будущие записи ({booked}). Сначала перенесите детей на другого тренера.")
                c.execute("UPDATE trainers SET active=? WHERE id=?", (new_active, trainer_id))
                audit(c, "trainer.activated" if new_active else "trainer.deactivated", "trainer", trainer_id,
                      {"name": trainer["name"], "active": bool(new_active)})
                flash(f"Тренер «{trainer['name']}» {'активирован' if new_active else 'отключён'}. История сохранена.")
                return redirect(url_for("trainers_page"))
            if action == "update":
                try:
                    trainer_id = int(request.form.get("trainer_id", "0"))
                except ValueError:
                    abort(400, "Неверный тренер")
                name = request.form.get("name", "").strip()
                if not name or len(name) > 100:
                    abort(400, "Укажите имя тренера (до 100 символов)")
                existing = c.execute("SELECT id,name,payroll_rate FROM trainers WHERE id=?", (trainer_id,)).fetchone()
                if not existing:
                    abort(404, "Тренер не найден")
                if name != existing["name"] and c.execute("SELECT 1 FROM attendance WHERE trainer=? LIMIT 1", (existing["name"],)).fetchone():
                    abort(400, "Нельзя менять имя тренера, которое уже записано в истории посещений/зарплаты. Отключите старую карточку и создайте новую, чтобы сохранить историю без переписывания.")
                if is_current_manager():
                    try:
                        rate = int(request.form.get("payroll_rate", str(existing["payroll_rate"])))
                    except ValueError:
                        abort(400, "Ставка должна быть целым числом")
                    if rate < 0:
                        abort(400, "Ставка не может быть отрицательной")
                else:
                    if request.form.get("payroll_rate", "").strip():
                        abort(403, "Ставку тренера может задавать только руководитель")
                    rate = existing["payroll_rate"]
                try:
                    c.execute("UPDATE trainers SET name=?, payroll_rate=? WHERE id=?", (name, rate, trainer_id))
                except sqlite3.IntegrityError:
                    abort(400, "Тренер с таким именем уже существует")
                audit(c, "trainer.updated", "trainer", trainer_id,
                      {"old_name": existing["name"], "name": name, "payroll_rate": rate})
                flash(f"Данные тренера «{name}» сохранены.")
                return redirect(url_for("trainers_page"))
            abort(400, "Неизвестное действие")
        rows = c.execute("""SELECT t.id,t.name,t.payroll_rate,t.active,
            (SELECT COUNT(*) FROM attendance a WHERE a.trainer=t.name AND a.status='attended') AS attended_count,
            (SELECT COUNT(*) FROM bookings b JOIN schedule_slots sl ON sl.id=b.slot_id
                WHERE sl.trainer_id=t.id AND sl.slot_date>=? AND b.status='booked') AS future_bookings
            FROM trainers t ORDER BY t.active DESC,t.name COLLATE NOCASE""", (today(),)).fetchall()
    is_manager = is_current_manager()
    default_rate = 400
    if not is_manager:
        with connect() as c:
            rate_row = c.execute("SELECT value FROM settings WHERE key='individual_rate'").fetchone()
            try: default_rate = max(0, int(rate_row["value"])) if rate_row else 400
            except (ValueError, TypeError): default_rate = 400
    body = "<div class='card'><h2>Тренеры</h2><p>Ставка применяется к новым начислениям. Зарплата рассчитывается по фактически отмеченным занятиям и сохранённой ставке каждого посещения. Добавление и отключение тренера не удаляет его прошлые занятия и начисления. Отключённый тренер недоступен для новых слотов.</p>"
    body += "<h3>Добавить тренера</h3><form method='post'><input type='hidden' name='action' value='create'><label>Имя</label><input name='name' required maxlength='100'>"
    if is_manager:
        body += f"<label>Ставка за занятие, ₽</label><input type='number' name='payroll_rate' min='0' step='1' value='{default_rate}' required>"
    body += "<button>Добавить тренера</button></form></div>"
    if not is_manager:
        body += "<p class='notice'>Администратор ведёт список и график тренеров. Ставки зарплаты доступны только руководителю.</p>"
    body += "<div class='card'><h2>Список тренеров</h2><div class='tablewrap'><table><tr><th>Тренер</th><th>Ставка за занятие, ₽</th><th>Проведено занятий</th><th>Будущие записи</th><th>Статус</th><th>Действие</th></tr>"
    for r in rows:
        edit_form = f"trainer-edit-{int(r['id'])}"
        rate_input = f"<input form='{edit_form}' type='number' name='payroll_rate' value='{r['payroll_rate']}' min='0' step='1' required>" if is_manager else f"{r['payroll_rate']} ₽"
        body += f"<tr><td><form id='{edit_form}' method='post'><input type='hidden' name='action' value='update'><input type='hidden' name='trainer_id' value='{r['id']}'></form><input form='{edit_form}' name='name' value='{esc(r['name'])}' required maxlength='100'></td><td>{rate_input}</td><td>{r['attended_count']}</td><td>{r['future_bookings']}</td><td>{'Активен' if r['active'] else 'Отключён'}</td><td><button form='{edit_form}'>Сохранить</button>"
        disabled = " disabled title='Сначала перенесите будущие записи'" if r['active'] and r['future_bookings'] else ""
        body += f"<form method='post'><input type='hidden' name='action' value='toggle'><input type='hidden' name='trainer_id' value='{r['id']}'><button class='{ 'danger' if r['active'] else '' }'{disabled}>{'Отключить' if r['active'] else 'Включить'}</button></form></td></tr>"
    body += "</table></div></div>"
    return page("Тренеры", body)


@app.route("/groups", methods=["GET", "POST"])
@login_required
def groups_page():
    """Named lesson cohorts and their roster; all changes are administrator-managed and audited."""
    with connect() as c:
        if request.method == "POST":
            action = request.form.get("action", "create")
            if action == "create":
                name = request.form.get("name", "").strip()
                notes = request.form.get("notes", "").strip()
                if not name or len(name) > 100:
                    abort(400, "Укажите название группы (до 100 символов)")
                if len(notes) > 1000:
                    abort(400, "Комментарий не должен превышать 1000 символов")
                try:
                    cur = c.execute("INSERT INTO lesson_groups(name,active,notes,created_by,created_at,updated_at) VALUES(?,1,?,?,?,?)",
                                    (name, notes, session["uid"], now(), now()))
                except sqlite3.IntegrityError:
                    abort(400, "Группа с таким названием уже существует")
                audit(c, "group.created", "lesson_group", cur.lastrowid, {"name": name})
                flash("Группа создана.")
                return redirect(url_for("groups_page"))
            if action == "update":
                try: group_id = int(request.form.get("group_id", "0"))
                except ValueError: abort(400, "Неверная группа")
                name = request.form.get("name", "").strip()
                notes = request.form.get("notes", "").strip()
                if not name or len(name) > 100 or len(notes) > 1000:
                    abort(400, "Проверьте название группы и комментарий")
                group = c.execute("SELECT * FROM lesson_groups WHERE id=?", (group_id,)).fetchone()
                if not group: abort(404, "Группа не найдена")
                try:
                    c.execute("UPDATE lesson_groups SET name=?,notes=?,updated_at=? WHERE id=?", (name, notes, now(), group_id))
                except sqlite3.IntegrityError:
                    abort(400, "Группа с таким названием уже существует")
                audit(c, "group.updated", "lesson_group", group_id, {"old_name": group["name"], "name": name})
                flash("Данные группы сохранены.")
                return redirect(url_for("groups_page"))
            if action == "toggle":
                try: group_id = int(request.form.get("group_id", "0"))
                except ValueError: abort(400, "Неверная группа")
                group = c.execute("SELECT * FROM lesson_groups WHERE id=?", (group_id,)).fetchone()
                if not group: abort(404, "Группа не найдена")
                active = 0 if group["active"] else 1
                c.execute("UPDATE lesson_groups SET active=?,updated_at=? WHERE id=?", (active, now(), group_id))
                audit(c, "group.activated" if active else "group.deactivated", "lesson_group", group_id, {"name": group["name"], "active": bool(active)})
                flash("Группа активирована." if active else "Группа отключена; состав и история сохранены.")
                return redirect(url_for("groups_page"))
            if action == "add_member":
                try: group_id = int(request.form.get("group_id", "0")); client_id = int(request.form.get("client_id", "0"))
                except ValueError: abort(400, "Выберите группу и клиента")
                group = c.execute("SELECT id,name,active FROM lesson_groups WHERE id=?", (group_id,)).fetchone()
                client = c.execute("SELECT id,child_name,status FROM clients WHERE id=?", (client_id,)).fetchone()
                if not group or not group["active"]: abort(400, "Выберите действующую группу")
                if not client or client["status"] == "archived": abort(400, "Клиент не найден или находится в архиве")
                existing = c.execute("SELECT id,active FROM lesson_group_members WHERE group_id=? AND client_id=?", (group_id, client_id)).fetchone()
                if existing:
                    if existing["active"]: abort(400, "Ребёнок уже состоит в этой группе")
                    c.execute("UPDATE lesson_group_members SET active=1 WHERE id=?", (existing["id"],))
                else:
                    c.execute("INSERT INTO lesson_group_members(group_id,client_id,active,created_at) VALUES(?,?,1,?)", (group_id, client_id, now()))
                audit(c, "group.member_added", "lesson_group", group_id, {"client_id": client_id, "child_name": client["child_name"]})
                flash("Ребёнок добавлен в группу.")
                return redirect(url_for("groups_page"))
            if action == "book_group":
                try:
                    group_id = int(request.form.get("group_id", "0"))
                    slot_id = int(request.form.get("slot_id", "0"))
                except ValueError:
                    abort(400, "Выберите группу и занятие")
                c.execute("BEGIN IMMEDIATE")
                group = c.execute("SELECT * FROM lesson_groups WHERE id=? AND active=1", (group_id,)).fetchone()
                if not group: abort(400, "Выберите действующую группу")
                members = c.execute("""SELECT gm.client_id,cl.child_name FROM lesson_group_members gm
                    JOIN clients cl ON cl.id=gm.client_id WHERE gm.group_id=? AND gm.active=1 AND cl.status!='archived'
                    ORDER BY cl.child_name COLLATE NOCASE""", (group_id,)).fetchall()
                if not members: abort(400, "В группе нет активных участников")
                slot = c.execute("""SELECT sl.*,tr.name trainer_name,tr.active trainer_active,
                    (SELECT COUNT(*) FROM bookings b WHERE b.slot_id=sl.id AND b.status='booked') booked
                    FROM schedule_slots sl JOIN trainers tr ON tr.id=sl.trainer_id WHERE sl.id=?""", (slot_id,)).fetchone()
                if not slot or not slot["trainer_active"]: abort(400, "Выберите слот действующего тренера")
                if slot["kind"] != "group": abort(400, "Для групповой записи выберите групповой слот")
                if slot["slot_date"] < today(): abort(400, "Нельзя записать группу на прошедшее занятие")
                if int(slot["capacity"]) - int(slot["booked"]) < len(members):
                    abort(400, f"Недостаточно мест: свободно {int(slot['capacity'])-int(slot['booked'])}, участников {len(members)}")
                validated = []
                for member in members:
                    client_id = int(member["client_id"])
                    try: subscription_id = int(request.form.get(f"subscription_{client_id}", "0"))
                    except ValueError: abort(400, f"Выберите абонемент для ребёнка {member['child_name']}")
                    sub = c.execute("""SELECT * FROM subscriptions WHERE id=? AND client_id=? AND status='active'
                        AND remaining_lessons>0 AND (COALESCE(expires_at,'')='' OR expires_at>=?)""",
                        (subscription_id, client_id, slot["slot_date"])).fetchone()
                    if not sub:
                        abort(400, f"У ребёнка {member['child_name']} нет подходящего абонемента на дату занятия")
                    existing = c.execute("SELECT id,status FROM bookings WHERE slot_id=? AND client_id=?", (slot_id, client_id)).fetchone()
                    if existing and existing["status"] != "cancelled":
                        abort(400, f"Ребёнок {member['child_name']} уже записан или обработан на этом занятии")
                    validated.append((client_id, subscription_id, existing["id"] if existing else None, member["child_name"]))
                booking_ids = []
                for client_id, subscription_id, existing_id, child_name in validated:
                    if existing_id:
                        c.execute("UPDATE bookings SET status='booked',subscription_id=?,created_by=?,created_at=? WHERE id=? AND status='cancelled'",
                                  (subscription_id, session["uid"], now(), existing_id))
                        booking_id = existing_id
                    else:
                        cur = c.execute("INSERT INTO bookings(slot_id,client_id,subscription_id,created_by,created_at) VALUES(?,?,?,?,?)",
                                        (slot_id, client_id, subscription_id, session["uid"], now()))
                        booking_id = cur.lastrowid
                    booking_ids.append(booking_id)
                audit(c, "group.booked_to_slot", "lesson_group", group_id,
                      {"slot_id": slot_id, "booking_ids": booking_ids, "client_ids": [x[0] for x in validated]})
                flash(f"Группа «{group['name']}» записана на {slot['slot_date']} {slot['slot_time']}: {len(booking_ids)} детей.")
                return redirect(url_for("schedule", day=slot["slot_date"]))
            if action == "remove_member":
                try: member_id = int(request.form.get("member_id", "0"))
                except ValueError: abort(400, "Неверный участник группы")
                member = c.execute("SELECT gm.*,g.name group_name,cl.child_name FROM lesson_group_members gm JOIN lesson_groups g ON g.id=gm.group_id JOIN clients cl ON cl.id=gm.client_id WHERE gm.id=?", (member_id,)).fetchone()
                if not member: abort(404, "Участник группы не найден")
                if member["active"]:
                    c.execute("UPDATE lesson_group_members SET active=0 WHERE id=?", (member_id,))
                    audit(c, "group.member_removed", "lesson_group", member["group_id"], {"client_id": member["client_id"], "child_name": member["child_name"]})
                flash("Ребёнок исключён из текущего состава; история группы сохранена.")
                return redirect(url_for("groups_page"))
            abort(400, "Неизвестное действие")
        groups = c.execute("""SELECT g.*,
            (SELECT COUNT(*) FROM lesson_group_members gm WHERE gm.group_id=g.id AND gm.active=1) member_count
            FROM lesson_groups g ORDER BY g.active DESC,g.name COLLATE NOCASE""").fetchall()
        clients = c.execute("SELECT id,child_name,parent_name FROM clients WHERE status!='archived' ORDER BY child_name COLLATE NOCASE").fetchall()
        member_rows = c.execute("""SELECT gm.id member_id,gm.group_id,gm.active member_active,cl.id client_id,
            cl.child_name,cl.parent_name,cl.phone FROM lesson_group_members gm JOIN clients cl ON cl.id=gm.client_id
            ORDER BY gm.group_id,gm.active DESC,cl.child_name COLLATE NOCASE""").fetchall()
        group_slots = c.execute("""SELECT sl.id,sl.slot_date,sl.slot_time,sl.capacity,
            (SELECT COUNT(*) FROM bookings b WHERE b.slot_id=sl.id AND b.status='booked') booked,tr.name trainer_name
            FROM schedule_slots sl JOIN trainers tr ON tr.id=sl.trainer_id
            WHERE sl.slot_date>=? AND sl.kind='group' AND tr.active=1 ORDER BY sl.slot_date,sl.slot_time,tr.name""", (today(),)).fetchall()
        group_subs = c.execute("""SELECT s.id,s.client_id,s.title,s.remaining_lessons,s.expires_at FROM subscriptions s
            WHERE s.status='active' AND s.remaining_lessons>0 AND (COALESCE(s.expires_at,'')='' OR s.expires_at>=?)
            ORDER BY s.client_id,s.id DESC""", (today(),)).fetchall()
    clients_options = "".join(f"<option value='{int(cl['id'])}'>{esc(cl['child_name'])} — {esc(cl['parent_name'])}</option>" for cl in clients)
    body = ("<div class='card'><h2>Создать группу</h2><p class='muted'>Группы — это списки детей для удобства администратора. Запись на занятие по-прежнему оформляется в расписании отдельно; добавление в группу не создаёт запись и не списывает абонемент.</p>"
        "<form method='post'><input type='hidden' name='action' value='create'><label>Название группы</label><input name='name' maxlength='100' required><label>Комментарий</label><textarea name='notes' maxlength='1000'></textarea><button>Создать группу</button></form></div>")
    members_by_group = {}
    for m in member_rows: members_by_group.setdefault(m["group_id"], []).append(m)
    for g in groups:
        edit_id = f"group-edit-{int(g['id'])}"
        body += f"<div class='card'><h2>{esc(g['name'])} {'(отключена)' if not g['active'] else ''}</h2><p>Участников: {int(g['member_count'])}</p>"
        body += f"<form id='{edit_id}' method='post'><input type='hidden' name='action' value='update'><input type='hidden' name='group_id' value='{int(g['id'])}'><label>Название</label><input name='name' value='{esc(g['name'])}' maxlength='100' required><label>Комментарий</label><textarea name='notes' maxlength='1000'>{esc(g['notes'])}</textarea><button>Сохранить</button></form>"
        body += f"<form method='post'><input type='hidden' name='action' value='toggle'><input type='hidden' name='group_id' value='{int(g['id'])}'><button>{'Отключить группу' if g['active'] else 'Активировать группу'}</button></form>"
        active_group_members = [m for m in members_by_group.get(g["id"], []) if m["member_active"]]
        if g["active"]:
            body += f"<form method='post'><input type='hidden' name='action' value='add_member'><input type='hidden' name='group_id' value='{int(g['id'])}'><label>Добавить ребёнка</label><select name='client_id' required><option value=''>Выберите клиента</option>{clients_options}</select><button>Добавить участника</button></form>"
            if active_group_members:
                group_slot_options = "".join(f"<option value='{int(sl['id'])}' {'disabled' if int(sl['capacity'])-int(sl['booked']) < len(active_group_members) else ''}>{esc(sl['slot_date'])} {esc(sl['slot_time'])} — {esc(sl['trainer_name'])}, свободно {int(sl['capacity'])-int(sl['booked'])} из {int(sl['capacity'])}</option>" for sl in group_slots)
                body += f"<form method='post'><input type='hidden' name='action' value='book_group'><input type='hidden' name='group_id' value='{int(g['id'])}'><label>Записать всю группу на занятие</label><select name='slot_id' required><option value=''>Выберите групповой слот</option>{group_slot_options}</select>"
                for member in active_group_members:
                    options = "".join(f"<option value='{int(sub['id'])}'>{esc(sub['title'])}, осталось {int(sub['remaining_lessons'])}</option>" for sub in group_subs if sub['client_id']==member['client_id'])
                    body += f"<label>{esc(member['child_name'])} — абонемент</label><select name='subscription_{int(member['client_id'])}' required><option value=''>Выберите абонемент</option>{options}</select>"
                body += "<button>Записать всех детей</button><p class='muted'>Запись группы атомарная: если у любого ребёнка нет подходящего абонемента, мест недостаточно или есть конфликтующая запись, никого не запишем.</p></form>"
        body += "<div class='tablewrap'><table><tr><th>Ребёнок</th><th>Телефон</th><th>Состояние</th><th>Действие</th></tr>"
        for m in members_by_group.get(g["id"], []):
            remove = ""
            if m["member_active"]:
                remove = f"<form method='post'><input type='hidden' name='action' value='remove_member'><input type='hidden' name='member_id' value='{int(m['member_id'])}'><button>Исключить</button></form>"
            body += f"<tr><td><a href='/client/{int(m['client_id'])}'>{esc(m['child_name'])}</a></td><td>{esc(m['phone'])}</td><td>{'В группе' if m['member_active'] else 'В истории'}</td><td>{remove}</td></tr>"
        body += "</table></div></div>"
    return page("Группы", body)


@app.route("/waitlist", methods=["GET", "POST"])
@login_required
def waitlist_page():
    """Admin-managed waiting list for preferred lesson times; no client-side booking portal."""
    statuses = {"waiting": "Ожидает", "offered": "Предложено", "booked": "Записан", "cancelled": "Отменена"}
    with connect() as c:
        if request.method == "POST":
            action = request.form.get("action", "create")
            if action == "create":
                try:
                    client_id = int(request.form.get("client_id", "0"))
                    trainer_id = int(request.form.get("preferred_trainer_id") or 0)
                except ValueError:
                    abort(400, "Проверьте клиента и тренера")
                preferred_date = request.form.get("preferred_date", "").strip()
                preferred_time = request.form.get("preferred_time", "").strip()
                kind = request.form.get("kind", "individual")
                notes = request.form.get("notes", "").strip()
                if preferred_date:
                    try:
                        date.fromisoformat(preferred_date)
                    except ValueError:
                        abort(400, "Некорректная желаемая дата")
                    if preferred_date < today():
                        abort(400, "Дата в листе ожидания не может быть в прошлом")
                if preferred_time:
                    try:
                        datetime.strptime(preferred_time, "%H:%M")
                    except ValueError:
                        abort(400, "Некорректное желаемое время")
                if kind not in ("individual", "group"):
                    abort(400, "Выберите тип занятия")
                if len(notes) > 1000:
                    abort(400, "Комментарий не должен превышать 1000 символов")
                if not c.execute("SELECT 1 FROM clients WHERE id=? AND status!='archived'", (client_id,)).fetchone():
                    abort(400, "Клиент не найден или находится в архиве")
                if trainer_id and not c.execute("SELECT 1 FROM trainers WHERE id=? AND active=1", (trainer_id,)).fetchone():
                    abort(400, "Выбранный тренер неактивен")
                cur = c.execute("""INSERT INTO waitlist_entries
                    (client_id,preferred_date,preferred_time,preferred_trainer_id,kind,status,notes,created_by,created_at,updated_at)
                    VALUES(?,?,?,?,?,'waiting',?,?,?,?)""",
                    (client_id, preferred_date, preferred_time, trainer_id or None, kind, notes, session["uid"], now(), now()))
                audit(c, "waitlist.created", "waitlist_entry", cur.lastrowid,
                      {"client_id": client_id, "preferred_date": preferred_date, "preferred_time": preferred_time, "kind": kind})
                flash("Клиент добавлен в лист ожидания.")
                return redirect(url_for("waitlist_page"))
            if action == "status":
                try:
                    entry_id = int(request.form.get("entry_id", "0"))
                except ValueError:
                    abort(400, "Неверная запись листа ожидания")
                status = request.form.get("status", "")
                if status not in ("waiting", "offered", "cancelled"):
                    abort(400, "Недопустимый статус листа ожидания")
                entry = c.execute("SELECT * FROM waitlist_entries WHERE id=?", (entry_id,)).fetchone()
                if not entry:
                    abort(404, "Запись листа ожидания не найдена")
                if entry["status"] == "booked":
                    abort(400, "Запись уже перенесена в расписание; статус нельзя менять вручную")
                c.execute("UPDATE waitlist_entries SET status=?,updated_at=? WHERE id=?", (status, now(), entry_id))
                audit(c, "waitlist.status_changed", "waitlist_entry", entry_id,
                      {"old_status": entry["status"], "status": status})
                flash("Статус листа ожидания обновлён.")
                return redirect(url_for("waitlist_page"))
            if action == "book":
                try:
                    entry_id = int(request.form.get("entry_id", "0"))
                    slot_id = int(request.form.get("slot_id", "0"))
                    subscription_id = int(request.form.get("subscription_id", "0"))
                except ValueError:
                    abort(400, "Выберите свободный слот и абонемент")
                c.execute("BEGIN IMMEDIATE")
                entry = c.execute("SELECT * FROM waitlist_entries WHERE id=?", (entry_id,)).fetchone()
                if not entry or entry["status"] not in ("waiting", "offered"):
                    abort(400, "Запись листа ожидания уже обработана")
                slot = c.execute("""SELECT sl.*,tr.name trainer_name,tr.active trainer_active,
                    (SELECT COUNT(*) FROM bookings b WHERE b.slot_id=sl.id AND b.status='booked') booked
                    FROM schedule_slots sl JOIN trainers tr ON tr.id=sl.trainer_id WHERE sl.id=?""", (slot_id,)).fetchone()
                if not slot or not slot["trainer_active"]:
                    abort(400, "Выберите слот действующего тренера")
                if slot["slot_date"] < today():
                    abort(400, "Нельзя записать клиента на прошедшее занятие")
                if slot["kind"] != entry["kind"]:
                    abort(400, "Тип выбранного слота не совпадает с предпочтением клиента")
                if slot["booked"] >= slot["capacity"]:
                    abort(400, "На выбранное занятие больше нет свободных мест")
                sub = c.execute("""SELECT * FROM subscriptions WHERE id=? AND client_id=? AND status='active'
                    AND remaining_lessons>0 AND (COALESCE(expires_at,'')='' OR expires_at>=?)""",
                    (subscription_id, entry["client_id"], slot["slot_date"])).fetchone()
                if not sub:
                    abort(400, "У клиента нет подходящего активного абонемента на выбранную дату")
                existing = c.execute("SELECT id,status FROM bookings WHERE slot_id=? AND client_id=?", (slot_id, entry["client_id"])).fetchone()
                if existing and existing["status"] != "cancelled":
                    abort(400, "У клиента уже есть запись на этот слот")
                if existing:
                    booking_id = existing["id"]
                    try:
                        c.execute("UPDATE bookings SET status='booked',subscription_id=?,created_by=?,created_at=? WHERE id=? AND status='cancelled'",
                                  (subscription_id, session["uid"], now(), booking_id))
                    except sqlite3.IntegrityError as exc:
                        if "booking_capacity_full" in str(exc): abort(400, "На выбранное занятие больше нет свободных мест")
                        raise
                else:
                    try:
                        cur = c.execute("INSERT INTO bookings(slot_id,client_id,subscription_id,created_by,created_at) VALUES(?,?,?,?,?)",
                                        (slot_id, entry["client_id"], subscription_id, session["uid"], now()))
                        booking_id = cur.lastrowid
                    except sqlite3.IntegrityError as exc:
                        if "booking_capacity_full" in str(exc): abort(400, "На выбранное занятие больше нет свободных мест")
                        raise
                c.execute("UPDATE waitlist_entries SET status='booked',booking_id=?,updated_at=? WHERE id=? AND status IN ('waiting','offered')",
                          (booking_id, now(), entry_id))
                if c.execute("SELECT changes() n").fetchone()["n"] != 1:
                    abort(400, "Запись листа ожидания уже обработана; обновите страницу")
                audit(c, "waitlist.booked", "waitlist_entry", entry_id,
                      {"booking_id": booking_id, "slot_id": slot_id, "subscription_id": subscription_id})
                flash("Клиент записан на занятие, лист ожидания обновлён.")
                return redirect(url_for("schedule", day=slot["slot_date"]))
            abort(400, "Неизвестное действие")
        clients = c.execute("SELECT id,child_name,parent_name,phone FROM clients WHERE status!='archived' ORDER BY child_name COLLATE NOCASE").fetchall()
        trainers = c.execute("SELECT id,name FROM trainers WHERE active=1 ORDER BY name COLLATE NOCASE").fetchall()
        rows = c.execute("""SELECT w.*,cl.child_name,cl.parent_name,cl.phone,tr.name preferred_trainer,
            b.slot_id booked_slot_id,sl.slot_date booked_date,sl.slot_time booked_time
            FROM waitlist_entries w JOIN clients cl ON cl.id=w.client_id
            LEFT JOIN trainers tr ON tr.id=w.preferred_trainer_id
            LEFT JOIN bookings b ON b.id=w.booking_id LEFT JOIN schedule_slots sl ON sl.id=b.slot_id
            ORDER BY CASE w.status WHEN 'waiting' THEN 0 WHEN 'offered' THEN 1 WHEN 'booked' THEN 2 ELSE 3 END,
            COALESCE(NULLIF(w.preferred_date,''),'9999-12-31'), COALESCE(NULLIF(w.preferred_time,''),'99:99'),w.id DESC LIMIT 500""").fetchall()
        open_slots = c.execute("""SELECT sl.id,sl.slot_date,sl.slot_time,sl.kind,sl.capacity,tr.name,
            (SELECT COUNT(*) FROM bookings b WHERE b.slot_id=sl.id AND b.status='booked') booked
            FROM schedule_slots sl JOIN trainers tr ON tr.id=sl.trainer_id
            WHERE sl.slot_date>=? AND tr.active=1 ORDER BY sl.slot_date,sl.slot_time,tr.name""", (today(),)).fetchall()
        active_subs = c.execute("""SELECT s.id,s.client_id,s.title,s.remaining_lessons,c.child_name,s.expires_at
            FROM subscriptions s JOIN clients c ON c.id=s.client_id WHERE s.status='active' AND s.remaining_lessons>0
            AND (COALESCE(s.expires_at,'')='' OR s.expires_at>=?) ORDER BY c.child_name,s.id DESC""", (today(),)).fetchall()
    client_options = "".join(f"<option value='{int(r['id'])}'>{esc(r['child_name'])} — {esc(r['parent_name'])} ({esc(r['phone'])})</option>" for r in clients)
    trainer_options = "<option value='0'>Любой тренер</option>" + "".join(f"<option value='{int(r['id'])}'>{esc(r['name'])}</option>" for r in trainers)
    form = ("<div class='card'><h2>Добавить в лист ожидания</h2><form method='post'><input type='hidden' name='action' value='create'>"
        "<label>Клиент</label><select name='client_id' required><option value=''>Выберите ребёнка</option>" + client_options + "</select>"
        "<label>Желаемая дата</label><input type='date' name='preferred_date' min='" + today() + "'>"
        "<label>Желаемое время</label><input type='time' name='preferred_time'>"
        "<label>Предпочтительный тренер</label><select name='preferred_trainer_id'>" + trainer_options + "</select>"
        "<label>Тип занятия</label><select name='kind'><option value='individual'>Индивидуальное</option><option value='group'>Групповое</option></select>"
        "<label>Комментарий</label><textarea name='notes' maxlength='1000'></textarea><button>Добавить</button></form></div>")
    table = "<div class='card'><h2>Лист ожидания</h2><p class='muted'>Запись в лист ожидания не списывает занятие и не создаёт оплату. Абонемент списывается только после фактической отметки посещения или пропуска в установленном порядке.</p><div class='tablewrap'><table><tr><th>Клиент</th><th>Пожелания</th><th>Статус</th><th>Запись</th><th>Действия</th></tr>"
    for r in rows:
        pref = " · ".join(x for x in [r["preferred_date"], r["preferred_time"], r["preferred_trainer"] or ""] if x)
        booked_text = f"{esc(r['booked_date'])} {esc(r['booked_time'])}" if r["status"] == "booked" else "—"
        actions = ""
        if r["status"] in ("waiting", "offered"):
            slot_options = "".join(f"<option value='{int(sl['id'])}' {'disabled' if sl['booked']>=sl['capacity'] or sl['kind']!=r['kind'] else ''}>{esc(sl['slot_date'])} {esc(sl['slot_time'])} — {esc(sl['name'])} ({'группа' if sl['kind']=='group' else 'индивидуально'}, мест {int(sl['capacity'])-int(sl['booked'])})</option>" for sl in open_slots)
            sub_options = "".join(f"<option value='{int(sub['id'])}'>{esc(sub['title'])}, осталось {int(sub['remaining_lessons'])} — до {esc(sub['expires_at'] or 'без срока')}</option>" for sub in active_subs if sub['client_id']==r['client_id'])
            actions += f"<form method='post'><input type='hidden' name='action' value='book'><input type='hidden' name='entry_id' value='{int(r['id'])}'><label>Свободный слот</label><select name='slot_id' required><option value=''>Выберите время</option>{slot_options}</select><label>Абонемент</label><select name='subscription_id' required><option value=''>Выберите абонемент</option>{sub_options}</select><button>Записать</button></form>"
            for state,label in (("offered","Предложено"),("waiting","Ожидает"),("cancelled","Отменить")):
                if state != r["status"]:
                    actions += f"<form method='post'><input type='hidden' name='action' value='status'><input type='hidden' name='entry_id' value='{int(r['id'])}'><input type='hidden' name='status' value='{state}'><button>{label}</button></form>"
        table += f"<tr><td>{esc(r['child_name'])}<br><span class='muted'>{esc(r['phone'])}</span></td><td>{esc(pref)}<br>{'Групповое' if r['kind']=='group' else 'Индивидуальное'}<br>{esc(r['notes'])}</td><td>{statuses[r['status']]}</td><td>{booked_text}</td><td>{actions}</td></tr>"
    if not rows:
        table += "<tr><td colspan='5'>Лист ожидания пуст.</td></tr>"
    table += "</table></div></div>"
    return page("Лист ожидания", form + table)


@app.route("/resources", methods=["GET", "POST"])
@login_required
def resources_page():
    from resource_rules import validate_resource, resource_name_conflicts
    with connect() as c:
        if request.method == "POST":
            action=request.form.get("action", "create")
            if action == "create":
                try:
                    name, resource_type = validate_resource(request.form.get("name"), request.form.get("resource_type"))
                except ValueError as exc:
                    abort(400, str(exc))
                existing_names=[row["name"] for row in c.execute("SELECT name FROM schedule_resources WHERE resource_type=?",(resource_type,)).fetchall()]
                if resource_name_conflicts(name,existing_names): abort(400,"Такое название уже есть в этом типе ресурсов")
                try:
                    cur=c.execute("INSERT INTO schedule_resources(name,resource_type,active,created_at,updated_at) VALUES(?,?,1,?,?)", (name,resource_type,now(),now()))
                except sqlite3.IntegrityError:
                    abort(400, "Такое название уже есть в этом типе ресурсов")
                audit(c,"schedule_resource.created","schedule_resource",cur.lastrowid,{"name":name,"resource_type":resource_type})
            elif action == "rename":
                try: resource_id=int(request.form.get("resource_id", "0"))
                except ValueError: abort(400,"Неверный ресурс")
                resource=c.execute("SELECT * FROM schedule_resources WHERE id=?",(resource_id,)).fetchone()
                if not resource: abort(404,"Ресурс не найден")
                try: name, resource_type=validate_resource(request.form.get("name"),resource["resource_type"])
                except ValueError as exc: abort(400,str(exc))
                existing_names=[row["name"] for row in c.execute("SELECT name FROM schedule_resources WHERE resource_type=? AND id<>?",(resource_type,resource_id)).fetchall()]
                if resource_name_conflicts(name,existing_names): abort(400,"Такое название уже есть в этом типе ресурсов")
                try:
                    c.execute("UPDATE schedule_resources SET name=?,updated_at=? WHERE id=?",(name,now(),resource_id))
                except sqlite3.IntegrityError: abort(400,"Такое название уже есть в этом типе ресурсов")
                audit(c,"schedule_resource.renamed","schedule_resource",resource_id,{"old_name":resource["name"],"new_name":name})
            elif action == "toggle":
                try: resource_id=int(request.form.get("resource_id", "0"))
                except ValueError: abort(400,"Неверный ресурс")
                resource=c.execute("SELECT * FROM schedule_resources WHERE id=?",(resource_id,)).fetchone()
                if not resource: abort(404,"Ресурс не найден")
                new_active=0 if resource["active"] else 1
                if not new_active:
                    used=c.execute("SELECT COUNT(*) n FROM schedule_slots WHERE (room_id=? OR lane_id=?) AND slot_date>=?",(resource_id,resource_id,today())).fetchone()["n"]
                    if used: abort(400,"Нельзя отключить ресурс с назначенными занятиями сегодня или в будущем. Сначала переназначьте слоты.")
                c.execute("UPDATE schedule_resources SET active=?,updated_at=? WHERE id=?",(new_active,now(),resource_id))
                audit(c,"schedule_resource.activated" if new_active else "schedule_resource.deactivated","schedule_resource",resource_id,{"name":resource["name"],"active":bool(new_active)})
            else:
                abort(400,"Неизвестное действие")
            return redirect(url_for("resources_page"))
        rows=c.execute("""SELECT r.*,
          (SELECT COUNT(*) FROM schedule_slots s WHERE s.room_id=r.id OR s.lane_id=r.id) slot_count,
          (SELECT COUNT(*) FROM schedule_slots s WHERE (s.room_id=r.id OR s.lane_id=r.id) AND s.slot_date>=?) upcoming_count
          FROM schedule_resources r ORDER BY r.resource_type,r.active DESC,r.name""",(today(),)).fetchall()
    body="<div class='card'><h2>Помещения и дорожки</h2><p class='muted'>Настройка физических ресурсов бассейна. Ресурс можно назначить слоту; два занятия не могут пересекаться по времени в одном помещении/на одной дорожке. Отключение сохраняет историю.</p><form method='post'><input type='hidden' name='action' value='create'><label>Название</label><input name='name' required maxlength='80' placeholder='Например, Большой бассейн или Дорожка 1'><label>Тип</label><select name='resource_type'><option value='room'>Помещение/бассейн</option><option value='lane'>Дорожка</option></select><button>Добавить ресурс</button></form></div>"
    body+="<div class='card'><h2>Список ресурсов</h2><div class='tablewrap'><table><tr><th>Название</th><th>Тип</th><th>Статус</th><th>Слотов всего</th><th>Сегодня и далее</th><th>Действия</th></tr>"
    for r in rows:
        typ="Помещение/бассейн" if r["resource_type"]=="room" else "Дорожка"
        action=f"<form method='post'><input type='hidden' name='action' value='rename'><input type='hidden' name='resource_id' value='{r['id']}'><input name='name' value='{esc(r['name'])}' maxlength='80' required><button>Переименовать</button></form><form method='post'><input type='hidden' name='action' value='toggle'><input type='hidden' name='resource_id' value='{r['id']}'><button class='{ 'danger' if r['active'] else '' }'>{'Отключить' if r['active'] else 'Включить'}</button></form>"
        body+=f"<tr><td>{esc(r['name'])}</td><td>{typ}</td><td>{'Активен' if r['active'] else 'Отключён'}</td><td>{r['slot_count']}</td><td>{r['upcoming_count']}</td><td>{action}</td></tr>"
    if not rows: body+="<tr><td colspan='6'>Ресурсы ещё не добавлены. Можно работать без назначения помещения/дорожки.</td></tr>"
    return page("Помещения и дорожки",body+"</table></div></div>")


@app.route("/schedule",methods=["GET","POST"])
@login_required
def schedule():
    from resource_rules import ensure_resource_no_overlap
    with connect() as c:
        if request.method=="POST":
            action=request.form.get("action","slot")
            if action in ("repeat_slots", "repeat_shift"):
                try:
                    trainer_id=int(request.form.get("repeat_trainer_id","0"))
                    capacity=int(request.form.get("repeat_capacity","1"))
                    duration=int(request.form.get("repeat_duration","30"))
                    room_id=int(request.form.get("repeat_room_id") or 0) or None
                    lane_id=int(request.form.get("repeat_lane_id") or 0) or None
                except (TypeError, ValueError):
                    abort(400,"Проверьте тренера, вместимость и длительность занятия")
                start_date=request.form.get("repeat_start_date","").strip()
                end_date=request.form.get("repeat_end_date","").strip()
                kind=request.form.get("repeat_kind","individual")
                weekdays=request.form.getlist("weekdays")
                notes=request.form.get("repeat_notes","").strip()
                if len(notes)>1000: abort(400,"Примечание не должно превышать 1000 символов")
                try:
                    dates=weekly_dates(start_date,end_date,weekdays,today())
                    if action == "repeat_shift":
                        slot_times=shift_start_times(request.form.get("repeat_start_time","09:00"), request.form.get("repeat_end_time","15:00"), duration)
                    else:
                        slot_times=[request.form.get("repeat_time","09:00").strip()]
                    _,_,capacity,duration,kind=validate_slot_details(dates[0],slot_times[0],capacity,duration,kind,today())
                except ValueError as exc:
                    abort(400,str(exc))
                trainer=c.execute("SELECT id,name FROM trainers WHERE id=? AND active=1",(trainer_id,)).fetchone()
                if not trainer: abort(400,"Выберите действующего тренера")
                if room_id is not None and not c.execute("SELECT id FROM schedule_resources WHERE id=? AND active=1 AND resource_type='room'",(room_id,)).fetchone():
                    abort(400,"Выберите действующее помещение/бассейн")
                if lane_id is not None and not c.execute("SELECT id FROM schedule_resources WHERE id=? AND active=1 AND resource_type='lane'",(lane_id,)).fetchone():
                    abort(400,"Выберите действующую дорожку")
                requested=len(dates)*len(slot_times)
                try:
                    created,skipped=create_recurring_slots(c,trainer_id,dates,slot_times,duration,capacity,kind,notes,room_id=room_id,lane_id=lane_id)
                except ValueError as exc:
                    abort(400,f"Проверьте расписание: {exc}")
                audit(c,"schedule_slots.recurring_created","schedule_slots",None,{"trainer_id":trainer_id,"trainer":trainer["name"],"start_date":start_date,"end_date":end_date,"weekdays":[int(x) for x in weekdays],"times":slot_times,"requested":requested,"created":created,"skipped_existing":skipped,"kind":kind,"duration":duration,"room_id":room_id,"lane_id":lane_id})
                flash(f"Повторяющееся расписание: создано слотов — {created}; пропущено совпадений — {skipped}.")
                return redirect(url_for("schedule",day=dates[0]))
            elif action=="trainer":
                name=request.form.get("trainer_name","").strip()
                raw_rate=request.form.get("payroll_rate","").strip()
                if not name or len(name)>100: abort(400,"Укажите имя тренера (до 100 символов)")
                if is_current_manager():
                    try: payroll_rate=int(raw_rate or "400")
                    except ValueError: abort(400,"Ставка тренера должна быть числом")
                    if payroll_rate<0: abort(400,"Ставка не может быть отрицательной")
                else:
                    if raw_rate: abort(403,"Ставку тренера может задавать только руководитель")
                    rate_row=c.execute("SELECT value FROM settings WHERE key='individual_rate'").fetchone()
                    try: payroll_rate=max(0,int(rate_row["value"])) if rate_row else 400
                    except (ValueError,TypeError): payroll_rate=400
                try:
                    cur=c.execute("INSERT INTO trainers(name,payroll_rate) VALUES(?,?)",(name,payroll_rate))
                except sqlite3.IntegrityError: abort(400,"Тренер с таким именем уже существует")
                audit(c,"trainer.created","trainer",cur.lastrowid,{"name":name,"payroll_rate":payroll_rate})
            elif action=="slot":
                trainer_name=request.form.get("trainer_name","").strip()
                try:
                    capacity=int(request.form.get("capacity","1"))
                    duration=int(request.form.get("duration","30"))
                    raw_rate=request.form.get("payroll_rate","").strip()
                    payroll_rate=int(raw_rate) if raw_rate else 400
                    room_id=int(request.form.get("room_id") or 0) or None
                    lane_id=int(request.form.get("lane_id") or 0) or None
                except: abort(400,"Проверьте имя тренера, ставку и параметры занятия")
                d=request.form.get("slot_date",today()); t=request.form.get("slot_time","09:00")
                kind=request.form.get("kind","individual")
                if not trainer_name or len(trainer_name)>100: abort(400,"Введите имя тренера (до 100 символов)")
                if payroll_rate<0: abort(400,"Ставка тренера не может быть отрицательной")
                try:
                    d,t,capacity,duration,kind=validate_slot_details(d,t,capacity,duration,kind,today())
                except ValueError as exc:
                    abort(400,str(exc))
                notes=request.form.get("notes","").strip()
                if len(notes)>1000: abort(400,"Примечание к занятию не должно превышать 1000 символов")
                trainer=c.execute("SELECT id FROM trainers WHERE name=? COLLATE NOCASE AND active=1",(trainer_name,)).fetchone()
                supplied_rate = bool(request.form.get("payroll_rate","").strip())
                if not is_current_manager() and supplied_rate:
                    abort(403,"Менять ставки тренеров может только руководитель")
                if not trainer:
                    if not is_current_manager():
                        abort(400,"Сначала добавьте тренера в разделе «Тренеры»")
                if trainer:
                    trainer_id=trainer["id"]
                    if is_current_manager() and supplied_rate:
                        c.execute("UPDATE trainers SET payroll_rate=? WHERE id=?",(payroll_rate,trainer_id))
                else:
                    cur_tr=c.execute("INSERT INTO trainers(name,payroll_rate) VALUES(?,?)",(trainer_name,payroll_rate))
                    trainer_id=cur_tr.lastrowid
                    audit(c,"trainer.created","trainer",trainer_id,{"name":trainer_name,"payroll_rate":payroll_rate,"created_from_schedule":True})
                existing=c.execute("SELECT id,slot_time,duration_minutes FROM schedule_slots WHERE trainer_id=? AND slot_date=?",(trainer_id,d)).fetchall()
                try:
                    ensure_no_overlap(t,duration,existing)
                except ValueError as exc:
                    abort(400,str(exc))
                if room_id is not None:
                    if not c.execute("SELECT id FROM schedule_resources WHERE id=? AND active=1 AND resource_type='room'",(room_id,)).fetchone(): abort(400,"Выберите действующее помещение/бассейн")
                    room_slots=c.execute("SELECT id,slot_time,duration_minutes FROM schedule_slots WHERE room_id=? AND slot_date=?",(room_id,d)).fetchall()
                    try: ensure_resource_no_overlap(t,duration,room_slots)
                    except ValueError as exc: abort(400,str(exc))
                if lane_id is not None:
                    if not c.execute("SELECT id FROM schedule_resources WHERE id=? AND active=1 AND resource_type='lane'",(lane_id,)).fetchone(): abort(400,"Выберите действующую дорожку")
                    lane_slots=c.execute("SELECT id,slot_time,duration_minutes FROM schedule_slots WHERE lane_id=? AND slot_date=?",(lane_id,d)).fetchall()
                    try: ensure_resource_no_overlap(t,duration,lane_slots)
                    except ValueError as exc: abort(400,str(exc))
                try:
                    cur=c.execute("INSERT INTO schedule_slots(trainer_id,slot_date,slot_time,duration_minutes,capacity,kind,notes,room_id,lane_id) VALUES(?,?,?,?,?,?,?,?,?)",
                        (trainer_id,d,t,duration,capacity,kind,notes,room_id,lane_id))
                except sqlite3.IntegrityError: abort(400,"У этого тренера уже есть слот на эту дату и время")
                audit(c,"schedule_slot.created","schedule_slot",cur.lastrowid,{"trainer_id":trainer_id,"date":d,"time":t,"capacity":capacity,"kind":kind,"room_id":room_id,"lane_id":lane_id})
            elif action=="edit_slot":
                try:
                    slot_id=int(request.form["slot_id"])
                    trainer_id=int(request.form["trainer_id"])
                    capacity=int(request.form["capacity"])
                    duration=int(request.form["duration"])
                    room_id=int(request.form.get("room_id") or 0) or None
                    lane_id=int(request.form.get("lane_id") or 0) or None
                except (ValueError, KeyError):
                    abort(400,"Проверьте параметры слота")
                slot=c.execute("SELECT * FROM schedule_slots WHERE id=?",(slot_id,)).fetchone()
                if not slot: abort(404,"Слот не найден")
                if slot["slot_date"]<=today(): abort(400,"Можно менять только занятия с будущей датой")
                if c.execute("SELECT 1 FROM bookings WHERE slot_id=? LIMIT 1",(slot_id,)).fetchone():
                    abort(400,"Нельзя редактировать слот с записями, включая отменённые. Создайте новый слот")
                if c.execute("SELECT 1 FROM attendance WHERE schedule_slot_id=? LIMIT 1",(slot_id,)).fetchone():
                    abort(400,"Нельзя редактировать слот, связанный с историей посещений")
                trainer=c.execute("SELECT id FROM trainers WHERE id=? AND active=1",(trainer_id,)).fetchone()
                if not trainer: abort(400,"Выберите действующего тренера")
                new_date=request.form.get("slot_date","").strip()
                new_time=request.form.get("slot_time","").strip()
                kind=request.form.get("kind","")
                notes=request.form.get("notes","").strip()
                try:
                    new_date,new_time,capacity,duration,kind=validate_slot_details(new_date,new_time,capacity,duration,kind,today())
                except ValueError as exc:
                    abort(400,str(exc))
                if len(notes)>1000: abort(400,"Примечание к занятию не должно превышать 1000 символов")
                existing=c.execute("SELECT id,slot_time,duration_minutes FROM schedule_slots WHERE trainer_id=? AND slot_date=?",(trainer_id,new_date)).fetchall()
                try:
                    ensure_no_overlap(new_time,duration,existing,exclude_slot_id=slot_id)
                except ValueError as exc:
                    abort(400,str(exc))
                if room_id is not None:
                    if not c.execute("SELECT id FROM schedule_resources WHERE id=? AND active=1 AND resource_type='room'",(room_id,)).fetchone(): abort(400,"Выберите действующее помещение/бассейн")
                    room_slots=c.execute("SELECT id,slot_time,duration_minutes FROM schedule_slots WHERE room_id=? AND slot_date=?",(room_id,new_date)).fetchall()
                    try: ensure_resource_no_overlap(new_time,duration,room_slots,exclude_slot_id=slot_id)
                    except ValueError as exc: abort(400,str(exc))
                if lane_id is not None:
                    if not c.execute("SELECT id FROM schedule_resources WHERE id=? AND active=1 AND resource_type='lane'",(lane_id,)).fetchone(): abort(400,"Выберите действующую дорожку")
                    lane_slots=c.execute("SELECT id,slot_time,duration_minutes FROM schedule_slots WHERE lane_id=? AND slot_date=?",(lane_id,new_date)).fetchall()
                    try: ensure_resource_no_overlap(new_time,duration,lane_slots,exclude_slot_id=slot_id)
                    except ValueError as exc: abort(400,str(exc))
                try:
                    c.execute("UPDATE schedule_slots SET trainer_id=?,slot_date=?,slot_time=?,duration_minutes=?,capacity=?,kind=?,notes=?,room_id=?,lane_id=? WHERE id=?",
                              (trainer_id,new_date,new_time,duration,capacity,kind,notes,room_id,lane_id,slot_id))
                except sqlite3.IntegrityError:
                    abort(400,"У этого тренера уже есть слот на выбранные дату и время")
                audit(c,"schedule_slot.updated","schedule_slot",slot_id,{"trainer_id":trainer_id,"date":new_date,"time":new_time,"capacity":capacity,"kind":kind,"room_id":room_id,"lane_id":lane_id})
            elif action=="delete_slot":
                try: slot_id=int(request.form.get("slot_id","0"))
                except ValueError: abort(400,"Неверный слот")
                slot=c.execute("SELECT * FROM schedule_slots WHERE id=?",(slot_id,)).fetchone()
                if not slot: abort(404,"Слот не найден")
                if slot["slot_date"]<=today(): abort(400,"Удалять можно только будущие слоты")
                if c.execute("SELECT 1 FROM bookings WHERE slot_id=? LIMIT 1",(slot_id,)).fetchone():
                    abort(400,"Нельзя удалить слот с историей записей. Перенесите записи или оставьте историю")
                if c.execute("SELECT 1 FROM attendance WHERE schedule_slot_id=? LIMIT 1",(slot_id,)).fetchone():
                    abort(400,"Нельзя удалить слот, связанный с посещением")
                c.execute("DELETE FROM schedule_slots WHERE id=?",(slot_id,))
                audit(c,"schedule_slot.deleted","schedule_slot",slot_id,{"trainer_id":slot["trainer_id"],"date":slot["slot_date"],"time":slot["slot_time"]})
                flash("Свободный будущий слот удалён. История записей не затронута.")
                return redirect(url_for("schedule",day=slot["slot_date"]))
            elif action=="booking":
                try: slot_id=int(request.form["slot_id"]); client_id=int(request.form["client_id"]); sub_id=int(request.form.get("subscription_id") or 0)
                except: abort(400,"Проверьте клиента и слот")
                slot=c.execute("SELECT sl.*,tr.active trainer_active FROM schedule_slots sl JOIN trainers tr ON tr.id=sl.trainer_id WHERE sl.id=?",(slot_id,)).fetchone()
                if not slot: abort(400,"Слот не найден")
                if not slot["trainer_active"]: abort(400,"Тренер отключён. Выберите слот действующего тренера.")
                if slot["slot_date"] < today(): abort(400,"Нельзя записать на прошедшее занятие")
                client=c.execute("SELECT id FROM clients WHERE id=?",(client_id,)).fetchone()
                if not client: abort(400,"Клиент не найден")
                if not sub_id: abort(400,"Для записи из расписания выберите абонемент. Разовое занятие сначала оформите через продажу.")
                sub=c.execute("SELECT * FROM subscriptions WHERE id=? AND client_id=? AND status='active' AND remaining_lessons>0 AND (COALESCE(expires_at,'')='' OR expires_at>=?)",(sub_id,client_id,slot["slot_date"])).fetchone()
                if not sub: abort(400,"У ребёнка нет подходящего активного абонемента на дату занятия")
                count=c.execute("SELECT COUNT(*) n FROM bookings WHERE slot_id=? AND status='booked'",(slot_id,)).fetchone()["n"]
                if count>=slot["capacity"]: abort(400,"На это время уже нет свободных мест")
                existing=c.execute("SELECT id,status FROM bookings WHERE slot_id=? AND client_id=?",(slot_id,client_id)).fetchone()
                if existing and existing["status"]=="attended": abort(400,"Ребёнок уже посетил это занятие")
                if existing and existing["status"]=="missed": abort(400,"Ребёнок уже отмечен как пропустивший это занятие")
                if existing and existing["status"]=="booked": abort(400,"Ребёнок уже записан на это время")
                if existing and existing["status"]=="cancelled":
                    booking_id=existing["id"]
                    try:
                        c.execute("UPDATE bookings SET status='booked',subscription_id=?,created_by=?,created_at=? WHERE id=? AND status='cancelled'",
                            (sub_id,session["uid"],now(),booking_id))
                    except sqlite3.IntegrityError as exc:
                        if "booking_capacity_full" in str(exc): abort(400,"На это время уже нет свободных мест")
                        raise
                    audit(c,"booking.rebooked","booking",booking_id,{"slot_id":slot_id,"client_id":client_id,"subscription_id":sub_id})
                else:
                    try:
                        cur=c.execute("INSERT INTO bookings(slot_id,client_id,subscription_id,created_by,created_at) VALUES(?,?,?,?,?)",
                            (slot_id,client_id,sub_id,session["uid"],now()))
                    except sqlite3.IntegrityError as exc:
                        if "booking_capacity_full" in str(exc): abort(400,"На это время уже нет свободных мест")
                        raise
                    booking_id=cur.lastrowid
                    audit(c,"booking.created","booking",booking_id,{"slot_id":slot_id,"client_id":client_id,"subscription_id":sub_id})
            else: abort(400,"Неизвестное действие")
            return redirect(url_for("schedule",day=request.form.get("slot_date",today())))
        day=request.args.get("day",today())
        try: date.fromisoformat(day)
        except ValueError: abort(400,"Некорректная дата")
        trainers=c.execute("SELECT * FROM trainers WHERE active=1 ORDER BY name").fetchall()
        resources=c.execute("SELECT * FROM schedule_resources WHERE active=1 ORDER BY resource_type,name").fetchall()
        clients=c.execute("SELECT id,child_name FROM clients ORDER BY child_name").fetchall()
        selected_date=date.fromisoformat(day)
        view=request.args.get("view","day").strip().lower()
        group_by=request.args.get("group_by","trainer").strip().lower()
        if view not in ("day","list","calendar","month"): abort(400,"Неизвестный режим расписания")
        if group_by not in ("trainer","resource"): group_by="trainer"
        if view in ("list","calendar","month"):
            if view=="list":
                range_start=selected_date
                range_end=range_start+timedelta(days=13)
                title_range=f"14 дней: {range_start.strftime('%d.%m.%Y')} — {range_end.strftime('%d.%m.%Y')}"
                prev_day=(range_start-timedelta(days=14)).isoformat(); next_day=(range_start+timedelta(days=14)).isoformat()
                navigation=f"<a class='btn' href='/schedule?view=list&day={prev_day}&group_by={group_by}'>← 14 дней назад</a> <a class='btn' href='/schedule?view=list&day={next_day}&group_by={group_by}'>Следующие 14 дней →</a>"
            elif view=="calendar":
                range_start=selected_date-timedelta(days=selected_date.weekday())
                range_end=range_start+timedelta(days=6)
                prev_day=(range_start-timedelta(days=7)).isoformat(); next_day=(range_start+timedelta(days=7)).isoformat()
                title_range=f"Неделя: {range_start.strftime('%d.%m.%Y')} — {range_end.strftime('%d.%m.%Y')}"
                navigation=f"<a class='btn' href='/schedule?view=calendar&day={prev_day}&group_by={group_by}'>← Предыдущая неделя</a> <a class='btn' href='/schedule?view=calendar&day={next_day}&group_by={group_by}'>Следующая неделя →</a>"
            else:
                range_start=selected_date.replace(day=1)
                if range_start.month==12: next_month=date(range_start.year+1,1,1)
                else: next_month=date(range_start.year,range_start.month+1,1)
                range_end=next_month-timedelta(days=1)
                cal_start=range_start-timedelta(days=range_start.weekday())
                cal_end=range_end+timedelta(days=(6-range_end.weekday()))
                prev_month=(range_start-timedelta(days=1)).replace(day=1).isoformat(); next_month_day=next_month.isoformat()
                navigation=f"<a class='btn' href='/schedule?view=month&day={prev_month}'>← Предыдущий месяц</a> <a class='btn' href='/schedule?view=month&day={next_month_day}'>Следующий месяц →</a>"
                title_range=range_start.strftime('%m.%Y')
            view_rows=c.execute("""SELECT sl.*,tr.name trainer_name,rm.name room_name,ln.name lane_name,
                (SELECT COUNT(*) FROM bookings b WHERE b.slot_id=sl.id AND b.status='booked') booked
                FROM schedule_slots sl JOIN trainers tr ON tr.id=sl.trainer_id
                LEFT JOIN schedule_resources rm ON rm.id=sl.room_id
                LEFT JOIN schedule_resources ln ON ln.id=sl.lane_id
                WHERE sl.slot_date BETWEEN ? AND ? ORDER BY sl.slot_date,sl.slot_time,tr.name""",(range_start.isoformat(),range_end.isoformat())).fetchall()
            view_links="<div class='card'><h2>Режим расписания</h2><a class='btn' href='/schedule?view=day&day="+selected_date.isoformat()+"'>День</a> <a class='btn' href='/schedule?view=list&day="+selected_date.isoformat()+"&group_by=trainer'>Список на 14 дней</a> <a class='btn' href='/schedule?view=calendar&day="+selected_date.isoformat()+"&group_by=trainer'>Календарь недели</a> <a class='btn' href='/schedule?view=month&day="+selected_date.isoformat()+"'>Месяц</a><form method='get'><input type='hidden' name='view' value='list'><input type='hidden' name='day' value='"+selected_date.isoformat()+"'><label>Группировать список по</label><select name='group_by'><option value='trainer' "+("selected" if group_by=='trainer' else "")+">Тренеру</option><option value='resource' "+("selected" if group_by=='resource' else "")+">Помещению/дорожке</option></select><button>Применить</button></form></div>"
            if view=="list":
                groups={}
                for row in view_rows:
                    key=(row['trainer_name'] if group_by=='trainer' else ' / '.join(x for x in [row['room_name'],row['lane_name']] if x) or 'Без помещения/дорожки')
                    groups.setdefault(key,[]).append(row)
                listing=f"<div class='card'><h2>{esc(title_range)}</h2>{navigation}<div class='tablewrap'><table><tr><th>Дата</th><th>Время</th><th>Тренер</th><th>Помещение / дорожка</th><th>Тип</th><th>Записи</th></tr>"
                for key,items in groups.items():
                    listing+=f"<tr><th colspan='6'>{esc(key)}</th></tr>"
                    for row in items:
                        res='; '.join(x for x in [('Помещение: '+row['room_name']) if row['room_name'] else '', ('Дорожка: '+row['lane_name']) if row['lane_name'] else ''] if x) or '—'
                        kind_label={'individual':'Индивидуальное','group':'Групповое'}.get(row['kind'],row['kind'])
                        listing+=f"<tr><td><a href='/schedule?day={row['slot_date']}'>{esc(row['slot_date'])}</a></td><td>{esc(row['slot_time'])} ({row['duration_minutes']} мин.)</td><td>{esc(row['trainer_name'])}</td><td>{esc(res)}</td><td>{esc(kind_label)}</td><td>{row['booked']}/{row['capacity']}</td></tr>"
                if not view_rows: listing+="<tr><td colspan='6'>На выбранный период занятий нет.</td></tr>"
                return page("Расписание — список",view_links+listing+"</table></div></div>")
            if view=="calendar":
                by_date={}
                for row in view_rows: by_date.setdefault(row['slot_date'],[]).append(row)
                row_keys=[]
                for row in view_rows:
                    key=row['trainer_name'] if group_by=='trainer' else (' / '.join(x for x in [row['room_name'],row['lane_name']] if x) or 'Без помещения/дорожки')
                    if key not in row_keys: row_keys.append(key)
                calendar=f"<div class='card'><h2>Загрузка по {'тренерам' if group_by=='trainer' else 'помещениям/дорожкам'} · {esc(title_range)}</h2>{navigation}<div class='tablewrap'><table><tr><th>{'Тренер' if group_by=='trainer' else 'Помещение/дорожка'}</th>"
                dates=[range_start+timedelta(days=i) for i in range(7)]
                for current in dates: calendar+=f"<th><a href='/schedule?day={current.isoformat()}'>{['Пн','Вт','Ср','Чт','Пт','Сб','Вс'][current.weekday()]}<br>{current.strftime('%d.%m')}</a></th>"
                calendar+="</tr>"
                for key in row_keys:
                    calendar+=f"<tr><th>{esc(key)}</th>"
                    for current in dates:
                        cell_rows=[]
                        for row in by_date.get(current.isoformat(),[]):
                            row_key=row['trainer_name'] if group_by=='trainer' else (' / '.join(x for x in [row['room_name'],row['lane_name']] if x) or 'Без помещения/дорожки')
                            if row_key==key: cell_rows.append(row)
                        cell=""
                        for row in cell_rows:
                            cls='group' if row['kind']=='group' else 'individual'
                            label='Группа' if row['kind']=='group' else 'Индивидуально'
                            cell+=f"<a class='slot-chip {cls}' href='/schedule?day={current.isoformat()}' style='color:#182536;text-decoration:none'>{esc(row['slot_time'])} · {label}<br>{row['booked']}/{row['capacity']} мест</a>"
                        calendar+=f"<td style='min-width:115px;vertical-align:top'>{cell or '—'}</td>"
                    calendar+="</tr>"
                if not row_keys: calendar+="<tr><td colspan='8'>На этой неделе занятий нет.</td></tr>"
                calendar+="</table></div><p class='muted'>Синий — групповое занятие; красный — индивидуальное. Нажмите время, чтобы открыть рабочий день.</p></div>"
                return page("Расписание — календарь недели",view_links+calendar)
            calendar=f"<div class='card'><h2>Календарь: {esc(title_range)}</h2>{navigation}<div style='display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:5px;margin-top:12px'>"
            for weekday in ('Пн','Вт','Ср','Чт','Пт','Сб','Вс'):
                calendar+=f"<div class='muted' style='font-weight:bold;padding:4px'>{weekday}</div>"
            by_date={}
            for row in view_rows: by_date.setdefault(row['slot_date'],[]).append(row)
            current=cal_start
            while current<=cal_end:
                iso=current.isoformat(); off=current.month!=range_start.month
                cell_style='background:#f0f3f7;color:#9aa5b1;' if off else 'background:#fff;'
                calendar+=f"<div style='min-height:110px;min-width:0;border:1px solid #dce4ee;border-radius:7px;padding:4px;{cell_style}'><a href='/schedule?day={iso}' style='font-weight:bold'>{current.day}</a>"
                for row in by_date.get(iso,[])[:5]:
                    cls='group' if row['kind']=='group' else 'individual'
                    resource_name=' / '.join(x for x in [row['room_name'],row['lane_name']] if x) or row['trainer_name']
                    calendar+=f"<a class='slot-chip {cls}' href='/schedule?day={iso}' style='color:#182536;text-decoration:none'>{esc(row['slot_time'])} {esc(resource_name)}<br><span class='muted'>{row['booked']}/{row['capacity']} мест</span></a>"
                if len(by_date.get(iso,[]))>5: calendar+=f"<small>ещё {len(by_date[iso])-5}</small>"
                calendar+="</div>"
                current+=timedelta(days=1)
            calendar+="</div><p class='muted'>Цвета: синий — групповое, красный — индивидуальное. Нажмите дату или занятие, чтобы открыть рабочий день.</p></div>"
            return page("Расписание — календарь",view_links+calendar)
        week_start=selected_date-timedelta(days=selected_date.weekday())
        week_end=week_start+timedelta(days=6)
        week_rows=c.execute("""SELECT sl.slot_date, COUNT(*) slot_count,
            SUM((SELECT COUNT(*) FROM bookings b WHERE b.slot_id=sl.id AND b.status='booked')) booked_count,
            SUM(sl.capacity) total_capacity
            FROM schedule_slots sl WHERE sl.slot_date BETWEEN ? AND ? GROUP BY sl.slot_date""",
            (week_start.isoformat(),week_end.isoformat())).fetchall()
        week_stats={r['slot_date']:r for r in week_rows}
        slots=c.execute("""SELECT sl.*,tr.name trainer_name,tr.active trainer_active,
            rm.name room_name,ln.name lane_name,
            (SELECT COUNT(*) FROM bookings b WHERE b.slot_id=sl.id AND b.status='booked') booked
            FROM schedule_slots sl JOIN trainers tr ON tr.id=sl.trainer_id
            LEFT JOIN schedule_resources rm ON rm.id=sl.room_id
            LEFT JOIN schedule_resources ln ON ln.id=sl.lane_id
            WHERE sl.slot_date=? ORDER BY sl.slot_time,tr.name""",(day,)).fetchall()
        subs=c.execute("""SELECT s.id,s.client_id,s.title,s.remaining_lessons,c.child_name
            FROM subscriptions s JOIN clients c ON c.id=s.client_id
            WHERE s.status='active' AND s.remaining_lessons>0 AND (COALESCE(s.expires_at,'')='' OR s.expires_at>=?) ORDER BY c.child_name""",(day,)).fetchall()
    is_manager = is_current_manager()
    trainer_admin_html = '<div class="card"><h2>Добавить тренера</h2><form method="post"><input type="hidden" name="action" value="trainer"><label>Имя</label><input name="trainer_name" required maxlength="100">' + ('<label>Оплата за занятие, ₽</label><input type="number" name="payroll_rate" min="0" step="1" value="400" required>' if is_manager else '') + '<button>Добавить</button></form><p class="muted"><a href="/trainers">Полный список и управление тренерами</a></p></div>' 
    repeat_days_html = "".join(f"<label style='display:inline-block;margin-right:12px'><input style='width:auto' type='checkbox' name='weekdays' value='{i}' {'checked' if i < 5 else ''}> {name}</label>" for i,name in enumerate(['Пн','Вт','Ср','Чт','Пт','Сб','Вс']))
    room_opts = "<option value=''>Без назначения</option>" + "".join(f"<option value='{r['id']}'>{esc(r['name'])}</option>" for r in resources if r['resource_type']=='room')
    lane_opts = "<option value=''>Без назначения</option>" + "".join(f"<option value='{r['id']}'>{esc(r['name'])}</option>" for r in resources if r['resource_type']=='lane')
    resource_select = f"<label>Помещение/бассейн</label><select name='room_id'>{room_opts}</select><label>Дорожка</label><select name='lane_id'>{lane_opts}</select>"
    repeat_resource_select = f"<label>Помещение/бассейн</label><select name='repeat_room_id'>{room_opts}</select><label>Дорожка</label><select name='repeat_lane_id'>{lane_opts}</select>"
    repeat_default_start = max(selected_date, date.today())
    repeat_default_end = repeat_default_start + timedelta(days=28)
    repeat_trainer_opts = "".join(f"<option value='{t['id']}'>{esc(t['name'])}</option>" for t in trainers)
    repeat_schedule_html = ("<div class='card'><h2>Создать повторяющееся расписание</h2>"
        "<p class='muted'>Создаёт все слоты смены в выбранные дни недели. Окончание смены не включается; период — до 90 дней. Существующие совпадения пропускаются.</p>"
        "<form method='post'><input type='hidden' name='action' value='repeat_shift'><label>Тренер</label><select name='repeat_trainer_id' required>" + repeat_trainer_opts + "</select>"
        f"<label>Дата начала</label><input type='date' name='repeat_start_date' value='{repeat_default_start.isoformat()}' required>"
        f"<label>Дата окончания</label><input type='date' name='repeat_end_date' value='{repeat_default_end.isoformat()}' required>"
        f"<label>Дни недели</label><div>{repeat_days_html}</div>"
        "<label>Начало смены</label><input type='time' name='repeat_start_time' value='09:00' required>"
        "<label>Окончание смены (не включительно)</label><input type='time' name='repeat_end_time' value='15:00' required>"
        "<label>Длительность слота</label><select name='repeat_duration'><option value='30'>30 минут</option><option value='60'>60 минут</option></select>"
        "<label>Тип занятия</label><select name='repeat_kind'><option value='individual'>Индивидуальное</option><option value='group'>Групповое</option></select>"
        "<label>Вместимость</label><input type='number' name='repeat_capacity' min='1' max='100' value='1' required>"
        + repeat_resource_select +
        "<label>Примечание</label><input name='repeat_notes' maxlength='1000'><button>Создать повторение</button></form></div>")
    slot_rate_html = '<label>Ставка тренера, ₽ за занятие (необязательно)</label><input type="number" name="payroll_rate" min="0" step="1" placeholder="Введите свою ставку">' if is_manager else "<p class='muted'>Ставку начисления задаёт руководитель. Нового тренера добавьте в разделе «Тренеры».</p>"
    client_opts="".join(f"<option value='{c['id']}'>{esc(c['child_name'])}</option>" for c in clients)
    sub_opts="".join(f"<option value='{s['id']}' data-client-id='{s['client_id']}'>{esc(s['child_name'])}: {esc(s['title'])} ({s['remaining_lessons']})</option>" for s in subs)
    week_html="<div class='card'><h2>Неделя: "+esc(week_start.strftime('%d.%m.%Y'))+" — "+esc(week_end.strftime('%d.%m.%Y'))+"</h2><div class='grid'>"
    for offset in range(7):
        current=week_start+timedelta(days=offset)
        iso=current.isoformat(); stat=week_stats.get(iso)
        slot_count=int(stat['slot_count']) if stat else 0
        booked_count=int(stat['booked_count'] or 0) if stat else 0
        total_capacity=int(stat['total_capacity'] or 0) if stat else 0
        is_selected=iso==day
        week_html+=f"<div class='card' style='min-width:0;{ 'border:2px solid #1768a6;' if is_selected else ''}'><b>{esc(['Пн','Вт','Ср','Чт','Пт','Сб','Вс'][offset])}, {current.strftime('%d.%m')}</b><p>{slot_count} слотов</p><p>Записи: {booked_count}/{total_capacity} мест</p><a class='btn' href='/schedule?day={iso}'>Открыть день</a></div>"
    prev_week=(week_start-timedelta(days=7)).isoformat(); next_week=(week_start+timedelta(days=7)).isoformat()
    week_html+="</div><p><a class='btn' href='/schedule?day="+prev_week+"'>← Предыдущая неделя</a> <a class='btn' href='/schedule?day="+next_week+"'>Следующая неделя →</a></p></div>"
    available_slots=[sl for sl in slots if sl["trainer_active"] and sl["booked"] < sl["capacity"]]
    slot_opts="".join(f"<option value='{sl['id']}'>{esc(sl['slot_time'])} — {esc(sl['trainer_name'])}, {'Группа' if sl['kind']=='group' else 'Индивидуально'}, мест {sl['booked']}/{sl['capacity']}</option>" for sl in available_slots)
    if not slot_opts:
        slot_opts="<option value='' disabled selected>Нет свободных мест на выбранную дату</option>"
    body=f"""<div class="card"><h2>Расписание на день</h2><form method="get"><input type="hidden" name="view" value="day"><label>Дата</label><input type="date" name="day" value="{esc(day)}"><button>Показать</button></form><p><a class="btn" href="/schedule?view=list&day={esc(day)}&group_by=trainer">Список на 14 дней</a> <a class="btn" href="/schedule?view=calendar&day={esc(day)}&group_by=trainer">Календарь недели</a> <a class="btn" href="/schedule?view=month&day={esc(day)}">Календарь на месяц</a></p></div>{week_html}
    <div class="grid">{trainer_admin_html}{repeat_schedule_html}
    <div class="card"><h2>Создать временной слот</h2><form method="post"><input type="hidden" name="action" value="slot"><label>Имя тренера (можно вписать вручную)</label><input name="trainer_name" list="trainer_names" required maxlength="100"><datalist id="trainer_names">{''.join(f"<option value='{esc(t['name'])}'>" for t in trainers)}</datalist>{slot_rate_html}<label>Дата</label><input type="date" name="slot_date" value="{esc(day)}" required><label>Время начала</label><input type="time" name="slot_time" value="09:00" required><label>Длительность</label><select name="duration"><option value="30">30 минут</option><option value="60">60 минут</option></select><label>Тип</label><select name="kind"><option value="individual">Индивидуальное</option><option value="group">Групповое</option></select><label>Вместимость</label><input type="number" name="capacity" min="1" value="1">{resource_select}<button>Создать слот</button></form></div>
    <div class="card"><h2>Записать ребёнка</h2><form method="post"><input type="hidden" name="action" value="booking"><label>Слот</label><select name="slot_id" required>{slot_opts}</select><label>Ребёнок</label><select name="client_id" id="booking_client_id" required>{client_opts}</select><label>Абонемент</label><select name="subscription_id" id="booking_subscription_id" required>{sub_opts}</select><button>Записать</button></form></div></div><script>(()=>{{const client=document.getElementById("booking_client_id");const sub=document.getElementById("booking_subscription_id");if(!client||!sub)return;const filter=()=>{{let first=null;for(const option of sub.options){{const visible=option.dataset.clientId===client.value;option.hidden=!visible;option.disabled=!visible;if(visible&&first===null)first=option;}}if(first){{const selected=sub.options[sub.selectedIndex];if(!selected||selected.disabled)sub.value=first.value;}}else{{sub.value="";}}}};client.addEventListener("change",filter);filter();}})();</script>
    <div class="card"><h2>Слоты и записи — {esc(day)}</h2><div class="tablewrap"><table><tr><th>Время</th><th>Тренер</th><th>Тип</th><th>Длительность</th><th>Помещение / дорожка</th><th>Загрузка</th><th>Дети</th></tr>"""
    for sl in slots:
        with connect() as c:
            kids=c.execute("SELECT b.id booking_id,b.status booking_status,b.booking_type,cl.child_name FROM bookings b JOIN clients cl ON cl.id=b.client_id WHERE b.slot_id=? ORDER BY cl.child_name",(sl["id"],)).fetchall()
            has_attendance=c.execute("SELECT 1 FROM attendance WHERE schedule_slot_id=? LIMIT 1",(sl["id"],)).fetchone() is not None
        kid_html=[]
        for k in kids:
            if k["booking_status"]=="booked":
                try:
                    starts_at=datetime.fromisoformat(f"{sl['slot_date']}T{sl['slot_time']}")
                except ValueError:
                    starts_at=datetime.min
                if k["booking_type"] == "trial":
                    if datetime.now() < starts_at:
                        controls=f"<small>Пробное занятие</small><form method='post' action='/trial-lessons'><input type='hidden' name='action' value='cancel'><input type='hidden' name='booking_id' value='{k['booking_id']}'><button class='danger'>Отменить пробное</button></form>"
                    else:
                        controls=f"<small>Пробное · без автоматического списания абонемента</small><form method='post' action='/trial-lessons'><input type='hidden' name='action' value='attended'><input type='hidden' name='booking_id' value='{k['booking_id']}'><button>Пробное: посетил</button></form><form method='post' action='/trial-lessons'><input type='hidden' name='action' value='missed'><input type='hidden' name='booking_id' value='{k['booking_id']}'><button class='danger'>Пробное: не пришёл</button></form>"
                elif datetime.now() < starts_at:
                    controls=f"<form method='post' action='/booking/{k['booking_id']}/cancel'><button>Отменить запись</button></form>"
                else:
                    controls=f"<form method='post' action='/booking/{k['booking_id']}/attended'><button>Посетил / списать</button></form><form method='post' action='/booking/{k['booking_id']}/missed'><button class='danger'>Пропуск / списать</button></form>"
                kid_html.append(f"{esc(k['child_name'])} {controls}")
            else:
                state_label={"attended":"посетил","missed":"пропуск","cancelled":"запись отменена"}.get(k["booking_status"],k["booking_status"])
                kid_html.append(esc(k["child_name"])+" — "+state_label)
        edit_html=""
        if sl["slot_date"]>today() and not kids and not has_attendance:
            escaped_notes=esc(sl["notes"] or "").replace("'", "&#x27;")
            trainer_edit_opts="".join(f"<option value='{t['id']}' {'selected' if t['id']==sl['trainer_id'] else ''}>{esc(t['name'])}</option>" for t in trainers)
            slot_id = sl["id"]
            slot_date = esc(sl["slot_date"])
            slot_time = esc(sl["slot_time"])
            slot_duration = sl["duration_minutes"]
            slot_kind = sl["kind"]
            slot_capacity = sl["capacity"]
            slot_room_id = sl["room_id"]
            slot_lane_id = sl["lane_id"]
            room_options = "".join(
                "<option value='{}' {}>{}</option>".format(
                    r["id"], "selected" if slot_room_id == r["id"] else "", esc(r["name"])
                )
                for r in resources if r["resource_type"] == "room"
            )
            lane_options = "".join(
                "<option value='{}' {}>{}</option>".format(
                    r["id"], "selected" if slot_lane_id == r["id"] else "", esc(r["name"])
                )
                for r in resources if r["resource_type"] == "lane"
            )
            room_unassigned = "selected" if not slot_room_id else ""
            lane_unassigned = "selected" if not slot_lane_id else ""
            edit_html = (
                "<details><summary>Изменить будущий слот</summary>"
                "<form method='post'><input type='hidden' name='action' value='edit_slot'>"
                "<input type='hidden' name='slot_id' value='{}'>".format(slot_id)
                + "<label>Тренер</label><select name='trainer_id' required>{}</select>".format(trainer_edit_opts)
                + "<label>Дата</label><input type='date' name='slot_date' min='{}' value='{}' required>".format(
                    (date.today() + timedelta(days=1)).isoformat(), slot_date
                )
                + "<label>Время</label><input type='time' name='slot_time' value='{}' required>".format(slot_time)
                + "<label>Длительность</label><select name='duration'>"
                + "<option value='30' {}>30 минут</option>".format("selected" if slot_duration == 30 else "")
                + "<option value='60' {}>60 минут</option></select>".format("selected" if slot_duration == 60 else "")
                + "<label>Тип</label><select name='kind'>"
                + "<option value='individual' {}>Индивидуальное</option>".format("selected" if slot_kind == "individual" else "")
                + "<option value='group' {}>Групповое</option></select>".format("selected" if slot_kind == "group" else "")
                + "<label>Вместимость</label><input type='number' name='capacity' min='1' value='{}' required>".format(slot_capacity)
                + "<label>Помещение/бассейн</label><select name='room_id'>{}<option value='' {}>Без назначения</option></select>".format(room_options, room_unassigned)
                + "<label>Дорожка</label><select name='lane_id'>{}<option value='' {}>Без назначения</option></select>".format(lane_options, lane_unassigned)
                + "<label>Примечание</label><input name='notes' value='{}'>".format(escaped_notes)
                + "<button>Сохранить изменения</button></form></details>"
                "<form method='post'><input type='hidden' name='action' value='delete_slot'>"
                "<input type='hidden' name='slot_id' value='{}'>".format(slot_id)
                + "<button class='danger'>Удалить свободный слот</button></form>"
            )
        elif sl["slot_date"]>today():
            edit_html="<small>Изменение/удаление заблокировано: у слота есть записи или история посещений.</small>"
        trainer_label=esc(sl['trainer_name']) if sl['trainer_active'] else esc(sl['trainer_name'])+" (отключён)"
        resource_label='; '.join(x for x in [('Помещение: '+esc(sl['room_name'])) if sl['room_name'] else '', ('Дорожка: '+esc(sl['lane_name'])) if sl['lane_name'] else ''] if x) or '—'
        body+=f"<tr><td>{esc(sl['slot_time'])}</td><td>{trainer_label}</td><td>{'Групповое' if sl['kind']=='group' else 'Индивидуальное'}</td><td>{sl['duration_minutes']} мин.</td><td>{resource_label}</td><td>{sl['booked']}/{sl['capacity']}</td><td>{'<br>'.join(kid_html)}{edit_html}</td></tr>"
    return page("Расписание",body+"</table></div></div>")


@app.route("/booking/<int:booking_id>/attended", methods=["POST"])
@login_required
def booking_attended(booking_id):
    with connect() as c:
        try:
            result=mark_booking_outcome(c,booking_id,"attended",session["uid"],now(),today())
        except ValueError as exc:
            abort(400,str(exc))
        audit(c,"booking.attended","booking",booking_id,result)
    if request.form.get("return_to") == "journal":
        return redirect(url_for("daily_electronic_journal", day=result["date"]))
    return redirect(url_for("schedule",day=result["date"]))


@app.route("/booking/<int:booking_id>/missed", methods=["POST"])
@login_required
def booking_missed(booking_id):
    with connect() as c:
        try:
            result=mark_booking_outcome(c,booking_id,"missed",session["uid"],now(),today())
        except ValueError as exc:
            abort(400,str(exc))
        audit(c,"booking.missed","booking",booking_id,result)
    if request.form.get("return_to") == "journal":
        return redirect(url_for("daily_electronic_journal", day=result["date"]))
    return redirect(url_for("schedule",day=result["date"]))


@app.route("/booking/<int:booking_id>/cancel", methods=["POST"])
@login_required
def booking_cancel(booking_id):
    with connect() as c:
        c.execute("BEGIN IMMEDIATE")
        b=c.execute("SELECT * FROM bookings WHERE id=? AND status='booked'",(booking_id,)).fetchone()
        if not b: abort(400,"Запись уже обработана или не найдена")
        slot=c.execute("SELECT slot_date,slot_time FROM schedule_slots WHERE id=?",(b["slot_id"],)).fetchone()
        if not slot: abort(400,"Слот не найден")
        try:
            ensure_booking_cancellable(slot["slot_date"],slot["slot_time"])
        except ValueError as exc:
            abort(400,str(exc))
        changed=c.execute("UPDATE bookings SET status='cancelled' WHERE id=? AND status='booked'",(booking_id,))
        if changed.rowcount != 1: abort(400,"Запись уже обработана; обновите страницу")
        audit(c,"booking.cancelled","booking",booking_id,{"slot_id":b["slot_id"],"client_id":b["client_id"]})
    return redirect(url_for("schedule",day=slot["slot_date"] if slot else today()))

@app.get("/journal")
@login_required
def daily_electronic_journal():
    """GoCRM-style daily electronic notebook; all actions remain administrator-managed."""
    try:
        selected_day = normalize_journal_date(request.args.get("day", today()), today())
    except ValueError as exc:
        abort(400, str(exc))
    with connect() as c:
        report = get_daily_journal(c, selected_day)
        finance = get_daily_finance_summary(c, selected_day) if is_current_manager() else None
    t = report["totals"]
    body = f"""<div class='card'><h2>Электронная тетрадь</h2>
      <p class='muted'>Ежедневный список занятий, клиентов и отметок. Все записи ведёт администратор.</p>
      <form method='get'><label>Дата журнала</label><input type='date' name='day' value='{esc(selected_day)}' required><button>Открыть день</button>
      <a class='btn' href='/schedule?day={esc(selected_day)}'>Расписание дня</a></form></div>
      <div class='grid'><div class='card'><h2>Слоты</h2><p style='font-size:26px'>{t['slots']}</p></div>
      <div class='card'><h2>Записаны</h2><p style='font-size:26px'>{t['booked']}</p></div>
      <div class='card'><h2>Посетили</h2><p style='font-size:26px'>{t['attended']}</p></div>
      <div class='card'><h2>Пропуски</h2><p style='font-size:26px'>{t['missed']}</p></div></div>"""
    if finance:
        sales = finance["sales"]; expenses = finance["expenses"]
        body += f"""<div class='grid'><div class='card'><h2>Продажи за день</h2><p style='font-size:24px'>{sales['gross_sales']:,} ₽</p></div>
        <div class='card'><h2>Возвраты</h2><p style='font-size:24px'>{sales['refunds']:,} ₽</p></div>
        <div class='card'><h2>Расходы</h2><p style='font-size:24px'>{expenses['expenses']:,} ₽</p></div></div>"""
    body += "<div class='card'><h2>Занятия и записи</h2>"
    if not report["slots"]:
        body += "<p class='muted'>На эту дату занятий нет.</p>"
    else:
        body += "<div class='tablewrap'><table><tr><th>Время</th><th>Тренер</th><th>Тип</th><th>Помещение / дорожка</th><th>Запись</th><th>Клиенты и статусы</th></tr>"
        for slot in report["slots"]:
            children = [x for x in report["children"] if x["slot_id"] == slot["slot_id"]]
            names = []
            for child in children:
                status_labels = {"booked":"Записан", "attended":"Посетил", "missed":"Пропуск", "cancelled":"Отменён"}
                label = f"{esc(child['child_name'])} — {status_labels.get(child['status'], esc(child['status']))}"
                if child["status"] == "booked":
                    starts_at = datetime.fromisoformat(f"{selected_day}T{slot['slot_time']}")
                    if datetime.now() >= starts_at:
                        if child["booking_type"] == "trial":
                            label += f" · пробное <form method='post' action='/trial-lessons' style='display:inline'><input type='hidden' name='action' value='attended'><input type='hidden' name='booking_id' value='{child['booking_id']}'><button>Пробное: посетил</button></form> <form method='post' action='/trial-lessons' style='display:inline'><input type='hidden' name='action' value='missed'><input type='hidden' name='booking_id' value='{child['booking_id']}'><button class='danger'>Пробное: не пришёл</button></form>"
                        else:
                            label += f"<form method='post' action='/booking/{child['booking_id']}/attended' style='display:inline'><input type='hidden' name='return_to' value='journal'><button>Посетил</button></form> <form method='post' action='/booking/{child['booking_id']}/missed' style='display:inline'><input type='hidden' name='return_to' value='journal'><button class='danger'>Пропуск</button></form>"
                names.append(label)
            resource = "; ".join(x for x in ["Помещение: "+esc(slot["room_name"]) if slot["room_name"] else "", "Дорожка: "+esc(slot["lane_name"]) if slot["lane_name"] else ""] if x) or "—"
            kind = "Групповое" if slot["kind"] == "group" else "Индивидуальное"
            children_html = '<br>'.join(names) if names else '<span class="muted">Нет записей</span>'
            body += f"<tr><td>{esc(slot['slot_time'])} ({slot['duration_minutes']} мин.)</td><td>{esc(slot['trainer_name'])}</td><td>{kind}</td><td>{resource}</td><td>{slot['occupied_count']}/{slot['capacity']}</td><td>{children_html}</td></tr>"
        body += "</table></div>"
    body += "</div><div class='card'><h2>Быстрые действия</h2><a class='btn' href='/schedule?day="+esc(selected_day)+"'>Управление записями и посещаемостью</a> <a class='btn' href='/sales'>Продажи</a> <a class='btn' href='/tasks'>Мои дела / задачи</a></div>"
    return page("Электронная тетрадь", body)


@app.route("/attendance",methods=["GET","POST"])
@login_required
def attendance():
    with connect() as c:
        if request.method=="POST":
            try: sub_id=int(request.form["subscription_id"])
            except (ValueError, KeyError): abort(400,"Проверьте абонемент")
            sub=c.execute("SELECT * FROM subscriptions WHERE id=?",(sub_id,)).fetchone()
            if not sub or sub["status"]!="active" or sub["remaining_lessons"]<1: abort(400,"Нет активного абонемента с доступными занятиями")
            lesson_date=request.form.get("lesson_date",today()); lesson_time=request.form.get("lesson_time","09:00")
            try:
                date.fromisoformat(lesson_date)
                datetime.strptime(lesson_time,"%H:%M")
            except ValueError:
                abort(400,"Проверьте дату и время занятия")
            if sub["expires_at"] and sub["expires_at"] < lesson_date:
                abort(400,"Срок действия абонемента истекает до даты занятия")
            trainer_name=request.form.get("trainer","").strip()
            trainer=c.execute("SELECT name,payroll_rate FROM trainers WHERE name=? COLLATE NOCASE AND active=1",(trainer_name,)).fetchone() if trainer_name else None
            if not trainer:
                abort(400,"Выберите действующего тренера из справочника «Тренеры и ставки»")
            # Payroll rate is always taken from the manager-maintained trainer record;
            # never trust a rate supplied by an administrator's POST request.
            rate=int(trainer["payroll_rate"])
            cur=c.execute("INSERT INTO attendance(client_id,subscription_id,trainer,lesson_date,lesson_time,status,rate_snapshot,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                (sub["client_id"],sub_id,trainer["name"],lesson_date,lesson_time,"planned",rate,session["uid"],now()))
            audit(c,"attendance.planned","attendance",cur.lastrowid,{"subscription_id":sub_id,"date":lesson_date,"time":lesson_time,"rate_snapshot":rate,"trainer":trainer["name"]})
            return redirect(url_for("attendance"))
        subs=c.execute("SELECT s.id,s.title,s.remaining_lessons,c.child_name FROM subscriptions s JOIN clients c ON c.id=s.client_id WHERE s.status='active' AND s.remaining_lessons>0 AND (COALESCE(s.expires_at,'')='' OR s.expires_at>=?) ORDER BY c.child_name",(today(),)).fetchall()
        rows=c.execute("SELECT a.*,c.child_name,s.title FROM attendance a JOIN clients c ON c.id=a.client_id JOIN subscriptions s ON s.id=a.subscription_id ORDER BY a.lesson_date DESC,a.lesson_time DESC LIMIT 200").fetchall()
        trainer_rows=c.execute("SELECT name FROM trainers WHERE active=1 ORDER BY name COLLATE NOCASE").fetchall()
    options="".join(f"<option value='{r['id']}'>#{r['id']} {esc(r['child_name'])} — {esc(r['title'])} (осталось {r['remaining_lessons']})</option>" for r in subs)
    trainer_options="".join(f"<option value=\"{esc(r['name'])}\">{esc(r['name'])}</option>" for r in trainer_rows)
    form=f"""<div class="card"><h2>Записать на занятие</h2><form method="post"><label>Абонемент</label><select name="subscription_id" required>{options}</select><label>Дата</label><input type="date" name="lesson_date" value="{today()}" required><label>Время</label><input type="time" name="lesson_time" value="09:00" required><label>Тренер</label><select name="trainer" required><option value="">Выберите тренера</option>{trainer_options}</select><p class="muted">Ставка автоматически берётся из справочника тренеров и фиксируется для расчёта зарплаты.</p><button>Записать</button></form></div>"""
    table="<div class='card'><h2>Посещения</h2><div class='tablewrap'><table><tr><th>Дата</th><th>Время</th><th>Ребёнок</th><th>Абонемент</th><th>Тренер</th><th>Статус</th><th>Ставка</th><th>Действие</th></tr>"
    for r in rows:
        action=""
        if r["status"]=="planned":
            action=f"<form method='post' action='/attendance/{r['id']}/attended'><button>Посетил</button></form><form method='post' action='/attendance/{r['id']}/missed'><button class='danger'>Пропуск</button></form>"
        table+=f"<tr><td>{r['lesson_date']}</td><td>{r['lesson_time']}</td><td>{esc(r['child_name'])}</td><td>{esc(r['title'])}</td><td>{esc(r['trainer'])}</td><td>{esc(r['status'])}</td><td>{r['rate_snapshot']} ₽</td><td>{action}</td></tr>"
    return page("Посещения",form+table+"</table></div></div>")

@app.post("/attendance/<int:aid>/<status>")
@login_required
def attendance_status(aid,status):
    if status not in ("attended","missed"): abort(400)
    with connect() as c:
        a=c.execute("SELECT * FROM attendance WHERE id=?",(aid,)).fetchone()
        if not a or a["status"]!="planned": abort(400,"Занятие уже обработано")
        if a["lesson_date"]>today(): abort(400,"Нельзя списывать занятие до даты проведения")
        # Both attended and missed lessons consume one lesson under the club's current
        # policy; a manager can later restore a missed lesson through the audited
        # restoration flow. Cancellation before attendance does not consume a lesson.
        s=c.execute("SELECT * FROM subscriptions WHERE id=? AND client_id=? AND status='active' AND (COALESCE(expires_at,'')='' OR expires_at>=?)",(a["subscription_id"],a["client_id"],a["lesson_date"])).fetchone()
        if not s or s["remaining_lessons"]<1: abort(400,"Нет занятий для списания или абонемент не принадлежит этому ребёнку: срок истёк или абонемент недоступен")
        # Conditional decrement + conditional attendance transition avoid duplicate charges.
        changed=c.execute("UPDATE subscriptions SET remaining_lessons=remaining_lessons-1 WHERE id=? AND client_id=? AND status='active' AND remaining_lessons>0 AND (COALESCE(expires_at,'')='' OR expires_at>=?)",(s["id"],a["client_id"],a["lesson_date"]))
        if changed.rowcount != 1: abort(400,"Занятие уже списано или абонемент больше недоступен")
        if s["remaining_lessons"]-1==0: c.execute("UPDATE subscriptions SET status='completed' WHERE id=? AND remaining_lessons=0",(s["id"],))
        changed=c.execute("UPDATE attendance SET status=? WHERE id=? AND status='planned'",(status,aid))
        if changed.rowcount != 1: abort(400,"Занятие уже обработано")
        audit(c,"attendance."+status,"attendance",aid,{"subscription_id":a["subscription_id"],"date":a["lesson_date"]})
    return redirect(url_for("attendance"))

@app.route("/sales",methods=["GET","POST"])
@login_required
def sales():
    with connect() as c:
        if request.method=="POST":
            try: client_id=int(request.form["client_id"])
            except (ValueError, KeyError): abort(400,"Проверьте клиента")
            if not c.execute("SELECT 1 FROM clients WHERE id=?",(client_id,)).fetchone():
                abort(400,"Клиент не найден")
            loyalty_settings={r["key"]:r["value"] for r in c.execute("SELECT key,value FROM settings WHERE key LIKE 'loyalty_%'")}
            loyalty_enabled=loyalty_settings.get("loyalty_enabled","0")=="1"
            try: requested_points=int(request.form.get("redeem_points","0") or 0)
            except ValueError: abort(400,"Укажите целое количество бонусных баллов")
            if requested_points<0: abort(400,"Количество бонусных баллов не может быть отрицательным")
            item=request.form.get("item","").strip()
            wallet_raw=request.form.get("wallet_id","").strip()
            wallet_id=None
            if wallet_raw:
                try: wallet_id=int(wallet_raw)
                except ValueError: abort(400,"Выберите корректный счёт/кошелёк")
                wallet=c.execute("SELECT id,payment_method FROM cash_wallets WHERE id=? AND active=1",(wallet_id,)).fetchone()
                if not wallet: abort(400,"Счёт/кошелёк отключён или не найден")
                method=wallet["payment_method"]
            else:
                method=request.form.get("payment_method","cash")
            if len(item)>200: abort(400,"Название позиции не должно превышать 200 символов")
            product_id=request.form.get("product_id","").strip()
            sale_type=request.form.get("sale_type","manual")
            subscription_title=request.form.get("subscription_title","").strip()
            subscription_lessons=0
            if sale_type not in ("manual","subscription") or (sale_type=="subscription" and product_id): abort(400,"Выберите либо абонемент, либо товар/ручную продажу")
            if sale_type=="subscription":
                try: subscription_lessons=int(request.form.get("subscription_lessons",""))
                except ValueError: abort(400,"Укажите количество занятий в абонементе")
                if not subscription_title or len(subscription_title)>100 or subscription_lessons<1 or subscription_lessons>1000:
                    abort(400,"Для абонемента укажите название до 100 символов и от 1 до 1000 занятий")
            try: campaign_id=int(request.form.get("campaign_id") or 0)
            except ValueError: abort(400,"Неверная маркетинговая кампания")
            campaign=c.execute("SELECT id,name FROM marketing_campaigns WHERE id=? AND status IN ('draft','active','completed')",(campaign_id,)).fetchone() if campaign_id else None
            if campaign_id and not campaign: abort(400,"Кампания недоступна для привязки к продаже")
            quantity=1; unit_cost=0; profit=0
            try: discount_id=int(request.form.get("discount_id") or 0)
            except: abort(400,"Неверная скидка")
            discount=c.execute("SELECT * FROM discounts WHERE id=? AND active=1",(discount_id,)).fetchone() if discount_id else None
            if discount_id and not discount: abort(400,"Скидка недоступна")
            discount_percent=discount["percent"] if discount else 0
            if method not in ("cash","card","transfer","qr"): abort(400,"Неверный способ оплаты")
            if product_id:
                try: product_id=int(product_id); quantity=int(request.form.get("quantity","1"))
                except: abort(400,"Проверьте товар и количество")
                product=c.execute("SELECT * FROM products WHERE id=? AND active=1",(product_id,)).fetchone()
                if not product or quantity<1 or product["stock"]<quantity: abort(400,"Товар не найден или недостаточно остатка")
                item=product["name"]; gross=product["sale_price"]*quantity; amount=round(gross*(100-discount_percent)/100); unit_cost=product["purchase_price"]; profit=amount-unit_cost*quantity
                if discount: item += f" (скидка {discount_percent}%: {discount['name']})"
                c.execute("UPDATE products SET stock=stock-? WHERE id=? AND stock>=?",(quantity,product_id,quantity))
                if c.execute("SELECT changes()").fetchone()[0]!=1: abort(400,"Остаток товара изменился; повторите продажу")
                c.execute("INSERT INTO stock_movements(product_id,movement_type,quantity,unit_cost,note,created_by,created_at) VALUES(?,?,?,?,?,?,?)",(product_id,"sale",quantity,unit_cost,"Продажа",session["uid"],now()))
            else:
                try: amount=int(request.form["amount"])
                except (ValueError, KeyError): abort(400,"Проверьте сумму")
                if amount > 100_000_000: abort(400,"Сумма слишком велика; проверьте ввод")
                if sale_type=="subscription": item=f"Абонемент: {subscription_title} ({subscription_lessons} занятий)"
                if amount<=0 or (not item and sale_type!="subscription"): abort(400,"Укажите позицию и положительную сумму")
                if discount:
                    amount=round(amount*(100-discount_percent)/100)
                    item += f" (скидка {discount_percent}%: {discount['name']})"
            if amount<=0: abort(400,"После применения скидки сумма продажи должна быть больше нуля")
            gross_amount=amount
            points_balance=c.execute("SELECT COALESCE(SUM(points_delta),0) FROM loyalty_ledger WHERE client_id=?",(client_id,)).fetchone()[0]
            redemption=calculate_loyalty_redemption(
                gross_amount=gross_amount, balance=points_balance, requested_points=requested_points,
                point_value_rubles=int(loyalty_settings.get("loyalty_point_value_rubles","1")),
                max_redeem_percent=int(loyalty_settings.get("loyalty_max_redeem_percent","0")), enabled=loyalty_enabled)
            points_redeemed=redemption["points_redeemed"]
            loyalty_discount_amount=redemption["discount_amount"]
            amount=redemption["final_amount"]
            points_earned=calculate_points_earned(paid_amount=amount,points_per_100=int(loyalty_settings.get("loyalty_points_per_100","0")),enabled=loyalty_enabled)
            if points_redeemed:
                item += f" (использовано {points_redeemed} бонусных баллов)"
            if product_id:
                profit=amount-unit_cost*quantity
            cur=c.execute("INSERT INTO sales(client_id,item,amount,payment_method,status,created_by,created_at,product_id,quantity,unit_cost_snapshot,profit_snapshot,campaign_id,wallet_id,gross_amount,points_earned,points_redeemed,loyalty_discount_amount) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (client_id,item,amount,method,"completed",session["uid"],now(),product_id or None,quantity,unit_cost,profit,campaign_id or None,wallet_id,gross_amount,points_earned,points_redeemed,loyalty_discount_amount))
            if points_redeemed:
                c.execute("INSERT INTO loyalty_ledger(client_id,sale_id,entry_type,points_delta,note,created_by,created_at) VALUES(?,?,?,?,?,?,?)",
                          (client_id,cur.lastrowid,"redeem",-points_redeemed,f"Использование при продаже #{cur.lastrowid}",session["uid"],now()))
            if points_earned:
                c.execute("INSERT INTO loyalty_ledger(client_id,sale_id,entry_type,points_delta,note,created_by,created_at) VALUES(?,?,?,?,?,?,?)",
                          (client_id,cur.lastrowid,"earn",points_earned,f"Начисление за продажу #{cur.lastrowid}",session["uid"],now()))
            subscription_id=None
            if sale_type=="subscription":
                subcur=c.execute("INSERT INTO subscriptions(client_id,title,total_lessons,remaining_lessons,price,purchased_at,status,created_by) VALUES(?,?,?,?,?,?,?,?)",
                    (client_id,subscription_title,subscription_lessons,subscription_lessons,amount,today(),"active",session["uid"]))
                subscription_id=subcur.lastrowid
                c.execute("UPDATE sales SET subscription_id=? WHERE id=?",(subscription_id,cur.lastrowid))
            audit(c,"sale.created","sale",cur.lastrowid,{"client_id":client_id,"item":item,"amount":amount,"payment_method":method,"product_id":product_id or None,"quantity":quantity,"profit_snapshot":profit,"subscription_id":subscription_id,"campaign_id":campaign_id or None,"wallet_id":wallet_id,"gross_amount":gross_amount,"loyalty_discount_amount":loyalty_discount_amount,"points_redeemed":points_redeemed,"points_earned":points_earned})
            return redirect(url_for("sales"))
        clients=c.execute("SELECT cl.id,cl.child_name,COALESCE((SELECT SUM(ll.points_delta) FROM loyalty_ledger ll WHERE ll.client_id=cl.id),0) points_balance FROM clients cl ORDER BY cl.child_name").fetchall()
        rows=c.execute("SELECT s.*,c.child_name,m.name campaign_name,w.name wallet_name FROM sales s JOIN clients c ON c.id=s.client_id LEFT JOIN marketing_campaigns m ON m.id=s.campaign_id LEFT JOIN cash_wallets w ON w.id=s.wallet_id ORDER BY s.id DESC LIMIT 300").fetchall()
        loyalty_values={r["key"]:r["value"] for r in c.execute("SELECT key,value FROM settings WHERE key LIKE 'loyalty_%'")}
        products=c.execute("SELECT id,name,sale_price,stock FROM products WHERE active=1 AND stock>0 ORDER BY name").fetchall()
        discounts=c.execute("SELECT id,name,percent FROM discounts WHERE active=1 ORDER BY name").fetchall()
        campaigns=c.execute("SELECT id,name,status FROM marketing_campaigns WHERE status IN ('draft','active','completed') ORDER BY CASE status WHEN 'active' THEN 0 WHEN 'draft' THEN 1 ELSE 2 END,name").fetchall()
        wallets=c.execute("SELECT id,name,payment_method FROM cash_wallets WHERE active=1 ORDER BY name COLLATE NOCASE").fetchall()
    default_wallet_id=next((r["id"] for r in wallets if r["payment_method"]=="cash"), wallets[0]["id"] if wallets else 0)
    wallet_opts="".join(f"<option value='{r['id']}' {'selected' if r['id']==default_wallet_id else ''}>{esc(r['name'])} · { {'cash':'наличные','card':'карта','transfer':'перевод','qr':'QR'}[r['payment_method']] }</option>" for r in wallets)
    campaign_opts="<option value='0'>Без кампании</option>"+"".join(f"<option value='{r['id']}'>{esc(r['name'])} — {r['status']}</option>" for r in campaigns)
    discount_opts="".join(f"<option value='{r['id']}'>{esc(r['name'])} — {r['percent']}%</option>" for r in discounts)
    product_opts="".join(f"<option value='{r['id']}'>{esc(r['name'])} — {r['sale_price']} ₽/шт. (остаток {r['stock']})</option>" for r in products)
    loyalty_enabled=loyalty_values.get("loyalty_enabled","0")=="1"
    if loyalty_enabled:
        opts="".join(f"<option value='{r['id']}' data-points='{r['points_balance']}'>{esc(r['child_name'])} · {r['points_balance']} баллов</option>" for r in clients)
        if int(loyalty_values.get("loyalty_max_redeem_percent","0")) > 0:
            loyalty_form=f"<div class='card'><h3>Бонусная программа</h3><p class='muted'>Баланс выбранного клиента отображается в списке. Списание ограничено настройкой программы и проверяется сервером.</p><label>Списать баллы</label><input name='redeem_points' type='number' min='0' value='0'><p>Баланс клиента: <strong id='sale-points-balance'>0</strong> баллов</p></div><script>document.addEventListener('DOMContentLoaded',function(){{const c=document.querySelector('select[name=client_id]');const b=document.getElementById('sale-points-balance');function sync(){{if(c&&b){{b.textContent=c.options[c.selectedIndex]?.dataset.points||'0';}}}}if(c){{c.addEventListener('change',sync);sync();}}}});</script>"
        else:
            loyalty_form="<p class='muted'>Начисление включено по настройке. Списание баллов выключено: установите максимальный процент оплаты баллами в настройках программы.</p>"
    else:
        opts="".join(f"<option value='{r['id']}'>{esc(r['child_name'])}</option>" for r in clients)
        loyalty_form="<p class='muted'>Бонусная программа отключена руководителем; продажа не начисляет и не списывает баллы.</p>"
    form=f"""<div class="card"><h2>Новая продажа</h2><form method="post"><label>Клиент</label><select name="client_id" required>{opts}</select>{loyalty_form}<label>Тип продажи</label><select name="sale_type"><option value="manual">Разовая / прочая продажа</option><option value="subscription">Продажа абонемента</option></select><p class="muted">Для продажи абонемента заполни название и количество занятий; программа создаст абонемент и финансовую запись вместе.</p><label>Название абонемента (для продажи абонемента)</label><input name="subscription_title" placeholder="Например, 8 занятий"><label>Количество занятий в абонементе</label><input name="subscription_lessons" type="number" min="1" value="8"><label>Товар со склада (необязательно; только для обычной продажи)</label><select name="product_id"><option value="">Не со склада — ручная продажа</option>{product_opts}</select><label>Количество товара</label><input name="quantity" type="number" min="1" value="1"><label>Маркетинговая кампания (если продажа связана с акцией)</label><select name="campaign_id">{campaign_opts}</select><label>Утверждённая скидка</label><select name="discount_id"><option value="">Без скидки</option>{discount_opts}</select><label>Или позиция вручную</label><input name="item"><label>Сумма вручную, ₽ (цена абонемента — полная сумма продажи)</label><input name="amount" type="number" min="1"><label>Счёт/кошелёк</label><select name="wallet_id" required>{wallet_opts}</select><button>Провести продажу</button></form></div>"""
    table="<div class='card'><h2>Продажи</h2><div class='tablewrap'><table><tr><th>№</th><th>Клиент</th><th>Позиция</th><th>Сумма</th><th>Баллы +/−</th><th>Счёт/кошелёк</th><th>Кампания</th><th>Статус</th></tr>"
    for r in rows: table+=f"<tr><td>{r['id']}</td><td>{esc(r['child_name'])}</td><td>{esc(r['item'])}</td><td>{r['amount']} ₽</td><td>+{r['points_earned']} / −{r['points_redeemed']}</td><td>{esc(r['wallet_name'] or 'Не назначен')} · {esc(r['payment_method'])}</td><td>{esc(r['campaign_name'] or '—')}</td><td>{esc(r['status'])}</td></tr>"
    return page("Продажи",form+table+"</table></div></div>")

@app.route("/refunds",methods=["GET","POST"])
@login_required
def refunds():
    with connect() as c:
        actor=c.execute("SELECT role,active FROM users WHERE id=?",(session.get("uid"),)).fetchone()
        if not actor or not actor["active"]:
            session.clear()
            return redirect(url_for("login"))
        is_manager = actor["role"] == "manager"
        if request.method=="POST":
            # Serialize refund decisions and duplicate-request checks. Without an
            # immediate write lock, two administrators could both pass the
            # existence check before either request is committed.
            c.execute("BEGIN IMMEDIATE")
            action=request.form.get("action")
            if action=="request":
                try: sale_id=int(request.form["sale_id"])
                except: abort(400)
                reason=request.form.get("reason","").strip()
                sale=c.execute("SELECT * FROM sales WHERE id=? AND status='completed'",(sale_id,)).fetchone()
                if not sale or not reason: abort(400,"Продажа не найдена или не указана причина")
                existing=c.execute("SELECT id,status FROM refund_requests WHERE sale_id=? AND status IN ('pending','approved') ORDER BY id DESC LIMIT 1",(sale_id,)).fetchone()
                if existing:
                    if existing["status"]=="approved": abort(400,"Возврат по этой продаже уже одобрен")
                    abort(400,"По этой продаже уже есть ожидающий запрос возврата")
                cur=c.execute("INSERT INTO refund_requests(sale_id,reason,requested_by,created_at) VALUES(?,?,?,?)",(sale_id,reason,session["uid"],now()))
                audit(c,"refund.requested","refund_request",cur.lastrowid,{"sale_id":sale_id,"reason":reason})
            elif action=="approve":
                # Use the role from the database, never a potentially stale session role.
                if not is_manager: abort(403,"Только руководитель может подтверждать возвраты")
                try: rid=int(request.form["request_id"])
                except: abort(400)
                req=c.execute("SELECT * FROM refund_requests WHERE id=? AND status='pending'",(rid,)).fetchone()
                if not req: abort(400,"Запрос уже обработан или не найден")
                already_refunded=c.execute("SELECT 1 FROM refund_requests WHERE sale_id=? AND status='approved' LIMIT 1",(req["sale_id"],)).fetchone()
                linked_refund=c.execute("SELECT 1 FROM sales WHERE original_sale_id=? AND status='refund' LIMIT 1",(req["sale_id"],)).fetchone()
                if already_refunded or linked_refund:
                    abort(400,"По этой продаже уже есть одобренный или проведённый возврат; нужна ручная сверка")
                sale=c.execute("SELECT * FROM sales WHERE id=? AND status='completed'",(req["sale_id"],)).fetchone()
                if not sale: abort(400,"Продажа уже возвращена или недоступна")
                # Subscription refund is permitted only if all lessons remain unused.
                if sale["subscription_id"]:
                    sub=c.execute("SELECT * FROM subscriptions WHERE id=?",(sale["subscription_id"],)).fetchone()
                    if not sub or sub["remaining_lessons"]!=sub["total_lessons"] or sub["status"]!="active":
                        abort(400,"Абонемент уже использовался или закрыт: автоматический полный возврат запрещён, требуется ручная сверка")
                    c.execute("UPDATE subscriptions SET status='cancelled' WHERE id=?",(sub["id"],))
                # Do not delete or edit the original sale: create a compensating record.
                cur=c.execute("INSERT INTO sales(client_id,item,amount,payment_method,status,created_by,created_at,product_id,quantity,unit_cost_snapshot,profit_snapshot,original_sale_id,wallet_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (sale["client_id"],"ВОЗВРАТ: "+sale["item"],sale["amount"],sale["payment_method"],"refund",session["uid"],now(),sale["product_id"],sale["quantity"],sale["unit_cost_snapshot"],-sale["profit_snapshot"],sale["id"],sale["wallet_id"]))
                if sale["points_earned"]:
                    c.execute("INSERT INTO loyalty_ledger(client_id,sale_id,entry_type,points_delta,note,created_by,created_at) VALUES(?,?,?,?,?,?,?)",
                              (sale["client_id"],sale["id"],"refund_earn_reversal",-sale["points_earned"],f"Отмена бонусов по возврату продажи #{sale['id']}",session["uid"],now()))
                if sale["points_redeemed"]:
                    c.execute("INSERT INTO loyalty_ledger(client_id,sale_id,entry_type,points_delta,note,created_by,created_at) VALUES(?,?,?,?,?,?,?)",
                              (sale["client_id"],sale["id"],"refund_redeem_restore",sale["points_redeemed"],f"Возврат использованных баллов по продаже #{sale['id']}",session["uid"],now()))
                if sale["product_id"]:
                    c.execute("UPDATE products SET stock=stock+? WHERE id=?",(sale["quantity"],sale["product_id"]))
                    c.execute("INSERT INTO stock_movements(product_id,movement_type,quantity,unit_cost,note,created_by,created_at) VALUES(?,?,?,?,?,?,?)",
                        (sale["product_id"],"adjustment",sale["quantity"],sale["unit_cost_snapshot"],f"Возврат по продаже #{sale['id']}",session["uid"],now()))
                c.execute("UPDATE refund_requests SET status='approved',approved_by=?,resolved_at=? WHERE id=?",(session["uid"],now(),rid))
                audit(c,"refund.approved","sale",cur.lastrowid,{"original_sale_id":sale["id"],"request_id":rid,"amount":sale["amount"]})
            elif action=="reject":
                if not is_manager: abort(403,"Только руководитель может отклонять возвраты")
                try: rid=int(request.form["request_id"])
                except (ValueError, KeyError): abort(400,"Не указан запрос возврата")
                req=c.execute("SELECT * FROM refund_requests WHERE id=? AND status='pending'",(rid,)).fetchone()
                if not req: abort(400,"Запрос уже обработан или не найден")
                c.execute("UPDATE refund_requests SET status='rejected',approved_by=?,resolved_at=? WHERE id=? AND status='pending'",(session["uid"],now(),rid))
                if c.execute("SELECT changes()").fetchone()[0] != 1:
                    abort(400,"Запрос уже обработан; обновите страницу")
                audit(c,"refund.rejected","refund_request",rid,{"sale_id":req["sale_id"],"reason":req["reason"]})
            else: abort(400,"Неизвестное действие")
            return redirect(url_for("refunds"))
        sales=c.execute("SELECT id,item,amount FROM sales WHERE status='completed' ORDER BY id DESC").fetchall()
        rows=c.execute("SELECT r.*,s.item,s.amount,s.id sale_id FROM refund_requests r JOIN sales s ON s.id=r.sale_id ORDER BY r.id DESC").fetchall()
    opts="".join(f"<option value='{r['id']}'>#{r['id']} — {esc(r['item'])}, {r['amount']} ₽</option>" for r in sales)
    form=f"""<div class="card"><h2>Запрос возврата</h2><form method="post"><input type="hidden" name="action" value="request"><label>Исходная продажа</label><select name="sale_id" required>{opts}</select><label>Причина</label><textarea name="reason" required></textarea><button>Отправить руководителю</button></form><p class="muted">Запрос не меняет баланс, продажу или абонемент до решения руководителя.</p></div>"""
    table="<div class='card'><h2>Запросы</h2><div class='tablewrap'><table><tr><th>Запрос</th><th>Продажа</th><th>Причина</th><th>Статус</th><th>Действие</th></tr>"
    for r in rows:
        action=""
        if is_manager and r["status"]=="pending":
            action=f"<form method='post'><input type='hidden' name='action' value='approve'><input type='hidden' name='request_id' value='{r['id']}'><button>Одобрить</button></form><form method='post'><input type='hidden' name='action' value='reject'><input type='hidden' name='request_id' value='{r['id']}'><button class='danger'>Отклонить</button></form>"
        table+=f"<tr><td>#{r['id']}</td><td>#{r['sale_id']} {esc(r['item'])} ({r['amount']} ₽)</td><td>{esc(r['reason'])}</td><td>{esc(r['status'])}</td><td>{action}</td></tr>"
    return page("Возвраты",form+table+"</table></div></div>")

@app.get("/settings")
@manager_required
def settings():
    with connect() as c:
        vals={r["key"]:r["value"] for r in c.execute("SELECT * FROM settings")}
        users=c.execute("SELECT id,username,role,active FROM users ORDER BY id").fetchall()
    body=f"""<div class="card"><h2>Настройки ставок</h2><p>Справочные ставки для новых записей. Зарплата рассчитывается по фактически отмеченным занятиям и сохранённой ставке каждого посещения.</p><form method="post" action="/settings/rates"><label>Индивидуальное занятие, ₽</label><input type="number" name="individual_rate" min="0" value="{esc(vals.get('individual_rate','400'))}"><label>Групповое занятие на ребёнка, ₽</label><input type="number" name="group_rate" min="0" value="{esc(vals.get('group_rate','270'))}"><button>Сохранить ставки</button></form></div>"""
    body+="<div class='card'><h2>Учётные записи</h2><p>Создавайте администраторов и временно отключайте доступ сотрудникам. Роль руководителя из этой формы не выдаётся.</p>"
    body+="<h3>Добавить администратора</h3><form method='post' action='/settings/users'><input type='hidden' name='action' value='create'><label>Логин</label><input name='username' required minlength='3' maxlength='40' pattern='[A-Za-z0-9_.-]+' autocomplete='off'><label>Временный пароль (от 12 символов)</label><input type='password' name='password' required minlength='12' maxlength='256' autocomplete='new-password'><button>Создать администратора</button></form><div class='tablewrap'><table><tr><th>Логин</th><th>Роль</th><th>Активен</th><th>Действие</th></tr>"
    for u in users:
        action="Текущая учётная запись" if int(u['id'])==int(session['uid']) else f"<form method='post' action='/settings/users'><input type='hidden' name='action' value='toggle'><input type='hidden' name='user_id' value='{u['id']}'><button class='{ 'danger' if u['active'] else '' }'>{'Отключить' if u['active'] else 'Включить'}</button></form>"
        body+=f"<tr><td>{esc(u['username'])}</td><td>{'Руководитель' if u['role']=='manager' else 'Администратор'}</td><td>{'Да' if u['active'] else 'Нет'}</td><td>{action}</td></tr>"
    return page("Настройки",body+"</table></div></div>")

@app.post("/settings/users")
@manager_required
def manage_users_page():
    action=request.form.get("action","")
    with connect() as c:
        c.execute("BEGIN IMMEDIATE")
        if action=="create":
            try:
                username=validate_new_admin(request.form.get("username",""),request.form.get("password",""))
            except ValueError as exc:
                abort(400,str(exc))
            try:
                cur=c.execute("INSERT INTO users(username,password_hash,role,active,created_at) VALUES(?,?, 'admin',1,?)",
                              (username,generate_password_hash(request.form.get("password","")),now()))
            except sqlite3.IntegrityError:
                abort(400,"Такой логин уже существует")
            audit(c,"user.created","user",cur.lastrowid,{"username":username,"role":"admin"})
        elif action=="toggle":
            try: user_id=int(request.form.get("user_id",""))
            except ValueError: abort(400,"Неверная учётная запись")
            target=c.execute("SELECT id,username,role,active FROM users WHERE id=?",(user_id,)).fetchone()
            if not target: abort(404,"Учётная запись не найдена")
            if user_id==int(session["uid"]): abort(400,"Нельзя отключить собственную учётную запись из текущего сеанса")
            new_active=0 if target["active"] else 1
            if not new_active and target["role"]=="manager":
                active_managers=c.execute("SELECT COUNT(*) n FROM users WHERE role='manager' AND active=1").fetchone()["n"]
                if active_managers<=1: abort(400,"Нельзя отключить последнюю активную учётную запись руководителя")
            c.execute("UPDATE users SET active=?,auth_version=auth_version+1 WHERE id=?",(new_active,user_id))
            audit(c,"user.activated" if new_active else "user.deactivated","user",user_id,{"username":target["username"],"active":bool(new_active)})
        else:
            abort(400,"Неизвестное действие")
    return redirect(url_for("settings"))

@app.post("/settings/rates")
@manager_required
def save_rates():
    try: individual=int(request.form["individual_rate"]); group=int(request.form["group_rate"])
    except: abort(400,"Ставки должны быть числами")
    if individual<0 or group<0: abort(400,"Ставка не может быть отрицательной")
    with connect() as c:
        for k,v in [("individual_rate",individual),("group_rate",group)]:
            old=c.execute("SELECT value FROM settings WHERE key=?",(k,)).fetchone()
            c.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(k,str(v)))
            audit(c,"settings.changed","setting",None,{"key":k,"old":old["value"] if old else None,"new":v})
    return redirect(url_for("settings"))





@app.route("/income-categories", methods=["GET", "POST"])
@manager_required
def income_categories_page():
    if request.method == "POST":
        action=request.form.get("action","create")
        try:
            with connect() as c:
                c.execute("BEGIN IMMEDIATE")
                if action == "create":
                    name=normalize_expense_category(request.form.get("name"))
                    if c.execute("SELECT 1 FROM cash_income_categories WHERE name=? COLLATE NOCASE",(name,)).fetchone(): abort(400,"Категория с таким названием уже существует")
                    cur=c.execute("INSERT INTO cash_income_categories(name,active,created_at) VALUES(?,1,?)",(name,now()))
                    audit(c,"cash.income_category.created","cash_income_category",cur.lastrowid,{"name":name})
                elif action == "edit":
                    try: category_id=int(request.form.get("category_id",""))
                    except ValueError: abort(400,"Неверная категория")
                    category=c.execute("SELECT * FROM cash_income_categories WHERE id=?",(category_id,)).fetchone()
                    if not category: abort(404,"Категория не найдена")
                    name=normalize_expense_category(request.form.get("name"))
                    if c.execute("SELECT 1 FROM cash_income_categories WHERE name=? COLLATE NOCASE AND id<>?",(name,category_id)).fetchone(): abort(400,"Категория с таким названием уже существует")
                    c.execute("UPDATE cash_income_categories SET name=? WHERE id=?",(name,category_id))
                    audit(c,"cash.income_category.updated","cash_income_category",category_id,{"old_name":category["name"],"new_name":name})
                elif action == "toggle":
                    try: category_id=int(request.form.get("category_id",""))
                    except ValueError: abort(400,"Неверная категория")
                    category=c.execute("SELECT * FROM cash_income_categories WHERE id=?",(category_id,)).fetchone()
                    if not category: abort(404,"Категория не найдена")
                    active=0 if category["active"] else 1
                    if not active and c.execute("SELECT COUNT(*) FROM cash_income_categories WHERE active=1").fetchone()[0]<=1: abort(400,"Нельзя отключить последнюю активную категорию")
                    c.execute("UPDATE cash_income_categories SET active=? WHERE id=?",(active,category_id))
                    audit(c,"cash.income_category.activated" if active else "cash.income_category.deactivated","cash_income_category",category_id,{"active":bool(active)})
                else: abort(400,"Неизвестное действие с категорией")
        except ValueError as exc: abort(400,str(exc))
        return redirect(url_for("income_categories_page"))
    with connect() as c:
        rows=c.execute("SELECT cat.*,COUNT(i.id) usage_count,COALESCE(SUM(i.amount),0) amount FROM cash_income_categories cat LEFT JOIN cash_other_income i ON i.category_id=cat.id GROUP BY cat.id ORDER BY cat.active DESC,cat.name COLLATE NOCASE").fetchall()
    body="<div class='card'><h2>Добавить категорию поступления</h2><p class='muted'>Прочие поступления не создают продажи и не меняют абонементы.</p><form method='post'><input type='hidden' name='action' value='create'><label>Название категории</label><input name='name' maxlength='100' required><button>Добавить категорию</button></form></div><div class='card'><h2>Категории поступлений</h2><div class='tablewrap'><table><tr><th>Название</th><th>Операций</th><th>Сумма</th><th>Статус</th><th>Действия</th></tr>"
    for r in rows: body+=f"<tr><td><form method='post' style='display:flex;gap:8px'><input type='hidden' name='action' value='edit'><input type='hidden' name='category_id' value='{r['id']}'><input name='name' value='{esc(r['name'])}' maxlength='100' required><button>Переименовать</button></form></td><td>{r['usage_count']}</td><td>{r['amount']:,} ₽</td><td>{'Активна' if r['active'] else 'Отключена'}</td><td><form method='post'><input type='hidden' name='action' value='toggle'><input type='hidden' name='category_id' value='{r['id']}'><button>{'Отключить' if r['active'] else 'Включить'}</button></form></td></tr>"
    return page("Категории поступлений",body+"</table></div></div>")


@app.route("/loyalty", methods=["GET", "POST"])
@manager_required
def loyalty_page():
    if request.method == "POST":
        action=request.form.get("action","settings")
        try:
            with connect() as c:
                c.execute("BEGIN IMMEDIATE")
                if action == "settings":
                    values=normalize_loyalty_settings(request.form.get("enabled","0"),request.form.get("points_per_100","0"),request.form.get("point_value_rubles","1"),request.form.get("max_redeem_percent","0"))
                    old={r["key"]:r["value"] for r in c.execute("SELECT key,value FROM settings WHERE key LIKE 'loyalty_%'")}
                    new_values={"loyalty_enabled":str(values["enabled"]),"loyalty_points_per_100":str(values["points_per_100"]),"loyalty_point_value_rubles":str(values["point_value_rubles"]),"loyalty_max_redeem_percent":str(values["max_redeem_percent"])}
                    for key,value in new_values.items(): c.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(key,value))
                    audit(c,"loyalty.settings.updated","loyalty_settings",None,{"old":old,"new":new_values})
                elif action == "adjust":
                    try: client_id=int(request.form.get("client_id","")); delta=int(request.form.get("points_delta",""))
                    except ValueError: abort(400,"Выберите клиента и укажите целое количество баллов")
                    reason=request.form.get("reason","").strip()
                    if delta==0 or abs(delta)>100000 or not reason or len(reason)>200:
                        abort(400,"Корректировка должна быть от −100 000 до 100 000 баллов, с указанием причины")
                    if not c.execute("SELECT 1 FROM clients WHERE id=?",(client_id,)).fetchone(): abort(400,"Клиент не найден")
                    cur=c.execute("INSERT INTO loyalty_ledger(client_id,sale_id,entry_type,points_delta,note,created_by,created_at) VALUES(?,NULL,'adjustment',?,?,?,?)",(client_id,delta,reason,session["uid"],now()))
                    audit(c,"loyalty.adjustment","loyalty_entry",cur.lastrowid,{"client_id":client_id,"points_delta":delta,"reason":reason})
                else:
                    abort(400,"Неизвестное действие бонусной программы")
        except ValueError as exc:
            abort(400,str(exc))
        return redirect(url_for("loyalty_page"))
    with connect() as c:
        values={r["key"]:r["value"] for r in c.execute("SELECT key,value FROM settings WHERE key LIKE 'loyalty_%'")}
        clients=c.execute("SELECT cl.id,cl.child_name,cl.parent_name,cl.phone,COALESCE((SELECT SUM(ll.points_delta) FROM loyalty_ledger ll WHERE ll.client_id=cl.id),0) points_balance FROM clients cl ORDER BY cl.child_name").fetchall()
        ledger=c.execute("SELECT ll.*,cl.child_name,cl.parent_name,u.username FROM loyalty_ledger ll JOIN clients cl ON cl.id=ll.client_id LEFT JOIN users u ON u.id=ll.created_by ORDER BY ll.id DESC LIMIT 300").fetchall()
    client_opts="".join(f"<option value='{r['id']}'>{esc(r['child_name'])} — {esc(r['parent_name'])} ({r['points_balance']} баллов)</option>" for r in clients)
    enabled=values.get("loyalty_enabled","0")=="1"
    body=f"""<div class='card'><h2>Настройки бонусной программы</h2><p class='muted'>Программа по умолчанию выключена. Пока её не включили и не задали правила, продажи не начисляют и не списывают баллы. Старые продажи не пересчитываются.</p><form method='post'><input type='hidden' name='action' value='settings'><label>Статус</label><select name='enabled'><option value='0' {'selected' if not enabled else ''}>Выключена</option><option value='1' {'selected' if enabled else ''}>Включена</option></select><label>Начислять баллов за каждые 100 ₽ фактической оплаты</label><input type='number' name='points_per_100' min='0' max='10000' value='{esc(values.get('loyalty_points_per_100','0'))}' required><label>Сколько рублей скидки даёт 1 балл</label><input type='number' name='point_value_rubles' min='1' max='100000' value='{esc(values.get('loyalty_point_value_rubles','1'))}' required><label>Максимальная доля оплаты баллами, % (0 — списание выключено)</label><input type='number' name='max_redeem_percent' min='0' max='100' value='{esc(values.get('loyalty_max_redeem_percent','0'))}' required><button>Сохранить правила</button></form></div>"""
    body+=f"""<div class='card'><h2>Ручная корректировка баллов</h2><p class='muted'>Используйте для исправления баланса с обязательным комментарием. Корректировка не создаёт продажу или платёж.</p><form method='post'><input type='hidden' name='action' value='adjust'><label>Клиент</label><select name='client_id' required>{client_opts}</select><label>Изменение баллов (может быть отрицательным)</label><input type='number' name='points_delta' min='-100000' max='100000' required><label>Причина</label><input name='reason' maxlength='200' required><button>Записать корректировку</button></form></div>"""
    body+="<div class='card'><h2>Баланс клиентов</h2><div class='tablewrap'><table><tr><th>Клиент</th><th>Телефон</th><th>Баланс баллов</th></tr>"
    for r in clients: body+=f"<tr><td><a href='/client/{r['id']}'>{esc(r['child_name'])}</a><br>{esc(r['parent_name'])}</td><td>{esc(r['phone'])}</td><td><strong>{r['points_balance']}</strong></td></tr>"
    if not clients: body+="<tr><td colspan='3'>Клиентов пока нет.</td></tr>"
    body+="</table></div></div><div class='card'><h2>История бонусных операций</h2><div class='tablewrap'><table><tr><th>Время</th><th>Клиент</th><th>Тип</th><th>Баллы</th><th>Комментарий</th><th>Сотрудник</th></tr>"
    labels={"earn":"Начисление","redeem":"Списание при продаже","refund_earn_reversal":"Отмена начисления при возврате","refund_redeem_restore":"Возврат использованных баллов","adjustment":"Ручная корректировка"}
    for r in ledger: body+=f"<tr><td>{esc(r['created_at'])}</td><td>{esc(r['child_name'])} · {esc(r['parent_name'])}</td><td>{labels.get(r['entry_type'],esc(r['entry_type']))}</td><td>{r['points_delta']:+d}</td><td>{esc(r['note'])}</td><td>{esc(r['username'] or '—')}</td></tr>"
    if not ledger: body+="<tr><td colspan='6'>Бонусных операций пока нет.</td></tr>"
    return page("Бонусная программа",body+"</table></div></div>")


@app.route("/expense-categories", methods=["GET", "POST"])
@manager_required
def expense_categories_page():
    if request.method == "POST":
        action=request.form.get("action","create")
        try:
            with connect() as c:
                c.execute("BEGIN IMMEDIATE")
                if action == "create":
                    name=normalize_expense_category(request.form.get("name"))
                    if c.execute("SELECT 1 FROM cash_expense_categories WHERE name=? COLLATE NOCASE",(name,)).fetchone():
                        abort(400,"Категория с таким названием уже существует")
                    cur=c.execute("INSERT INTO cash_expense_categories(name,active,created_at) VALUES(?,1,?)",(name,now()))
                    audit(c,"cash.expense_category.created","cash_expense_category",cur.lastrowid,{"name":name})
                elif action == "edit":
                    try: category_id=int(request.form.get("category_id",""))
                    except ValueError: abort(400,"Неверная категория")
                    category=c.execute("SELECT * FROM cash_expense_categories WHERE id=?",(category_id,)).fetchone()
                    if not category: abort(404,"Категория не найдена")
                    name=normalize_expense_category(request.form.get("name"))
                    if c.execute("SELECT 1 FROM cash_expense_categories WHERE name=? COLLATE NOCASE AND id<>?",(name,category_id)).fetchone():
                        abort(400,"Категория с таким названием уже существует")
                    c.execute("UPDATE cash_expense_categories SET name=? WHERE id=?",(name,category_id))
                    audit(c,"cash.expense_category.updated","cash_expense_category",category_id,{"old_name":category["name"],"new_name":name})
                elif action == "toggle":
                    try: category_id=int(request.form.get("category_id",""))
                    except ValueError: abort(400,"Неверная категория")
                    category=c.execute("SELECT * FROM cash_expense_categories WHERE id=?",(category_id,)).fetchone()
                    if not category: abort(404,"Категория не найдена")
                    active=0 if category["active"] else 1
                    if not active and c.execute("SELECT COUNT(*) FROM cash_expense_categories WHERE active=1").fetchone()[0]<=1:
                        abort(400,"Нельзя отключить последнюю активную категорию")
                    c.execute("UPDATE cash_expense_categories SET active=? WHERE id=?",(active,category_id))
                    audit(c,"cash.expense_category.activated" if active else "cash.expense_category.deactivated","cash_expense_category",category_id,{"active":bool(active)})
                else:
                    abort(400,"Неизвестное действие с категорией")
        except ValueError as exc:
            abort(400,str(exc))
        return redirect(url_for("expense_categories_page"))
    with connect() as c:
        rows=c.execute("SELECT cat.*,COUNT(e.id) usage_count,COALESCE(SUM(e.amount),0) amount FROM cash_expense_categories cat LEFT JOIN cash_expenses e ON e.category_id=cat.id GROUP BY cat.id ORDER BY cat.active DESC,cat.name COLLATE NOCASE").fetchall()
    body="<div class='card'><h2>Добавить категорию расхода</h2><p class='muted'>Категории используются для отчётов по расходам. Старые расходы без категории остаются без категории; автоматического распределения нет.</p><form method='post'><input type='hidden' name='action' value='create'><label>Название категории</label><input name='name' maxlength='100' required><button>Добавить категорию</button></form></div><div class='card'><h2>Категории расходов</h2><div class='tablewrap'><table><tr><th>Название</th><th>Расходов</th><th>Сумма</th><th>Статус</th><th>Действия</th></tr>"
    for r in rows:
        body+=f"<tr><td><form method='post' style='display:flex;gap:8px'><input type='hidden' name='action' value='edit'><input type='hidden' name='category_id' value='{r['id']}'><input name='name' value='{esc(r['name'])}' maxlength='100' required><button>Переименовать</button></form></td><td>{r['usage_count']}</td><td>{r['amount']:,} ₽</td><td>{'Активна' if r['active'] else 'Отключена'}</td><td><form method='post'><input type='hidden' name='action' value='toggle'><input type='hidden' name='category_id' value='{r['id']}'><button>{'Отключить' if r['active'] else 'Включить'}</button></form></td></tr>"
    body+="</table></div></div>"
    return page("Категории расходов",body)


@app.route("/wallets", methods=["GET", "POST"])
@manager_required
def wallets_page():
    if request.method == "POST":
        action = request.form.get("action", "create")
        try:
            with connect() as c:
                c.execute("BEGIN IMMEDIATE")
                if action == "create":
                    values = normalize_wallet(request.form.get("name"), request.form.get("payment_method"), request.form.get("opening_balance", "0"))
                    duplicate = c.execute("SELECT id FROM cash_wallets WHERE name=? COLLATE NOCASE LIMIT 1", (values["name"],)).fetchone()
                    if duplicate:
                        abort(400, "Счёт/кошелёк с таким названием уже существует")
                    cur = c.execute("INSERT INTO cash_wallets(name,payment_method,opening_balance,active,created_at) VALUES(?,?,?,1,?)",
                                    (values["name"], values["payment_method"], values["opening_balance"], now()))
                    audit(c, "wallet.created", "cash_wallet", cur.lastrowid, values)
                elif action == "edit":
                    try: wallet_id = int(request.form.get("wallet_id", ""))
                    except ValueError: abort(400, "Неверный счёт/кошелёк")
                    wallet = c.execute("SELECT * FROM cash_wallets WHERE id=?", (wallet_id,)).fetchone()
                    if not wallet: abort(404, "Счёт/кошелёк не найден")
                    has_operations = c.execute("""SELECT 1 FROM sales WHERE wallet_id=? UNION ALL
                        SELECT 1 FROM cash_expenses WHERE wallet_id=? UNION ALL
                        SELECT 1 FROM wallet_transfers WHERE from_wallet_id=? OR to_wallet_id=? LIMIT 1""",
                        (wallet_id, wallet_id, wallet_id, wallet_id)).fetchone()
                    if has_operations:
                        abort(400, "Название и категорию нельзя менять после первой операции по счёту")
                    values = normalize_wallet(request.form.get("name"), request.form.get("payment_method"), wallet["opening_balance"])
                    duplicate = c.execute("SELECT id FROM cash_wallets WHERE name=? COLLATE NOCASE AND id<>? LIMIT 1", (values["name"], wallet_id)).fetchone()
                    if duplicate: abort(400, "Счёт/кошелёк с таким названием уже существует")
                    c.execute("UPDATE cash_wallets SET name=?,payment_method=? WHERE id=?", (values["name"], values["payment_method"], wallet_id))
                    audit(c, "wallet.updated", "cash_wallet", wallet_id, {"old_name": wallet["name"], "new_name": values["name"], "old_payment_method": wallet["payment_method"], "new_payment_method": values["payment_method"]})
                elif action == "opening":
                    try:
                        wallet_id = int(request.form.get("wallet_id", ""))
                        opening_balance = int(request.form.get("opening_balance", ""))
                    except ValueError:
                        abort(400, "Укажите счёт и начальный остаток")
                    if opening_balance < 0 or opening_balance > 1_000_000_000:
                        abort(400, "Начальный остаток должен быть от 0 до 1 000 000 000 ₽")
                    wallet = c.execute("SELECT * FROM cash_wallets WHERE id=?", (wallet_id,)).fetchone()
                    if not wallet: abort(404, "Счёт/кошелёк не найден")
                    has_operations = c.execute("""SELECT 1 FROM sales WHERE wallet_id=? UNION ALL
                        SELECT 1 FROM cash_expenses WHERE wallet_id=? UNION ALL
                        SELECT 1 FROM wallet_transfers WHERE from_wallet_id=? OR to_wallet_id=? LIMIT 1""",
                        (wallet_id, wallet_id, wallet_id, wallet_id)).fetchone()
                    if has_operations:
                        abort(400, "Начальный остаток нельзя менять после первой операции по счёту; оформите перевод/корректировку отдельно")
                    c.execute("UPDATE cash_wallets SET opening_balance=? WHERE id=?", (opening_balance, wallet_id))
                    audit(c, "wallet.opening.updated", "cash_wallet", wallet_id, {"old": wallet["opening_balance"], "new": opening_balance})
                elif action == "toggle":
                    try: wallet_id = int(request.form.get("wallet_id", ""))
                    except ValueError: abort(400, "Неверный счёт/кошелёк")
                    wallet = c.execute("SELECT * FROM cash_wallets WHERE id=?", (wallet_id,)).fetchone()
                    if not wallet: abort(404, "Счёт/кошелёк не найден")
                    new_active = 0 if wallet["active"] else 1
                    if not new_active and c.execute("SELECT COUNT(*) FROM cash_wallets WHERE active=1").fetchone()[0] <= 1:
                        abort(400, "Нельзя отключить последний активный счёт/кошелёк")
                    if not new_active:
                        current = next((r for r in wallet_balance_rows(c) if r["id"] == wallet_id), None)
                        if current and current["balance"] != 0:
                            abort(400, "Перед отключением переведите остаток на другой счёт; история останется сохранена")
                    c.execute("UPDATE cash_wallets SET active=? WHERE id=?", (new_active, wallet_id))
                    audit(c, "wallet.activated" if new_active else "wallet.deactivated", "cash_wallet", wallet_id, {"active": bool(new_active)})
                elif action == "transfer":
                    values = normalize_wallet_transfer(request.form.get("from_wallet_id"), request.form.get("to_wallet_id"), request.form.get("amount"), request.form.get("note"))
                    from_wallet = c.execute("SELECT * FROM cash_wallets WHERE id=? AND active=1", (values["from_wallet_id"],)).fetchone()
                    to_wallet = c.execute("SELECT * FROM cash_wallets WHERE id=? AND active=1", (values["to_wallet_id"],)).fetchone()
                    if not from_wallet or not to_wallet:
                        abort(400, "Оба счёта должны существовать и быть активными")
                    current = next((r for r in wallet_balance_rows(c) if r["id"] == values["from_wallet_id"]), None)
                    if not current or current["balance"] < values["amount"]:
                        abort(400, "Недостаточно средств на счёте-источнике")
                    cur = c.execute("INSERT INTO wallet_transfers(from_wallet_id,to_wallet_id,amount,note,created_by,created_at) VALUES(?,?,?,?,?,?)",
                                    (values["from_wallet_id"], values["to_wallet_id"], values["amount"], values["note"], session["uid"], now()))
                    audit(c, "wallet.transfer", "wallet_transfer", cur.lastrowid, values)
                else:
                    abort(400, "Неизвестное действие со счётом")
        except ValueError as exc:
            abort(400, str(exc))
        return redirect(url_for("wallets_page"))
    with connect() as c:
        wallets = wallet_balance_rows(c)
        legacy = unassigned_legacy_totals(c)
        transfers = c.execute("SELECT t.*,fw.name from_name,tw.name to_name,u.username FROM wallet_transfers t JOIN cash_wallets fw ON fw.id=t.from_wallet_id JOIN cash_wallets tw ON tw.id=t.to_wallet_id LEFT JOIN users u ON u.id=t.created_by ORDER BY t.id DESC LIMIT 100").fetchall()
    method_labels = {"cash": "Наличные", "card": "Карта", "transfer": "Перевод", "qr": "QR"}
    wallet_opts = "".join(f"<option value='{r['id']}'>{esc(r['name'])} · {method_labels[r['payment_method']]} · {r['balance']:,} ₽</option>" for r in wallets if r["active"])
    body = """<div class='card'><h2>Добавить счёт / кошелёк</h2><p class='muted'>Кошелёк — отдельный счёт учёта. Старые продажи и расходы не переназначаются автоматически: они показаны ниже как операции без кошелька.</p><form method='post'><input type='hidden' name='action' value='create'><label>Название счёта</label><input name='name' maxlength='100' required><label>Категория оплаты</label><select name='payment_method'><option value='cash'>Наличные</option><option value='card'>Карта</option><option value='transfer'>Перевод</option><option value='qr'>QR</option></select><label>Начальный остаток, ₽</label><input type='number' name='opening_balance' min='0' max='1000000000' value='0' required><button>Создать счёт</button></form></div>"""
    body += "<div class='card'><h2>Счета и остатки</h2><div class='tablewrap'><table><tr><th>Счёт</th><th>Категория</th><th>Начальный остаток</th><th>Продажи минус возвраты</th><th>Прочие поступления</th><th>Расходы</th><th>Переводы вход/выход</th><th>Остаток</th><th>Статус</th><th></th></tr>"
    for r in wallets:
        toggle = "Отключить" if r["active"] else "Включить"
        opening_control = f"<details><summary>Задать начальный остаток</summary><form method='post'><input type='hidden' name='action' value='opening'><input type='hidden' name='wallet_id' value='{r['id']}'><input type='number' name='opening_balance' min='0' max='1000000000' value='{r['opening_balance']}' required><button>Сохранить остаток</button></form></details>" if not r['has_operations'] else "<small>Зафиксирован после первой операции</small>"
        method_options = "".join(
            f'<option value="{m}" {"selected" if m == r["payment_method"] else ""}>{label}</option>'
            for m, label in method_labels.items()
        )
        edit_control = f"<details><summary>Изменить счёт</summary><form method='post'><input type='hidden' name='action' value='edit'><input type='hidden' name='wallet_id' value='{r['id']}'><label>Название</label><input name='name' value='{esc(r['name'])}' maxlength='100' required><label>Категория оплаты</label><select name='payment_method'>{method_options}</select><button>Сохранить счёт</button></form></details>"
        body += f"<tr><td>{esc(r['name'])}{edit_control}</td><td>{method_labels[r['payment_method']]}</td><td>{r['opening_balance']:,} ₽{opening_control}</td><td>{r['net_sales']:,} ₽</td><td>{r['other_income']:,} ₽</td><td>{r['expenses']:,} ₽</td><td>+{r['transfers_in']:,} / −{r['transfers_out']:,} ₽</td><td><strong>{r['balance']:,} ₽</strong></td><td>{'Активен' if r['active'] else 'Отключён'}</td><td><form method='post'><input type='hidden' name='action' value='toggle'><input type='hidden' name='wallet_id' value='{r['id']}'><button>{toggle}</button></form></td></tr>"
    body += "</table></div></div>"
    body += f"<div class='card'><h2>Перевод между счетами</h2><p class='muted'>Перевод не считается доходом или расходом. Он меняет остатки двух счетов и общий остаток наличных/безнала, если категория оплаты различается.</p><form method='post'><input type='hidden' name='action' value='transfer'><label>Откуда</label><select name='from_wallet_id' required>{wallet_opts}</select><label>Куда</label><select name='to_wallet_id' required>{wallet_opts}</select><label>Сумма, ₽</label><input type='number' name='amount' min='1' max='1000000000' required><label>Назначение</label><input name='note' maxlength='200' required><button>Провести перевод</button></form></div>"
    body += "<div class='card'><h2>Исторические операции без назначенного кошелька</h2><p class='muted'>Эти суммы сохранены как были в исходной базе. Для переноса старых операций на конкретный счёт потребуется отдельная ручная сверка; автоматического переназначения нет.</p><div class='tablewrap'><table><tr><th>Категория</th><th>Продажи минус возвраты</th><th>Прочие поступления</th><th>Расходы</th></tr>"
    for method, totals in legacy.items():
        body += f"<tr><td>{method_labels[method]}</td><td>{totals['sales']:,} ₽</td><td>{totals['other_income']:,} ₽</td><td>{totals['expenses']:,} ₽</td></tr>"
    body += "</table></div></div><div class='card'><h2>Последние переводы</h2><div class='tablewrap'><table><tr><th>Дата</th><th>Откуда</th><th>Куда</th><th>Сумма</th><th>Назначение</th><th>Кто</th></tr>"
    for r in transfers:
        body += f"<tr><td>{esc(r['created_at'])}</td><td>{esc(r['from_name'])}</td><td>{esc(r['to_name'])}</td><td>{r['amount']:,} ₽</td><td>{esc(r['note'])}</td><td>{esc(r['username'] or '—')}</td></tr>"
    if not transfers:
        body += "<tr><td colspan='6'>Переводов пока нет.</td></tr>"
    return page("Счета и кошельки", body + "</table></div></div>")


@app.post("/cash/close-shift")
@manager_required
def cash_close_shift():
    try: actual_cash=int(request.form.get("actual_cash","")); actual_noncash=int(request.form.get("actual_noncash",""))
    except: abort(400,"Введите фактические остатки наличных и безнала")
    if actual_cash<0 or actual_noncash<0: abort(400,"Остатки не могут быть отрицательными")
    shift_date=request.form.get("shift_date",today()).strip()
    note=request.form.get("note","").strip()
    try:
        date.fromisoformat(shift_date)
    except ValueError:
        abort(400,"Укажите корректную дату смены")
    if shift_date>today():
        abort(400,"Нельзя закрыть смену за будущую дату")
    with connect() as c:
        # Serialize closes: two administrators must not calculate against the same
        # previous shift and both commit stale expected balances.
        c.execute("BEGIN IMMEDIATE")
        init={r["key"]:int(r["value"]) for r in c.execute("SELECT key,value FROM settings WHERE key IN ('opening_cash','opening_non_cash')")}
        previous=c.execute("SELECT * FROM cash_shifts WHERE status='closed' ORDER BY closed_at DESC,id DESC LIMIT 1").fetchone()
        if previous and shift_date < previous["shift_date"]:
            abort(400,"Нельзя закрыть смену раньше уже закрытой смены. Проверьте дату.")
        closing_time=now()
        if previous:
            # Next shift starts from the last physically counted balance and accounts only for
            # transactions recorded after that close; this prevents re-applying opening balances
            # and re-counting earlier sales/expenses when a day has multiple shifts.
            opening_cash=previous["actual_cash"]
            opening_noncash=previous["actual_noncash"]
            sales=c.execute("""SELECT payment_method,SUM(CASE WHEN status='completed' THEN amount WHEN status='refund' THEN -amount ELSE 0 END) amount
              FROM sales WHERE created_at>? AND created_at<=? GROUP BY payment_method""",(previous["closed_at"],closing_time)).fetchall()
            ex=c.execute("""SELECT payment_method,SUM(amount) amount FROM cash_expenses WHERE created_at>? AND created_at<=? GROUP BY payment_method""",(previous["closed_at"],closing_time)).fetchall()
            incomes=c.execute("""SELECT payment_method,SUM(amount) amount FROM cash_other_income WHERE created_at>? AND created_at<=? GROUP BY payment_method""",(previous["closed_at"],closing_time)).fetchall()
        else:
            # For the first recorded close, configured opening balances are the baseline for
            # the selected business date.
            opening_cash=init.get("opening_cash",0)
            opening_noncash=init.get("opening_non_cash",0)
            sales=c.execute("""SELECT payment_method,SUM(CASE WHEN status='completed' THEN amount WHEN status='refund' THEN -amount ELSE 0 END) amount
              FROM sales WHERE substr(created_at,1,10)=? AND created_at<=? GROUP BY payment_method""",(shift_date,closing_time)).fetchall()
            ex=c.execute("""SELECT payment_method,SUM(amount) amount FROM cash_expenses WHERE expense_date=? AND created_at<=? GROUP BY payment_method""",(shift_date,closing_time)).fetchall()
            incomes=c.execute("""SELECT payment_method,SUM(amount) amount FROM cash_other_income WHERE substr(created_at,1,10)=? AND created_at<=? GROUP BY payment_method""",(shift_date,closing_time)).fetchall()
        by={r["payment_method"]:r["amount"] or 0 for r in sales}
        exby={r["payment_method"]:r["amount"] or 0 for r in ex}
        iby={r["payment_method"]:r["amount"] or 0 for r in incomes}
        expected_cash=opening_cash+by.get("cash",0)+iby.get("cash",0)-exby.get("cash",0)
        expected_noncash=opening_noncash+sum(by.get(k,0)+iby.get(k,0) for k in ("card","transfer","qr"))-sum(exby.get(k,0) for k in ("card","transfer","qr"))
        if previous:
            transfer_cash,transfer_noncash=transfer_balance_deltas(c,lower_bound=previous["closed_at"],upper_bound=closing_time)
        else:
            transfer_cash,transfer_noncash=transfer_balance_deltas(c,upper_bound=closing_time,business_date=shift_date)
        expected_cash+=transfer_cash; expected_noncash+=transfer_noncash
        diff_cash=actual_cash-expected_cash; diff_noncash=actual_noncash-expected_noncash
        cur=c.execute("""INSERT INTO cash_shifts(shift_date,opened_by,opening_cash,opening_noncash,expected_cash,expected_noncash,
          actual_cash,actual_noncash,cash_difference,noncash_difference,note,status,created_at,closed_at)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
          (shift_date,session["uid"],opening_cash,opening_noncash,expected_cash,expected_noncash,
           actual_cash,actual_noncash,diff_cash,diff_noncash,note,"closed",closing_time,closing_time))
        audit(c,"cash.shift.closed","cash_shift",cur.lastrowid,{"date":shift_date,"expected_cash":expected_cash,"actual_cash":actual_cash,"cash_difference":diff_cash,
             "expected_noncash":expected_noncash,"actual_noncash":actual_noncash,"noncash_difference":diff_noncash,"note":note})
    return redirect(url_for("cash_journal"))

@app.get("/cash")
@manager_required
def cash_journal():
    from datetime import date
    start=request.args.get("start",date.today().replace(day=1).isoformat())
    end=request.args.get("end",date.today().isoformat())
    try:
        date.fromisoformat(start); date.fromisoformat(end)
    except ValueError: abort(400,"Укажите даты в формате ГГГГ-ММ-ДД")
    if start>end: abort(400,"Начальная дата не может быть позже конечной")
    with connect() as c:
        # Sales and refunds are the source of truth for incoming cash/non-cash.
        sums=c.execute("""SELECT payment_method,
          SUM(CASE WHEN status='completed' THEN amount WHEN status='refund' THEN -amount ELSE 0 END) amount
          FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? GROUP BY payment_method""",(start,end)).fetchall()
        expenses=c.execute("""SELECT e.*,w.name wallet_name,cat.name category_name FROM cash_expenses e LEFT JOIN cash_wallets w ON w.id=e.wallet_id LEFT JOIN cash_expense_categories cat ON cat.id=e.category_id WHERE e.expense_date BETWEEN ? AND ? ORDER BY e.expense_date DESC,e.id DESC""",(start,end)).fetchall()
        other_incomes=c.execute("""SELECT i.*,w.name wallet_name,cat.name category_name FROM cash_other_income i LEFT JOIN cash_wallets w ON w.id=i.wallet_id LEFT JOIN cash_income_categories cat ON cat.id=i.category_id WHERE i.income_date BETWEEN ? AND ? ORDER BY i.income_date DESC,i.id DESC""",(start,end)).fetchall()
        other_income_total=c.execute("SELECT COALESCE(SUM(amount),0) n FROM cash_other_income WHERE income_date BETWEEN ? AND ?",(start,end)).fetchone()["n"]
        exp_total=c.execute("SELECT COALESCE(SUM(amount),0) n FROM cash_expenses WHERE expense_date BETWEEN ? AND ?",(start,end)).fetchone()["n"]
        exp_cash=c.execute("SELECT COALESCE(SUM(amount),0) n FROM cash_expenses WHERE expense_date BETWEEN ? AND ? AND payment_method='cash'",(start,end)).fetchone()["n"]
        exp_non_cash=c.execute("SELECT COALESCE(SUM(amount),0) n FROM cash_expenses WHERE expense_date BETWEEN ? AND ? AND payment_method!='cash'",(start,end)).fetchone()["n"]
        init={r["key"]:int(r["value"]) for r in c.execute("SELECT key,value FROM settings WHERE key IN ('opening_cash','opening_non_cash')")}
        # The displayed balance is the true cumulative balance as of the period end,
        # anchored to the latest physical close when one exists. It is not a balance
        # made by re-applying opening funds to every arbitrary report period.
        cash_balance,noncash_balance=balances_as_of(c,end)
        wallets=c.execute("SELECT id,name,payment_method FROM cash_wallets WHERE active=1 ORDER BY name COLLATE NOCASE").fetchall()
        expense_categories=c.execute("SELECT id,name FROM cash_expense_categories WHERE active=1 ORDER BY name COLLATE NOCASE").fetchall()
        income_categories=c.execute("SELECT id,name FROM cash_income_categories WHERE active=1 ORDER BY name COLLATE NOCASE").fetchall()
        income_category_sums=c.execute("SELECT COALESCE(cat.name,'Без категории') category_name,SUM(i.amount) amount FROM cash_other_income i LEFT JOIN cash_income_categories cat ON cat.id=i.category_id WHERE i.income_date BETWEEN ? AND ? GROUP BY COALESCE(cat.name,'Без категории') ORDER BY amount DESC",(start,end)).fetchall()
        expense_category_sums=c.execute("SELECT COALESCE(cat.name,'Без категории') category_name,SUM(e.amount) amount FROM cash_expenses e LEFT JOIN cash_expense_categories cat ON cat.id=e.category_id WHERE e.expense_date BETWEEN ? AND ? GROUP BY COALESCE(cat.name,'Без категории') ORDER BY amount DESC",(start,end)).fetchall()
    default_expense_category_id=next((r["id"] for r in expense_categories if r["name"]=="Прочее"), expense_categories[0]["id"] if expense_categories else 0)
    expense_category_opts="".join(f"<option value='{r['id']}' {'selected' if r['id']==default_expense_category_id else ''}>{esc(r['name'])}</option>" for r in expense_categories)
    default_income_category_id=next((r["id"] for r in income_categories if r["name"]=="Прочее"), income_categories[0]["id"] if income_categories else 0)
    income_category_opts="".join(f"<option value='{r['id']}' {'selected' if r['id']==default_income_category_id else ''}>{esc(r['name'])}</option>" for r in income_categories)
    default_expense_wallet_id=next((r["id"] for r in wallets if r["payment_method"]=="cash"), wallets[0]["id"] if wallets else 0)
    wallet_expense_opts="".join(f"<option value='{r['id']}' {'selected' if r['id']==default_expense_wallet_id else ''}>{esc(r['name'])} · { {'cash':'наличные','card':'карта','transfer':'перевод','qr':'QR'}[r['payment_method']] }</option>" for r in wallets)
    by={r["payment_method"]:r["amount"] or 0 for r in sums}
    cash_in=by.get("cash",0); noncash_in=sum(by.get(k,0) for k in ("card","transfer","qr"))
    body=f"""<div class='card'><h2>Касса и финансовый журнал</h2><form method='get'><label>С даты</label><input type='date' name='start' value='{esc(start)}' required><label>По дату</label><input type='date' name='end' value='{esc(end)}' required><button>Показать</button><a class='btn' href='/cash.csv?start={esc(start)}&end={esc(end)}'>Экспорт CSV</a></form></div>
    <div class='grid'><div class='card'><h2>Расчётный остаток наличных на конец периода</h2><p style='font-size:26px'>{cash_balance:,} ₽</p></div><div class='card'><h2>Расчётный безналичный остаток на конец периода</h2><p style='font-size:26px'>{noncash_balance:,} ₽</p></div><div class='card'><h2>Расходы</h2><p style='font-size:26px'>{exp_total:,} ₽</p></div><div class='card'><h2>Прочие поступления</h2><p style='font-size:26px'>{other_income_total:,} ₽</p></div></div>
    <div class='card'><h2>Добавить расход</h2><form method='post' action='/cash/expense'><label>Дата</label><input type='date' name='expense_date' value='{today()}' required><label>Описание</label><input name='description' required><label>Сумма, ₽</label><input type='number' name='amount' min='1' required><label>Категория расхода</label><select name='category_id' required>{expense_category_opts}</select><label>Счёт/кошелёк</label><select name='wallet_id' required>{wallet_expense_opts}</select><button>Записать расход</button></form></div>
    <div class='card'><h2>Добавить прочее поступление</h2><p class='muted'>Это не продажа и не создаёт абонемент. Используйте для внесения средств или прочих поступлений, которые не являются оплатой клиента.</p><form method='post' action='/cash/income'><label>Дата</label><input type='date' name='income_date' value='{today()}' required><label>Описание</label><input name='description' required maxlength='200'><label>Сумма, ₽</label><input type='number' name='amount' min='1' required><label>Категория поступления</label><select name='category_id' required>{income_category_opts}</select><label>Счёт/кошелёк</label><select name='wallet_id' required>{wallet_expense_opts}</select><button>Записать поступление</button></form></div>
    <div class='card'><h2>Начальные остатки</h2><p>Изменять может только руководитель. Значения — исходный остаток до первой закрытой смены. После закрытия смен остаток переносится по фактическому пересчёту и новым операциям.</p><form method='post' action='/cash/opening'><label>Начальные наличные, ₽</label><input type='number' name='opening_cash' min='0' value='{init.get('opening_cash',0)}' required><label>Начальный безналичный остаток, ₽</label><input type='number' name='opening_non_cash' min='0' value='{init.get('opening_non_cash',0)}' required><button>Сохранить остатки</button></form></div>
    <div class='card'><h2>Прочие поступления за период</h2><div class='tablewrap'><table><tr><th>Дата</th><th>Описание</th><th>Категория</th><th>Сумма</th><th>Счёт/кошелёк</th><th>Сотрудник</th></tr>"""
    for r in other_incomes: body+=f"<tr><td>{esc(r['income_date'])}</td><td>{esc(r['description'])}</td><td>{esc(r['category_name'] or 'Без категории')}</td><td>+{r['amount']:,} ₽</td><td>{esc(r['wallet_name'] or 'Не назначен')} · {esc(r['payment_method'])}</td><td>{esc(r['created_by_name'])}</td></tr>"
    if not other_incomes: body+="<tr><td colspan='6'>Прочих поступлений за период нет.</td></tr>"
    body+="</table></div></div>"
    body+="<div class='card'><h2>Поступления по категориям</h2><div class='tablewrap'><table><tr><th>Категория</th><th>Сумма</th></tr>"
    for r in income_category_sums: body+=f"<tr><td>{esc(r['category_name'])}</td><td>{r['amount']:,} ₽</td></tr>"
    if not income_category_sums: body+="<tr><td colspan='2'>Поступлений за период нет.</td></tr>"
    body+="</table></div></div>"
    body+="<div class='card'><h2>Расходы за период</h2><div class='tablewrap'><table><tr><th>Дата</th><th>Описание</th><th>Категория</th><th>Сумма</th><th>Счёт/кошелёк</th><th>Сотрудник</th></tr>"""
    for r in expenses: body+=f"<tr><td>{esc(r['expense_date'])}</td><td>{esc(r['description'])}</td><td>{esc(r['category_name'] or 'Без категории')}</td><td>{r['amount']:,} ₽</td><td>{esc(r['wallet_name'] or 'Не назначен')} · {esc(r['payment_method'])}</td><td>{esc(r['created_by_name'])}</td></tr>"
    body+="</table></div></div>"
    body+="<div class='card'><h2>Расходы по категориям</h2><div class='tablewrap'><table><tr><th>Категория</th><th>Сумма</th></tr>"
    for r in expense_category_sums: body+=f"<tr><td>{esc(r['category_name'])}</td><td>{r['amount']:,} ₽</td></tr>"
    if not expense_category_sums: body+="<tr><td colspan='2'>Расходов за период нет.</td></tr>"
    body+="</table></div></div>"
    with connect() as c:
        shifts=c.execute("SELECT * FROM cash_shifts ORDER BY id DESC LIMIT 30").fetchall()
    body+=f"""<div class='card'><h2>Закрытие смены / сверка</h2><form method='post' action='/cash/close-shift'><label>Дата смены</label><input type='date' name='shift_date' value='{esc(end)}' required><label>Фактические наличные, ₽</label><input type='number' name='actual_cash' min='0' required><label>Фактический безналичный остаток, ₽</label><input type='number' name='actual_noncash' min='0' required><label>Комментарий</label><input name='note'><button>Закрыть смену</button></form></div><div class='card'><h2>История сверок</h2><div class='tablewrap'><table><tr><th>Дата</th><th>Ожидалось наличных</th><th>Фактически</th><th>Разница</th><th>Ожидалось безналом</th><th>Фактически</th><th>Разница</th><th>Комментарий</th></tr>"""
    for sh in shifts:
        body+=f"<tr><td>{esc(sh['shift_date'])}</td><td>{sh['expected_cash']:,} ₽</td><td>{sh['actual_cash']:,} ₽</td><td>{sh['cash_difference']:,} ₽</td><td>{sh['expected_noncash']:,} ₽</td><td>{sh['actual_noncash']:,} ₽</td><td>{sh['noncash_difference']:,} ₽</td><td>{esc(sh['note'])}</td></tr>"
    return page("Касса",body+"</table></div></div><p class='muted'>Остаток на конец периода считается накопительно: до первой закрытой смены — от исходного остатка и всех записанных операций; после закрытия — от фактического остатка последней смены и операций, внесённых после неё.</p>")

@app.post("/cash/income")
@manager_required
def cash_add_other_income():
    try: amount=int(request.form.get("amount",""))
    except ValueError: abort(400,"Проверьте сумму поступления")
    description=request.form.get("description","").strip()
    try: category_id=int(request.form.get("category_id","")); wallet_id=int(request.form.get("wallet_id",""))
    except ValueError: abort(400,"Выберите категорию и счёт/кошелёк")
    income_date=request.form.get("income_date",today())
    if amount<1 or amount>100_000_000 or not description or len(description)>200:
        abort(400,"Укажите описание до 200 символов и сумму от 1 ₽")
    try: date.fromisoformat(income_date)
    except ValueError: abort(400,"Укажите корректную дату поступления")
    if income_date>today(): abort(400,"Нельзя записать поступление за будущую дату")
    with connect() as c:
        c.execute("BEGIN IMMEDIATE")
        wallet=c.execute("SELECT id,payment_method FROM cash_wallets WHERE id=? AND active=1",(wallet_id,)).fetchone()
        category=c.execute("SELECT id FROM cash_income_categories WHERE id=? AND active=1",(category_id,)).fetchone()
        if not wallet: abort(400,"Счёт/кошелёк отключён или не найден")
        if not category: abort(400,"Категория поступления отключена или не найдена")
        cur=c.execute("INSERT INTO cash_other_income(income_date,description,amount,payment_method,created_by,created_by_name,created_at,wallet_id,category_id) VALUES(?,?,?,?,?,?,?,?,?)",
          (income_date,description,amount,wallet["payment_method"],session["uid"],current_user()["username"],now(),wallet_id,category_id))
        audit(c,"cash.other_income.created","cash_other_income",cur.lastrowid,{"date":income_date,"description":description,"amount":amount,"payment_method":wallet["payment_method"],"wallet_id":wallet_id,"category_id":category_id})
    return redirect(url_for("cash_journal"))


@app.post("/cash/expense")
@manager_required
def cash_add_expense():
    try: amount=int(request.form.get("amount",""))
    except: abort(400,"Проверьте сумму")
    desc=request.form.get("description","").strip()
    category_raw=request.form.get("category_id","").strip()
    category_id=None
    if category_raw:
        try: category_id=int(category_raw)
        except ValueError: abort(400,"Выберите корректную категорию расхода")
    wallet_raw=request.form.get("wallet_id","").strip()
    wallet_id=None
    if wallet_raw:
        try: wallet_id=int(wallet_raw)
        except ValueError: abort(400,"Выберите корректный счёт/кошелёк")
        method=None
    else:
        method=request.form.get("payment_method","cash")
    d=request.form.get("expense_date",today())
    if amount<1 or amount>100_000_000 or not desc or len(desc)>200:
        abort(400,"Проверьте описание (до 200 символов) и сумму")
    if method is not None and method not in ("cash","card","transfer","qr"):
        abort(400,"Неверная категория оплаты")
    try:
        date.fromisoformat(d)
    except ValueError:
        abort(400,"Укажите корректную дату расхода")
    if d>today(): abort(400,"Нельзя записать кассовый расход за будущую дату")
    with connect() as c:
        if wallet_id is not None:
            wallet=c.execute("SELECT id,payment_method FROM cash_wallets WHERE id=? AND active=1",(wallet_id,)).fetchone()
            if not wallet: abort(400,"Счёт/кошелёк отключён или не найден")
            method=wallet["payment_method"]
        if category_id is not None and not c.execute("SELECT 1 FROM cash_expense_categories WHERE id=? AND active=1",(category_id,)).fetchone():
            abort(400,"Категория расхода отключена или не найдена")
        cur=c.execute("INSERT INTO cash_expenses(expense_date,description,amount,payment_method,created_by,created_by_name,created_at,wallet_id,category_id) VALUES(?,?,?,?,?,?,?,?,?)",
          (d,desc,amount,method,session["uid"],current_user()["username"],now(),wallet_id,category_id))
        audit(c,"cash.expense.created","cash_expense",cur.lastrowid,{"date":d,"description":desc,"amount":amount,"payment_method":method,"wallet_id":wallet_id,"category_id":category_id})
    return redirect(url_for("cash_journal"))

@app.post("/cash/opening")
@manager_required
def cash_save_opening():
    try: cash=int(request.form.get("opening_cash","")); noncash=int(request.form.get("opening_non_cash",""))
    except: abort(400,"Проверьте начальные остатки")
    if cash<0 or noncash<0 or cash>1_000_000_000 or noncash>1_000_000_000:
        abort(400,"Остатки должны быть от 0 до 1 000 000 000 ₽")
    with connect() as c:
        # Lock before checking the first close to avoid a concurrent close racing
        # with a baseline edit.
        c.execute("BEGIN IMMEDIATE")
        try:
            ensure_opening_balances_editable(c)
        except ValueError as exc:
            abort(400, str(exc))
        for key,val in (("opening_cash",cash),("opening_non_cash",noncash)):
            old=c.execute("SELECT value FROM settings WHERE key=?",(key,)).fetchone()
            c.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(key,str(val)))
            audit(c,"cash.opening.updated","setting",None,{"key":key,"old":old["value"] if old else None,"new":val})
    return redirect(url_for("cash_journal"))

@app.get("/cash.csv")
@manager_required
def cash_csv():
    import csv,io
    from flask import Response
    from datetime import date
    start=request.args.get("start",date.today().replace(day=1).isoformat()); end=request.args.get("end",date.today().isoformat())
    try: date.fromisoformat(start); date.fromisoformat(end)
    except ValueError: abort(400,"Укажите даты в формате ГГГГ-ММ-ДД")
    if start>end: abort(400,"Начальная дата не может быть позже конечной")
    from cash_export import cash_transactions
    with connect() as c:
        rows=cash_transactions(c,start,end)
    out=io.StringIO(); w=csv.writer(out,delimiter=';')
    w.writerow(["Дата","Тип операции","ID","Описание","Категория ДДС","Сумма со знаком, ₽","Категория оплаты","Счёт/кошелёк","Сотрудник","Создано"])
    w.writerows([safe_csv_row(tuple(r)) for r in rows])
    return Response("\ufeff"+out.getvalue(),mimetype="text/csv; charset=utf-8",headers={"Content-Disposition":f"attachment; filename=cash_{start}_{end}.csv"})


@app.route("/discounts",methods=["GET","POST"])
@manager_required
def discounts_page():
    from datetime import date
    start=request.args.get("start",date.today().replace(day=1).isoformat())
    end=request.args.get("end",date.today().isoformat())
    try: date.fromisoformat(start); date.fromisoformat(end)
    except ValueError: abort(400,"Укажите даты в формате ГГГГ-ММ-ДД")
    if start>end: abort(400,"Начальная дата не может быть позже конечной")
    with connect() as c:
        if request.method=="POST":
            name=request.form.get("name","").strip()
            try: percent=int(request.form.get("percent",""))
            except: abort(400,"Укажите процент скидки")
            if not name or not 1<=percent<=100: abort(400,"Название обязательно, скидка от 1 до 100%")
            try:
                cur=c.execute("INSERT INTO discounts(name,percent,created_by,created_at) VALUES(?,?,?,?)",(name,percent,session["uid"],now()))
            except Exception: abort(400,"Скидка с таким названием уже есть")
            audit(c,"discount.created","discount",cur.lastrowid,{"name":name,"percent":percent})
            return redirect(url_for("discounts_page"))
        rows=c.execute("SELECT * FROM discounts ORDER BY active DESC,name").fetchall()
    body="""<div class='card'><h2>Добавить скидку</h2><form method='post'><label>Название акции</label><input name='name' required><label>Скидка, %</label><input name='percent' type='number' min='1' max='100' required><button>Сохранить скидку</button></form></div><div class='card'><h2>Утверждённые скидки</h2><div class='tablewrap'><table><tr><th>Название</th><th>Процент</th><th>Статус</th><th></th></tr>"""
    for r in rows:
        toggle="Выключить" if r["active"] else "Включить"
        body+=f"<tr><td>{esc(r['name'])}</td><td>{r['percent']}%</td><td>{'Активна' if r['active'] else 'Неактивна'}</td><td><form method='post' action='/discounts/{r['id']}/toggle'><button>{toggle}</button></form></td></tr>"
    return page("Скидки",body+"</table></div></div>")

@app.post("/discounts/<int:did>/toggle")
@manager_required
def discount_toggle(did):
    with connect() as c:
        r=c.execute("SELECT * FROM discounts WHERE id=?",(did,)).fetchone()
        if not r: abort(404)
        c.execute("UPDATE discounts SET active=? WHERE id=?",(0 if r["active"] else 1,did))
        audit(c,"discount.toggled","discount",did,{"active":not bool(r["active"])})
    return redirect(url_for("discounts_page"))

@app.route("/products",methods=["GET","POST"])
@manager_required
def products():
    from datetime import date
    start=request.args.get("start",date.today().replace(day=1).isoformat())
    end=request.args.get("end",date.today().isoformat())
    try:
        date.fromisoformat(start); date.fromisoformat(end)
    except ValueError:
        abort(400,"Укажите даты в формате ГГГГ-ММ-ДД")
    if start>end:
        abort(400,"Начальная дата не может быть позже конечной")
    with connect() as c:
        if request.method=="POST":
            name=request.form.get("name","").strip()
            try: purchase=int(request.form.get("purchase_price","")); sale=int(request.form.get("sale_price","")); qty=int(request.form.get("quantity",""))
            except: abort(400,"Проверьте цены и количество")
            if not name or min(purchase,sale,qty)<0: abort(400,"Неверные данные товара")
            try:
                cur=c.execute("INSERT INTO products(name,purchase_price,sale_price,stock,created_at) VALUES(?,?,?,?,?)",(name,purchase,sale,qty,now()))
            except Exception: abort(400,"Товар с таким названием уже существует")
            if qty:
                c.execute("INSERT INTO stock_movements(product_id,movement_type,quantity,unit_cost,note,created_by,created_at) VALUES(?,?,?,?,?,?,?)",
                    (cur.lastrowid,"purchase",qty,purchase,"Начальный остаток",session["uid"],now()))
            audit(c,"product.created","product",cur.lastrowid,{"name":name,"purchase_price":purchase,"sale_price":sale,"stock":qty})
            return redirect(url_for("products"))
        rows=c.execute("SELECT * FROM products ORDER BY active DESC,name").fetchall()
        profit_row=c.execute("SELECT COALESCE(SUM(CASE WHEN status='completed' THEN quantity WHEN status='refund' THEN -quantity ELSE 0 END),0) qty,COALESCE(SUM(CASE WHEN status='completed' THEN amount WHEN status='refund' THEN -amount ELSE 0 END),0) revenue,COALESCE(SUM(CASE WHEN status='completed' THEN unit_cost_snapshot*quantity WHEN status='refund' THEN -unit_cost_snapshot*quantity ELSE 0 END),0) cost,COALESCE(SUM(profit_snapshot),0) profit FROM sales WHERE product_id IS NOT NULL AND substr(created_at,1,10) BETWEEN ? AND ?",(start,end)).fetchone()
    body=f"""<div class='card'><h2>Продажи товаров и прибыль</h2><form method='get'><label>С</label><input type='date' name='start' value='{esc(start)}' required><label>По</label><input type='date' name='end' value='{esc(end)}' required><button>Показать период</button></form><p>Продано единиц: {profit_row['qty']} · Выручка: {profit_row['revenue']:,} ₽ · Себестоимость: {profit_row['cost']:,} ₽ · Валовая прибыль: {profit_row['profit']:,} ₽</p><p class='muted'>Период: {esc(start)} — {esc(end)}. Себестоимость сохраняется на момент продажи; возвраты уменьшают выручку, количество и прибыль.</p></div><div class='card'><h2>Добавить товар</h2><form method='post'><label>Название</label><input name='name' required><label>Закупочная цена, ₽</label><input type='number' name='purchase_price' min='0' required><label>Продажная цена, ₽</label><input type='number' name='sale_price' min='0' required><label>Начальный остаток</label><input type='number' name='quantity' min='0' required><button>Добавить товар</button></form></div><div class='card'><h2>Склад</h2><div class='tablewrap'><table><tr><th>Товар</th><th>Закупка</th><th>Продажа</th><th>Остаток</th><th>Действия</th></tr>"""
    for r in rows:
        active_label = "Активен" if r["active"] else "Отключён"
        body+=f"<tr><td>{esc(r['name'])}<br><small>{active_label}</small><details><summary>Изменить товар</summary><form method='post' action='/products/{r['id']}/edit'><label>Название</label><input name='name' value='{esc(r['name'])}' maxlength='100' required><label>Закупочная цена, ₽</label><input type='number' name='purchase_price' min='0' max='100000000' value='{r['purchase_price']}' required><label>Продажная цена, ₽</label><input type='number' name='sale_price' min='0' max='100000000' value='{r['sale_price']}' required><label>Доступность для новых продаж</label><select name='active'><option value='1' {'selected' if r['active'] else ''}>Активен</option><option value='0' {'selected' if not r['active'] else ''}>Отключён</option></select><button>Сохранить карточку</button></form></details></td><td>{r['purchase_price']} ₽</td><td>{r['sale_price']} ₽</td><td>{r['stock']}</td><td><form method='post' action='/products/{r['id']}/receive'><input type='number' name='quantity' min='1' placeholder='Кол-во' required><input type='number' name='unit_cost' min='0' value='{r['purchase_price']}' required><input name='note' placeholder='Поставка' required><button>Приход</button></form><form method='post' action='/products/{r['id']}/writeoff'><input type='number' name='quantity' min='1' max='{r['stock']}' placeholder='Кол-во' required><input name='note' placeholder='Причина списания' required><button class='danger'>Списать</button></form></td></tr>"
    return page("Товары и склад",body+"</table></div></div>")

@app.post("/products/<int:pid>/edit")
@manager_required
def product_edit(pid):
    try:
        values = normalize_product_update(request.form.get("name"), request.form.get("purchase_price"), request.form.get("sale_price"), request.form.get("active"))
    except ValueError as exc:
        abort(400, str(exc))
    with connect() as c:
        old = c.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
        if not old:
            abort(404, "Товар не найден")
        duplicate = c.execute("SELECT id FROM products WHERE name=? COLLATE NOCASE AND id<>? LIMIT 1", (values["name"], pid)).fetchone()
        if duplicate:
            abort(400, "Товар с таким названием уже существует")
        try:
            c.execute("UPDATE products SET name=?,purchase_price=?,sale_price=?,active=? WHERE id=?",
                      (values["name"], values["purchase_price"], values["sale_price"], values["active"], pid))
        except sqlite3.IntegrityError:
            abort(400, "Товар с таким названием уже существует")
        audit(c, "product.updated", "product", pid, {
            "old_name": old["name"], "new_name": values["name"],
            "old_purchase_price": old["purchase_price"], "new_purchase_price": values["purchase_price"],
            "old_sale_price": old["sale_price"], "new_sale_price": values["sale_price"],
            "old_active": old["active"], "new_active": values["active"],
            "historical_sales_snapshots_preserved": True,
        })
    return redirect(url_for("products"))


@app.post("/products/<int:pid>/receive")
@manager_required
def product_receive(pid):
    try: qty=int(request.form.get("quantity","")); cost=int(request.form.get("unit_cost",""))
    except: abort(400,"Проверьте количество и закупочную цену")
    note=request.form.get("note","").strip()
    if qty<1 or cost<0 or not note: abort(400,"Укажите количество, цену и комментарий")
    with connect() as c:
        pr=c.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone()
        if not pr: abort(404)
        c.execute("UPDATE products SET stock=stock+?,purchase_price=? WHERE id=?",(qty,cost,pid))
        cur=c.execute("INSERT INTO stock_movements(product_id,movement_type,quantity,unit_cost,note,created_by,created_at) VALUES(?,?,?,?,?,?,?)",(pid,"purchase",qty,cost,note,session["uid"],now()))
        audit(c,"stock.received","stock_movement",cur.lastrowid,{"product_id":pid,"quantity":qty,"unit_cost":cost,"note":note})
    return redirect(url_for("products"))

@app.post("/products/<int:pid>/writeoff")
@manager_required
def product_writeoff(pid):
    try: qty=int(request.form.get("quantity",""))
    except: abort(400,"Проверьте количество")
    note=request.form.get("note","").strip()
    if qty<1 or not note: abort(400,"Укажите количество и причину")
    with connect() as c:
        pr=c.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone()
        if not pr or pr["stock"]<qty: abort(400,"Товар не найден или недостаточно остатка")
        # Re-check stock in the UPDATE itself so simultaneous write-offs cannot
        # spend the same units twice or surface an unhandled CHECK constraint error.
        changed=c.execute("UPDATE products SET stock=stock-? WHERE id=? AND stock>=?",(qty,pid,qty))
        if changed.rowcount != 1: abort(400,"Остаток изменился; обновите страницу и повторите списание")
        cur=c.execute("INSERT INTO stock_movements(product_id,movement_type,quantity,unit_cost,note,created_by,created_at) VALUES(?,?,?,?,?,?,?)",(pid,"writeoff",qty,pr["purchase_price"],note,session["uid"],now()))
        audit(c,"stock.written_off","stock_movement",cur.lastrowid,{"product_id":pid,"quantity":qty,"note":note})
    return redirect(url_for("products"))

@app.get("/reconciliation/late-expenses.csv")
@manager_required
def reconciliation_late_expenses_csv():
    import csv, io
    with connect() as c:
        rows=find_late_cash_expenses(c, limit=1000)
    output=io.StringIO(newline="")
    writer=csv.writer(output)
    writer.writerow(["ID расхода","Дата расхода","Описание","Сумма","Способ оплаты","Кем внесён","Время внесения","ID смены","Дата смены","Время закрытия смены"])
    for r in rows:
        writer.writerow(safe_csv_row([r["id"],r["expense_date"],r["description"],r["amount"],r["payment_method"],r["created_by_name"],r["created_at"],r["affected_shift_id"],r["affected_shift_date"],r["affected_closed_at"]]))
    from flask import Response
    return Response("\ufeff"+output.getvalue(), mimetype="text/csv; charset=utf-8", headers={"Content-Disposition":"attachment; filename=late_cash_expenses.csv","Cache-Control":"no-store"})


@app.get("/reconciliation/cash-shift-mismatches.csv")
@manager_required
def reconciliation_cash_shift_mismatches_csv():
    import csv, io
    with connect() as c:
        rows=find_cash_shift_math_mismatches(c, limit=1000)
    output=io.StringIO(newline="")
    writer=csv.writer(output)
    writer.writerow(["ID смены","Дата","Расчёт наличных","Факт наличных","Разница сохранена","Разница рассчитана","Расчёт безнала","Факт безнала","Разница сохранена безнал","Разница рассчитана безнал","Комментарий","Закрыта"])
    for r in rows:
        writer.writerow(safe_csv_row([r["id"],r["shift_date"],r["expected_cash"],r["actual_cash"],r["cash_difference"],r["calculated_cash_difference"],r["expected_noncash"],r["actual_noncash"],r["noncash_difference"],r["calculated_noncash_difference"],r["note"],r["closed_at"]]))
    from flask import Response
    return Response("\ufeff"+output.getvalue(), mimetype="text/csv; charset=utf-8", headers={"Content-Disposition":"attachment; filename=cash_shift_integrity.csv","Cache-Control":"no-store"})


@app.get("/reconciliation")
@manager_required
def reconciliation():
    """Read-only consistency checks; never changes financial or stock records."""
    with connect() as c:
        stock_rows=c.execute("""SELECT p.id,p.name,p.stock,
              COALESCE(SUM(CASE
                WHEN m.movement_type='purchase' THEN m.quantity
                WHEN m.movement_type='sale' THEN -m.quantity
                WHEN m.movement_type='writeoff' THEN -m.quantity
                WHEN m.movement_type='adjustment' THEN m.quantity
                ELSE 0 END),0) movement_stock
            FROM products p LEFT JOIN stock_movements m ON m.product_id=p.id
            GROUP BY p.id,p.name,p.stock ORDER BY p.name""").fetchall()
        bad_sales=c.execute("""SELECT s.id,s.item,s.status,s.subscription_id
            FROM sales s LEFT JOIN subscriptions sub ON sub.id=s.subscription_id
            WHERE (s.subscription_id IS NOT NULL AND sub.id IS NULL)
               OR (s.subscription_id IS NOT NULL AND s.status='completed' AND sub.status='cancelled')
            ORDER BY s.id DESC LIMIT 100""").fetchall()
        pending=c.execute("SELECT COUNT(*) n FROM refund_requests WHERE status='pending'").fetchone()["n"]
        # Closed cash shifts with a non-zero difference are surfaced for review;
        # the report never changes actuals or rewrites the closeout record.
        bad_cash_shifts=c.execute("""SELECT id,shift_date,expected_cash,actual_cash,cash_difference,
                  expected_noncash,actual_noncash,noncash_difference,note
            FROM cash_shifts
            WHERE status='closed' AND (cash_difference!=0 OR noncash_difference!=0)
            ORDER BY shift_date DESC,id DESC LIMIT 100""").fetchall()
        late_cash_expenses=find_late_cash_expenses(c)
        cash_shift_math_mismatches=find_cash_shift_math_mismatches(c)
        bad_refunds=c.execute("""SELECT r.id request_id,r.sale_id,r.status request_status,
                  s.status sale_status,s.amount original_amount,
                  COALESCE(x.refund_count,0) refund_count,COALESCE(x.refund_amount,0) refund_amount
            FROM refund_requests r JOIN sales s ON s.id=r.sale_id
            LEFT JOIN (SELECT original_sale_id,COUNT(*) refund_count,SUM(amount) refund_amount
                       FROM sales WHERE status='refund' AND original_sale_id IS NOT NULL
                       GROUP BY original_sale_id) x ON x.original_sale_id=s.id
            WHERE (r.status='approved' AND s.status!='completed')
               OR (r.status='approved' AND (COALESCE(x.refund_count,0)=0
                    OR COALESCE(x.refund_count,0)>1 OR COALESCE(x.refund_amount,0)!=s.amount))
               OR (r.status='pending' AND s.status!='completed')
            ORDER BY r.id DESC LIMIT 100""").fetchall()
        bad_attendance=c.execute("""SELECT a.id,a.lesson_date,a.lesson_time,a.status,a.subscription_id,
              s.client_id sub_client_id,a.client_id
            FROM attendance a LEFT JOIN subscriptions s ON s.id=a.subscription_id
            WHERE s.id IS NULL OR s.client_id!=a.client_id
            ORDER BY a.id DESC LIMIT 100""").fetchall()
        bad_subscriptions=c.execute("""SELECT s.id,s.title,s.client_id,s.total_lessons,s.remaining_lessons,s.status
            FROM subscriptions s JOIN clients cl ON cl.id=s.client_id
            WHERE s.remaining_lessons>s.total_lessons
               OR (s.status='active' AND s.remaining_lessons=0)
               OR (s.status='completed' AND s.remaining_lessons>0)
            ORDER BY s.id DESC LIMIT 100""").fetchall()
        # Payroll uses one rate per scheduled group slot. Conflicting snapshots
        # or trainer names inside one slot are ambiguous and must be reviewed.
        bad_payroll_slots=c.execute("""SELECT schedule_slot_id,lesson_date,lesson_time,
                COUNT(*) children_count,COUNT(DISTINCT COALESCE(NULLIF(TRIM(trainer),''),'Не указан')) trainer_count,
                COUNT(DISTINCT rate_snapshot) rate_count,
                GROUP_CONCAT(DISTINCT COALESCE(NULLIF(TRIM(trainer),''),'Не указан')) trainers,
                MIN(rate_snapshot) min_rate,MAX(rate_snapshot) max_rate
            FROM attendance WHERE status='attended' AND schedule_slot_id IS NOT NULL
            GROUP BY schedule_slot_id,lesson_date,lesson_time
            HAVING COUNT(DISTINCT COALESCE(NULLIF(TRIM(trainer),''),'Не указан'))>1 OR COUNT(DISTINCT rate_snapshot)>1
            ORDER BY lesson_date DESC,lesson_time LIMIT 100""").fetchall()
    drift=[r for r in stock_rows if r['stock']!=r['movement_stock']]
    body=f"""<div class='card'><h2>Сверка данных</h2><p>Это только диагностический отчёт: он ничего не исправляет автоматически. Если найдены расхождения, проверьте первичные документы и журнал операций перед корректировкой.</p>
      <div class='grid'><div class='card'><h2>Расхождения склада</h2><p style='font-size:28px'>{len(drift)}</p></div><div class='card'><h2>Смены с расхождениями</h2><p style='font-size:28px'>{len(bad_cash_shifts)}</p></div><div class='card'><h2>Ошибки арифметики закрытия</h2><p style='font-size:28px'>{len(cash_shift_math_mismatches)}</p></div><div class='card'><h2>Расходы внесены после закрытия</h2><p style='font-size:28px'>{len(late_cash_expenses)}</p></div><div class='card'><h2>Проблемные связи продаж</h2><p style='font-size:28px'>{len(bad_sales)}</p></div><div class='card'><h2>Проблемные посещения</h2><p style='font-size:28px'>{len(bad_attendance)}</p></div><div class='card'><h2>Подозрительные остатки абонементов</h2><p style='font-size:28px'>{len(bad_subscriptions)}</p></div><div class='card'><h2>Ожидают решения по возвратам</h2><p style='font-size:28px'>{pending}</p></div><div class='card'><h2>Подозрительные возвраты</h2><p style='font-size:28px'>{len(bad_refunds)}</p></div><div class='card'><h2>Ставки/тренеры в слотах</h2><p style='font-size:28px'>{len(bad_payroll_slots)}</p></div></div></div>
      <div class='card'><h2>Склад: остаток против журнала движений</h2><p class='muted'>Для существующих до внедрения журнала товаров возможны исторические расхождения. Сверьте их вручную.</p><div class='tablewrap'><table><tr><th>Товар</th><th>Остаток в карточке</th><th>По движениям</th><th>Разница</th><th>Статус</th></tr>"""
    for r in stock_rows:
        diff=r['stock']-r['movement_stock']
        body+=f"<tr><td>{esc(r['name'])}</td><td>{r['stock']}</td><td>{r['movement_stock']}</td><td>{diff:+d}</td><td>{'Совпадает' if diff==0 else 'Проверить'}</td></tr>"
    body+="</table></div></div><div class='card'><h2>Закрытые смены с расхождениями</h2><p class='muted'>Показываются только смены, где фактический остаток отличается от расчётного. Проверьте чеки, расходы и способ оплаты; значения прошлой сверки автоматически не меняются.</p><div class='tablewrap'><table><tr><th>Смена</th><th>Наличные: расчёт</th><th>Наличные: факт</th><th>Разница</th><th>Безнал: расчёт</th><th>Безнал: факт</th><th>Разница</th><th>Комментарий</th></tr>"
    for r in bad_cash_shifts:
        body+=f"<tr><td>#{r['id']} · {esc(r['shift_date'])}</td><td>{r['expected_cash']} ₽</td><td>{r['actual_cash']} ₽</td><td>{r['cash_difference']:+d} ₽</td><td>{r['expected_noncash']} ₽</td><td>{r['actual_noncash']} ₽</td><td>{r['noncash_difference']:+d} ₽</td><td>{esc(r['note'] or '')}</td></tr>"
    if not bad_cash_shifts: body+="<tr><td colspan='8'>Смен с ненулевой разницей не найдено</td></tr>"
    body+="</table></div></div><div class='card'><h2>Проверка арифметики сохранённых закрытий</h2><p class='muted'>Здесь показаны закрытые смены, где сохранённая разница не равна факту минус расчёту. Это отдельная проверка целостности записи, даже если обычное расхождение показывает ноль. Значения не исправляются автоматически.</p><p><a class='btn' href='/reconciliation/cash-shift-mismatches.csv'>Экспорт CSV</a></p><div class='tablewrap'><table><tr><th>Смена</th><th>Сохранённая разница наличных</th><th>Рассчитанная разница наличных</th><th>Сохранённая разница безнала</th><th>Рассчитанная разница безнала</th><th>Закрыта</th></tr>"
    for r in cash_shift_math_mismatches:
        body+=f"<tr><td>#{r['id']} · {esc(r['shift_date'])}</td><td>{r['cash_difference']} ₽</td><td>{r['calculated_cash_difference']:+d} ₽</td><td>{r['noncash_difference']} ₽</td><td>{r['calculated_noncash_difference']:+d} ₽</td><td>{esc(r['closed_at'])}</td></tr>"
    if not cash_shift_math_mismatches: body+="<tr><td colspan='6'>Ошибок арифметики сохранённых закрытий не найдено</td></tr>"
    body+="</table></div></div><div class='card'><h2>Расходы, внесённые после закрытия смены</h2><p class='muted'>Расходы, внесённые позже закрытия смены, но с датой расхода не позже даты закрытия. Это повод проверить первичные документы; история закрытия не переписывается.</p><p><a class='btn' href='/reconciliation/late-expenses.csv'>Экспорт CSV</a></p><div class='tablewrap'><table><tr><th>Расход</th><th>Дата расхода</th><th>Описание</th><th>Сумма</th><th>Оплата</th><th>Внесён</th><th>Затронутая смена</th><th>Кем внесён</th></tr>"
    for r in late_cash_expenses:
        body+=f"<tr><td>#{r['id']}</td><td>{esc(r['expense_date'])}</td><td>{esc(r['description'])}</td><td>{r['amount']} ₽</td><td>{esc(r['payment_method'])}</td><td>{esc(r['created_at'])}</td><td>#{r['affected_shift_id']} · {esc(r['affected_shift_date'])}</td><td>{esc(r['created_by_name'])}</td></tr>"
    if not late_cash_expenses: body+="<tr><td colspan='8'>Поздно внесённых расходов не найдено</td></tr>"
    body+="</table></div></div><div class='card'><h2>Продажи и абонементы</h2><div class='tablewrap'><table><tr><th>Продажа</th><th>Позиция</th><th>Статус</th><th>Абонемент</th></tr>"
    for r in bad_sales:
        body+=f"<tr><td>#{r['id']}</td><td>{esc(r['item'])}</td><td>{esc(r['status'])}</td><td>{r['subscription_id']}</td></tr>"
    if not bad_sales: body+="<tr><td colspan='4'>Подозрительных связей не найдено</td></tr>"
    body+="</table></div></div><div class='card'><h2>Возвраты для ручной проверки</h2><p class='muted'>Сверка использует явную связь возврата с исходной продажей. Старые возвраты, созданные до этой версии, не связаны автоматически и могут попасть сюда — проверьте документы вручную.</p><div class='tablewrap'><table><tr><th>Запрос</th><th>Продажа</th><th>Статус запроса</th><th>Статус продажи</th><th>Сумма продажи</th><th>Найдено возвратов</th></tr>"
    for r in bad_refunds:
        body+=f"<tr><td>#{r['request_id']}</td><td>#{r['sale_id']}</td><td>{esc(r['request_status'])}</td><td>{esc(r['sale_status'])}</td><td>{r['original_amount']} ₽</td><td>{r['refund_count']}</td></tr>"
    if not bad_refunds: body+="<tr><td colspan='6'>Подозрительных возвратов не найдено</td></tr>"
    body+="</table></div></div><div class='card'><h2>Посещения и абонементы</h2><div class='tablewrap'><table><tr><th>Посещение</th><th>Дата</th><th>Время</th><th>Статус</th><th>Абонемент</th><th>Клиент</th></tr>"
    for r in bad_attendance:
        body+=f"<tr><td>#{r['id']}</td><td>{esc(r['lesson_date'])}</td><td>{esc(r['lesson_time'])}</td><td>{esc(r['status'])}</td><td>{r['subscription_id']}</td><td>{r['client_id']}</td></tr>"
    if not bad_attendance: body+="<tr><td colspan='6'>Подозрительных связей не найдено</td></tr>"
    body+="</table></div></div><div class='card'><h2>Неоднозначные данные для зарплаты</h2><p class='muted'>В одном групповом слоте у посещений должны совпадать тренер и ставка. Эти записи не исправляются автоматически: проверьте расписание и историю начислений.</p><div class='tablewrap'><table><tr><th>Слот</th><th>Дата</th><th>Время</th><th>Детей</th><th>Тренеры в записях</th><th>Диапазон ставки</th></tr>"
    for r in bad_payroll_slots:
        body+=f"<tr><td>#{r['schedule_slot_id']}</td><td>{esc(r['lesson_date'])}</td><td>{esc(r['lesson_time'])}</td><td>{r['children_count']}</td><td>{esc(r['trainers'] or '')}</td><td>{r['min_rate']}–{r['max_rate']} ₽</td></tr>"
    if not bad_payroll_slots: body+="<tr><td colspan='6'>Неоднозначных групповых слотов не найдено</td></tr>"
    body+="</table></div></div><div class='card'><h2>Остатки абонементов</h2><div class='tablewrap'><table><tr><th>Абонемент</th><th>Клиент ID</th><th>Всего занятий</th><th>Осталось</th><th>Статус</th></tr>"
    for r in bad_subscriptions:
        body+=f"<tr><td>#{r['id']} — {esc(r['title'])}</td><td>{r['client_id']}</td><td>{r['total_lessons']}</td><td>{r['remaining_lessons']}</td><td>{esc(r['status'])}</td></tr>"
    if not bad_subscriptions: body+="<tr><td colspan='5'>Подозрительных остатков не найдено</td></tr>"
    return page("Сверка данных",body+"</table></div></div>")


@app.get("/payroll")
@manager_required
def payroll():
    from datetime import date
    from payroll_calculation import get_payroll_sessions, get_ambiguous_payroll_slot_count, summarize_payroll_sessions
    start=request.args.get("start",date.today().replace(day=1).isoformat())
    end=request.args.get("end",date.today().isoformat())
    try:
        date.fromisoformat(start); date.fromisoformat(end)
    except ValueError: abort(400,"Укажите даты в формате ГГГГ-ММ-ДД")
    if start>end: abort(400,"Начальная дата не может быть позже конечной")
    with connect() as c:
        sessions=get_payroll_sessions(c,start,end)
        rows=summarize_payroll_sessions(sessions)
        bad_payroll_slots=get_ambiguous_payroll_slot_count(c,start,end)
    total=sum(r["amount"] for r in rows)
    warning=(f"<div class='card'><h2>Требуют проверки: {bad_payroll_slots} групповых слотов</h2><p>Слоты с разными тренерами или ставками исключены из автоматического начисления, чтобы не назначать зарплату неверному сотруднику. Разберите их в <a href='/settings'>сверке данных</a>, затем пересчитайте период.</p></div>" if bad_payroll_slots else "")
    body=f"""<div class='card'><h2>Зарплата тренеров</h2><p>Начисление считается за тренировку тренера, а не за каждого ребёнка в группе. Один и тот же шаблон расписания может повторяться в разные дни: каждое фактическое занятие учитывается отдельно. Неоднозначные слоты временно исключаются из суммы до проверки.</p><form method='get'><label>С даты</label><input type='date' name='start' value='{esc(start)}' required><label>По дату</label><input type='date' name='end' value='{esc(end)}' required><button>Показать</button><a class='btn' href='/payroll.csv?start={esc(start)}&end={esc(end)}'>Экспорт CSV</a></form></div>{warning}
    <div class='card'><h2>Начислено за период</h2><p style='font-size:28px'>{total:,} ₽</p><div class='tablewrap'><table><tr><th>Тренер</th><th>Тренировок</th><th>К начислению</th></tr>"""
    for r in rows: body+=f"<tr><td>{esc(r['trainer'])}</td><td>{r['lessons']}</td><td>{r['amount']:,} ₽</td></tr>"
    body+="</table></div></div><div class='card'><h2>Детализация по тренировкам</h2><div class='tablewrap'><table><tr><th>Дата</th><th>Время</th><th>Тренер</th><th>Детей в слоте</th><th>Дети</th><th>Начисление за слот</th></tr>"
    for r in sessions: body+=f"<tr><td>{esc(r['lesson_date'])}</td><td>{esc(r['lesson_time'])}</td><td>{esc(r['trainer'])}</td><td>{r['children_count']}</td><td>{esc(r['children'] or '')}</td><td>{r['rate_snapshot']} ₽</td></tr>"
    return page("Зарплата тренеров",body+"</table></div></div>")

@app.get("/payroll.csv")
@manager_required
def payroll_csv():
    import csv, io
    from flask import Response
    from datetime import date
    from payroll_calculation import get_payroll_sessions
    start=request.args.get("start",date.today().replace(day=1).isoformat())
    end=request.args.get("end",date.today().isoformat())
    try:
        date.fromisoformat(start); date.fromisoformat(end)
    except ValueError: abort(400,"Укажите даты в формате ГГГГ-ММ-ДД")
    if start>end: abort(400,"Начальная дата не может быть позже конечной")
    with connect() as c:
        rows=get_payroll_sessions(c,start,end)
    out=io.StringIO(); w=csv.writer(out,delimiter=';')
    w.writerow(["Дата","Время","Тренер","Детей в слоте","Дети","Начисление за тренировку, ₽"])
    w.writerows([safe_csv_row((r["lesson_date"],r["lesson_time"],r["trainer"],r["children_count"],r["children"] or "",r["rate_snapshot"])) for r in rows])
    return Response("\ufeff"+out.getvalue(),mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition":f"attachment; filename=payroll_{start}_{end}.csv", "Cache-Control":"no-store", "Pragma":"no-cache"})

@app.get("/reports")
@manager_required
def reports():
    from datetime import date
    start=request.args.get("start",date.today().replace(day=1).isoformat())
    end=request.args.get("end",date.today().isoformat())
    try:
        date.fromisoformat(start); date.fromisoformat(end)
    except ValueError:
        abort(400,"Укажите даты в формате ГГГГ-ММ-ДД")
    if start>end: abort(400,"Начальная дата не может быть позже конечной")
    with connect() as c:
        rows=c.execute("""SELECT s.id,s.item,s.amount,s.payment_method,s.status,s.created_at,
          cl.child_name, u.username
          FROM sales s JOIN clients cl ON cl.id=s.client_id
          LEFT JOIN users u ON u.id=s.created_by
          WHERE substr(s.created_at,1,10) BETWEEN ? AND ?
          ORDER BY s.created_at DESC""",(start,end)).fetchall()
        totals=c.execute("""SELECT
          COALESCE(SUM(CASE WHEN status='completed' THEN amount ELSE 0 END),0) gross,
          COALESCE(SUM(CASE WHEN status='refund' THEN amount ELSE 0 END),0) refunds,
          COALESCE(SUM(CASE WHEN status='completed' THEN amount WHEN status='refund' THEN -amount ELSE 0 END),0) net
          FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ?""",(start,end)).fetchone()
        methods=c.execute("""SELECT payment_method,
          COALESCE(SUM(CASE WHEN status='completed' THEN amount WHEN status='refund' THEN -amount ELSE 0 END),0) net
          FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? GROUP BY payment_method""",(start,end)).fetchall()
    body=f"""<div class="card"><h2>Отчёт по продажам</h2>
    <form method="get"><label>С даты</label><input type="date" name="start" value="{esc(start)}" required>
    <label>По дату</label><input type="date" name="end" value="{esc(end)}" required><button>Показать</button>
    <a class="btn" href="/reports.csv?start={esc(start)}&end={esc(end)}">Экспорт CSV</a></form></div>
    <div class="grid"><div class="card"><h2>Продажи до возвратов</h2><p style="font-size:28px">{totals['gross']:,} ₽</p></div>
    <div class="card"><h2>Возвраты</h2><p style="font-size:28px">{totals['refunds']:,} ₽</p></div>
    <div class="card"><h2>Чистая сумма</h2><p style="font-size:28px">{totals['net']:,} ₽</p></div></div>
    <div class="card"><h2>По способам оплаты</h2><table><tr><th>Способ</th><th>Сумма с учётом возвратов</th></tr>"""
    labels={"cash":"Наличные","card":"Карта","transfer":"Перевод","qr":"QR"}
    for r in methods:
        body+=f"<tr><td>{labels.get(r['payment_method'],esc(r['payment_method']))}</td><td>{r['net']:,} ₽</td></tr>"
    body+="</table></div><div class='card'><h2>Операции</h2><div class='tablewrap'><table><tr><th>Дата</th><th>№</th><th>Клиент</th><th>Позиция</th><th>Сумма</th><th>Оплата</th><th>Тип</th><th>Сотрудник</th></tr>"
    for r in rows:
        signed=f"-{r['amount']:,}" if r["status"]=="refund" else f"{r['amount']:,}"
        kind="Возврат" if r["status"]=="refund" else ("Продажа" if r["status"]=="completed" else esc(r["status"]))
        body+=f"<tr><td>{esc(r['created_at'])}</td><td>{r['id']}</td><td>{esc(r['child_name'])}</td><td>{esc(r['item'])}</td><td>{signed} ₽</td><td>{esc(r['payment_method'])}</td><td>{kind}</td><td>{esc(r['username'] or '')}</td></tr>"
    return page("Отчёты",body+"</table></div></div>")

@app.get("/reports.csv")
@manager_required
def reports_csv():
    import csv, io
    from flask import Response
    from datetime import date
    start=request.args.get("start",date.today().replace(day=1).isoformat())
    end=request.args.get("end",date.today().isoformat())
    try:
        date.fromisoformat(start); date.fromisoformat(end)
    except ValueError: abort(400,"Некорректный диапазон дат")
    if start>end: abort(400,"Некорректный диапазон дат")
    with connect() as c:
        rows=c.execute("""SELECT s.id,s.created_at,cl.child_name,s.item,s.amount,s.payment_method,s.status,u.username
          FROM sales s JOIN clients cl ON cl.id=s.client_id LEFT JOIN users u ON u.id=s.created_by
          WHERE substr(s.created_at,1,10) BETWEEN ? AND ? ORDER BY s.created_at""",(start,end)).fetchall()
    buf=io.StringIO()
    writer=csv.writer(buf,delimiter=";")
    writer.writerow(["Номер","Дата","Ребёнок","Позиция","Сумма ₽","Способ оплаты","Статус","Сотрудник"])
    for r in rows:
        amount=-r["amount"] if r["status"]=="refund" else r["amount"]
        writer.writerow(safe_csv_row([r["id"],r["created_at"],r["child_name"],r["item"],amount,r["payment_method"],r["status"],r["username"] or ""]))
    return Response("\ufeff"+buf.getvalue(),mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition":f'attachment; filename="lider_sales_{start}_{end}.csv"'})


@app.get("/attendance-report")
@login_required
def attendance_report_page():
    """Read-only report of attended/missed/cancelled lessons and net sales."""
    start = request.args.get("start", date.today().replace(day=1).isoformat())
    end = request.args.get("end", date.today().isoformat())
    try:
        start, end = validate_attendance_period(start, end)
    except ValueError as exc:
        abort(400, str(exc))
    with connect() as c:
        rows = get_attendance_report_rows(c, start, end)
    is_manager = is_current_manager()
    report_headers = "<th>Продажи за период</th><th>Сумма после возвратов</th>" if is_manager else ""
    body = ("<div class='card'><h2>Отчёт посещаемости</h2><p>Сводка по посещённым, пропущенным и отменённым занятиям за выбранный период. Финансовые показатели видны только руководителю.</p>"
        f"<form method='get'><label>С даты</label><input type='date' name='start' value='{esc(start)}' required><label>По дату</label><input type='date' name='end' value='{esc(end)}' required><button>Показать</button></form>"
        f"<p><a class='btn' href='/attendance-report.csv?start={esc(start)}&amp;end={esc(end)}'>Экспорт CSV</a></p></div>"
        f"<div class='card'><div class='tablewrap'><table><tr><th>Ребёнок / родитель</th><th>Телефон</th><th>Статус</th><th>Посетил</th><th>Пропуск</th><th>Отменено</th><th>Первое / последнее посещение</th>{report_headers}</tr>")
    for r in rows:
        financial_cells = f"<td>{int(r['completed_sales'])}</td><td>{int(r['net_sales']):,} ₽</td>" if is_manager else ""
        body += (f"<tr><td><a href='/client/{int(r['client_id'])}'>{esc(r['child_name'])}</a><br><small>{esc(r['parent_name'])}</small></td>"
            f"<td>{esc(r['phone'])}</td><td>{esc(r['client_status'])}</td><td>{int(r['attended_count'])}</td><td>{int(r['missed_count'])}</td>"
            f"<td>{int(r['cancelled_count'])}</td><td>{esc(r['first_attended'] or '—')} / {esc(r['last_attended'] or '—')}</td>{financial_cells}</tr>")
    if not rows:
        body += "<tr><td colspan='9'>За выбранный период данных нет.</td></tr>"
    body += "</table></div><p class='muted'>Отчёт только читает историю; посещения, продажи и статусы клиентов не меняются.</p></div>"
    return page("Отчёт посещаемости", body)


@app.get("/attendance-report.csv")
@login_required
def attendance_report_csv():
    start = request.args.get("start", date.today().replace(day=1).isoformat())
    end = request.args.get("end", date.today().isoformat())
    try:
        start, end = validate_attendance_period(start, end)
    except ValueError as exc:
        abort(400, str(exc))
    with connect() as c:
        rows = get_attendance_report_rows(c, start, end)
    output = io.StringIO(newline="")
    writer = csv.writer(output, delimiter=";", lineterminator="\r\n")
    is_manager = is_current_manager()
    headers = ["ID клиента", "Ребёнок", "Родитель", "Телефон", "Статус", "Посещено", "Пропуск", "Отменено", "Первое посещение", "Последнее посещение"]
    if is_manager:
        headers += ["Продаж", "Сумма после возвратов, ₽"]
    writer.writerow(headers)
    for r in rows:
        values = [r["client_id"],r["child_name"],r["parent_name"],r["phone"],r["client_status"],r["attended_count"],r["missed_count"],r["cancelled_count"],r["first_attended"],r["last_attended"]]
        if is_manager:
            values += [r["completed_sales"],r["net_sales"]]
        writer.writerow(safe_csv_row(values))
    response = app.response_class("\ufeff" + output.getvalue(), mimetype="text/csv; charset=utf-8")
    response.headers["Content-Disposition"] = f'attachment; filename="lider_attendance_{start}_{end}.csv"'
    response.headers["Cache-Control"] = "no-store"
    response.headers["Pragma"] = "no-cache"
    return response


@app.get("/one-visit")
@login_required
def one_visit_report_page():
    """Find clients with exactly one attended lesson ever in a selected period."""
    start = request.args.get("start", (date.today() - timedelta(days=90)).isoformat())
    end = request.args.get("end", date.today().isoformat())
    try:
        start, end = validate_attendance_period(start, end)
    except ValueError as exc:
        abort(400, str(exc))
    with connect() as c:
        rows = get_one_visit_rows(c, start, end)
    body = ("<div class='card'><h2>Клиенты с одним посещением</h2><p>Показываются активные, неактивные и потерянные клиенты, у которых за всю историю ровно одно проведённое занятие, и оно попало в выбранный период. Архивные клиенты исключены. Это список для ручной работы администратора, статусы не меняются.</p>"
        f"<form method='get'><label>С даты</label><input type='date' name='start' value='{esc(start)}' required><label>По дату</label><input type='date' name='end' value='{esc(end)}' required><button>Показать</button></form></div>"
        "<div class='card'><div class='tablewrap'><table><tr><th>Ребёнок / родитель</th><th>Телефон</th><th>Статус</th><th>Единственное посещение</th><th>Действие</th></tr>")
    for r in rows:
        body += (f"<tr><td><a href='/client/{int(r['client_id'])}'>{esc(r['child_name'])}</a><br><small>{esc(r['parent_name'])}</small></td>"
            f"<td>{esc(r['phone'])}</td><td>{esc(r['client_status'])}</td><td>{esc(r['first_visit'])} {esc(r['first_visit_time'])}</td>"
            f"<td><a class='btn' href='/client/{int(r['client_id'])}'>Открыть карточку</a></td></tr>")
    if not rows:
        body += "<tr><td colspan='5'>Таких клиентов за период не найдено.</td></tr>"
    body += "</table></div><p class='muted'>Проверяйте историю контактов и причину отсутствия перед повторным звонком.</p></div>"
    return page("Одно посещение", body)


@app.route("/leads", methods=["GET","POST"])
@login_required
def leads_page():
    statuses={"new":"Новая","contacted":"Связались","trial_booked":"Пробное занятие","converted":"Клиент","lost":"Не состоялась"}
    with connect() as c:
        if request.method=="POST":
            action=request.form.get("action","create")
            if action=="update":
                try: lid=int(request.form["lead_id"])
                except (KeyError,ValueError): abort(400,"Неверная заявка")
                status=request.form.get("status","new")
                if status not in statuses: abort(400,"Недопустимый статус заявки")
                existing_lead=c.execute("SELECT client_id FROM leads WHERE id=?",(lid,)).fetchone()
                if not existing_lead: abort(404,"Заявка не найдена")
                if status=="converted" and not existing_lead["client_id"]:
                    abort(400,"Чтобы отметить заявку как клиента, сначала используйте действие «Создать карточку клиента»")
                next_contact=request.form.get("next_contact","").strip()
                if next_contact:
                    try: date.fromisoformat(next_contact)
                    except ValueError: abort(400,"Некорректная дата перезвона")
                cur=c.execute("UPDATE leads SET status=?,next_contact=?,notes=?,updated_at=? WHERE id=?",
                    (status,next_contact,request.form.get("notes","").strip(),now(),lid))
                if cur.rowcount!=1: abort(404,"Заявка не найдена")
                audit(c,"lead.updated","lead",lid,{"status":status,"next_contact":next_contact})
                return redirect(url_for("leads_page"))
            if action=="convert":
                try: lid=int(request.form["lead_id"])
                except (KeyError,ValueError): abort(400,"Неверная заявка")
                lead=c.execute("SELECT * FROM leads WHERE id=?",(lid,)).fetchone()
                if not lead: abort(404,"Заявка не найдена")
                if lead["client_id"]:
                    return redirect(url_for("client_profile",client_id=lead["client_id"]))
                existing=c.execute("SELECT id FROM clients WHERE phone=? ORDER BY id LIMIT 1",(lead["phone"],)).fetchone()
                if existing:
                    client_id=existing["id"]
                else:
                    child=lead["child_name"].strip() or "Ребёнок — уточнить имя"
                    cur=c.execute("INSERT INTO clients(child_name,parent_name,phone,notes,created_at) VALUES(?,?,?,?,?)",
                        (child,lead["parent_name"],lead["phone"],"Создано из заявки №"+str(lid)+(". "+lead["notes"] if lead["notes"] else ""),now()))
                    client_id=cur.lastrowid
                c.execute("UPDATE leads SET status='converted',client_id=?,updated_at=? WHERE id=?",(client_id,now(),lid))
                audit(c,"lead.converted","lead",lid,{"client_id":client_id})
                return redirect(url_for("client_profile",client_id=client_id))
            parent=request.form.get("parent_name","").strip(); child=request.form.get("child_name","").strip()
            phone=request.form.get("phone","").strip(); source=request.form.get("source","").strip()
            status=request.form.get("status","new"); next_contact=request.form.get("next_contact","").strip()
            if not parent or not phone: abort(400,"Укажите имя родителя и телефон")
            if status not in statuses: abort(400,"Недопустимый статус заявки")
            if status=="converted": abort(400,"Новую заявку нельзя сразу отметить клиентом: сначала сохраните её, затем создайте карточку клиента")
            if next_contact:
                try: date.fromisoformat(next_contact)
                except ValueError: abort(400,"Некорректная дата перезвона")
            cur=c.execute("INSERT INTO leads(parent_name,child_name,phone,source,status,next_contact,notes,assigned_to,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (parent,child,phone,source,status,next_contact,request.form.get("notes","").strip(),session["uid"],session["uid"],now(),now()))
            audit(c,"lead.created","lead",cur.lastrowid,{"source":source,"status":status})
            return redirect(url_for("leads_page"))
        rows=c.execute("SELECT l.*,u.username FROM leads l LEFT JOIN users u ON u.id=l.assigned_to ORDER BY CASE status WHEN 'new' THEN 0 WHEN 'contacted' THEN 1 WHEN 'trial_booked' THEN 2 WHEN 'converted' THEN 3 ELSE 4 END, COALESCE(NULLIF(next_contact,''),'9999-12-31'), l.id DESC LIMIT 500").fetchall()
    form="""<div class='card'><h2>Новая заявка</h2><form method='post'><label>Родитель *</label><input name='parent_name' required><label>Ребёнок</label><input name='child_name'><label>Телефон *</label><input name='phone' required><label>Источник</label><select name='source'><option>Звонок</option><option>Сайт</option><option>Яндекс Карты</option><option>2ГИС</option><option>Авито</option><option>Рекомендация</option><option>Другое</option></select><label>Статус</label><select name='status'><option value='new'>Новая</option><option value='contacted'>Связались</option><option value='trial_booked'>Записан на пробное</option><option value='converted'>Стали клиентом</option><option value='lost'>Не состоялась</option></select><label>Когда перезвонить</label><input type='date' name='next_contact'><label>Комментарий</label><textarea name='notes'></textarea><button>Сохранить заявку</button></form></div>"""
    table="<div class='card'><h2>Воронка заявок и перезвоны</h2><div class='tablewrap'><table><tr><th>Дата</th><th>Родитель / ребёнок</th><th>Телефон</th><th>Источник</th><th>Статус / перезвон</th><th>Комментарий</th><th>Действия</th></tr>"
    for r in rows:
        overdue=bool(r["next_contact"] and r["next_contact"]<=today() and r["status"] not in ("converted","lost"))
        rowstyle=" style='background:#fff0e8'" if overdue else ""
        # Do not offer a manual "converted" status without a linked client card;
        # conversion is a dedicated audited action that creates/reuses the client.
        visible_statuses = statuses if r["client_id"] else {k:v for k,v in statuses.items() if k != "converted"}
        status_opts="".join(f"<option value='{v}' {'selected' if r['status']==v else ''}>{label}</option>" for v,label in visible_statuses.items())
        update=f"""<form method='post'><input type='hidden' name='action' value='update'><input type='hidden' name='lead_id' value='{r['id']}'><select name='status'>{status_opts}</select><input type='date' name='next_contact' value='{esc(r['next_contact'])}' title='Дата следующего контакта'><textarea name='notes' placeholder='Комментарий'>{esc(r['notes'])}</textarea><button>Сохранить</button></form>"""
        convert=""
        if r["status"]!="converted":
            convert=f"<form method='post'><input type='hidden' name='action' value='convert'><input type='hidden' name='lead_id' value='{r['id']}'><button>Создать карточку клиента</button></form>"
        elif r["client_id"]:
            convert=f"<a class='btn' href='/client/{r['client_id']}'>Открыть клиента</a>"
        table+=f"<tr{rowstyle}><td>{esc(r['created_at'])}</td><td>{esc(r['parent_name'])} / {esc(r['child_name'])}</td><td>{esc(r['phone'])}</td><td>{esc(r['source'])}</td><td>{'⚠️ Перезвонить: ' if overdue else ''}{esc(r['next_contact'])}</td><td>{esc(r['notes'])}</td><td>{update}{convert}</td></tr>"
    return page("Заявки",form+table+"</table></div></div>")

@app.route("/trial-lessons", methods=["GET", "POST"])
@login_required
def trial_lessons_page():
    """Administrator-managed trial lessons; no automatic sale, subscription use, or payroll."""
    if request.method == "POST":
        action = request.form.get("action", "book")
        try:
            with connect() as c:
                if action == "book":
                    lead_id = int(request.form.get("lead_id", "0"))
                    slot_id = int(request.form.get("slot_id", "0"))
                    result = book_trial(c, lead_id=lead_id, slot_id=slot_id, actor_id=session["uid"], created_at=now(), today_date=today())
                    audit(c, "trial.booked", "booking", result["booking_id"], result)
                elif action in ("attended", "missed"):
                    booking_id = int(request.form.get("booking_id", "0"))
                    result = mark_trial_outcome(c, booking_id=booking_id, outcome=action, actor_id=session["uid"], created_at=now(), today_date=today())
                    audit(c, "trial.outcome", "booking", booking_id, result)
                elif action == "cancel":
                    booking_id = int(request.form.get("booking_id", "0"))
                    result = cancel_trial(c, booking_id=booking_id, created_at=now(), today_date=today())
                    audit(c, "trial.cancelled", "booking", booking_id, result)
                else:
                    abort(400, "Недопустимое действие с пробным занятием")
        except (ValueError, TypeError, sqlite3.IntegrityError) as exc:
            abort(400, str(exc) or "Пробная запись уже существует; обновите страницу")
        return redirect(url_for("trial_lessons_page"))
    with connect() as c:
        leads = c.execute("SELECT l.id,l.parent_name,l.child_name,l.phone,l.client_id,l.status FROM leads l JOIN clients cl ON cl.id=l.client_id WHERE l.status!='lost' AND cl.status!='archived' AND NOT EXISTS (SELECT 1 FROM bookings b WHERE b.lead_id=l.id AND b.booking_type='trial' AND b.status!='cancelled') ORDER BY l.created_at DESC LIMIT 500").fetchall()
        slots = c.execute("SELECT sl.id,sl.slot_date,sl.slot_time,sl.duration_minutes,sl.capacity,sl.kind,t.name trainer_name,COALESCE((SELECT COUNT(*) FROM bookings b WHERE b.slot_id=sl.id AND b.status='booked'),0) occupied FROM schedule_slots sl JOIN trainers t ON t.id=sl.trainer_id WHERE (sl.slot_date>? OR (sl.slot_date=? AND sl.slot_time>?)) AND t.active=1 ORDER BY sl.slot_date,sl.slot_time LIMIT 1000", (today(), today(), datetime.now().strftime("%H:%M"))).fetchall()
        rows = c.execute("SELECT b.id booking_id,b.status booking_status,b.booking_type,l.id lead_id,l.client_id,l.parent_name,l.child_name,l.phone,sl.slot_date,sl.slot_time,sl.duration_minutes,t.name trainer_name,ta.status trial_outcome FROM bookings b JOIN leads l ON l.id=b.lead_id JOIN schedule_slots sl ON sl.id=b.slot_id JOIN trainers t ON t.id=sl.trainer_id LEFT JOIN trial_attendance ta ON ta.booking_id=b.id WHERE b.booking_type='trial' ORDER BY CASE b.status WHEN 'booked' THEN 0 ELSE 1 END,sl.slot_date,sl.slot_time LIMIT 1000").fetchall()
    lead_opts = "".join(f"<option value='{r['id']}'>Заявка #{r['id']} · {esc(r['child_name'] or 'Имя не указано')} · {esc(r['parent_name'])} · {esc(r['phone'])}</option>" for r in leads)
    slot_opts = "".join(f"<option value='{r['id']}' {'disabled' if r['occupied']>=r['capacity'] else ''}>{esc(r['slot_date'])} {esc(r['slot_time'])} · {esc(r['trainer_name'])} · {'Группа' if r['kind']=='group' else 'Индивидуально'} · {r['occupied']}/{r['capacity']} мест</option>" for r in slots)
    form = "<div class='card'><h2>Записать заявку на пробное занятие</h2><p class='muted'>Сначала создайте карточку клиента из заявки. Пробное занятие не создаёт продажу, не списывает абонемент и не добавляет начисление зарплаты автоматически.</p>"
    if lead_opts and slot_opts:
        form += f"<form method='post'><input type='hidden' name='action' value='book'><label>Заявка / клиент</label><select name='lead_id' required>{lead_opts}</select><label>Свободный слот</label><select name='slot_id' required>{slot_opts}</select><button>Записать на пробное</button></form>"
    else:
        form += "<p>Для записи нужны заявка, связанная с карточкой клиента, и свободный слот расписания.</p>"
    form += "</div><div class='card'><h2>Пробные занятия</h2><div class='tablewrap'><table><tr><th>Дата и время</th><th>Ребёнок / родитель</th><th>Тренер</th><th>Статус</th><th>Действия</th></tr>"
    labels = {"booked":"Записан", "attended":"Посетил", "missed":"Не пришёл", "cancelled":"Отменён"}
    for r in rows:
        actions = ""
        if r['booking_status'] == 'booked':
            if f"{r['slot_date']}T{r['slot_time']}" <= now() and r['slot_date'] <= today():
                for action, label in (("attended", "Посетил"), ("missed", "Не пришёл")):
                    actions += f"<form method='post' style='display:inline'><input type='hidden' name='action' value='{action}'><input type='hidden' name='booking_id' value='{r['booking_id']}'><button>{label}</button></form> "
            else:
                actions = f"<form method='post' style='display:inline'><input type='hidden' name='action' value='cancel'><input type='hidden' name='booking_id' value='{r['booking_id']}'><button class='danger'>Отменить запись</button></form>"
        form += f"<tr><td>{esc(r['slot_date'])} {esc(r['slot_time'])} ({r['duration_minutes']} мин.)</td><td><a href='/client/{r['client_id']}'>{esc(r['child_name'] or 'Имя не указано')}</a><br>{esc(r['parent_name'])} · {esc(r['phone'])}</td><td>{esc(r['trainer_name'])}</td><td>{labels.get(r['booking_status'],esc(r['booking_status']))}</td><td>{actions or '—'}</td></tr>"
    if not rows:
        form += "<tr><td colspan='5'>Пробных занятий пока нет.</td></tr>"
    form += "</table></div><p class='muted'>Итог пробного занятия сохраняется отдельно от обычной посещаемости и зарплатных начислений до утверждения правил клуба.</p></div>"
    return page("Пробные занятия", form)


@app.route("/tasks", methods=["GET","POST"])
@login_required
def tasks_page():
    with connect() as c:
        if request.method=="POST":
            action=request.form.get("action","create")
            if action=="complete":
                try: tid=int(request.form["task_id"])
                except (KeyError,ValueError): abort(400,"Неверная задача")
                cur=c.execute("UPDATE tasks SET status='done',completed_at=? WHERE id=? AND status='open'",(now(),tid))
                if cur.rowcount!=1: abort(400,"Задача уже закрыта или не найдена")
                audit(c,"task.completed","task",tid,{})
                return redirect(url_for("tasks_page"))
            title=request.form.get("title","").strip(); due=request.form.get("due_at","").strip()
            if not title or not due: abort(400,"Укажите задачу и срок")
            try: datetime.fromisoformat(due)
            except ValueError: abort(400,"Срок укажите в формате даты и времени")
            try:
                client_id=int(request.form.get("client_id") or 0) or None
                lead_id=int(request.form.get("lead_id") or 0) or None
            except ValueError: abort(400,"Неверно указан клиент или заявка")
            if client_id and not c.execute("SELECT id FROM clients WHERE id=?",(client_id,)).fetchone(): abort(400,"Клиент не найден")
            if lead_id and not c.execute("SELECT id FROM leads WHERE id=?",(lead_id,)).fetchone(): abort(400,"Заявка не найдена")
            if client_id and lead_id: abort(400,"Свяжите задачу либо с клиентом, либо с заявкой")
            cur=c.execute("INSERT INTO tasks(title,client_id,lead_id,due_at,notes,assigned_to,created_by,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (title,client_id,lead_id,due,request.form.get("notes","").strip(),session["uid"],session["uid"],now()))
            audit(c,"task.created","task",cur.lastrowid,{"title":title,"due_at":due,"client_id":client_id,"lead_id":lead_id})
            return redirect(url_for("tasks_page"))
        clients=c.execute("SELECT id,child_name,parent_name,phone FROM clients WHERE status!='archived' ORDER BY child_name LIMIT 1000").fetchall()
        leads=c.execute("SELECT id,parent_name,child_name,phone FROM leads WHERE status NOT IN ('converted','lost') ORDER BY id DESC LIMIT 1000").fetchall()
        rows=c.execute("SELECT t.*,u.username,cl.child_name,cl.parent_name,le.parent_name lead_parent,le.child_name lead_child FROM tasks t LEFT JOIN users u ON u.id=t.assigned_to LEFT JOIN clients cl ON cl.id=t.client_id LEFT JOIN leads le ON le.id=t.lead_id ORDER BY CASE t.status WHEN 'open' THEN 0 ELSE 1 END,CASE WHEN t.status='open' AND t.due_at<? THEN 0 ELSE 1 END,t.due_at LIMIT 500",(now(),)).fetchall()
    client_opts="<option value=''>Без привязки</option>"+"".join(f"<option value='{r['id']}'>#{r['id']} {esc(r['child_name'])} — {esc(r['parent_name'])} ({esc(r['phone'])})</option>" for r in clients)
    lead_opts="<option value=''>Без привязки</option>"+"".join(f"<option value='{r['id']}'>#{r['id']} {esc(r['child_name'])} — {esc(r['parent_name'])} ({esc(r['phone'])})</option>" for r in leads)
    form=f"""<div class='card'><h2>Новое дело / напоминание</h2><form method='post'><label>Что сделать</label><input name='title' required><label>Срок (дата и время)</label><input type='datetime-local' name='due_at' required><div class='grid'><div><label>Связать с клиентом</label><select name='client_id'>{client_opts}</select></div><div><label>Или с заявкой</label><select name='lead_id'>{lead_opts}</select></div></div><label>Комментарий</label><textarea name='notes'></textarea><button>Создать задачу</button></form></div>"""
    table="<div class='card'><h2>Задачник и контроль перезвонов</h2><div class='tablewrap'><table><tr><th>Срок</th><th>Задача</th><th>Клиент / заявка</th><th>Комментарий</th><th>Статус</th><th></th></tr>"
    for r in rows:
        overdue=r['status']=='open' and r['due_at']<now()
        due_style=" style='background:#fff0e8;color:#8a321c;font-weight:600'" if overdue else ""
        if r['client_id']: linked=f"<a href='/client/{r['client_id']}'>{esc(r['child_name'])} — {esc(r['parent_name'])}</a>"
        elif r['lead_id']: linked=f"Заявка: {esc(r['lead_child'])} — {esc(r['lead_parent'])} (<a href='/leads'>открыть в заявках</a>)"
        else: linked="—"
        action=f"""<form method='post'><input type='hidden' name='action' value='complete'><input type='hidden' name='task_id' value='{r['id']}'><button>Выполнено</button></form>""" if r['status']=="open" else ""
        table+=f"<tr><td{due_style}>{'ПРОСРОЧЕНО · ' if overdue else ''}{esc(r['due_at'])}</td><td>{esc(r['title'])}</td><td>{linked}</td><td>{esc(r['notes'])}</td><td>{'Открыта' if r['status']=='open' else 'Выполнена'}</td><td>{action}</td></tr>"
    return page("Задачи",form+table+"</table></div></div>")

@app.get("/renewals.csv")
@login_required
def subscription_renewals_csv():
    try:
        days = normalize_horizon_days(request.args.get("days", "14"))
    except ValueError as exc:
        abort(400, str(exc))
    with connect() as c:
        rows = build_renewal_worklist(c, current_date=today(), horizon_days=days)
    fields = ("subscription_id", "client_id", "child_name", "parent_name", "phone", "title",
              "remaining_lessons", "total_lessons", "expires_at", "price", "priority")
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(fields)
    for row in rows:
        writer.writerow(safe_csv_row([row[field] for field in fields]))
    response = app.response_class("\ufeff" + output.getvalue(), mimetype="text/csv; charset=utf-8")
    response.headers["Content-Disposition"] = f'attachment; filename="lider_renewals_{days}_days.csv"'
    response.headers["Cache-Control"] = "no-store"
    return response


@app.get("/renewals")
@login_required
def subscription_renewals():
    """Action list for subscriptions that need a renewal conversation soon."""
    try:
        days = normalize_horizon_days(request.args.get("days", "14"))
    except ValueError as exc:
        abort(400, str(exc))
    current = today()
    horizon = (date.fromisoformat(current) + timedelta(days=days)).isoformat()
    with connect() as c:
        rows = build_renewal_worklist(c, current_date=current, horizon_days=days)
    body="<div class='card'><h2>Кому предложить продление</h2><p>Список активных клиентов, у которых осталось не больше двух занятий или абонемент заканчивается в ближайшие " + str(days) + " дней. Это подсказка для администратора: продажа автоматически не создаётся.</p>"
    body+=f"<div class='grid'><div class='card'><h3>На контроле</h3><p style='font-size:28px'>{len(rows)}</p></div><div class='card'><h3>Критично мало занятий</h3><p style='font-size:28px'>{sum(1 for r in rows if int(r['remaining_lessons'])<=1)}</p></div><div class='card'><h3>Срок до выбранного периода</h3><p style='font-size:28px'>{sum(1 for r in rows if r['expires_at'] and r['expires_at']<=horizon)}</p></div></div>"
    body += "<p>Период: " + " · ".join(f"<a href='/renewals?days={n}'>{n} дней</a>" for n in (7,14,30,60,90)) + " · <a class='btn' href='/renewals.csv?days=" + str(days) + "'>Экспорт CSV</a></p>"
    if not rows:
        body+="<p>Сейчас нет активных абонементов, требующих внимания по сроку или остатку.</p>"
    else:
        body+="<div class='tablewrap'><table><tr><th>Ребёнок / родитель</th><th>Телефон</th><th>Абонемент</th><th>Остаток</th><th>Действует до</th><th>Причина</th><th>Действие</th></tr>"
        for r in rows:
            reasons=[]
            if int(r['remaining_lessons'])<=2: reasons.append('Мало занятий')
            if r['expires_at'] and r['expires_at']<=horizon: reasons.append('Срок заканчивается')
            if r['expires_at'] and r['expires_at']<current: reasons.append('Срок истёк')
            body+=f"<tr><td>{esc(r['child_name'])}<br><small>{esc(r['parent_name'])}</small></td><td><a href='tel:{esc(r['phone'])}'>{esc(r['phone'])}</a></td><td>{esc(r['title'])}</td><td>{r['remaining_lessons']} / {r['total_lessons']}</td><td>{esc(r['expires_at'] or 'Не указан')}</td><td>{esc(', '.join(dict.fromkeys(reasons)))}</td><td><a class='btn' href='/client/{r['client_id']}'>Открыть карточку</a></td></tr>"
        body+="</table></div>"
    body+="<p class='muted'>Дата окончания берётся из карточки абонемента. Если срок не указан, клиент попадёт в список только по остатку занятий. CSV содержит контактные данные — храните его безопасно.</p></div>"
    return page("Продления абонементов",body)

@app.route("/reactivation", methods=["GET", "POST"])
@login_required
def client_reactivation():
    """Worklist for re-engaging former or inactive clients; contact history is explicit."""
    allowed_outcomes={"no_answer":"Не ответили","interested":"Интересуется","later":"Перезвонить позже","declined":"Отказался","returned":"Вернулся"}
    if request.method=="POST":
        try: client_id=int(request.form.get("client_id", ""))
        except ValueError: abort(400,"Некорректный клиент")
        outcome=request.form.get("outcome","")
        if outcome not in allowed_outcomes: abort(400,"Выберите результат контакта")
        note=request.form.get("notes","").strip()[:1000]
        next_contact=request.form.get("next_contact","").strip()
        if next_contact:
            try: date.fromisoformat(next_contact)
            except ValueError: abort(400,"Некорректная дата следующего звонка")
        try: assigned_to=int(request.form.get("assigned_to") or session["uid"])
        except ValueError: abort(400,"Некорректный ответственный")
        try: campaign_id=int(request.form.get("campaign_id") or 0)
        except ValueError: abort(400,"Некорректная кампания")
        with connect() as c:
            client=c.execute("SELECT id FROM clients WHERE id=?",(client_id,)).fetchone()
            if not client: abort(404,"Клиент не найден")
            staff=c.execute("SELECT id FROM users WHERE id=? AND active=1",(assigned_to,)).fetchone()
            if not staff: abort(400,"Выберите действующего сотрудника")
            if campaign_id and not c.execute("SELECT id FROM marketing_campaigns WHERE id=? AND status IN ('draft','active')",(campaign_id,)).fetchone():
                abort(400,"Кампания не найдена или уже закрыта")
            cur=c.execute("INSERT INTO client_outreach(client_id,outcome,notes,contacted_by,contacted_at,assigned_to,next_contact,campaign_id) VALUES(?,?,?,?,?,?,?,?)",
                (client_id,outcome,note,session["uid"],now(),assigned_to,next_contact,campaign_id or None))
            if outcome=="returned":
                c.execute("UPDATE clients SET status='active' WHERE id=? AND status IN ('inactive','archived','lost')",(client_id,))
            audit(c,"client.outreach_recorded","client",client_id,{"outcome":outcome,"outreach_id":cur.lastrowid})
        return redirect(url_for("client_reactivation",days=request.form.get("days","60")))

    try: days=int(request.args.get("days","60"))
    except ValueError: days=60
    days=max(14,min(days,730))
    cutoff=(date.today()-timedelta(days=days)).isoformat()
    show_recent=request.args.get("show_recent")=="1"
    with connect() as c:
        staff_rows=c.execute("SELECT id,username FROM users WHERE active=1 ORDER BY username").fetchall()
        campaigns=c.execute("SELECT id,name FROM marketing_campaigns WHERE status IN ('draft','active') ORDER BY name").fetchall()
        rows=c.execute("""SELECT cl.id,cl.child_name,cl.parent_name,cl.phone,cl.status,cl.created_at,
            (SELECT MAX(a.lesson_date) FROM attendance a WHERE a.client_id=cl.id AND a.status='attended') last_visit,
            (SELECT o.outcome FROM client_outreach o WHERE o.client_id=cl.id ORDER BY o.contacted_at DESC,o.id DESC LIMIT 1) last_outcome,
            (SELECT o.contacted_at FROM client_outreach o WHERE o.client_id=cl.id ORDER BY o.contacted_at DESC,o.id DESC LIMIT 1) last_contact,
            (SELECT o.notes FROM client_outreach o WHERE o.client_id=cl.id ORDER BY o.contacted_at DESC,o.id DESC LIMIT 1) last_note,
            (SELECT o.next_contact FROM client_outreach o WHERE o.client_id=cl.id ORDER BY o.contacted_at DESC,o.id DESC LIMIT 1) next_contact,
            (SELECT o.assigned_to FROM client_outreach o WHERE o.client_id=cl.id ORDER BY o.contacted_at DESC,o.id DESC LIMIT 1) outreach_assigned,
            (SELECT u.username FROM client_outreach o LEFT JOIN users u ON u.id=o.assigned_to WHERE o.client_id=cl.id ORDER BY o.contacted_at DESC,o.id DESC LIMIT 1) assigned_name
            FROM clients cl ORDER BY cl.child_name COLLATE NOCASE""").fetchall()
    candidates=[]
    for r in rows:
        last_visit=r["last_visit"] or ""
        old_visit=bool(last_visit and last_visit<cutoff)
        old_never_visited=not last_visit and (r["created_at"] or "")[:10]<cutoff
        former=r["status"] in ("inactive","archived","lost")
        if not (former or old_visit or old_never_visited): continue
        recent_contact=bool(r["last_contact"] and r["last_contact"][:10]>=(date.today()-timedelta(days=7)).isoformat())
        if recent_contact and not show_recent: continue
        candidates.append((r,former,old_visit or old_never_visited,recent_contact))
    candidates.sort(key=lambda item:(0 if item[1] else 1, item[0]["last_visit"] or item[0]["created_at"], item[0]["child_name"].casefold()))
    labels={"no_answer":"Не ответили","interested":"Интересуется","later":"Перезвонить позже","declined":"Отказался","returned":"Вернулся"}
    body="<div class='card'><h2>Возврат бывших клиентов</h2><p>Рабочий список для обзвона. Включает клиентов со статусом «Неактивный», «Архив» или «Потеряшка», а также клиентов без посещений за выбранный период. Контакт фиксируется вручную; массовых рассылок и автоматических изменений статусов нет.</p>"
    body+=f"<p><strong>К обзвону: {len(candidates)}</strong> · <a class='btn' href='/reactivation/report'>Отчёт и повторные звонки</a></p><form method='get'><label>Не посещали бассейн (дней)</label><select name='days'>"+"".join(f"<option value='{n}' {'selected' if n==days else ''}>{n}</option>" for n in (30,45,60,90,120,180,365))+"</select><label><input type='checkbox' name='show_recent' value='1' "+("checked" if show_recent else "")+"> Показывать тех, с кем уже связывались за последние 7 дней</label><button>Обновить список</button></form>"
    if not candidates:
        body+="<p>Нет клиентов, подходящих под выбранные условия.</p>"
    else:
        body+="<div class='tablewrap'><table><tr><th>Клиент</th><th>Телефон</th><th>Последнее посещение</th><th>Статус</th><th>Последний контакт / ответственный</th><th>Результат и следующий звонок</th></tr>"
        for r,former,stale,recent in candidates:
            why=[]
            if former: why.append("Бывший клиент")
            if stale: why.append("Давно не посещал")
            next_due=r['next_contact'] or ''
            assigned_selected=int(r['outreach_assigned'] or session['uid'])
            staff_opts="".join(f"<option value='{u['id']}' {'selected' if int(u['id'])==assigned_selected else ''}>{esc(u['username'])}</option>" for u in staff_rows)
            campaign_opts="<option value='0'>Без кампании</option>"+"".join(f"<option value='{cp['id']}'>{esc(cp['name'])}</option>" for cp in campaigns)
            body+=f"<tr><td><a href='/client/{r['id']}'>{esc(r['child_name'])}</a><br><small>{esc(r['parent_name'])}</small><br><small>#{r['id']} · {'; '.join(why)}</small></td><td><a href='tel:{esc(r['phone'])}'>{esc(r['phone'])}</a></td><td>{esc(r['last_visit'] or 'Нет посещений')}</td><td>{esc(r['status'])}</td><td>{esc(r['last_contact'] or 'Ещё не связывались')}<br><small>{esc(labels.get(r['last_outcome'],''))} · {esc(r['assigned_name'] or 'Не назначен')}</small></td><td><form method='post'><input type='hidden' name='client_id' value='{r['id']}'><input type='hidden' name='days' value='{days}'><select name='outcome'>"+"".join(f"<option value='{key}'>{label}</option>" for key,label in labels.items())+f"</select><label>Ответственный</label><select name='assigned_to'>{staff_opts}</select><label>Перезвонить</label><input type='date' name='next_contact' value='{esc(next_due)}'><label>Кампания</label><select name='campaign_id'>{campaign_opts}</select><input name='notes' placeholder='Краткий комментарий'><button>Сохранить контакт</button></form></td></tr>"
        body+="</table></div>"
    body+="<p class='muted'>Повторные контакты за последние 7 дней скрыты по умолчанию, но историю можно посмотреть, включив соответствующий фильтр. Результат «Вернулся» возвращает статус клиента в «Активный»; продажи и абонементы не создаются.</p></div>"
    return page("Возврат клиентов",body)

@app.route("/contact-log")
@login_required
def contact_log_page():
    start=request.args.get("start", (date.today()-timedelta(days=30)).isoformat()).strip()
    end=request.args.get("end", today()).strip()
    outcome=request.args.get("outcome", "").strip()
    search=request.args.get("q", "").strip()[:100]
    try:
        start_date=date.fromisoformat(start); end_date=date.fromisoformat(end)
        if start_date.isoformat()!=start or end_date.isoformat()!=end or end_date<start_date:
            raise ValueError
    except ValueError:
        abort(400,"Укажите корректный период журнала контактов")
    allowed_outcomes={"no_answer","interested","later","declined","returned"}
    if outcome and outcome not in allowed_outcomes: abort(400,"Неизвестный результат контакта")
    clauses=["date(o.contacted_at) BETWEEN ? AND ?"]
    params=[start,end]
    if outcome:
        clauses.append("o.outcome=?"); params.append(outcome)
    if search:
        clauses.append("(cl.child_name LIKE ? OR cl.parent_name LIKE ? OR cl.phone LIKE ? OR o.notes LIKE ?)")
        like=f"%{search}%"; params.extend([like,like,like,like])
    with connect() as c:
        rows=c.execute("""SELECT o.id,o.client_id,o.outcome,o.notes,o.contacted_at,o.next_contact,
            cl.child_name,cl.parent_name,cl.phone,u.username assigned_name,actor.username actor_name
            FROM client_outreach o JOIN clients cl ON cl.id=o.client_id
            LEFT JOIN users u ON u.id=o.assigned_to LEFT JOIN users actor ON actor.id=o.contacted_by
            WHERE """+" AND ".join(clauses)+" ORDER BY o.contacted_at DESC,o.id DESC LIMIT 1000",params).fetchall()
    labels={"no_answer":"Не ответил","interested":"Заинтересован","later":"Перезвонить позже","declined":"Отказ","returned":"Вернулся"}
    options="".join(f"<option value='{key}' {'selected' if outcome==key else ''}>{label}</option>" for key,label in labels.items())
    body=f"<div class='card'><h2>Журнал звонков и контактов</h2><p class='muted'>История контактов, внесённых в карточках возврата клиентов. Записи журнала не меняют продажи, абонементы или посещения.</p><form method='get'><div class='grid'><div><label>С даты</label><input type='date' name='start' value='{esc(start)}' required></div><div><label>По дату</label><input type='date' name='end' value='{esc(end)}' required></div><div><label>Результат</label><select name='outcome'><option value=''>Все результаты</option>{options}</select></div><div><label>Поиск по клиенту, телефону или заметке</label><input name='q' value='{esc(search)}' maxlength='100'></div></div><button>Показать</button></form></div>"
    body+="<div class='card'><h2>Контакты за период: "+str(len(rows))+" записей</h2><div class='tablewrap'><table><tr><th>Дата/время</th><th>Ребёнок / родитель</th><th>Телефон</th><th>Результат</th><th>Комментарий</th><th>Следующий контакт</th><th>Ответственный</th></tr>"
    for r in rows:
        body+=f"<tr><td>{esc(r['contacted_at'])}</td><td><a href='/client/{int(r['client_id'])}'>{esc(r['child_name'])}</a><br>{esc(r['parent_name'])}</td><td>{esc(r['phone'])}</td><td>{labels.get(r['outcome'],esc(r['outcome']))}</td><td>{esc(r['notes'])}</td><td>{esc(r['next_contact'] or '—')}</td><td>{esc(r['assigned_name'] or r['actor_name'] or '—')}</td></tr>"
    if not rows: body+="<tr><td colspan='7'>За выбранный период контактов нет.</td></tr>"
    return page("Журнал контактов",body+"</table></div></div>")


@app.get("/reactivation/report")
@login_required
def reactivation_report():
    """Contact outcomes and follow-up workload; not causal revenue attribution."""
    with connect() as c:
        outcomes=c.execute("SELECT outcome,COUNT(*) n FROM client_outreach GROUP BY outcome ORDER BY n DESC").fetchall()
        due=c.execute("""SELECT o.id,o.client_id,o.outcome,o.next_contact,o.notes,cl.child_name,cl.parent_name,cl.phone,u.username
            FROM client_outreach o JOIN clients cl ON cl.id=o.client_id
            LEFT JOIN users u ON u.id=o.assigned_to
            WHERE o.next_contact<>'' AND o.next_contact<=? AND o.outcome NOT IN ('returned','declined')
            AND o.id=(SELECT MAX(o2.id) FROM client_outreach o2 WHERE o2.client_id=o.client_id)
            ORDER BY o.next_contact,o.id""",(today(),)).fetchall()
        returned=c.execute("SELECT COUNT(*) n FROM client_outreach WHERE outcome='returned'").fetchone()['n']
        contacts=c.execute("SELECT COUNT(*) n FROM client_outreach").fetchone()['n']
    labels={"no_answer":"Не ответили","interested":"Интересуется","later":"Перезвонить позже","declined":"Отказался","returned":"Вернулся"}
    body=f"<div class='card'><h2>Эффективность возврата клиентов</h2><div class='grid'><div class='card'><h3>Всего контактов</h3><p style='font-size:26px'>{contacts}</p></div><div class='card'><h3>Отметили «Вернулся»</h3><p style='font-size:26px'>{returned}</p></div><div class='card'><h3>Контакты к повтору</h3><p style='font-size:26px'>{len(due)}</p></div></div><p class='muted'>Отчёт отражает результаты, которые внесли сотрудники. Доход от повторных продаж не приписывается звонкам автоматически: для этого нужна отдельная подтверждённая связь продажи с кампанией.</p></div><div class='card'><h2>Результаты контактов</h2><table><tr><th>Результат</th><th>Количество</th></tr>"
    for r in outcomes: body+=f"<tr><td>{labels.get(r['outcome'],esc(r['outcome']))}</td><td>{r['n']}</td></tr>"
    body+="</table></div><div class='card'><h2>Нужно перезвонить</h2>"
    if not due: body+="<p>Просроченных или сегодняшних повторных звонков нет.</p>"
    else:
        body+="<div class='tablewrap'><table><tr><th>Дата</th><th>Клиент</th><th>Телефон</th><th>Ответственный</th><th>Результат</th><th>Комментарий</th></tr>"
        for r in due: body+=f"<tr><td>{esc(r['next_contact'])}</td><td><a href='/client/{r['client_id']}'>{esc(r['child_name'])}</a><br><small>{esc(r['parent_name'])}</small></td><td><a href='tel:{esc(r['phone'])}'>{esc(r['phone'])}</a></td><td>{esc(r['username'] or 'Не назначен')}</td><td>{labels.get(r['outcome'],esc(r['outcome']))}</td><td>{esc(r['notes'])}</td></tr>"
        body+="</table></div>"
    return page("Отчёт возврата клиентов",body+"</div>")

@app.route("/campaigns", methods=["GET", "POST"])
@login_required
def marketing_campaigns():
    segments={"reactivation":"Возврат бывших клиентов","renewal":"Продление абонементов","inactive":"Неактивные клиенты","general":"Общая кампания"}
    statuses={"draft":"Черновик","active":"Активна","completed":"Завершена","cancelled":"Отменена"}
    if request.method=="POST":
        if not is_current_manager(): abort(403)
        action=request.form.get("action","create")
        if action=="cost":
            try:
                campaign_id=int(request.form.get("campaign_id",""))
                cost_amount=int(request.form.get("cost_amount",""))
            except ValueError: abort(400,"Укажите корректную кампанию и расходы в целых рублях")
            if cost_amount<0 or cost_amount>100_000_000: abort(400,"Расходы должны быть от 0 до 100 000 000 ₽")
            with connect() as c:
                cur=c.execute("UPDATE marketing_campaigns SET cost_amount=?,updated_at=? WHERE id=?",(cost_amount,now(),campaign_id))
                if cur.rowcount!=1: abort(404,"Кампания не найдена")
                audit(c,"marketing_campaign.cost_updated","marketing_campaign",campaign_id,{"cost_amount":cost_amount})
            return redirect(url_for("marketing_campaigns"))
        if action=="status":
            try: campaign_id=int(request.form.get("campaign_id",""))
            except ValueError: abort(400)
            status=request.form.get("status","")
            if status not in statuses: abort(400,"Некорректный статус")
            with connect() as c:
                c.execute("UPDATE marketing_campaigns SET status=?,updated_at=? WHERE id=?",(status,now(),campaign_id))
                audit(c,"marketing_campaign.status_changed","marketing_campaign",campaign_id,{"status":status})
            return redirect(url_for("marketing_campaigns"))
        name=request.form.get("name","").strip()[:120]
        segment=request.form.get("segment","reactivation")
        offer=request.form.get("offer","").strip()[:500]
        notes=request.form.get("notes","").strip()[:1000]
        try: cost_amount=int(request.form.get("cost_amount") or 0)
        except ValueError: abort(400,"Расходы кампании укажите целым числом рублей")
        if cost_amount<0 or cost_amount>100_000_000: abort(400,"Расходы должны быть от 0 до 100 000 000 ₽")
        if not name: abort(400,"Укажите название кампании")
        if segment not in segments: abort(400,"Выберите сегмент")
        with connect() as c:
            cur=c.execute("INSERT INTO marketing_campaigns(name,segment,status,offer,notes,created_by,created_at,updated_at,cost_amount) VALUES(?,?, 'draft',?,?,?,?,?,?)",(name,segment,offer,notes,session["uid"],now(),now(),cost_amount))
            audit(c,"marketing_campaign.created","marketing_campaign",cur.lastrowid,{"segment":segment,"cost_amount":cost_amount})
        return redirect(url_for("marketing_campaigns"))
    with connect() as c:
        rows=c.execute("""SELECT m.*,u.username,
          (SELECT COUNT(*) FROM client_outreach o WHERE o.campaign_id=m.id) contacts,
          (SELECT COUNT(*) FROM client_outreach o WHERE o.campaign_id=m.id AND o.outcome='returned') returned,
          (SELECT COUNT(DISTINCT o.client_id) FROM client_outreach o WHERE o.campaign_id=m.id) unique_contacted,
          (SELECT COUNT(DISTINCT o.client_id) FROM client_outreach o WHERE o.campaign_id=m.id AND o.outcome='returned') unique_returned,
          (SELECT COUNT(*) FROM sales s WHERE s.campaign_id=m.id AND s.status='completed') sale_count,
          (SELECT COALESCE(SUM(s.amount),0) FROM sales s WHERE s.campaign_id=m.id AND s.status='completed') gross_revenue,
          (SELECT COALESCE(SUM(r.amount),0) FROM sales r JOIN sales src ON src.id=r.original_sale_id
             WHERE r.status='refund' AND src.campaign_id=m.id) refund_total
          FROM marketing_campaigns m LEFT JOIN users u ON u.id=m.created_by ORDER BY m.id DESC""").fetchall()
    if request.args.get("format") == "csv":
        if not is_current_manager(): abort(403,"Экспорт маркетинговых показателей доступен только руководителю")
        import csv, io
        from flask import Response
        output=io.StringIO(newline="")
        writer=csv.writer(output)
        writer.writerow(["ID","Кампания","Сегмент","Статус","Попытки контакта","Отметки о возврате","Уникальные клиенты в контактах","Уникальные вернувшиеся клиенты","Конверсия уникальных клиентов, %","Продажи","Выручка до возвратов, ₽","Возвраты, ₽","Выручка после возвратов, ₽","Расходы, ₽","Выручка / расходы","Расходы на одного вернувшегося клиента, ₽","Создал"])
        for r in rows:
            gross=int(r["gross_revenue"] or 0); refunds=int(r["refund_total"] or 0)
            net=gross-refunds; contacts=int(r["contacts"] or 0); returned=int(r["returned"] or 0)
            unique_contacted=int(r["unique_contacted"] or 0); unique_returned=int(r["unique_returned"] or 0)
            rate=round(unique_returned*100/unique_contacted,2) if unique_contacted else ""
            cost=int(r["cost_amount"] or 0)
            roas=round(net/cost,2) if cost>0 else ""
            cost_per_return=round(cost/unique_returned,2) if cost>0 and unique_returned else ""
            writer.writerow(safe_csv_row([r["id"],r["name"],r["segment"],r["status"],contacts,returned,unique_contacted,unique_returned,rate,r["sale_count"],gross,refunds,net,cost,roas,cost_per_return,r["username"] or ""]))
        return Response("\ufeff"+output.getvalue(),mimetype="text/csv; charset=utf-8",headers={"Content-Disposition":f'attachment; filename="lider_campaigns_{today()}.csv"',"Cache-Control":"no-store"})
    body="<div class='card'><h2>Маркетинговые кампании</h2><p>Связывайте контакты и продажи с конкретной акцией. Выручка считается по отмеченным продажам за вычетом проведённых возвратов; это атрибуция, а не доказательство, что продажа произошла только благодаря кампании.</p>"
    if is_current_manager():
        body+="<p><a class='btn' href='/campaigns?format=csv'>Скачать CSV-отчёт по кампаниям</a></p>"
    if is_current_manager():
        body+="<h3>Новая кампания</h3><form method='post'><label>Название</label><input name='name' maxlength='120' required placeholder='Например, Вернёмся в бассейн — ноябрь'><label>Сегмент</label><select name='segment'>"+"".join(f"<option value='{k}'>{v}</option>" for k,v in segments.items())+"</select><label>Предложение</label><input name='offer' maxlength='500' placeholder='Условия акции или текст предложения'><label>Фактические расходы на кампанию, ₽</label><input type='number' name='cost_amount' min='0' max='100000000' value='0' required><label>Внутренние заметки</label><textarea name='notes' maxlength='1000'></textarea><button>Создать черновик</button></form>"
    body+="</div><div class='card'><h2>Список кампаний</h2><div class='tablewrap'><table><tr><th>Кампания</th><th>Сегмент</th><th>Статус</th><th>Попытки контакта</th><th>Отметки о возврате</th><th>Уникальные клиенты</th><th>Уникальные вернувшиеся</th><th>Конверсия клиентов</th><th>Продажи</th><th>Выручка до возвратов</th><th>Возвраты</th><th>Выручка после возвратов</th><th>Расходы</th><th>Выручка / расходы</th><th>Расходы на вернувшегося</th><th>Предложение</th><th>Управление</th></tr>"
    for r in rows:
        net_revenue=(r['gross_revenue'] or 0)-(r['refund_total'] or 0)
        campaign_roas=f"{net_revenue / r['cost_amount']:.2f}×" if r['cost_amount'] else "—"
        unique_contacted=int(r['unique_contacted'] or 0); unique_returned=int(r['unique_returned'] or 0)
        campaign_rate=f"{unique_returned*100/unique_contacted:.1f}%" if unique_contacted else "—"
        cost_per_return=f"{r['cost_amount']/unique_returned:,.2f} ₽" if r['cost_amount'] and unique_returned else "—"
        body+=f"<tr><td>{esc(r['name'])}<br><small>#{r['id']} · {esc(r['username'] or '')}</small></td><td>{segments.get(r['segment'],esc(r['segment']))}</td><td>{statuses.get(r['status'],esc(r['status']))}</td><td>{r['contacts']}</td><td>{r['returned']}</td><td>{unique_contacted}</td><td>{unique_returned}</td><td>{campaign_rate}</td><td>{r['sale_count']}</td><td>{(r['gross_revenue'] or 0):,} ₽</td><td>{(r['refund_total'] or 0):,} ₽</td><td>{net_revenue:,} ₽</td><td><form method='post'><input type='hidden' name='action' value='cost'><input type='hidden' name='campaign_id' value='{r['id']}'><input type='number' name='cost_amount' min='0' max='100000000' value='{r['cost_amount']}' required><button>Сохранить расходы</button></form></td><td>{campaign_roas}</td><td>{cost_per_return}</td><td>{esc(r['offer'])}</td><td>"
        if is_current_manager():
            body+="<form method='post'><input type='hidden' name='action' value='status'><input type='hidden' name='campaign_id' value='"+str(r['id'])+"'><select name='status'>"+"".join(f"<option value='{k}' {'selected' if k==r['status'] else ''}>{v}</option>" for k,v in statuses.items())+"</select><button>Сохранить</button></form>"
        body+="</td></tr>"
    body+="</table></div><p class='muted'>В отчёт попадают только контакты, которым сотрудник явно назначил кампанию. Не создавайте массовую рассылку без проверки согласий на связь и актуальности телефонов.</p></div>"
    return page("Маркетинговые кампании",body)

@app.get("/backup")
@manager_required
def backup_export():
    import csv, io, zipfile
    from flask import Response
    buf=io.BytesIO()
    with connect() as c:
        # Discover application tables from the live schema so new CRM modules
        # cannot be accidentally omitted from the export list.
        tables=exportable_table_names(c)
        with zipfile.ZipFile(buf,"w",zipfile.ZIP_DEFLATED) as z:
            for table in tables:
                rows=c.execute(f'SELECT * FROM "{table}"').fetchall()
                out=io.StringIO(newline="")
                writer=csv.writer(out)
                cols=[d[1] for d in c.execute(f'PRAGMA table_info("{table}")').fetchall()]
                writer.writerow(cols)
                for row in rows: writer.writerow(safe_csv_row([row[col] for col in cols]))
                z.writestr(f"{table}.csv","\ufeff"+out.getvalue())
            z.writestr("README.txt","Резервная CSV-выгрузка CRM Лидер. Храните архив в защищённом месте: он содержит персональные данные и хэши паролей. Это не полноценная резервная копия SQLite и не предназначено для автоматического восстановления.\n")
    return Response(buf.getvalue(),mimetype="application/zip",headers={"Content-Disposition":f'attachment; filename="lider_crm_export_{today()}.zip"'})

@app.get("/backup/sqlite")
@manager_required
def backup_sqlite():
    """Create a consistent SQLite snapshot, including schema and all rows."""
    import tempfile
    from flask import send_file
    fd, path = tempfile.mkstemp(prefix="lider_crm_", suffix=".sqlite3")
    os.close(fd)
    try:
        # Do not offer a download unless the snapshot passes integrity and foreign-key checks.
        create_verified_sqlite_snapshot(DB_PATH, path)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        response = send_file(path, as_attachment=True, download_name=f"lider_crm_full_backup_{stamp}.sqlite3", mimetype="application/vnd.sqlite3", max_age=0)
        response.headers["Cache-Control"] = "no-store"
        response.call_on_close(lambda: os.path.exists(path) and os.remove(path))
        return response
    except Exception:
        if os.path.exists(path):
            os.remove(path)
        raise

@app.get("/schedule-audit.csv")
@manager_required
def schedule_audit_csv():
    with connect() as c:
        rows = build_schedule_audit(c, today=today())
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(SCHEDULE_AUDIT_FIELDS)
    for row in rows:
        writer.writerow(safe_csv_row([row.get(field, "") for field in SCHEDULE_AUDIT_FIELDS]))
    response = app.response_class("\ufeff" + output.getvalue(), mimetype="text/csv; charset=utf-8")
    response.headers["Content-Disposition"] = 'attachment; filename="lider_schedule_audit.csv"'
    response.headers["Cache-Control"] = "no-store"
    return response


@app.get("/schedule-audit")
@manager_required
def schedule_audit_page():
    with connect() as c:
        rows = build_schedule_audit(c, today=today())
    high = sum(row["severity"] == "high" for row in rows)
    body = ("<div class='card'><h2>Проверка расписания</h2>"
            "<p>Отчёт ищет подозрительные данные в расписании и записях: переполнение слотов, пересечения времени у тренера, прошедшие необработанные записи, неактивных тренеров и проблемы с привязанными абонементами.</p>"
            "<p><b>Найдено замечаний: " + str(len(rows)) + "</b>; высокого приоритета: " + str(high) + ". "
            "Ничего не исправляется и не отменяется автоматически.</p>"
            "<p><a class='btn' href='/schedule-audit.csv'>Экспорт CSV</a> <a class='btn' href='/schedule'>Открыть расписание</a></p>"
            "<div class='tablewrap'><table><tr><th>Приоритет</th><th>Проблема</th><th>Дата</th><th>Время</th><th>Тренер</th><th>Слот</th><th>Запись</th><th>Клиент</th><th>Абонемент</th><th>Подробности</th></tr>")
    for row in rows:
        priority = "Высокий" if row["severity"] == "high" else ("Средний" if row["severity"] == "medium" else "Низкий")
        body += ("<tr><td>" + priority + "</td><td>" + esc(row["issue_type"]) + "</td><td>" + esc(row["slot_date"]) +
                 "</td><td>" + esc(row["slot_time"]) + "</td><td>" + esc(row["trainer"]) + "</td><td>#" + esc(row["slot_id"]) +
                 "</td><td>" + ("#" + esc(row["booking_id"]) if row["booking_id"] != "" else "—") +
                 "</td><td>" + esc(row["client_id"] or "—") + "</td><td>" + esc(row["subscription_id"] or "—") +
                 "</td><td>" + esc(row["details"]) + "</td></tr>")
    if not rows:
        body += "<tr><td colspan='10'>Замечаний не найдено</td></tr>"
    body += "</table></div></div>"
    return page("Проверка расписания", body)


@app.get("/followup-audit.csv")
@manager_required
def followup_audit_csv():
    with connect() as c:
        rows = build_followup_audit(c, current_date=today(), current_datetime=now())
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(FOLLOWUP_AUDIT_FIELDS)
    for row in rows:
        writer.writerow(safe_csv_row([row.get(field, "") for field in FOLLOWUP_AUDIT_FIELDS]))
    response = app.response_class("\ufeff" + output.getvalue(), mimetype="text/csv; charset=utf-8")
    response.headers["Content-Disposition"] = 'attachment; filename="lider_followup_audit.csv"'
    response.headers["Cache-Control"] = "no-store"
    return response


@app.get("/followup-audit")
@manager_required
def followup_audit_page():
    with connect() as c:
        rows = build_followup_audit(c, current_date=today(), current_datetime=now())
    counts = {}
    for row in rows:
        counts[row["issue_type"]] = counts.get(row["issue_type"], 0) + 1
    body = ("<div class='card'><h2>Контроль перезвонов и задач</h2>"
            "<p>Отчёт показывает просроченные/сегодняшние контакты по незакрытым заявкам, открытые просроченные задачи и заявки со статусом «Клиент» без связанной карточки. Данные не изменяются автоматически.</p>"
            "<p><a class='btn' href='/followup-audit.csv'>Экспорт CSV</a> <a class='btn' href='/leads'>Заявки</a> <a class='btn' href='/tasks'>Задачи</a></p>"
            "<div class='tablewrap'><table><tr><th>Приоритет</th><th>Проблема</th><th>Срок</th><th>Родитель</th><th>Ребёнок</th><th>Телефон</th><th>Задача</th><th>Статус</th><th>Ответственный</th><th>Подробности</th></tr>")
    for row in rows:
        priority = "Высокий" if row["severity"] == "high" else ("Средний" if row["severity"] == "medium" else "Низкий")
        body += ("<tr><td>" + priority + "</td><td>" + esc(row["issue_type"]) + " #" + esc(row["record_id"]) +
                 "</td><td>" + esc(row["due_at"] or "—") + "</td><td>" + esc(row["parent_name"]) +
                 "</td><td>" + esc(row["child_name"]) + "</td><td>" + esc(row["phone"]) +
                 "</td><td>" + esc(row["title"]) + "</td><td>" + esc(row["status"]) +
                 "</td><td>" + esc(row["assignee"]) + "</td><td>" + esc(row["details"]) + "</td></tr>")
    if not rows:
        body += "<tr><td colspan='10'>Просроченных действий и ошибок связей не найдено</td></tr>"
    body += "</table></div><p class='muted'>Отчёт ограничен последними 1000 замечаниями; сначала проверяйте высокий приоритет. Экспорт содержит контактные данные.</p></div>"
    return page("Контроль перезвонов", body)


@app.get("/client-data-quality.csv")
@manager_required
def client_data_quality_csv():
    with connect() as c:
        rows = build_client_data_quality_audit(c, current_date=today())
    output = io.StringIO(newline="")
    writer = csv.writer(output, lineterminator="\r\n")
    writer.writerow(["Тип проблемы", "Приоритет", "Тип записи", "ID", "Ребёнок", "Родитель", "Телефон", "Что проверить"])
    labels = {"high": "Высокий", "medium": "Средний", "low": "Низкий", "client": "Клиент", "lead": "Заявка"}
    for row in rows:
        writer.writerow(safe_csv_row([row["issue_type"], labels.get(row["severity"], row["severity"]),
            labels.get(row["entity_type"], row["entity_type"]), row["record_id"], row["child_name"],
            row["parent_name"], row["phone"], row["details"]]))
    response = app.response_class("\ufeff" + output.getvalue(), mimetype="text/csv; charset=utf-8")
    response.headers["Content-Disposition"] = 'attachment; filename="lider_client_data_quality.csv"'
    response.headers["Cache-Control"] = "no-store"
    return response


@app.get("/client-data-quality")
@manager_required
def client_data_quality_page():
    with connect() as c:
        rows = build_client_data_quality_audit(c, current_date=today())
    labels = {"high": "Высокий", "medium": "Средний", "low": "Низкий"}
    counts = {key: sum(1 for row in rows if row["severity"] == key) for key in labels}
    body = ("<div class='card'><h2>Качество клиентской базы и заявок</h2>"
        "<p>Только проверка: CRM не меняет карточки и не объединяет контакты автоматически. Общий телефон у нескольких детей часто нормален для одной семьи и требует лишь проверки.</p>"
        "<p><a class='btn' href='/client-data-quality.csv'>Экспорт CSV</a> <a class='btn' href='/clients'>Клиенты</a> <a class='btn' href='/leads'>Заявки</a></p>"
        f"<div class='grid'><div class='card'><h2>Высокий приоритет</h2><p style='font-size:28px'>{counts['high']}</p></div>"
        f"<div class='card'><h2>Средний приоритет</h2><p style='font-size:28px'>{counts['medium']}</p></div>"
        f"<div class='card'><h2>Низкий приоритет</h2><p style='font-size:28px'>{counts['low']}</p></div></div>"
        "<div class='tablewrap'><table><tr><th>Приоритет</th><th>Проблема</th><th>Запись</th><th>Ребёнок</th><th>Родитель</th><th>Телефон</th><th>Что проверить</th></tr>")
    for row in rows:
        target = f"/client/{row['record_id']}" if row["entity_type"] == "client" else "/leads"
        body += (f"<tr><td>{esc(labels.get(row['severity'], row['severity']))}</td><td>{esc(row['issue_type'])}</td>"
            f"<td><a href='{target}'>#{int(row['record_id'])} · {esc(row['entity_type'])}</a></td>"
            f"<td>{esc(row['child_name'])}</td><td>{esc(row['parent_name'])}</td><td>{esc(row['phone'])}</td><td>{esc(row['details'])}</td></tr>")
    if not rows:
        body += "<tr><td colspan='7'>Замечаний по проверяемым правилам не найдено.</td></tr>"
    body += "</table></div><p class='muted'>Показано до 2 000 замечаний. Сначала проверьте высокий приоритет; перед изменениями сверяйте карточки, оплаты и историю абонементов.</p></div>"
    response = app.make_response(page("Качество базы", body))
    response.headers["Cache-Control"] = "no-store"
    response.headers["Pragma"] = "no-cache"
    return response


@app.get("/subscription-integrity.csv")
@manager_required
def subscription_integrity_csv():
    with connect() as c:
        rows = build_subscription_integrity_audit(c, current_date=today())
    output = io.StringIO(newline="")
    writer = csv.writer(output, lineterminator="\r\n")
    writer.writerow(["Тип проблемы", "Приоритет", "Тип записи", "ID записи", "ID клиента", "ID абонемента", "Ребёнок", "Телефон", "Что проверить"])
    labels = {"high": "Высокий", "medium": "Средний", "low": "Низкий", "subscription": "Абонемент", "sale": "Продажа", "attendance": "Посещение"}
    for row in rows:
        writer.writerow(safe_csv_row([row["issue_type"], labels.get(row["severity"], row["severity"]),
            labels.get(row["entity_type"], row["entity_type"]), row["record_id"], row["client_id"],
            row["subscription_id"], row["child_name"], row["phone"], row["details"]]))
    response = app.response_class("\ufeff" + output.getvalue(), mimetype="text/csv; charset=utf-8")
    response.headers["Content-Disposition"] = 'attachment; filename="lider_subscription_integrity.csv"'
    response.headers["Cache-Control"] = "no-store"
    response.headers["Pragma"] = "no-cache"
    return response


@app.get("/subscription-integrity")
@manager_required
def subscription_integrity_page():
    with connect() as c:
        rows = build_subscription_integrity_audit(c, current_date=today())
    labels = {"high": "Высокий", "medium": "Средний", "low": "Низкий"}
    counts = {key: sum(1 for row in rows if row["severity"] == key) for key in labels}
    body = ("<div class='card'><h2>Проверка целостности абонементов</h2>"
        "<p>Отчёт ищет подозрительные связи между абонементами, продажами и посещениями, а также ошибки статусов, дат и остатков. Это только диагностика: данные не исправляются и не удаляются автоматически.</p>"
        "<p><a class='btn' href='/subscription-integrity.csv'>Экспорт CSV</a> <a class='btn' href='/subscriptions'>Абонементы</a> <a class='btn' href='/sales'>Продажи</a> <a class='btn' href='/attendance'>Посещения</a></p>"
        f"<div class='grid'><div class='card'><h2>Высокий приоритет</h2><p style='font-size:28px'>{counts['high']}</p></div>"
        f"<div class='card'><h2>Средний приоритет</h2><p style='font-size:28px'>{counts['medium']}</p></div>"
        f"<div class='card'><h2>Низкий приоритет</h2><p style='font-size:28px'>{counts['low']}</p></div></div>"
        "<div class='tablewrap'><table><tr><th>Приоритет</th><th>Проблема</th><th>Запись</th><th>Клиент</th><th>Абонемент</th><th>Ребёнок</th><th>Телефон</th><th>Что проверить</th></tr>")
    for row in rows:
        body += (f"<tr><td>{esc(labels.get(row['severity'], row['severity']))}</td><td>{esc(row['issue_type'])}</td>"
            f"<td>{esc(row['entity_type'])} #{esc(row['record_id'])}</td><td>{esc(row['client_id'] or '—')}</td>"
            f"<td>{esc(row['subscription_id'] or '—')}</td><td>{esc(row['child_name'])}</td>"
            f"<td>{esc(row['phone'])}</td><td>{esc(row['details'])}</td></tr>")
    if not rows:
        body += "<tr><td colspan='8'>Замечаний по проверяемым правилам не найдено.</td></tr>"
    body += "</table></div><p class='muted'>Сначала проверяйте высокий приоритет. Перед исправлениями сверяйте первичные документы, посещения и возвраты.</p></div>"
    response = app.make_response(page("Проверка абонементов", body))
    response.headers["Cache-Control"] = "no-store"
    response.headers["Pragma"] = "no-cache"
    return response


@app.get("/client-retention.csv")
@manager_required
def client_retention_csv():
    try:
        days = normalize_retention_period(request.args.get("days", "30"))
    except ValueError as exc:
        abort(400, str(exc))
    with connect() as c:
        rows = build_client_retention_report(c, as_of=request.args.get("as_of") or today(), period_days=days)
    output = io.StringIO(newline="")
    writer = csv.writer(output, lineterminator="\r\n")
    writer.writerow(["ID клиента", "Ребёнок", "Родитель", "Телефон", "Статус клиента", "Последнее посещение",
                     f"Посещения за последние {days} дней", f"Посещения за предыдущие {days} дней", "Динамика",
                     "Активных абонементов", "Ближайшее окончание"])
    for row in rows:
        writer.writerow(safe_csv_row([row["client_id"], row["child_name"], row["parent_name"], row["phone"],
            row["client_status"], row["last_visit"], row["current_visits"], row["previous_visits"], row["trend"],
            row["active_subscriptions"], row["nearest_expiry"]]))
    response = app.response_class("\ufeff" + output.getvalue(), mimetype="text/csv; charset=utf-8")
    response.headers["Content-Disposition"] = 'attachment; filename="lider_client_retention.csv"'
    response.headers["Cache-Control"] = "no-store"
    response.headers["Pragma"] = "no-cache"
    return response


@app.get("/client-retention")
@manager_required
def client_retention_page():
    try:
        days = normalize_retention_period(request.args.get("days", "30"))
    except ValueError as exc:
        abort(400, str(exc))
    as_of = request.args.get("as_of") or today()
    with connect() as c:
        rows = build_client_retention_report(c, as_of=as_of, period_days=days)
    counts = {}
    for row in rows:
        counts[row["trend"]] = counts.get(row["trend"], 0) + 1
    body = ("<div class='card'><h2>Удержание клиентов и динамика посещений</h2>"
        "<p>Сравниваются два последовательных равных периода. Считаются только посещения со статусом «Был». Отчёт помогает найти семьи, которым стоит позвонить, но сам по себе не доказывает отток и ничего не меняет в карточках.</p>"
        f"<form method='get'><label>Период сравнения</label><select name='days'>" +
        "".join(f"<option value='{n}' {'selected' if n == days else ''}>{n} дней</option>" for n in (7, 14, 30, 60, 90)) +
        f"</select><label>Дата отчёта</label><input type='date' name='as_of' value='{esc(as_of)}'><button>Обновить</button></form>"
        f"<p><a class='btn' href='/client-retention.csv?days={days}&amp;as_of={esc(as_of)}'>Экспорт CSV</a> <a class='btn' href='/reactivation'>Возврат клиентов</a></p>"
        "<div class='grid'>" + "".join(f"<div class='card'><h3>{esc(label)}</h3><p style='font-size:26px'>{count}</p></div>" for label, count in sorted(counts.items())) +
        "</div><div class='tablewrap'><table><tr><th>Динамика</th><th>Клиент</th><th>Телефон</th><th>Последнее посещение</th><th>Посещения сейчас</th><th>Посещения раньше</th><th>Активные абонементы</th><th>Ближайшее окончание</th></tr>")
    for row in rows:
        body += (f"<tr><td>{esc(row['trend'])}</td><td><a href='/client/{int(row['client_id'])}'>{esc(row['child_name'])}</a><br><small>{esc(row['parent_name'])}</small></td>"
            f"<td>{esc(row['phone'])}</td><td>{esc(row['last_visit'] or 'Нет посещений')}</td><td>{int(row['current_visits'])}</td>"
            f"<td>{int(row['previous_visits'])}</td><td>{int(row['active_subscriptions'])}</td><td>{esc(row['nearest_expiry'] or '—')}</td></tr>")
    if not rows:
        body += "<tr><td colspan='8'>Клиенты не найдены.</td></tr>"
    body += "</table></div><p class='muted'>CSV содержит персональные данные и доступен только руководителю. Перед звонком проверьте карточку клиента и историю контактов.</p></div>"
    response = app.make_response(page("Удержание клиентов", body))
    response.headers["Cache-Control"] = "no-store"
    response.headers["Pragma"] = "no-cache"
    return response


@app.get("/audit")
@manager_required
def audit_page():
    with connect() as c:
        rows=c.execute("SELECT a.*,u.username FROM audit_log a LEFT JOIN users u ON u.id=a.actor_user_id ORDER BY a.id DESC LIMIT 300").fetchall()
    table="<div class='card'><h2>Журнал аудита (последние 300)</h2><div class='tablewrap'><table><tr><th>Время</th><th>Сотрудник</th><th>Действие</th><th>Объект</th><th>Детали</th></tr>"
    for r in rows: table+=f"<tr><td>{esc(r['created_at'])}</td><td>{esc(r['username'] or 'системный пользователь')}</td><td>{esc(r['action'])}</td><td>{esc(r['entity'])} #{r['entity_id'] or ''}</td><td>{esc(r['details'])}</td></tr>"
    return page("Журнал аудита",table+"</table></div></div>")


@app.get("/system-check.csv")
@manager_required
def system_check_csv():
    checks = _system_readiness_checks()
    output = io.StringIO(newline="")
    writer = csv.writer(output, lineterminator="\r\n")
    writer.writerow(["Проверка", "Статус", "Результат"])
    status_labels = {"ok": "Норма", "warning": "Внимание", "error": "Ошибка", "info": "Информация"}
    for item in checks:
        writer.writerow(safe_csv_row([item["title"], status_labels.get(item["status"], item["status"]), item["detail"]]))
    response = app.response_class("\ufeff" + output.getvalue(), mimetype="text/csv; charset=utf-8")
    response.headers["Content-Disposition"] = 'attachment; filename="lider_system_readiness.csv"'
    response.headers["Cache-Control"] = "no-store"
    response.headers["Pragma"] = "no-cache"
    return response


def _system_readiness_checks():
    backup_dir = os.environ.get("LIDER_CRM_BACKUP_DIR", os.path.join(APP_DIR, "backups"))
    with connect() as c:
        return build_system_readiness_report(
            c,
            db_path=DB_PATH,
            backup_dir=backup_dir,
            secret_configured=bool(SECRET_KEY),
            cookie_secure=bool(app.config.get("SESSION_COOKIE_SECURE")),
            host=os.environ.get("LIDER_HOST", "127.0.0.1"),
            debug=bool(app.debug),
        )


@app.get("/system-check")
@manager_required
def system_check_page():
    checks = _system_readiness_checks()
    labels = {"ok": "Норма", "warning": "Внимание", "error": "Ошибка", "info": "Информация"}
    counts = {status: sum(1 for item in checks if item["status"] == status) for status in labels}
    body = ("<div class='card'><h2>Готовность системы к эксплуатации</h2>"
        "<p>Проверка не изменяет базу и файлы. Это предварительная диагностика конфигурации, целостности SQLite и наличия резервных копий; она не заменяет браузерную приёмку и тестовое восстановление.</p>"
        "<p><a class='btn' href='/system-check.csv'>Скачать CSV-отчёт</a> <a class='btn' href='/backup'>Экспорт таблиц</a></p>"
        f"<div class='grid'><div class='card'><h2>Ошибки</h2><p style='font-size:28px'>{counts['error']}</p></div>"
        f"<div class='card'><h2>Предупреждения</h2><p style='font-size:28px'>{counts['warning']}</p></div>"
        f"<div class='card'><h2>В норме</h2><p style='font-size:28px'>{counts['ok']}</p></div></div>"
        "<div class='tablewrap'><table><tr><th>Проверка</th><th>Статус</th><th>Результат</th></tr>")
    for item in checks:
        status = item["status"]
        body += f"<tr><td>{esc(item['title'])}</td><td><b>{esc(labels.get(status, status))}</b></td><td>{esc(item['detail'])}</td></tr>"
    body += ("</table></div><p class='muted'>Для удалённого доступа используйте HTTPS, постоянный LIDER_CRM_SECRET, Secure cookie и WSGI-сервер за reverse proxy. Любое предупреждение требует оценки до загрузки реальных данных.</p></div>")
    response = app.make_response(page("Готовность системы", body))
    response.headers["Cache-Control"] = "no-store"
    response.headers["Pragma"] = "no-cache"
    return response

if __name__=="__main__":
    init_db()
    app.run(host=os.environ.get("LIDER_HOST","127.0.0.1"),port=int(os.environ.get("PORT","5000")),debug=False)
