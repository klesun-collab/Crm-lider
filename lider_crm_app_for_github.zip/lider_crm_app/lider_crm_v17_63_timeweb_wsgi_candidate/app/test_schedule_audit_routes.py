"""Source-level route checks run even in environments without Flask installed."""
import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE = ast.parse(SOURCE)


def route_function(name):
    node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment(SOURCE, node)


class ScheduleAuditRouteTests(unittest.TestCase):
    def test_both_routes_are_manager_protected(self):
        for name in ('schedule_audit_page', 'schedule_audit_csv'):
            fn = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name)
            decorators = [ast.unparse(d) for d in fn.decorator_list]
            self.assertIn('manager_required', decorators)

    def test_csv_export_has_bom_safe_cells_and_no_store(self):
        source = route_function('schedule_audit_csv')
        self.assertIn('safe_csv_row', source)
        self.assertIn('SCHEDULE_AUDIT_FIELDS', source)
        self.assertIn('"\\ufeff"', source)
        self.assertIn('Cache-Control', source)
        self.assertIn('text/csv; charset=utf-8', source)

    def test_report_is_read_only(self):
        for name in ('schedule_audit_page', 'schedule_audit_csv'):
            source = route_function(name)
            self.assertNotIn('INSERT INTO', source.upper())
            self.assertNotIn('UPDATE ', source.upper())
            self.assertNotIn('DELETE FROM', source.upper())

    def test_manager_navigation_links_to_audit(self):
        self.assertIn('/schedule-audit', route_function('page'))

    def test_page_escapes_user_controlled_report_values(self):
        source = route_function('schedule_audit_page')
        self.assertIn('esc(row["details"])', source)
        self.assertIn('esc(row["trainer"])', source)
        self.assertIn('esc(row["slot_date"])', source)


if __name__ == '__main__':
    unittest.main()
