"""Scheduling is administered by staff; payroll rate changes stay manager-only."""
from pathlib import Path
import unittest

SOURCE = (Path(__file__).parent / 'app.py').read_text(encoding='utf-8')


class SchedulePermissionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        start = SOURCE.index('def schedule():')
        end = SOURCE.index('@app.route("/booking/<int:booking_id>/attended"', start)
        cls.section = SOURCE[start:end]

    def test_admin_can_create_recurring_slots_and_edit_future_empty_slots(self):
        self.assertIn('if action in ("repeat_slots", "repeat_shift"):', self.section)
        self.assertIn('if action=="edit_slot":', self.section)
        self.assertIn('Создать повторяющееся расписание', self.section)
        self.assertIn('Начало смены', self.section)
        self.assertIn('Окончание смены (не включительно)', self.section)
        self.assertNotIn('Создавать повторяющееся расписание может только руководитель', self.section)
        self.assertNotIn('Изменять расписание может только руководитель', self.section)

    def test_admin_cannot_set_payroll_rate_from_schedule(self):
        self.assertIn('if not is_current_manager() and supplied_rate:', self.section)
        self.assertIn('Менять ставки тренеров может только руководитель', self.section)

    def test_admin_must_select_existing_trainer_for_one_off_slot(self):
        self.assertIn('Сначала добавьте тренера в разделе «Тренеры»', self.section)

    def test_schedule_has_repeat_days_weekdays_controls(self):
        self.assertIn('name=\'weekdays\'', self.section)
        self.assertIn('weekly_dates(start_date,end_date,weekdays,today())', self.section)


if __name__ == '__main__':
    unittest.main()
