import unittest
from schedule_rules import validate_slot_details


class ScheduleRulesTests(unittest.TestCase):
    def test_valid_slot_is_normalized(self):
        self.assertEqual(validate_slot_details('2026-10-20', '09:30', '4', '30', 'group', '2026-10-16'),
                         ('2026-10-20', '09:30', 4, 30, 'group'))

    def test_rejects_past_date(self):
        with self.assertRaisesRegex(ValueError, 'прошедшую дату'):
            validate_slot_details('2026-10-15', '09:00', 1, 30, 'individual', '2026-10-16')

    def test_rejects_invalid_date_time_and_kind(self):
        for args in [
            ('2026-13-40', '09:00', 1, 30, 'individual'),
            ('2026-10-20', '25:00', 1, 30, 'individual'),
            ('2026-10-20', '09:00', 1, 30, 'other'),
        ]:
            with self.subTest(args=args), self.assertRaises(ValueError):
                validate_slot_details(*args, today_date='2026-10-16')

    def test_capacity_and_duration_are_bounded(self):
        for capacity in (0, 101):
            with self.subTest(capacity=capacity), self.assertRaises(ValueError):
                validate_slot_details('2026-10-20', '09:00', capacity, 30, 'individual', '2026-10-16')
        with self.assertRaisesRegex(ValueError, '30 или 60'):
            validate_slot_details('2026-10-20', '09:00', 1, 45, 'individual', '2026-10-16')

    def test_routes_use_common_slot_validation_and_reject_past_bookings(self):
        from pathlib import Path
        source = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
        self.assertGreaterEqual(source.count('validate_slot_details('), 2)
        self.assertIn('Нельзя записать на прошедшее занятие', source)


if __name__ == '__main__':
    unittest.main()
