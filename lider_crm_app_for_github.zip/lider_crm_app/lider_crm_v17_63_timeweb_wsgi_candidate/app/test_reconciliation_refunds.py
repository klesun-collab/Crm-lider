import sqlite3
import unittest
from pathlib import Path

ROOT = Path(__file__).parent

class RefundReconciliationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = (ROOT / 'app.py').read_text(encoding='utf-8')
        start = cls.source.index('def reconciliation():')
        end = cls.source.index('@app.get("/payroll")', start)
        cls.section = cls.source[start:end]

    def test_refund_schema_migration_and_creation_are_explicitly_linked(self):
        self.assertIn('("original_sale_id","INTEGER REFERENCES sales(id)")', self.source)
        self.assertIn('CREATE INDEX IF NOT EXISTS idx_sales_original_sale_id ON sales(original_sale_id)', self.source)
        self.assertIn('profit_snapshot,original_sale_id,wallet_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)', self.source)
        self.assertIn('"refund",session["uid"],now(),sale["product_id"],sale["quantity"],sale["unit_cost_snapshot"],-sale["profit_snapshot"],sale["id"]', self.source)

    def test_reconciliation_uses_explicit_source_link_and_checks_amount_and_duplicates(self):
        self.assertIn('GROUP BY original_sale_id', self.section)
        self.assertIn('x.original_sale_id=s.id', self.section)
        self.assertIn('COALESCE(x.refund_count,0)>1', self.section)
        self.assertIn('COALESCE(x.refund_amount,0)!=s.amount', self.section)
        self.assertIn("r.status='approved' AND s.status!='completed'", self.section)
        self.assertIn("r.status='pending' AND s.status!='completed'", self.section)
        self.assertIn('Старые возвраты, созданные до этой версии', self.section)

    def test_reconciliation_sql_distinguishes_identical_sales_for_same_client(self):
        db = sqlite3.connect(':memory:')
        db.executescript('''
          CREATE TABLE sales(id INTEGER PRIMARY KEY, client_id INTEGER, item TEXT, amount INTEGER, status TEXT, original_sale_id INTEGER);
          CREATE TABLE refund_requests(id INTEGER PRIMARY KEY, sale_id INTEGER, status TEXT);
          INSERT INTO sales VALUES(1,7,'Абонемент 8 занятий',8000,'completed',NULL);
          INSERT INTO sales VALUES(2,7,'Абонемент 8 занятий',8000,'completed',NULL);
          INSERT INTO sales VALUES(3,7,'ВОЗВРАТ: Абонемент 8 занятий',8000,'refund',2);
          INSERT INTO refund_requests VALUES(11,1,'approved');
          INSERT INTO refund_requests VALUES(12,2,'approved');
        ''')
        rows = db.execute('''SELECT r.id request_id,r.sale_id,r.status request_status,
                  s.status sale_status,s.amount original_amount,
                  COALESCE(x.refund_count,0) refund_count,COALESCE(x.refund_amount,0) refund_amount
            FROM refund_requests r JOIN sales s ON s.id=r.sale_id
            LEFT JOIN (SELECT original_sale_id,COUNT(*) refund_count,SUM(amount) refund_amount
                       FROM sales WHERE status='refund' AND original_sale_id IS NOT NULL
                       GROUP BY original_sale_id) x ON x.original_sale_id=s.id
            WHERE (r.status='approved' AND s.status!='completed')
               OR (r.status='approved' AND (COALESCE(x.refund_count,0)=0
                    OR COALESCE(x.refund_count,0)>1 OR COALESCE(x.refund_amount,0)!=s.amount))
               OR (r.status='pending' AND s.status!='completed')
            ORDER BY r.id DESC LIMIT 100''').fetchall()
        # Sale #1 has no refund; sale #2 has a correctly linked refund, despite same client/item.
        self.assertEqual([r[0] for r in rows], [11])
        db.close()

    def test_reconciliation_displays_refund_alerts(self):
        self.assertIn('Подозрительные возвраты', self.section)
        self.assertIn('Возвраты для ручной проверки', self.section)
        self.assertIn('if not bad_refunds', self.section)

if __name__ == '__main__':
    unittest.main()
