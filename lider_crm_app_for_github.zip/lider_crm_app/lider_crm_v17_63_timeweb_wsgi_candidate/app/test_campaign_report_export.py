"""Regression tests for safe, manager-only marketing performance exports."""
import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name("app.py").read_text(encoding="utf-8")
TREE = ast.parse(SOURCE)

def fn(name):
    node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment(SOURCE, node)

class CampaignReportExportTests(unittest.TestCase):
    def test_csv_export_is_manager_only_and_no_store(self):
        route = fn("marketing_campaigns")
        self.assertIn('request.args.get("format") == "csv"', route)
        self.assertIn('if not is_current_manager(): abort(403', route)
        self.assertIn('"Cache-Control":"no-store"', route)
        self.assertIn('safe_csv_row([r["id"]', route)
        self.assertIn('text/csv; charset=utf-8', route)

    def test_csv_contains_net_revenue_roas_and_contact_return_rate(self):
        route = fn("marketing_campaigns")
        for field in ("Выручка после возвратов, ₽", "Выручка / расходы", "Конверсия уникальных клиентов, %", "Расходы на одного вернувшегося клиента, ₽"):
            self.assertIn(field, route)
        self.assertIn('net=gross-refunds', route)
        self.assertIn('COUNT(DISTINCT o.client_id)', route)
        self.assertIn('round(unique_returned*100/unique_contacted,2) if unique_contacted else ""', route)
        self.assertIn('round(cost/unique_returned,2) if cost>0 and unique_returned else ""', route)

    def test_campaign_page_exposes_export_only_to_manager(self):
        route = fn("marketing_campaigns")
        self.assertIn("/campaigns?format=csv", route)
        self.assertIn("if is_current_manager():", route)

    def test_csv_formula_injection_helper_is_used(self):
        self.assertIn("from csv_safety import safe_csv_row", SOURCE)
        self.assertIn("safe_csv_row([r[\"id\"]", fn("marketing_campaigns"))

if __name__ == "__main__":
    unittest.main()
