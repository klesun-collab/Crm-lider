"""Regression coverage for linking real sales to marketing campaigns."""
import ast
import sqlite3
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE = ast.parse(SOURCE)

def fn(name):
    node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment(SOURCE, node)

class CampaignSalesAttributionTests(unittest.TestCase):
    def test_sales_migration_adds_nullable_campaign_link_and_index(self):
        init = fn('init_db')
        self.assertIn('("campaign_id","INTEGER REFERENCES marketing_campaigns(id)")', init)
        self.assertIn('idx_sales_campaign_status', init)

    def test_sale_form_validates_campaign_and_saves_link(self):
        route = fn('sales')
        self.assertIn("status IN ('draft','active','completed')", route)
        self.assertIn('campaign_id=int(request.form.get("campaign_id") or 0)', route)
        self.assertIn('profit_snapshot,campaign_id,wallet_id,gross_amount,points_earned,points_redeemed,loyalty_discount_amount)', route)
        self.assertIn('campaign_id or None', route)
        self.assertIn('name="campaign_id"', route)
        legacy = fn('subscriptions')
        self.assertIn('subscription_id,campaign_id)', legacy)
        self.assertIn('name="campaign_id"', legacy)

    def test_campaign_report_uses_real_sales_and_refunds(self):
        route = fn('marketing_campaigns')
        self.assertIn("s.campaign_id=m.id AND s.status='completed'", route)
        self.assertIn('gross_revenue', route)
        self.assertIn('refund_total', route)
        self.assertIn('src.campaign_id=m.id', route)
        self.assertIn('Выручка после возвратов', route)


    def test_campaign_spend_is_migrated_validated_and_reported(self):
        init = fn('init_db')
        route = fn('marketing_campaigns')
        self.assertIn('ADD COLUMN cost_amount INTEGER NOT NULL DEFAULT 0 CHECK(cost_amount>=0)', init)
        self.assertIn('cost_amount=int(request.form.get("cost_amount") or 0)', route)
        self.assertIn('cost_amount<0 or cost_amount>100_000_000', route)
        self.assertIn('campaign_roas', route)
        self.assertIn('Выручка / расходы', route)

    def test_roas_handles_zero_spend_without_division(self):
        revenue = 12000
        self.assertEqual(f"{revenue / 3000:.2f}×", "4.00×")
        cost = 0
        displayed = f"{revenue / cost:.2f}×" if cost else "—"
        self.assertEqual(displayed, "—")

    def test_net_campaign_revenue_math(self):
        db = sqlite3.connect(':memory:')
        db.executescript('''
          CREATE TABLE marketing_campaigns(id INTEGER PRIMARY KEY);
          CREATE TABLE sales(id INTEGER PRIMARY KEY, amount INTEGER, status TEXT,
                             campaign_id INTEGER, original_sale_id INTEGER);
          INSERT INTO marketing_campaigns VALUES(1);
          INSERT INTO sales VALUES(10, 8000, 'completed', 1, NULL);
          INSERT INTO sales VALUES(11, 3000, 'completed', 1, NULL);
          INSERT INTO sales VALUES(12, 3000, 'refund', NULL, 11);
        ''')
        gross = db.execute("SELECT SUM(amount) FROM sales WHERE campaign_id=1 AND status='completed'").fetchone()[0]
        refunds = db.execute("SELECT SUM(r.amount) FROM sales r JOIN sales src ON src.id=r.original_sale_id WHERE r.status='refund' AND src.campaign_id=1").fetchone()[0]
        self.assertEqual(gross, 11000)
        self.assertEqual(refunds, 3000)
        self.assertEqual(gross-refunds, 8000)

    def test_migration_pattern_is_idempotent(self):
        db = sqlite3.connect(':memory:')
        db.execute('CREATE TABLE sales(id INTEGER PRIMARY KEY, status TEXT)')
        for _ in range(2):
            cols = {r[1] for r in db.execute('PRAGMA table_info(sales)')}
            if 'campaign_id' not in cols:
                db.execute('ALTER TABLE sales ADD COLUMN campaign_id INTEGER REFERENCES marketing_campaigns(id)')
            db.execute('CREATE INDEX IF NOT EXISTS idx_sales_campaign_status ON sales(campaign_id,status)')
        self.assertIn('campaign_id', {r[1] for r in db.execute('PRAGMA table_info(sales)')})
        self.assertIn('idx_sales_campaign_status', {r[1] for r in db.execute('PRAGMA index_list(sales)')})

if __name__ == '__main__':
    unittest.main()
