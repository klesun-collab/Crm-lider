import ast
import unittest
from pathlib import Path
SOURCE=Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE=ast.parse(SOURCE)
class ProductEditRouteContractTests(unittest.TestCase):
    def test_product_edit_is_manager_only_and_audited(self):
        fn=next(n for n in TREE.body if isinstance(n,ast.FunctionDef) and n.name=='product_edit')
        self.assertTrue(any('manager_required' in ast.unparse(d) for d in fn.decorator_list))
        text=ast.get_source_segment(SOURCE,fn)
        self.assertIn('product.updated',text)
        self.assertIn('historical_sales_snapshots_preserved',text)
    def test_edit_form_exposes_name_prices_and_active_status(self):
        self.assertIn("action='/products/{r['id']}/edit'",SOURCE)
        for field in ("name='name'", "name='purchase_price'", "name='sale_price'", "name='active'"):
            self.assertIn(field,SOURCE)
    def test_product_edit_does_not_rewrite_sales_history(self):
        fn=next(n for n in TREE.body if isinstance(n,ast.FunctionDef) and n.name=='product_edit')
        text=ast.get_source_segment(SOURCE,fn)
        self.assertNotIn('UPDATE sales',text)
        self.assertNotIn('DELETE FROM sales',text)
if __name__=='__main__': unittest.main()
