"""Behavioral tests for a complete, signed cash-journal CSV export."""
import sqlite3
import unittest
from cash_export import cash_transactions

class CashExportTests(unittest.TestCase):
    def setUp(self):
        self.db=sqlite3.connect(':memory:')
        self.db.row_factory=sqlite3.Row
        self.db.executescript('''
            CREATE TABLE users(id INTEGER PRIMARY KEY, username TEXT);
            CREATE TABLE cash_wallets(id INTEGER PRIMARY KEY,name TEXT,payment_method TEXT);
            CREATE TABLE wallet_transfers(id INTEGER PRIMARY KEY,from_wallet_id INTEGER,to_wallet_id INTEGER,amount INTEGER,note TEXT,created_by INTEGER,created_at TEXT);
            CREATE TABLE cash_expense_categories(id INTEGER PRIMARY KEY,name TEXT);
            CREATE TABLE cash_income_categories(id INTEGER PRIMARY KEY,name TEXT);
            CREATE TABLE cash_other_income(id INTEGER PRIMARY KEY,income_date TEXT,description TEXT,amount INTEGER,payment_method TEXT,created_by INTEGER,created_by_name TEXT,created_at TEXT,wallet_id INTEGER,category_id INTEGER);
            CREATE TABLE sales(id INTEGER PRIMARY KEY, item TEXT, amount INTEGER,
                payment_method TEXT, status TEXT, created_by INTEGER, created_at TEXT, wallet_id INTEGER);
            CREATE TABLE cash_expenses(id INTEGER PRIMARY KEY, expense_date TEXT,
                description TEXT, amount INTEGER, payment_method TEXT,
                created_by_name TEXT, created_at TEXT, wallet_id INTEGER, category_id INTEGER);
            INSERT INTO users VALUES(1,'admin');
            INSERT INTO cash_wallets VALUES(1,'Наличные','cash');
            INSERT INTO cash_wallets VALUES(2,'Банк','card');
            INSERT INTO cash_expense_categories VALUES(1,'Химия бассейна');
            INSERT INTO cash_income_categories VALUES(1,'Прочие поступления');
            INSERT INTO sales VALUES(1,'Абонемент',8000,'cash','completed',1,'2026-10-02T10:00:00',1);
            INSERT INTO sales VALUES(2,'ВОЗВРАТ: Абонемент',8000,'cash','refund',1,'2026-10-03T11:00:00',1);
            INSERT INTO sales VALUES(3,'Сторонняя запись',300,'card','void',1,'2026-10-03T12:00:00',2);
            INSERT INTO cash_expenses VALUES(1,'2026-10-03','Хлор',500,'cash','admin','2026-10-04T09:00:00',1,1);
            INSERT INTO cash_expenses VALUES(2,'2026-09-30','Старый расход',100,'cash','admin','2026-10-01T09:00:00',NULL,NULL);
            INSERT INTO cash_other_income VALUES(1,'2026-10-03','Внесение средств',1200,'card',1,'admin','2026-10-03T14:00:00',2,1);
            INSERT INTO wallet_transfers VALUES(1,1,2,200,'Внести на счёт',1,'2026-10-03T13:00:00');
        ''')

    def tearDown(self): self.db.close()

    def test_export_contains_sales_refunds_expenses_and_transfer_lines(self):
        rows=cash_transactions(self.db,'2026-10-01','2026-10-31')
        values=[(r['operation_type'],r['amount']) for r in rows]
        self.assertEqual(values,[('Продажа',8000),('Возврат',-8000),('Перевод между счетами — входящий',200),('Перевод между счетами — исходящий',-200),('Прочее поступление',1200),('Расход',-500)])
        self.assertEqual([r['operator'] for r in rows],['admin','admin','admin','admin','admin','admin'])
        self.assertEqual([r['wallet_name'] for r in rows],['Наличные','Наличные','Банк','Наличные','Банк','Наличные'])
        self.assertEqual([r['category_name'] for r in rows],['Продажи','Возвраты','Внутренний перевод','Внутренний перевод','Прочие поступления','Химия бассейна'])

    def test_export_uses_accounting_date_for_expenses_and_excludes_void_sales(self):
        rows=cash_transactions(self.db,'2026-10-03','2026-10-03')
        self.assertEqual([(r['operation_type'],r['operation_id']) for r in rows],[('Возврат',2),('Перевод между счетами — входящий',1),('Перевод между счетами — исходящий',1),('Прочее поступление',1),('Расход',1)])

if __name__=='__main__': unittest.main()
