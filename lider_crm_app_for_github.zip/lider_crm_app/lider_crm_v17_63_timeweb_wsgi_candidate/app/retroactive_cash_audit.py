"""Read-only diagnostics for expenses entered after a relevant cash close."""


def find_late_cash_expenses(conn, limit=200):
    """Return expenses recorded after the first close that should have included them.

    An expense is suspicious when its business date is on or before a closed
    shift's date, but the record itself was created after that shift was closed.
    If multiple later closes qualify, only the earliest affected close is shown
    so a single expense is never counted more than once.
    """
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = 200
    limit = max(1, min(limit, 1000))
    return conn.execute(
        """SELECT e.id,e.expense_date,e.description,e.amount,e.payment_method,
                  e.created_by_name,e.created_at,
                  cs.id AS affected_shift_id,cs.shift_date AS affected_shift_date,
                  cs.closed_at AS affected_closed_at
           FROM cash_expenses e
           JOIN cash_shifts cs
             ON cs.status='closed'
            AND cs.shift_date>=e.expense_date
            AND cs.closed_at<e.created_at
           WHERE NOT EXISTS (
             SELECT 1
             FROM cash_shifts earlier
             WHERE earlier.status='closed'
               AND earlier.shift_date>=e.expense_date
               AND earlier.closed_at<e.created_at
               AND (
                 earlier.closed_at<cs.closed_at
                 OR (earlier.closed_at=cs.closed_at AND earlier.id<cs.id)
               )
           )
           ORDER BY e.created_at DESC,e.id DESC
           LIMIT ?""",
        (limit,),
    ).fetchall()
