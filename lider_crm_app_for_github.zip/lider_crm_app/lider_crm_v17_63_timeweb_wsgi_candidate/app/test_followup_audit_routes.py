import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).with_name('app.py').read_text(encoding='utf-8')
TREE = ast.parse(SOURCE)


def fn(name):
    node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment(SOURCE, node), [ast.unparse(d) for d in node.decorator_list]


class FollowupAuditRouteTests(unittest.TestCase):
    def test_routes_are_manager_only(self):
        for name in ('followup_audit_page', 'followup_audit_csv'):
            _, decorators = fn(name)
            self.assertIn('manager_required', decorators)

    def test_csv_is_safe_utf8_and_not_cached(self):
        source, _ = fn('followup_audit_csv')
        self.assertIn('safe_csv_row', source)
        self.assertIn('"\\ufeff"', source)
        self.assertIn('Cache-Control', source)
        self.assertIn('text/csv; charset=utf-8', source)

    def test_report_is_read_only_and_escapes_values(self):
        source, _ = fn('followup_audit_page')
        self.assertNotIn('INSERT INTO', source.upper())
        self.assertNotIn('UPDATE ', source.upper())
        self.assertNotIn('DELETE FROM', source.upper())
        self.assertIn('esc(row["details"])', source)
        self.assertIn('/followup-audit.csv', source)

    def test_manager_nav_contains_link(self):
        source, _ = fn('page')
        self.assertIn('/followup-audit', source)


if __name__ == '__main__':
    unittest.main()
