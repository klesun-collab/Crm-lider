import sqlite3
import unittest
from client_retention_report import build_client_retention_report, normalize_period_days


class ClientRetentionReportTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.db.row_factory = sqlite3.Row
        self.db.executescript("""
        CREATE TABLE clients(id INTEGER PRIMARY KEY, child_name TEXT, parent_name TEXT, phone TEXT, status TEXT);
        CREATE TABLE attendance(id INTEGER PRIMARY KEY, client_id INTEGER, lesson_date TEXT, status TEXT);
        CREATE TABLE subscriptions(id INTEGER PRIMARY KEY, client_id INTEGER, status TEXT, expires_at TEXT);
        INSERT INTO clients VALUES(1,'Аня','Мама','+79990000001','active');
        INSERT INTO clients VALUES(2,'Борис','Папа','+79990000002','active');
        INSERT INTO clients VALUES(3,'Вика','Мама','+79990000003','inactive');
        INSERT INTO clients VALUES(4,'Глеб','Папа','+79990000004','active');
        INSERT INTO attendance VALUES(1,1,'2026-10-01','attended');
        INSERT INTO attendance VALUES(2,1,'2026-10-10','attended');
        INSERT INTO attendance VALUES(3,1,'2026-10-16','attended');
        INSERT INTO attendance VALUES(4,2,'2026-09-10','attended');
        INSERT INTO attendance VALUES(5,2,'2026-10-02','missed');
        INSERT INTO attendance VALUES(6,3,'2026-08-01','attended');
        INSERT INTO subscriptions VALUES(1,1,'active','2026-11-01');
        INSERT INTO subscriptions VALUES(2,1,'active','2026-10-25');
        INSERT INTO subscriptions VALUES(3,2,'frozen','2026-10-20');
        """)

    def tearDown(self):
        self.db.close()

    def test_equal_windows_and_trend(self):
        rows = {r['client_id']: r for r in build_client_retention_report(self.db, '2026-10-17', 30)}
        self.assertEqual(rows[1]['current_visits'], 3)
        self.assertEqual(rows[1]['previous_visits'], 0)
        self.assertEqual(rows[1]['trend'], 'Посещаемость выросла')
        self.assertEqual(rows[2]['current_visits'], 0)
        self.assertEqual(rows[2]['previous_visits'], 1)
        self.assertEqual(rows[2]['trend'], 'Риск оттока')
        self.assertEqual(rows[3]['trend'], 'Нет посещений в периоде')
        self.assertEqual(rows[4]['trend'], 'Нет посещений')

    def test_missed_lessons_do_not_count_as_attendance(self):
        rows = {r['client_id']: r for r in build_client_retention_report(self.db, '2026-10-17', 30)}
        self.assertEqual(rows[2]['current_visits'], 0)

    def test_active_subscription_summary_ignores_frozen(self):
        rows = {r['client_id']: r for r in build_client_retention_report(self.db, '2026-10-17', 30)}
        self.assertEqual(rows[1]['active_subscriptions'], 2)
        self.assertEqual(rows[1]['nearest_expiry'], '2026-10-25')
        self.assertEqual(rows[2]['active_subscriptions'], 0)

    def test_date_and_period_validation(self):
        with self.assertRaises(ValueError):
            build_client_retention_report(self.db, '17/10/2026', 30)
        for value in (6, 91, 'abc', None):
            with self.assertRaises(ValueError):
                normalize_period_days(value)
        self.assertEqual(normalize_period_days('30'), 30)

    def test_limit_is_bounded_and_output_sorted_by_attention(self):
        rows = build_client_retention_report(self.db, '2026-10-17', 30, 2)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]['trend'], 'Риск оттока')

    def test_future_visits_are_not_counted(self):
        self.db.execute("INSERT INTO attendance VALUES(7,2,'2026-10-20','attended')")
        rows = {r['client_id']: r for r in build_client_retention_report(self.db, '2026-10-17', 30)}
        self.assertEqual(rows[2]['current_visits'], 0)
        self.assertEqual(rows[2]['last_visit'], '2026-09-10')


if __name__ == '__main__':
    unittest.main()
