"""Regression checks for the operator-facing install and deployment handoff."""
from pathlib import Path

ROOT = Path(__file__).parent


def test_windows_install_and_run_scripts_exist_and_use_local_environment():
    setup = (ROOT / "setup_and_run_windows.bat").read_text(encoding="utf-8")
    run = (ROOT / "run_windows.bat").read_text(encoding="utf-8")
    assert "pip install -r requirements.txt" in setup
    assert ".venv\\Scripts\\python.exe" in setup
    assert "http://127.0.0.1:5000/setup" in setup
    assert "app.py" in run


def test_windows_backup_launcher_runs_verified_backup_tool():
    backup = (ROOT / "backup_windows.bat").read_text(encoding="utf-8")
    assert "backup_database.py" in backup
    assert "Backup completed and verified" in backup


def test_deployment_checklist_covers_restore_and_sensitive_data():
    guide = (ROOT / "DEPLOYMENT_CHECKLIST.md").read_text(encoding="utf-8")
    assert "восстановление" in guide.lower()
    assert "персональные данные" in guide.lower()
    assert "мультитенантность не реализована" in guide.lower()


def test_settings_no_longer_claim_payroll_calculation_is_disabled():
    app = (ROOT / "app.py").read_text(encoding="utf-8")
    assert "автоматический расчёт зарплаты пока не включён" not in app
    assert "Зарплата рассчитывается по фактически отмеченным занятиям" in app
