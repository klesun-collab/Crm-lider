import argparse, sqlite3, os, getpass
from werkzeug.security import generate_password_hash
from datetime import datetime
p=argparse.ArgumentParser()
p.add_argument("action",choices=["add-admin","add-manager"])
p.add_argument("username")
args=p.parse_args()
db_path=os.environ.get("LIDER_CRM_DB",os.path.join(os.path.dirname(os.path.abspath(__file__)),"lider_crm.sqlite3"))
password=getpass.getpass("Пароль (не менее 12 символов): ")
if len(password)<12: raise SystemExit("Пароль слишком короткий.")
role="admin" if args.action=="add-admin" else "manager"
c=sqlite3.connect(db_path)
try:
 c.execute("INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)",
           (args.username,generate_password_hash(password),role,datetime.now().isoformat(timespec="seconds")))
 c.commit()
 print("Учётная запись создана:",args.username,role)
except sqlite3.IntegrityError:
 raise SystemExit("Такой логин уже существует.")
finally: c.close()
