import unittest
from money_format import format_rubles_from_kopecks


class MoneyFormatTests(unittest.TestCase):
    def test_formats_positive_negative_and_zero_kopecks_exactly(self):
        self.assertEqual(format_rubles_from_kopecks(12550), "125,50")
        self.assertEqual(format_rubles_from_kopecks(-1364402), "-13 644,02")
        self.assertEqual(format_rubles_from_kopecks(0), "0,00")

    def test_rejects_non_integer_money_values(self):
        for value in ("not money", object()):
            with self.subTest(value=type(value).__name__), self.assertRaises(ValueError):
                format_rubles_from_kopecks(value)


if __name__ == "__main__":
    unittest.main()
