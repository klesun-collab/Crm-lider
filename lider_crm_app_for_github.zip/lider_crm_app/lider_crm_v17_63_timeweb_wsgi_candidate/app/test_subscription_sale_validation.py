"""Regression checks for the legacy subscription sale form."""
from pathlib import Path
import unittest

SOURCE = (Path(__file__).parent / 'app.py').read_text(encoding='utf-8')


class LegacySubscriptionSaleValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        start = SOURCE.index('def subscriptions():')
        end = SOURCE.index('@app.route("/subscription/<int:sub_id>/freeze"', start)
        cls.section = SOURCE[start:end]

    def test_payment_method_is_validated_before_sale_insert(self):
        validation = self.section.index('if payment_method not in ("cash","card","transfer","qr")')
        insert = self.section.index('INSERT INTO sales(client_id,item,amount,payment_method,status,created_by,created_at,subscription_id,campaign_id)')
        self.assertLess(validation, insert)
        self.assertIn('Неверный способ оплаты', self.section)

    def test_expiry_must_be_iso_date_and_not_in_past(self):
        self.assertIn('date.fromisoformat(expires_at)', self.section)
        self.assertIn('Укажите корректную дату окончания абонемента', self.section)
        self.assertIn('if expires_at<today(): abort(400,"Срок действия нового абонемента не может быть в прошлом")', self.section)

    def test_sale_and_subscription_remain_linked_in_same_flow(self):
        self.assertIn('(client_id,title,total,total,price,today(),expires_at,session["uid"])', self.section)
        self.assertIn('"sale.created"', self.section)
        self.assertIn('"linked_subscription":cur.lastrowid', self.section)


if __name__ == '__main__':
    unittest.main()
