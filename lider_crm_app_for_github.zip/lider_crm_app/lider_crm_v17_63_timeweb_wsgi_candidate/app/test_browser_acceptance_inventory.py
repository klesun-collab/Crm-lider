"""Keep read-only browser acceptance aligned with high-value deployed routes."""
from pathlib import Path
import unittest

BASE = Path(__file__).parent


class BrowserAcceptanceInventoryTests(unittest.TestCase):
    def test_sensitive_csv_exports_are_checked_for_admin_denial(self):
        source = (BASE / "acceptance_audit" / "browser_acceptance.py").read_text(encoding="utf-8")
        for path in (
            '"/cash.csv"', '"/wallets"', '"/payroll.csv"', '"/reports.csv"',
            '"/system-check.csv"', '"/reconciliation/late-expenses.csv"',
            '"/reconciliation/cash-shift-mismatches.csv"',
            '"/client-data-quality.csv"', '"/subscription-integrity.csv"',
            '"/client-retention.csv"',
        ):
            self.assertIn(path, source, f"Browser acceptance misses sensitive route {path}")

    def test_read_only_harness_does_not_call_sqlite_backup_endpoint(self):
        source = (BASE / "acceptance_audit" / "browser_acceptance.py").read_text(encoding="utf-8")
        self.assertNotIn('"/backup/sqlite"', source)
        self.assertIn("does not create, edit, import, sell, refund", source)


    def test_trainer_shift_and_attendance_reports_are_checked(self):
        source = (BASE / "acceptance_audit" / "browser_acceptance.py").read_text(encoding="utf-8")
        for path in ('"/attendance-report"', '"/one-visit"'):
            self.assertIn(path, source)
        for selector in ('input[name="repeat_start_time"]', 'input[name="repeat_end_time"]', 'input[name="weekdays"]', 'select[name="repeat_trainer_id"]'):
            self.assertIn(selector, source)
        self.assertIn('check_schedule_controls(page, "Администратор", failures)', source)


    def test_group_and_waitlist_routes_are_checked_in_browser(self):
        source = (BASE / "acceptance_audit" / "browser_acceptance.py").read_text(encoding="utf-8")
        self.assertIn('"/groups"', source)
        self.assertIn('"/waitlist"', source)
        self.assertIn('check_groups_and_waitlist(page, "Руководитель", failures)', source)
        self.assertIn('check_groups_and_waitlist(page, "Администратор", failures)', source)

    def test_trial_lesson_route_is_checked_read_only_for_both_roles(self):
        source = (BASE / "acceptance_audit" / "browser_acceptance.py").read_text(encoding="utf-8")
        self.assertIn("/trial-lessons", source)
        self.assertIn("/journal", source)
        self.assertIn('check_trial_lesson_page(page, "Руководитель", failures)', source)
        self.assertIn('check_trial_lesson_page(page, "Администратор", failures)', source)

    def test_wallet_and_sale_forms_are_checked_read_only(self):
        source = (BASE / "acceptance_audit" / "browser_acceptance.py").read_text(encoding="utf-8")
        self.assertIn('select[name=\"wallet_id\"]', source)
        self.assertIn('check_wallet_and_sale_forms(page, "Руководитель", failures)', source)
        self.assertIn('check_wallet_and_sale_forms(page, "Администратор", failures)', source)
        self.assertIn('"/expense-categories"', source)
        self.assertIn('"/income-categories"', source)
        self.assertIn("Руководитель: категории поступлений HTTP 200", source)
        self.assertIn('form[action="/cash/income"]', source)
        self.assertIn("Руководитель: форма прочего поступления", source)
        self.assertIn('"/loyalty"', source)
        self.assertIn("Руководитель: бонусная программа HTTP 200", source)
        self.assertIn("Руководитель: категории расходов HTTP 200", source)

    def test_browser_dependencies_have_install_instructions(self):
        readme = (BASE / "acceptance_audit" / "BROWSER_ACCEPTANCE_README_RU.md").read_text(encoding="utf-8")
        self.assertIn("requirements-browser.txt", readme)
        self.assertIn("playwright install chromium", readme)


if __name__ == "__main__":
    unittest.main()
