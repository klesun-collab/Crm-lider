"""Static inventory guard: every application route must declare its auth boundary.

This complements request-level tests and catches newly added routes that accidentally
omit login_required/manager_required. /setup, /login and / are deliberate exceptions.
"""
import ast
from pathlib import Path
import unittest

SOURCE_PATH = Path(__file__).with_name("app.py")
TREE = ast.parse(SOURCE_PATH.read_text(encoding="utf-8"))
PUBLIC_ENDPOINTS = {"setup", "login", "root"}


def route_inventory():
    result = []
    for node in TREE.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        decorators = [ast.unparse(d) for d in node.decorator_list]
        routes = [d for d in decorators if d.startswith("app.route(") or d.startswith("app.get(") or d.startswith("app.post(")]
        if routes:
            result.append((node.name, routes, decorators, node.lineno))
    return result


class RouteSecurityInventoryTests(unittest.TestCase):
    def test_every_route_has_explicit_auth_boundary(self):
        missing = []
        for name, routes, decorators, line in route_inventory():
            protected = any("login_required" in d or "manager_required" in d for d in decorators)
            if name not in PUBLIC_ENDPOINTS and not protected:
                missing.append(f"line {line}: {name} {routes}")
        self.assertEqual([], missing, "Routes missing an explicit auth decorator:\n" + "\n".join(missing))

    def test_only_expected_public_endpoints_are_exempt(self):
        names = {name for name, _, _, _ in route_inventory()}
        self.assertTrue(PUBLIC_ENDPOINTS.issubset(names))
        unprotected = {
            name for name, _, decorators, _ in route_inventory()
            if not any("login_required" in d or "manager_required" in d for d in decorators)
        }
        self.assertEqual(PUBLIC_ENDPOINTS, unprotected)

    def test_sensitive_routes_use_manager_guard(self):
        sensitive = {
            "settings", "manage_users_page", "save_rates", "cash_close_shift",
            "cash_journal", "cash_add_other_income", "cash_add_expense", "cash_save_opening", "cash_csv",
            "income_categories_page", "expense_categories_page", "wallets_page", "loyalty_page",
            "discounts_page", "discount_toggle", "products", "product_edit", "product_receive",
            "product_writeoff", "reconciliation_late_expenses_csv",
            "reconciliation_cash_shift_mismatches_csv", "reconciliation", "payroll",
            "payroll_csv", "reports", "reports_csv", "backup_export", "backup_sqlite",
            "schedule_audit_csv", "schedule_audit_page", "followup_audit_csv",
            "followup_audit_page", "client_data_quality_csv", "client_data_quality_page",
            "subscription_integrity_csv", "subscription_integrity_page", "client_retention_csv",
            "client_retention_page", "audit_page", "system_check_csv", "system_check_page",
        }
        found = {name: decorators for name, _, decorators, _ in route_inventory()}
        missing = sorted(name for name in sensitive if name not in found or not any("manager_required" in d for d in found[name]))
        self.assertEqual([], missing, "Sensitive routes missing manager guard: " + ", ".join(missing))


if __name__ == "__main__":
    unittest.main()
