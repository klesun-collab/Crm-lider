#!/usr/bin/env python3
"""Read-only aggregate quality audit for a GoCRM client-card XLSX export.

Outputs only aggregate counts and money totals; it does not write to CRM and
never emits names, phone numbers, source URLs, or raw rows.
"""
import argparse
import json
import sys
from datetime import date, datetime
from pathlib import Path

import pandas as pd

COLS = {
    'id': 'Номер клиента', 'name': 'Имя ребенка', 'phone': 'Телефон',
    'status': 'Статус', 'registered': 'Дата регистрации в системе',
    'last_payment_date': 'Дата последней оплаты', 'last_payment_amount': 'Cумма последней оплаты, ₽',
    'debt': 'Задолженность, ₽', 'lifetime': 'Всего заплатил, ₽',
    'next_lesson': 'Дата следующего занятия', 'last_visit': 'Дата последнего посещения',
    'first_visit': 'Дата первого посещения',
    'subscription': 'Абонементы (наименование, тип занятия, остаток, стоимость при покупке)',
}


def present(v):
    if v is None:
        return False
    try:
        if pd.isna(v):
            return False
    except (TypeError, ValueError):
        pass
    return bool(str(v).strip())


def parsed_date(v):
    if not present(v):
        return None
    try:
        ts = pd.to_datetime(v, dayfirst=True, errors='coerce')
        if pd.isna(ts):
            return None
        return ts.date()
    except (TypeError, ValueError, OverflowError):
        return None


def decimal_value(v):
    from decimal import Decimal, InvalidOperation
    if not present(v):
        return Decimal('0')
    raw = str(v).replace('\u00a0', '').replace(' ', '').replace(',', '.').replace('₽', '').replace('руб.', '')
    try:
        return Decimal(raw)
    except InvalidOperation:
        return Decimal('0')


def audit_dataframe(df, as_of=None):
    missing = set(COLS.values()) - set(df.columns)
    if missing:
        raise RuntimeError('Не найдены обязательные столбцы: ' + ', '.join(sorted(missing)))
    today = as_of or date.today()
    n = len(df)
    status_norm = df[COLS['status']].fillna('').astype(str).str.strip().str.lower()
    status_counts = {
        'active': int(status_norm.isin(['активный', 'active']).sum()),
        'archived': int(status_norm.isin(['архивный', 'archived']).sum()),
        'lost': int(status_norm.isin(['потеряшка', 'lost']).sum()),
        'inactive': int(status_norm.isin(['не активный', 'неактивный', 'inactive']).sum()),
        'unknown_or_blank': int((~status_norm.isin(['активный', 'active', 'архивный', 'archived', 'потеряшка', 'lost', 'не активный', 'неактивный', 'inactive'])).sum()),
    }
    id_values = df[COLS['id']].map(lambda x: str(x).strip() if present(x) else '')
    phone_values = df[COLS['phone']].map(lambda x: ''.join(ch for ch in str(x) if ch.isdigit()) if present(x) else '')
    first_dates = df[COLS['first_visit']].map(parsed_date)
    last_dates = df[COLS['last_visit']].map(parsed_date)
    next_dates = df[COLS['next_lesson']].map(parsed_date)
    payment_dates = df[COLS['last_payment_date']].map(parsed_date)
    payment_amounts = df[COLS['last_payment_amount']].map(decimal_value)
    debts = df[COLS['debt']].map(decimal_value)
    lifetime = df[COLS['lifetime']].map(decimal_value)
    subscriptions = df[COLS['subscription']].map(present)
    # Validate date values without exposing row-level values.
    first_last_inverted = sum(bool(f and l and f > l) for f, l in zip(first_dates, last_dates))
    last_visit_future = sum(bool(d and d > today) for d in last_dates)
    next_lesson_past = sum(bool(d and d < today) for d in next_dates)
    payment_date_missing_amount_present = sum(bool((not d) and a != 0) for d, a in zip(payment_dates, payment_amounts))
    amount_present_date_missing = payment_date_missing_amount_present
    return {
        'report_type': 'aggregate_read_only_quality_audit',
        'as_of_date': today.isoformat(),
        'source_rows': n,
        'missing_source_ids': int((id_values == '').sum()),
        'duplicate_source_ids': int(id_values[id_values != ''].duplicated().sum()),
        'missing_child_names': int((~df[COLS['name']].map(present)).sum()),
        'missing_phone': int((phone_values == '').sum()),
        'status_counts': status_counts,
        'rows_with_subscription_summary': int(subscriptions.sum()),
        'rows_with_nonzero_debt': int((debts != 0).sum()),
        'negative_debt_rows': int((debts < 0).sum()),
        'positive_debt_rows': int((debts > 0).sum()),
        'debt_sum_rub': str(sum(debts)),
        'lifetime_paid_sum_rub': str(sum(lifetime)),
        'last_payment_summary_sum_rub': str(sum(payment_amounts)),
        'rows_with_last_payment_amount_but_no_valid_date': amount_present_date_missing,
        'rows_with_first_visit_after_last_visit': first_last_inverted,
        'rows_with_last_visit_in_future': last_visit_future,
        'rows_with_next_lesson_in_past': next_lesson_past,
        'limitations': [
            'Only aggregate summary fields from client-card export were available; no full attendance ledger was supplied.',
            'Date and money anomalies are review flags, not proof of an error.',
            'Debt/payment/lifetime totals are source summaries, not cash ledger entries.',
            'No individual names, phone numbers, URLs, or raw rows are included in this report.'
        ],
        'database_changed': False,
    }


def audit_file(xlsx, output_json, as_of=None):
    df = pd.read_excel(xlsx, dtype=object)
    report = audit_dataframe(df, as_of=as_of)
    out = Path(output_json)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    return report


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--xlsx', required=True, help='Исходная выгрузка GoCRM XLSX')
    ap.add_argument('--out', required=True, help='Путь к агрегированному JSON-отчёту')
    ap.add_argument('--as-of', help='Дата для проверки будущих/прошедших дат, YYYY-MM-DD')
    args = ap.parse_args()
    try:
        as_of = date.fromisoformat(args.as_of) if args.as_of else None
        print(json.dumps(audit_file(args.xlsx, args.out, as_of=as_of), ensure_ascii=False, indent=2))
        return 0
    except Exception as e:
        print('ОШИБКА:', e, file=sys.stderr)
        return 2

if __name__ == '__main__':
    raise SystemExit(main())
