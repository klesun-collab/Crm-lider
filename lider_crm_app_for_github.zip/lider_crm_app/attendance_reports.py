"""Read-only attendance reports aligned with Go-CRM's attendance analytics."""
from datetime import date


def validate_period(start, end):
    try:
        parsed_start = date.fromisoformat(str(start))
        parsed_end = date.fromisoformat(str(end))
    except (TypeError, ValueError):
        raise ValueError("Укажите корректный период в формате ГГГГ-ММ-ДД")
    if parsed_start.isoformat() != str(start) or parsed_end.isoformat() != str(end):
        raise ValueError("Укажите корректный период в формате ГГГГ-ММ-ДД")
    if parsed_start > parsed_end:
        raise ValueError("Начало периода не может быть позже его окончания")
    return parsed_start.isoformat(), parsed_end.isoformat()


def get_attendance_report_rows(conn, start, end):
    """Return per-client attended/missed counts for the selected lesson-date period."""
    start, end = validate_period(start, end)
    return conn.execute("""WITH attendance_summary AS (
        SELECT client_id,
          COUNT(CASE WHEN status='attended' THEN 1 END) attended_count,
          COUNT(CASE WHEN status='missed' THEN 1 END) missed_count,
          COUNT(CASE WHEN status='cancelled' THEN 1 END) cancelled_count,
          MIN(CASE WHEN status='attended' THEN lesson_date END) first_attended,
          MAX(CASE WHEN status='attended' THEN lesson_date END) last_attended,
          COUNT(*) attendance_rows
        FROM attendance WHERE lesson_date BETWEEN ? AND ? GROUP BY client_id
      ), sales_summary AS (
        SELECT client_id,
          COUNT(CASE WHEN status='completed' THEN 1 END) completed_sales,
          COALESCE(SUM(CASE WHEN status='completed' THEN amount WHEN status='refund' THEN -amount ELSE 0 END),0) net_sales,
          COUNT(*) sales_rows
        FROM sales WHERE substr(created_at,1,10) BETWEEN ? AND ? GROUP BY client_id
      )
      SELECT c.id client_id,c.child_name,c.parent_name,c.phone,c.status client_status,
        COALESCE(a.attended_count,0) attended_count,COALESCE(a.missed_count,0) missed_count,
        COALESCE(a.cancelled_count,0) cancelled_count,a.first_attended,a.last_attended,
        COALESCE(s.completed_sales,0) completed_sales,COALESCE(s.net_sales,0) net_sales
      FROM clients c LEFT JOIN attendance_summary a ON a.client_id=c.id
      LEFT JOIN sales_summary s ON s.client_id=c.id
      WHERE c.status!='archived' AND (COALESCE(a.attendance_rows,0)>0 OR COALESCE(s.sales_rows,0)>0)
      ORDER BY c.child_name COLLATE NOCASE,c.id""", (start, end, start, end)).fetchall()


def get_one_visit_rows(conn, start, end):
    """Clients with exactly one attended lesson ever, whose sole visit is in period.

    Archived clients are excluded to match the Go-CRM report's documented behavior.
    The query is read-only and does not change client status or create follow-up tasks.
    """
    start, end = validate_period(start, end)
    return conn.execute("""SELECT c.id client_id,c.child_name,c.parent_name,c.phone,c.status client_status,
        MIN(a.lesson_date) first_visit, MIN(a.lesson_time) first_visit_time
        FROM clients c JOIN attendance a ON a.client_id=c.id AND a.status='attended'
        WHERE c.status IN ('active','inactive','lost')
        GROUP BY c.id,c.child_name,c.parent_name,c.phone,c.status
        HAVING COUNT(a.id)=1 AND MIN(a.lesson_date) BETWEEN ? AND ?
        ORDER BY first_visit DESC,c.child_name COLLATE NOCASE""", (start, end)).fetchall()
