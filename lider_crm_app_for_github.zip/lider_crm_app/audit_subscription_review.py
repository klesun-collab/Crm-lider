#!/usr/bin/env python3
"""Produce an aggregate, privacy-safe QA report from the subscription review CSV.

This is diagnostic only. It never approves/imports subscriptions or touches CRM DB.
"""
import argparse, csv, json
from collections import Counter, defaultdict
from pathlib import Path


def run_audit(csv_path):
    with open(csv_path, newline='', encoding='utf-8-sig') as f:
        rows = list(csv.DictReader(f))
    seen_no = Counter(r.get('subscription_no','').strip() for r in rows if r.get('subscription_no','').strip())
    seen_pair = Counter((r.get('source_client_id','').strip(), r.get('subscription_no','').strip()) for r in rows if r.get('source_client_id','').strip() and r.get('subscription_no','').strip())
    types = Counter(r.get('lesson_type','').strip() or '(не определён)' for r in rows)
    flags = Counter()
    for r in rows:
        for flag in (r.get('flags','') or '').split(';'):
            flag = flag.strip()
            if flag and flag != 'Сверить с первоисточником':
                flags[flag] += 1
    def as_int(v):
        try: return int(str(v).strip())
        except (ValueError, TypeError): return None
    remaining = [as_int(r.get('remaining_lessons')) for r in rows]
    remaining = [x for x in remaining if x is not None]
    totals = [as_int(r.get('total_lessons_hint')) for r in rows]
    price_missing = sum(not (r.get('purchase_rub') or '').strip() for r in rows)
    price_zero = sum((r.get('purchase_rub') or '').strip() == '0.00' for r in rows)
    negative = sum(x < 0 for x in remaining)
    no_total = sum(as_int(r.get('total_lessons_hint')) is None for r in rows)
    over_total = sum(as_int(r.get('remaining_lessons')) is not None and as_int(r.get('total_lessons_hint')) is not None and as_int(r.get('remaining_lessons')) > as_int(r.get('total_lessons_hint')) for r in rows)
    duplicate_number_rows = sum(n > 1 for n in seen_no.values())
    duplicate_pair_rows = sum(n > 1 for n in seen_pair.values())
    return {
      'report': 'GoCRM subscription summary review — aggregate QA',
      'review_rows': len(rows),
      'lesson_type_counts': dict(sorted(types.items())),
      'checks': {
        'rows_with_duplicate_subscription_number': duplicate_number_rows,
        'rows_with_duplicate_client_and_subscription_number': duplicate_pair_rows,
        'negative_remaining_count': negative,
        'remaining_greater_than_inferred_total_count': over_total,
        'rows_without_inferred_total_lessons': no_total,
        'rows_with_unparsed_purchase_price': price_missing,
        'rows_with_zero_purchase_price': price_zero,
      },
      'flag_counts': dict(sorted(flags.items())),
      'import_decision': 'NONE — every row still requires source reconciliation; do not import from this summary alone',
      'database_changed': False,
      'subscriptions_created': 0,
      'sales_created': 0,
      'attendance_created': 0,
      'privacy': 'Aggregate counts only; no client names, phones, URLs, IDs, or raw summary strings included.'
    }


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--csv', required=True, help='Private CSV from prepare_subscription_review.py')
    ap.add_argument('--out', required=True, help='Aggregate JSON report path')
    args=ap.parse_args()
    result=run_audit(args.csv)
    out=Path(args.out); out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0
if __name__=='__main__': raise SystemExit(main())
