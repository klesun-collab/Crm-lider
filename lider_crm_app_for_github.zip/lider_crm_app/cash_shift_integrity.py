"""Read-only checks for arithmetic consistency of saved cash closeouts."""


def find_cash_shift_math_mismatches(conn, limit=200):
    """Return closed shifts where stored differences disagree with the saved totals.

    This catches corrupted or legacy inconsistent closeout rows even when the
    stored difference is zero and the normal discrepancy list would hide them.
    No values are repaired here.
    """
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = 200
    limit = max(1, min(limit, 1000))
    return conn.execute(
        """SELECT id,shift_date,expected_cash,actual_cash,cash_difference,
                  (actual_cash-expected_cash) AS calculated_cash_difference,
                  expected_noncash,actual_noncash,noncash_difference,
                  (actual_noncash-expected_noncash) AS calculated_noncash_difference,
                  note,closed_at
           FROM cash_shifts
           WHERE status='closed'
             AND (cash_difference != actual_cash-expected_cash
                  OR noncash_difference != actual_noncash-expected_noncash)
           ORDER BY shift_date DESC,id DESC LIMIT ?""",
        (limit,),
    ).fetchall()
