"""Read-only client attendance trend report for manager retention work."""
from datetime import date, timedelta

FIELDS = (
    "client_id", "child_name", "parent_name", "phone", "client_status",
    "last_visit", "current_visits", "previous_visits", "trend",
    "active_subscriptions", "nearest_expiry",
)


def normalize_period_days(value):
    try:
        days = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("Период должен быть числом дней") from exc
    if days < 7 or days > 90:
        raise ValueError("Период должен быть от 7 до 90 дней")
    return days


def build_client_retention_report(conn, as_of=None, period_days=30, limit=2000):
    """Compare attended lessons in two equal windows; never changes CRM data."""
    current = str(as_of or date.today().isoformat())
    try:
        end_day = date.fromisoformat(current)
    except (TypeError, ValueError) as exc:
        raise ValueError("Дата отчёта должна быть в формате ГГГГ-ММ-ДД") from exc
    days = normalize_period_days(period_days)
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = 2000
    limit = max(1, min(limit, 5000))
    current_start = (end_day - timedelta(days=days - 1)).isoformat()
    previous_end = (end_day - timedelta(days=days)).isoformat()
    previous_start = (end_day - timedelta(days=2 * days - 1)).isoformat()

    rows = conn.execute(
        """SELECT cl.id client_id, cl.child_name, cl.parent_name, cl.phone,
                  cl.status client_status,
                  (SELECT MAX(a.lesson_date) FROM attendance a
                    WHERE a.client_id=cl.id AND a.status='attended' AND a.lesson_date<=?) last_visit,
                  (SELECT COUNT(*) FROM attendance a
                    WHERE a.client_id=cl.id AND a.status='attended'
                      AND a.lesson_date>=? AND a.lesson_date<=?) current_visits,
                  (SELECT COUNT(*) FROM attendance a
                    WHERE a.client_id=cl.id AND a.status='attended'
                      AND a.lesson_date>=? AND a.lesson_date<=?) previous_visits,
                  (SELECT COUNT(*) FROM subscriptions s
                    WHERE s.client_id=cl.id AND s.status='active') active_subscriptions,
                  (SELECT MIN(s.expires_at) FROM subscriptions s
                    WHERE s.client_id=cl.id AND s.status='active'
                      AND COALESCE(s.expires_at,'')<>'') nearest_expiry
           FROM clients cl
           ORDER BY cl.child_name COLLATE NOCASE, cl.id
           LIMIT ?""",
        (current, current_start, current, previous_start, previous_end, limit),
    ).fetchall()

    result = []
    for row in rows:
        item = dict(row)
        now_count = int(item["current_visits"] or 0)
        before_count = int(item["previous_visits"] or 0)
        last_visit = str(item["last_visit"] or "")
        if not last_visit:
            trend = "Нет посещений"
        elif now_count == 0 and before_count > 0:
            trend = "Риск оттока"
        elif now_count == 0 and last_visit < current_start:
            trend = "Нет посещений в периоде"
        elif now_count < before_count:
            trend = "Посещаемость снизилась"
        elif now_count > before_count:
            trend = "Посещаемость выросла"
        else:
            trend = "Без изменений"
        item["trend"] = trend
        result.append(item)
    priority = {"Риск оттока": 0, "Нет посещений в периоде": 1,
                "Посещаемость снизилась": 2, "Нет посещений": 3,
                "Без изменений": 4, "Посещаемость выросла": 5}
    result.sort(key=lambda x: (priority.get(x["trend"], 9), x["last_visit"] or "0000-00-00",
                               str(x["child_name"] or "").casefold(), int(x["client_id"])))
    return result
