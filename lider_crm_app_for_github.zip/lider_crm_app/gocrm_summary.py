"""Read-only access to imported GoCRM summary fields for reconciliation."""


def load_gocrm_client_summary(connection, client_id):
    """Return the imported summary row, or None before GoCRM import was applied."""
    exists = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='gocrm_client_summary'"
    ).fetchone()
    if not exists:
        return None
    return connection.execute(
        """SELECT client_id,source_id,subscription_summary,last_payment_date,
                  last_payment_amount_kopecks,debt_amount_kopecks,lifetime_paid_amount_kopecks,
                  next_lesson_date,last_visit_date,first_visit_date
           FROM gocrm_client_summary WHERE client_id=?""",
        (client_id,),
    ).fetchone()
