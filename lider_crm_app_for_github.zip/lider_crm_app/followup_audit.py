"""Read-only audit for overdue leads/tasks and inconsistent lead conversion state."""
from datetime import date, datetime

FIELDS = ("issue_type", "severity", "record_id", "due_at", "parent_name", "child_name", "phone", "title", "status", "assignee", "details")


def build_followup_audit(conn, current_date=None, current_datetime=None, limit=1000):
    day = str(current_date or date.today().isoformat())
    moment = str(current_datetime or (day + "T23:59:59"))
    try:
        date.fromisoformat(day)
        datetime.fromisoformat(moment)
    except ValueError as exc:
        raise ValueError("Дата или время имеют неверный формат") from exc
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = 1000
    limit = max(1, min(limit, 5000))
    issues = []

    for row in conn.execute(
        """SELECT l.id,l.next_contact,l.parent_name,l.child_name,l.phone,l.status,
                  COALESCE(u.username,'') assignee
           FROM leads l LEFT JOIN users u ON u.id=l.assigned_to
           WHERE l.status NOT IN ('converted','lost') AND COALESCE(l.next_contact,'')<>''
             AND l.next_contact<=?
           ORDER BY l.next_contact,l.id LIMIT ?""", (day, limit)
    ).fetchall():
        issues.append({
            "issue_type": "lead_followup_due", "severity": "high" if row["next_contact"] < day else "medium",
            "record_id": row["id"], "due_at": row["next_contact"], "parent_name": row["parent_name"],
            "child_name": row["child_name"], "phone": row["phone"], "title": "Перезвон по заявке",
            "status": row["status"], "assignee": row["assignee"],
            "details": "Дата следующего контакта наступила; заявка ещё не закрыта",
        })

    for row in conn.execute(
        """SELECT l.id,l.parent_name,l.child_name,l.phone,l.status,l.client_id
           FROM leads l LEFT JOIN clients cl ON cl.id=l.client_id
           WHERE l.status='converted' AND (l.client_id IS NULL OR cl.id IS NULL)
           ORDER BY l.id LIMIT ?""", (limit,)
    ).fetchall():
        issues.append({
            "issue_type": "converted_lead_without_client", "severity": "high", "record_id": row["id"],
            "due_at": "", "parent_name": row["parent_name"], "child_name": row["child_name"],
            "phone": row["phone"], "title": "Проверить конвертацию заявки", "status": row["status"],
            "assignee": "", "details": "Заявка отмечена клиентом, но связанная карточка отсутствует",
        })

    for row in conn.execute(
        """SELECT t.id,t.title,t.due_at,t.status,t.notes,t.client_id,t.lead_id,
                  COALESCE(c.parent_name,'') client_parent,COALESCE(c.child_name,'') client_child,
                  COALESCE(c.phone,'') client_phone,COALESCE(l.parent_name,'') lead_parent,
                  COALESCE(l.child_name,'') lead_child,COALESCE(l.phone,'') lead_phone,
                  COALESCE(u.username,'') assignee
           FROM tasks t LEFT JOIN clients c ON c.id=t.client_id LEFT JOIN leads l ON l.id=t.lead_id
           LEFT JOIN users u ON u.id=t.assigned_to
           WHERE t.status='open' AND t.due_at<?
           ORDER BY t.due_at,t.id LIMIT ?""", (moment, limit)
    ).fetchall():
        parent = row["client_parent"] or row["lead_parent"]
        child = row["client_child"] or row["lead_child"]
        phone = row["client_phone"] or row["lead_phone"]
        issues.append({
            "issue_type": "task_overdue", "severity": "high", "record_id": row["id"],
            "due_at": row["due_at"], "parent_name": parent, "child_name": child, "phone": phone,
            "title": row["title"], "status": row["status"], "assignee": row["assignee"],
            "details": row["notes"] or "Открытая задача просрочена",
        })

    severity_order = {"high": 0, "medium": 1, "low": 2}
    issues.sort(key=lambda row: (severity_order.get(row["severity"], 9), row["due_at"], row["issue_type"], str(row["record_id"])))
    return issues[:limit]
