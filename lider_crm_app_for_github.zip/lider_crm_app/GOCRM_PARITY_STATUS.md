# GoCRM parity status — Лидер CRM v17.56

## Изменения v17.56
- Добавлен `/journal` (пункт меню «Электронная тетрадь») — ежедневный электронный журнал, близкий по задаче к «Электронной тетради» Go-CRM: выбор даты, список занятий и детей, статусы записей, сводка посещений/пропусков, переход к расписанию, продажам и задачам.
- Сводка продаж, возвратов и расходов за день отображается только руководителю; администратор видит операционные показатели без финансовых сумм.
- Модуль агрегации `daily_journal.py` работает только на чтение. Тесты проверяют отсутствие задвоения слотов и отсутствие изменений данных.
- Реальная браузерная приёмка всё ещё не выполнена: среда сборки не содержит Flask/Werkzeug/xlrd, сеть установки недоступна.

## Изменения v17.55
- Добавлены режимы расписания: день, список на 14 дней, недельный календарь с группировкой по тренеру или помещению/дорожке и календарь месяца.
- Добавлен справочник помещений/бассейнов и дорожек. Слот может одновременно ссылаться на помещение и дорожку; создание, редактирование и массовая генерация проверяют временные пересечения по каждому ресурсу.
- Добавлен общий read-only журнал звонков/контактов с фильтрами периода, результата и поиска по клиенту/телефону/заметке.
- Добавлены регрессионные тесты для новых сценариев и требований к миграции схемы.
- SQL-схема из `init_db` проверена напрямую через SQLite: `integrity_check=ok`, `foreign_key_check` пуст.
- Полный браузерный прогон не выполнен: в среде отсутствуют Flask/Werkzeug и xlrd; pip не может разрешить DNS. Не считать это успешной браузерной приёмкой.

Полный сравнительный аудит и видео-реестр: `GOCRM_REFERENCE_REVIEW_v17_55.md`, `GOCRM_VIDEO_REVIEW_v17_55.md`, `GOCRM_parity_matrix_v17_55.csv`.


## Историческая заметка по сравнению v17.53/v17.54

Основные документы: `GOCRM_REFERENCE_REVIEW_v17_54.md`, `GOCRM_VIDEO_REVIEW_v17_54.md` и `GOCRM_parity_matrix_v17_54.csv`. Источники: [официальное руководство Go-CRM](https://go-crm.ru/files/user-manual-gocrm.pdf), [Go-CRM для центров плавания](https://go-crm.ru/plavatelnyie-czentryi.html), [официальный YouTube-канал коротких обзоров](https://www.youtube.com/channel/UCeoaFJqAPJCjjFimmE8o1wQ/videos), [видео-отзыв](https://www.youtube.com/watch?v=zeqqLba2USU), исходная матрица v17.46 и передача проекта.

### Изменения v17.54
- Добавлен раздел групп: постоянные группы детей, мягкое исключение участников и сохранение истории. Администратор может атомарно записать всех активных участников группы на групповой слот, указав абонемент каждого ребёнка; членство само по себе не списывает абонемент.
- Добавлен лист ожидания: желаемые дата/время/тренер, статус, комментарий; запись из листа ожидания в слот проверяет вместимость, тренера, абонемент и его срок действия в одной транзакции.
- Для листа ожидания добавлены регрессионные тесты; фактическая браузерная приёмка всё ещё не выполнена.

### Изменения v17.53
- Администратор ведёт список тренеров: добавление, изменение имени, включение/отключение без физического удаления истории. Нельзя отключить тренера с будущими активными записями.
- Повторяющееся расписание по дням недели и редактирование свободных будущих слотов доступны администратору. Ставки и финансовые отчёты остаются за руководителем.
- Добавлены read-only отчёт посещаемости и список клиентов с одним посещением; у администратора скрыты финансовые суммы, у руководителя они доступны. Отчёты не изменяют записи.
- Добавлены тесты на безопасное управление тренерами, права расписания, валидацию периода и правильные SQL-агрегаты без удвоения продаж из-за JOIN.
- В архиве исходников нет пользовательских видеофайлов; публичные материалы найдены на официальном сайте. Нельзя утверждать, что просмотрены все видео YouTube или приватные экраны действующего аккаунта.


This is a pragmatic feature checklist, not a claim of complete parity with GoCRM. Full parity requires comparing the live GoCRM configuration, permissions, exports, and business rules against a real test database.

## Available in this build
- Clients, parent contacts, search, client profile, sales and subscription history.
- Subscriptions, expiry, freezes, attendance journal, booking and missed-lesson restoration.
- Trainers, scheduled slots, capacity enforcement, recurring schedule creation and overlap validation.
- Leads, client conversion, follow-up tasks, reactivation, renewal worklist and campaign reporting.
- Sales, refunds with manager approval, cash expenses, cash closeouts, products/stock movements, payroll and reconciliation reports.
- Audit log, role checks, CSRF protection, secure response headers, session revocation after password changes.
- SQLite backups, SHA-256 manifests, backup verification and inventory export.
- Read-only schedule, follow-up, client-data-quality, and subscription-integrity audits; CSV exports are guarded and spreadsheet-safe.

- Manager-only client-data-quality report flags malformed phones and birth dates, shared phone numbers for manual review, and open leads missing source/next-contact details. It never merges or edits records.

## Still requires validation or implementation
- Visual/browser acceptance testing on the actual target machine and supported browsers.
- Reconciliation of imported GoCRM records, balances, freeze history, and attendance against a real export before production use.
- Confirmation of the club's exact salary rules against the source payroll workbook; no audit report should be treated as an automatic payroll correction.
- Confirmation of debt/advance accounting semantics against GoCRM and the club's accounting practice.
- Real integrations for SMS, messengers, telephony, and external payment services.
- Direct comparison of all GoCRM group/room scheduling features and reports; the new groups and waitlist modules still need browser acceptance and are not a claim of full feature parity.
- Production deployment hardening: HTTPS, stable secret key, access control on the host, monitored backups, and a tested restore procedure.

## Safety policy
- Financial, attendance, subscription, and client records are not automatically merged or rewritten by diagnostic reports.
- CSV exports may contain personal data and must be stored securely.
- Use a separate test database for acceptance tests; create and verify a backup before importing real data.

- Manager-only subscription integrity report flags suspicious subscription status/balance/date combinations and mismatched sale/attendance links. Findings require manual review and do not rewrite records.

- Manager-only client retention report compares two equal attendance windows, excludes missed/cancelled/planned lessons, highlights declining attendance, and exports CSV without modifying data.


## v17.49 payroll correctness review
- Fixed recurring schedule payroll grouping: the same schedule template ID can represent multiple dates, so payroll sessions are now keyed by slot ID + lesson date + lesson time.
- Conflicts are isolated to one slot occurrence. A trainer/rate conflict on one date no longer suppresses valid sessions for the same template on other dates.
- HTML and CSV payroll reports now share the same tested aggregation helper.
- Regression coverage: recurring IDs across dates, one-date conflict, different rates on different dates, legacy rows, and exclusion of missed lessons.
- Still unresolved: actual payroll rate/category/shift rules must be reconciled against the club's original Excel payroll workbook. The workbook was not present in the current working files, so no claim is made that payroll matches real payouts.

## v17.48 operational readiness audit
- Manager-only `/system-check` and `/system-check.csv` summarize read-only checks for SQLite integrity, foreign keys, core tables, DB file availability, stable session secret, Secure cookie, debug mode, network bind, and backup freshness/manifest presence.
- The report does not expose the configured secret value or full database path, and does not mutate database/backup files.
- Warnings are diagnostic only. Browser acceptance, actual backup restore, HTTPS/WSGI configuration, and reconciliation against real GoCRM exports remain required before production migration.


## v17.49 access-control and migration-backup hardening
- `/payroll` and `/payroll.csv` now require the manager role; the salary link is only rendered for managers. Role enforcement uses the current database role, not a stale session field.
- Manager-only cash, stock, discount-management, and reconciliation links are hidden for administrators; recording a cash expense also requires manager authorization.
- GoCRM pre-import SQLite backups now receive a canonical JSON sidecar manifest with SHA-256, file size, timestamp, table counts, and SQLite/foreign-key check results. The regular backup verifier accepts this manifest.
- Added `restore_backup.py`: it verifies the source manifest, restores only to a new path, refuses to overwrite existing files, and verifies the restored database and manifest.
- The operational readiness page now verifies the newest backup manifest and SHA-256 rather than treating manifest presence alone as sufficient.
- Tests cover the manager-only salary routes and verify the pre-import manifest digest.


## v17.50 booking-to-attendance flow
- Schedule bookings now support explicit attended and missed outcomes after lesson start. Cancellation is allowed only before the scheduled start.
- Both outcomes use a shared transaction helper with an immediate SQLite write lock, subscription/expiry validation, start-time validation on the server, exactly one lesson decrement, trainer-rate snapshot, one attendance row, and a booking status transition.
- Duplicate processing and rebooking a missed/attended slot are rejected; UI labels distinguish missed from cancelled.
- Remaining validation: run browser acceptance on the target machine and verify against real staff workflows.

- Import hardening: numeric Excel client IDs such as `1001.0` are normalized to `1001`; text IDs retain their literal formatting. Regression tests cover repeat import idempotency.

- Imported GoCRM summary fields are now visible in the client card as a read-only reconciliation panel. The source debt sign and summary totals are preserved as reference data; they do not become cash transactions, sales, or subscriptions. Amounts are formatted from integer kopecks without float arithmetic.

- SQLite request connections now close on context exit while preserving transaction commit/rollback semantics, reducing open-handle accumulation on Windows.

- Financial reports and their CSV export now require manager authorization; administrators no longer see the report link or the total revenue tile on the dashboard.


## v17.57 — trial lesson workflow
- Added separate trial booking/outcome workflow linked to a lead, client and normal schedule slot.
- Legacy bookings default to `booking_type=regular`; trial outcomes are stored in `trial_attendance`.
- Trial lessons do not create sales, consume subscriptions or affect standard payroll automatically until club rules are confirmed.
- Browser acceptance and full parity against the private GoCRM account remain unconfirmed. See `GOCRM_REFERENCE_REVIEW_v17_57.md`, `GOCRM_VIDEO_REVIEW_v17_57.md` and `GOCRM_parity_matrix_v17_57.csv`.


## v17.58 — product catalogue maintenance
- Added manager-only editing of product name, current purchase/sale price and active status.
- Historical sale descriptions and cost/profit snapshots remain unchanged; product edits are audited.
- Disabled products are retained for history but excluded from new sale choices.
- See `GOCRM_REFERENCE_REVIEW_v17_58.md` and `GOCRM_parity_matrix_v17_58.csv`.


## v17.59 — configurable wallets
- Added separate wallets/accounts with payment-method categories, opening balances, activation/deactivation and internal transfers.
- New sales/expenses can be assigned to a wallet; refunds inherit the original sale wallet. Transfers do not create revenue/expense and are reflected in cash/noncash balance roll-forward.
- Legacy financial rows are not automatically assigned; they remain visible as unassigned historical operations for manual review.
- See `GOCRM_REFERENCE_REVIEW_v17_59.md` and `GOCRM_parity_matrix_v17_59.csv`.


## v17.60 — expense/DDС categories
- Added configurable expense categories, initial reference categories, manager-only maintenance, category totals and CSV category column.
- Legacy expenses remain uncategorized and are not automatically backfilled.
- See `GOCRM_REFERENCE_REVIEW_v17_60.md` and `GOCRM_parity_matrix_v17_60.csv`.


## v17.61 — configurable loyalty points
- Added a manager-configurable loyalty program with client point balances, append-only ledger, manual adjustments, redemption limits and refund reversals.
- Disabled by default; no historic sales are backfilled. The club must confirm the earning/redemption parameters before enabling it.
- See `GOCRM_REFERENCE_REVIEW_v17_61.md` and `GOCRM_parity_matrix_v17_61.csv`.


## v17.62 — other income
- Added separate other-income operations and configurable income categories. They are not sales and do not create subscriptions, but are reflected in wallet balances, cash/noncash roll-forward, shift closeout and CSV.
- See `GOCRM_REFERENCE_REVIEW_v17_62.md` and `GOCRM_parity_matrix_v17_62.csv`.
