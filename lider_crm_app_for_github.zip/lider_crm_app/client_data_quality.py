"""Read-only checks for incomplete or inconsistent CRM contact records."""
from datetime import date
import re

FIELDS = ("issue_type", "severity", "entity_type", "record_id", "child_name", "parent_name", "phone", "details")


def normalize_ru_phone(value):
    digits = "".join(ch for ch in str(value or "") if ch.isdigit())
    if len(digits) == 11 and digits[0] == "8":
        digits = "7" + digits[1:]
    elif len(digits) == 10:
        digits = "7" + digits
    return digits if len(digits) == 11 and digits[0] == "7" else ""


def _valid_birth_date(value, current_date):
    value = str(value or "").strip()
    if not value:
        return None
    try:
        parsed = date.fromisoformat(value)
    except (TypeError, ValueError):
        return "invalid_birth_date"
    if parsed > date.fromisoformat(current_date):
        return "future_birth_date"
    # A child record with a birth date older than 100 years is likely a typo,
    # but report it as review-needed rather than rejecting historical data.
    if (date.fromisoformat(current_date) - parsed).days > 36525:
        return "unusually_old_birth_date"
    return None


def build_client_data_quality_audit(conn, current_date=None, limit=2000):
    """Return prioritized, read-only data quality findings; never changes rows."""
    day = str(current_date or date.today().isoformat())
    try:
        date.fromisoformat(day)
    except ValueError as exc:
        raise ValueError("Дата проверки имеет неверный формат") from exc
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = 2000
    limit = max(1, min(limit, 5000))
    issues = []

    clients = conn.execute(
        "SELECT id,child_name,parent_name,phone,birth_date,status FROM clients ORDER BY id"
    ).fetchall()
    phone_groups = {}
    for row in clients:
        phone = str(row["phone"] or "").strip()
        digits = "".join(ch for ch in phone if ch.isdigit())
        normalized = normalize_ru_phone(phone)
        if not normalized:
            issues.append({"issue_type": "invalid_client_phone", "severity": "high" if len(digits) < 7 else "medium",
                           "entity_type": "client", "record_id": row["id"], "child_name": row["child_name"] or "",
                           "parent_name": row["parent_name"] or "", "phone": phone,
                           "details": "Телефон не распознан как полный российский номер; проверьте контакт вручную"})
        else:
            phone_groups.setdefault(normalized, []).append(row)
        if not str(row["child_name"] or "").strip():
            issues.append({"issue_type": "missing_child_name", "severity": "high", "entity_type": "client",
                           "record_id": row["id"], "child_name": "", "parent_name": row["parent_name"] or "",
                           "phone": phone, "details": "Не заполнено имя ребёнка"})
        if not str(row["parent_name"] or "").strip():
            issues.append({"issue_type": "missing_parent_name", "severity": "medium", "entity_type": "client",
                           "record_id": row["id"], "child_name": row["child_name"] or "", "parent_name": "",
                           "phone": phone, "details": "Не заполнено имя родителя/контактного лица"})
        birth_issue = _valid_birth_date(row["birth_date"], day)
        if birth_issue:
            details = {"invalid_birth_date": "Дата рождения записана в неверном формате",
                       "future_birth_date": "Дата рождения находится в будущем",
                       "unusually_old_birth_date": "Дата рождения старше 100 лет; возможно, опечатка"}[birth_issue]
            issues.append({"issue_type": birth_issue, "severity": "medium", "entity_type": "client",
                           "record_id": row["id"], "child_name": row["child_name"] or "", "parent_name": row["parent_name"] or "",
                           "phone": phone, "details": details})

    # A shared family phone is common, so this is intentionally a low-priority
    # review hint and is never labelled as a duplicate or merged automatically.
    for normalized, group in phone_groups.items():
        if len(group) > 1:
            for row in group:
                issues.append({"issue_type": "shared_phone_review", "severity": "low", "entity_type": "client",
                               "record_id": row["id"], "child_name": row["child_name"] or "",
                               "parent_name": row["parent_name"] or "", "phone": row["phone"] or "",
                               "details": f"Этот номер указан у {len(group)} карточек; проверьте, что это разные дети одной семьи, если применимо"})

    leads = conn.execute(
        "SELECT id,parent_name,child_name,phone,source,status,next_contact,client_id FROM leads ORDER BY id"
    ).fetchall()
    for row in leads:
        status = str(row["status"] or "").strip().casefold()
        if status not in ("converted", "lost", "archived") and not str(row["source"] or "").strip():
            issues.append({"issue_type": "lead_without_source", "severity": "low", "entity_type": "lead",
                           "record_id": row["id"], "child_name": row["child_name"] or "", "parent_name": row["parent_name"] or "",
                           "phone": row["phone"] or "", "details": "Не указан источник заявки; статистика маркетинга может быть неполной"})
        if status not in ("converted", "lost", "archived") and not str(row["next_contact"] or "").strip():
            issues.append({"issue_type": "lead_without_next_contact", "severity": "medium", "entity_type": "lead",
                           "record_id": row["id"], "child_name": row["child_name"] or "", "parent_name": row["parent_name"] or "",
                           "phone": row["phone"] or "", "details": "У открытой заявки не назначена дата следующего контакта"})
        if status == "converted" and not row["client_id"]:
            issues.append({"issue_type": "converted_lead_without_client", "severity": "high", "entity_type": "lead",
                           "record_id": row["id"], "child_name": row["child_name"] or "", "parent_name": row["parent_name"] or "",
                           "phone": row["phone"] or "", "details": "Заявка отмечена конвертированной, но карточка клиента не связана"})

    severity_order = {"high": 0, "medium": 1, "low": 2}
    issues.sort(key=lambda x: (severity_order.get(x["severity"], 9), x["entity_type"], x["issue_type"], int(x["record_id"])))
    return issues[:limit]
