"""Calculate the cash position as of a date using the last physical close as anchor."""

from wallet_rules import transfer_balance_deltas


def balances_as_of(connection, end_date):
    """Return (cash, noncash) balances at end of ``end_date``.

    If a closed shift exists on or before the requested date, its actual count is
    the anchor and only transactions recorded after that close are rolled forward.
    Before the first close, configured opening balances are the baseline and all
    recorded sales/expenses up to the cutoff are included.
    """
    cutoff = f"{end_date}T23:59:59.999999"
    settings = {
        row["key"]: int(row["value"])
        for row in connection.execute(
            "SELECT key,value FROM settings WHERE key IN ('opening_cash','opening_non_cash')"
        )
    }
    previous = connection.execute(
        """SELECT actual_cash,actual_noncash,closed_at FROM cash_shifts
           WHERE status='closed' AND shift_date<=? AND closed_at<=?
           ORDER BY closed_at DESC,id DESC LIMIT 1""",
        (end_date, cutoff),
    ).fetchone()

    if previous:
        cash, noncash = previous["actual_cash"], previous["actual_noncash"]
        lower_bound = previous["closed_at"]
        sales = connection.execute(
            """SELECT payment_method,
                 SUM(CASE WHEN status='completed' THEN amount
                          WHEN status='refund' THEN -amount ELSE 0 END) amount
               FROM sales WHERE created_at>? AND created_at<=? GROUP BY payment_method""",
            (lower_bound, cutoff),
        ).fetchall()
        expenses = connection.execute(
            """SELECT payment_method,SUM(amount) amount FROM cash_expenses
               WHERE created_at>? AND created_at<=? GROUP BY payment_method""",
            (lower_bound, cutoff),
        ).fetchall()
        other_income = connection.execute(
            """SELECT payment_method,SUM(amount) amount FROM cash_other_income
               WHERE created_at>? AND created_at<=? GROUP BY payment_method""",
            (lower_bound, cutoff),
        ).fetchall() if connection.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='cash_other_income'").fetchone() else []
    else:
        cash, noncash = settings.get("opening_cash", 0), settings.get("opening_non_cash", 0)
        sales = connection.execute(
            """SELECT payment_method,
                 SUM(CASE WHEN status='completed' THEN amount
                          WHEN status='refund' THEN -amount ELSE 0 END) amount
               FROM sales WHERE created_at<=? GROUP BY payment_method""",
            (cutoff,),
        ).fetchall()
        expenses = connection.execute(
            """SELECT payment_method,SUM(amount) amount FROM cash_expenses
               WHERE created_at<=? GROUP BY payment_method""",
            (cutoff,),
        ).fetchall()
        other_income = connection.execute(
            """SELECT payment_method,SUM(amount) amount FROM cash_other_income
               WHERE created_at<=? GROUP BY payment_method""",
            (cutoff,),
        ).fetchall() if connection.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='cash_other_income'").fetchone() else []

    sales_by_method = {row["payment_method"]: row["amount"] or 0 for row in sales}
    expenses_by_method = {row["payment_method"]: row["amount"] or 0 for row in expenses}
    income_by_method = {row["payment_method"]: row["amount"] or 0 for row in other_income}
    cash += sales_by_method.get("cash", 0) + income_by_method.get("cash", 0) - expenses_by_method.get("cash", 0)
    noncash += sum(sales_by_method.get(method, 0) + income_by_method.get(method, 0) for method in ("card", "transfer", "qr"))
    noncash -= sum(expenses_by_method.get(method, 0) for method in ("card", "transfer", "qr"))
    transfer_cash, transfer_noncash = transfer_balance_deltas(
        connection, lower_bound=lower_bound if previous else None, upper_bound=cutoff
    )
    cash += transfer_cash
    noncash += transfer_noncash
    return cash, noncash


def ensure_opening_balances_editable(connection):
    """Prevent edits to the baseline after the first physical cash close.

    Opening balances are historical starting values. Changing them after a close
    would silently rewrite balances in reports for dates before that close.
    """
    closed = connection.execute(
        "SELECT 1 FROM cash_shifts WHERE status='closed' LIMIT 1"
    ).fetchone()
    if closed:
        raise ValueError(
            "Начальные остатки нельзя менять после первой закрытой смены: "
            "это изменит исторические отчёты. Исправления оформляйте отдельной операцией."
        )
