"""Read-only daily electronic journal query helpers shared by UI and tests."""
from datetime import date


def normalize_journal_date(value, fallback=None):
    fallback = fallback or date.today().isoformat()
    try:
        parsed = date.fromisoformat(value or fallback)
    except (TypeError, ValueError):
        raise ValueError("Укажите дату в формате ГГГГ-ММ-ДД")
    return parsed.isoformat()


def get_daily_journal(connection, journal_date):
    """Return schedule rows and daily attendance counts without mutating records."""
    day = normalize_journal_date(journal_date)
    slots = connection.execute(
        """SELECT sl.id AS slot_id, sl.slot_time, sl.duration_minutes, sl.capacity,
                  sl.kind, sl.notes, tr.name AS trainer_name,
                  room.name AS room_name, lane.name AS lane_name,
                  COUNT(CASE WHEN b.status='booked' THEN 1 END) AS booked_count,
                  COUNT(CASE WHEN b.status IN ('booked','attended','missed') THEN 1 END) AS occupied_count,
                  COUNT(CASE WHEN b.status='attended' THEN 1 END) AS attended_count,
                  COUNT(CASE WHEN b.status='missed' THEN 1 END) AS missed_count,
                  COUNT(CASE WHEN b.status='cancelled' THEN 1 END) AS cancelled_count,
                  GROUP_CONCAT(CASE WHEN b.status='booked' THEN cl.child_name END, ', ') AS booked_names
           FROM schedule_slots sl
           JOIN trainers tr ON tr.id=sl.trainer_id
           LEFT JOIN schedule_resources room ON room.id=sl.room_id
           LEFT JOIN schedule_resources lane ON lane.id=sl.lane_id
           LEFT JOIN bookings b ON b.slot_id=sl.id
           LEFT JOIN clients cl ON cl.id=b.client_id
           WHERE sl.slot_date=?
           GROUP BY sl.id
           ORDER BY sl.slot_time, tr.name""",
        (day,),
    ).fetchall()
    totals = connection.execute(
        """SELECT
           COUNT(*) AS slots,
           COALESCE(SUM((SELECT COUNT(*) FROM bookings b WHERE b.slot_id=sl.id AND b.status='booked')),0) AS booked,
           COALESCE(SUM((SELECT COUNT(*) FROM bookings b WHERE b.slot_id=sl.id AND b.status='attended')),0) AS attended,
           COALESCE(SUM((SELECT COUNT(*) FROM bookings b WHERE b.slot_id=sl.id AND b.status='missed')),0) AS missed,
           COALESCE(SUM((SELECT COUNT(*) FROM bookings b WHERE b.slot_id=sl.id AND b.status='cancelled')),0) AS cancelled
           FROM schedule_slots sl WHERE sl.slot_date=?""",
        (day,),
    ).fetchone()
    children = connection.execute(
        """SELECT b.id AS booking_id, b.status, b.booking_type, sl.id AS slot_id, sl.slot_time,
                  cl.child_name, tr.name AS trainer_name
           FROM bookings b JOIN schedule_slots sl ON sl.id=b.slot_id
           JOIN clients cl ON cl.id=b.client_id JOIN trainers tr ON tr.id=sl.trainer_id
           WHERE sl.slot_date=? ORDER BY sl.slot_time, cl.child_name""", (day,)
    ).fetchall()
    return {"date": day, "slots": slots, "children": children, "totals": dict(totals)}


def get_daily_finance_summary(connection, journal_date):
    """Manager-only aggregate. Returns integer rubles/kopecks as stored, no edits."""
    day = normalize_journal_date(journal_date)
    sales = connection.execute(
        """SELECT COALESCE(SUM(CASE WHEN status='completed' THEN amount ELSE 0 END),0) AS gross_sales,
                  COALESCE(SUM(CASE WHEN status='refund' THEN amount ELSE 0 END),0) AS refunds,
                  COALESCE(SUM(CASE WHEN status='completed' THEN amount WHEN status='refund' THEN -amount ELSE 0 END),0) AS net_sales,
                  COUNT(CASE WHEN status='completed' THEN 1 END) AS sale_count
           FROM sales WHERE substr(created_at,1,10)=?""", (day,)
    ).fetchone()
    expenses = connection.execute(
        "SELECT COALESCE(SUM(amount),0) AS expenses, COUNT(*) AS expense_count FROM cash_expenses WHERE expense_date=?",
        (day,),
    ).fetchone()
    return {"date": day, "sales": dict(sales), "expenses": dict(expenses)}
