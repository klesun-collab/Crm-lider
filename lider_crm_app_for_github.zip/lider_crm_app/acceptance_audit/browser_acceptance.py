#!/usr/bin/env python3
"""Read-only browser acceptance for a running CRM instance.

Required environment variables:
  LIDER_CRM_URL, LIDER_MANAGER_USER, LIDER_MANAGER_PASSWORD,
  LIDER_ADMIN_USER, LIDER_ADMIN_PASSWORD

The script only logs in, opens pages, checks access boundaries and logs out.
It does not create, edit, import, sell, refund, or otherwise mutate CRM business data.
"""
from __future__ import annotations
import os
import sys
from urllib.parse import urljoin

from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

BASE = os.environ.get("LIDER_CRM_URL", "").rstrip("/")
MANAGER_USER = os.environ.get("LIDER_MANAGER_USER", "")
MANAGER_PASSWORD = os.environ.get("LIDER_MANAGER_PASSWORD", "")
ADMIN_USER = os.environ.get("LIDER_ADMIN_USER", "")
ADMIN_PASSWORD = os.environ.get("LIDER_ADMIN_PASSWORD", "")

MANAGER_ROUTES = (
    "/reports", "/reports.csv", "/payroll", "/payroll.csv",
    "/cash", "/cash.csv", "/wallets", "/expense-categories", "/income-categories", "/loyalty", "/products", "/discounts",
    "/reconciliation", "/reconciliation/late-expenses.csv",
    "/reconciliation/cash-shift-mismatches.csv", "/backup", "/settings",
    "/audit", "/system-check", "/system-check.csv",
    "/schedule-audit", "/schedule-audit.csv", "/followup-audit",
    "/followup-audit.csv", "/client-data-quality", "/client-data-quality.csv",
    "/subscription-integrity", "/subscription-integrity.csv",
    "/client-retention", "/client-retention.csv",
)
COMMON_ROUTES = (
    "/dashboard", "/clients", "/client-duplicates", "/leads", "/tasks",
    "/subscriptions", "/renewals", "/renewals.csv", "/reactivation",
    "/journal", "/trial-lessons",
    "/reactivation/report", "/contact-log", "/campaigns", "/schedule", "/resources",
    "/schedule?view=list", "/schedule?view=calendar", "/schedule?view=month",
    "/groups", "/waitlist", "/trainers",
    "/attendance", "/attendance-report", "/attendance-report.csv", "/one-visit", "/sales", "/refunds",
)


def require_environment():
    missing = [name for name, value in {
        "LIDER_CRM_URL": BASE,
        "LIDER_MANAGER_USER": MANAGER_USER,
        "LIDER_MANAGER_PASSWORD": MANAGER_PASSWORD,
        "LIDER_ADMIN_USER": ADMIN_USER,
        "LIDER_ADMIN_PASSWORD": ADMIN_PASSWORD,
    }.items() if not value]
    if missing:
        raise SystemExit("Не заданы переменные окружения: " + ", ".join(missing))


def url(path: str) -> str:
    return urljoin(BASE + "/", path.lstrip("/"))


def check(condition: bool, label: str, failures: list[str]):
    print(("PASS" if condition else "FAIL") + " | " + label)
    if not condition:
        failures.append(label)


def login(page, username: str, password: str, failures: list[str], label: str):
    response = page.goto(url("/login"), wait_until="domcontentloaded")
    check(response is not None and response.status == 200, f"{label}: страница входа HTTP 200", failures)
    page.locator('input[name="username"]').fill(username)
    page.locator('input[name="password"]').fill(password)
    page.locator('form button[type="submit"], form button').first.click()
    try:
        page.wait_for_url(lambda current: "/login" not in current.path, timeout=10000)
    except PlaywrightTimeoutError:
        pass
    check("/login" not in page.url, f"{label}: успешный вход", failures)
    return page.url


def check_schedule_controls(page, role_label: str, failures: list[str]):
    try:
        response = page.goto(url("/schedule"), wait_until="domcontentloaded", timeout=15000)
        check(response is not None and response.status == 200, f"{role_label}: расписание HTTP 200", failures)
        for selector, label in (
            ('input[name="repeat_start_time"]', "начало смены"),
            ('input[name="repeat_end_time"]', "окончание смены"),
            ('input[name="weekdays"]', "выбор дней недели"),
            ('select[name="repeat_trainer_id"]', "выбор тренера для повторения"),
        ):
            check(page.locator(selector).count() > 0, f"{role_label}: расписание — {label}", failures)
        check(page.locator('a[href="/trainers"]').count() > 0, f"{role_label}: ссылка управления тренерами", failures)
        check(page.locator('select[name="room_id"]').count() > 0, f"{role_label}: назначение помещения", failures)
        check(page.locator('select[name="lane_id"]').count() > 0, f"{role_label}: назначение дорожки", failures)
        for path, label in (("/schedule?view=list", "список 14 дней"), ("/schedule?view=calendar", "календарь недели"), ("/schedule?view=month", "календарь месяца")):
            view_response = page.goto(url(path), wait_until="domcontentloaded", timeout=15000)
            check(view_response is not None and view_response.status == 200, f"{role_label}: {label} HTTP 200", failures)
        response = page.goto(url("/resources"), wait_until="domcontentloaded", timeout=15000)
        check(response is not None and response.status == 200, f"{role_label}: справочник помещений/дорожек HTTP 200", failures)
        response = page.goto(url("/contact-log"), wait_until="domcontentloaded", timeout=15000)
        check(response is not None and response.status == 200, f"{role_label}: журнал контактов HTTP 200", failures)
    except Exception as exc:
        check(False, f"{role_label}: проверка элементов расписания: {exc}", failures)


def check_groups_and_waitlist(page, role_label: str, failures: list[str]):
    try:
        response = page.goto(url("/groups"), wait_until="domcontentloaded", timeout=15000)
        check(response is not None and response.status == 200, f"{role_label}: группы HTTP 200", failures)
        check(page.locator('input[name="action"][value="create"]').count() > 0, f"{role_label}: форма создания группы", failures)
        response = page.goto(url("/waitlist"), wait_until="domcontentloaded", timeout=15000)
        check(response is not None and response.status == 200, f"{role_label}: лист ожидания HTTP 200", failures)
        check(page.locator('input[name="action"][value="create"]').count() > 0, f"{role_label}: форма листа ожидания", failures)
        check(page.locator('select[name="client_id"]').count() > 0, f"{role_label}: выбор клиента в листе ожидания", failures)
    except Exception as exc:
        check(False, f"{role_label}: проверка групп/листа ожидания: {exc}", failures)



def check_wallet_and_sale_forms(page, role_label: str, failures: list[str]):
    try:
        response = page.goto(url("/sales"), wait_until="domcontentloaded", timeout=15000)
        check(response is not None and response.status == 200, f"{role_label}: продажи HTTP 200", failures)
        check(page.locator('select[name="wallet_id"]').count() > 0, f"{role_label}: выбор счёта в продаже", failures)
        if role_label == "Руководитель":
            response = page.goto(url("/cash"), wait_until="domcontentloaded", timeout=15000)
            check(response is not None and response.status == 200, "Руководитель: движение денег HTTP 200", failures)
            check(page.locator('form[action="/cash/income"]').count() > 0, "Руководитель: форма прочего поступления", failures)
            response = page.goto(url("/wallets"), wait_until="domcontentloaded", timeout=15000)
            check(response is not None and response.status == 200, "Руководитель: счета/кошельки HTTP 200", failures)
            check(page.locator('input[name="action"][value="transfer"]').count() > 0, "Руководитель: форма перевода между счетами", failures)
            check(page.locator('input[name="action"][value="create"]').count() > 0, "Руководитель: форма создания счёта", failures)
            response = page.goto(url("/expense-categories"), wait_until="domcontentloaded", timeout=15000)
            check(response is not None and response.status == 200, "Руководитель: категории расходов HTTP 200", failures)
            check(page.locator('input[name="name"]').count() > 0, "Руководитель: форма категорий расходов", failures)
            response = page.goto(url("/income-categories"), wait_until="domcontentloaded", timeout=15000)
            check(response is not None and response.status == 200, "Руководитель: категории поступлений HTTP 200", failures)
            check(page.locator('input[name="name"]').count() > 0, "Руководитель: форма категорий поступлений", failures)
            response = page.goto(url("/loyalty"), wait_until="domcontentloaded", timeout=15000)
            check(response is not None and response.status == 200, "Руководитель: бонусная программа HTTP 200", failures)
            check(page.locator('input[name="points_per_100"]').count() > 0, "Руководитель: настройки бонусной программы", failures)
    except Exception as exc:
        check(False, f"{role_label}: проверка счетов/продаж: {exc}", failures)


def check_trial_lesson_page(page, role_label: str, failures: list[str]):
    try:
        response = page.goto(url("/trial-lessons"), wait_until="domcontentloaded", timeout=15000)
        check(response is not None and response.status == 200, f"{role_label}: пробные занятия HTTP 200", failures)
        check(page.get_by_role("heading", name="Пробные занятия").count() > 0, f"{role_label}: заголовок пробных занятий", failures)
        check(page.locator("text=не создаёт продажу").count() > 0, f"{role_label}: явно показаны финансовые ограничения пробного занятия", failures)
    except Exception as exc:
        check(False, f"{role_label}: проверка страницы пробных занятий: {exc}", failures)

def main():
    require_environment()
    failures: list[str] = []
    results: list[tuple[str, int | None, str | None]] = []
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True)
        context = browser.new_context(ignore_https_errors=False)
        page = context.new_page()
        try:
            response = page.goto(url("/login"), wait_until="domcontentloaded", timeout=15000)
            headers = response.headers if response else {}
            check(response is not None and response.status == 200, "Доступность /login", failures)
            check(headers.get("x-content-type-options") == "nosniff", "Заголовок X-Content-Type-Options", failures)
            check(headers.get("x-frame-options") == "DENY", "Заголовок X-Frame-Options", failures)
            check(headers.get("referrer-policy") == "strict-origin-when-cross-origin", "Заголовок Referrer-Policy", failures)
            check(headers.get("cache-control", "").lower().find("no-store") >= 0, "Запрет кеширования страниц", failures)

            login(page, MANAGER_USER, MANAGER_PASSWORD, failures, "Руководитель")
            check_schedule_controls(page, "Руководитель", failures)
            check_groups_and_waitlist(page, "Руководитель", failures)
            check_trial_lesson_page(page, "Руководитель", failures)
            check_wallet_and_sale_forms(page, "Руководитель", failures)
            for path in COMMON_ROUTES + MANAGER_ROUTES:
                try:
                    r = page.request.get(url(path), timeout=10000, max_redirects=0)
                    results.append((path, r.status, None))
                    check(r.status == 200, f"Руководитель GET {path} → {r.status}", failures)
                except Exception as exc:
                    results.append((path, None, str(exc)))
                    check(False, f"Руководитель GET {path}: {exc}", failures)
            # Logout is POST-only and CSRF protected; submit the actual visible form.
            logout = page.locator('form[action="/logout"]')
            if logout.count():
                logout.locator('button').click()
                try:
                    page.wait_for_url("**/login", timeout=5000)
                except PlaywrightTimeoutError:
                    pass
                check("/login" in page.url, "Руководитель: выход завершает сессию", failures)
            else:
                check(False, "Руководитель: форма выхода доступна", failures)

            login(page, ADMIN_USER, ADMIN_PASSWORD, failures, "Администратор")
            check_schedule_controls(page, "Администратор", failures)
            check_groups_and_waitlist(page, "Администратор", failures)
            check_trial_lesson_page(page, "Администратор", failures)
            check_wallet_and_sale_forms(page, "Администратор", failures)
            for path in COMMON_ROUTES:
                try:
                    r = page.request.get(url(path), timeout=10000, max_redirects=0)
                    check(r.status == 200, f"Администратор GET {path} → {r.status}", failures)
                except Exception as exc:
                    check(False, f"Администратор GET {path}: {exc}", failures)
            for path in MANAGER_ROUTES:
                try:
                    r = page.request.get(url(path), timeout=10000, max_redirects=0)
                    # Manager-only pages and exports must never disclose data to an administrator.
                    allowed = r.status in (302, 303, 401, 403)
                    check(allowed, f"Администратор ограничен на {path} (HTTP {r.status})", failures)
                except Exception as exc:
                    check(False, f"Администратор GET {path}: {exc}", failures)
            # Check browser back/session invalidation after logout.
            logout = page.locator('form[action="/logout"]')
            if logout.count():
                logout.locator('button').click()
            check("/login" in page.url, "Администратор: выход завершает сессию", failures)
        finally:
            context.close()
            browser.close()
    print(f"\nИТОГ: {len(failures)} ошибок; проверок с ошибками: {len(failures)}")
    if failures:
        print("Не пройдены:")
        for failure in failures:
            print(" - " + failure)
        return 1
    print("Все read-only браузерные проверки пройдены. Это не заменяет отдельные бизнес-сценарии записи/оплаты/восстановления.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
