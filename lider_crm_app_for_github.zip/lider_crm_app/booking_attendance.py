"""Atomic transitions for scheduled booking outcomes."""
from datetime import datetime


def ensure_booking_cancellable(slot_date, slot_time, now_value=None):
    """Allow cancellation only before the scheduled lesson starts."""
    try:
        starts_at = datetime.fromisoformat(f"{slot_date}T{slot_time}")
    except (TypeError, ValueError) as exc:
        raise ValueError("У слота некорректная дата или время; проверьте расписание") from exc
    current = now_value or datetime.now()
    if current >= starts_at:
        raise ValueError("Нельзя отменить запись после начала занятия. Отметьте посещение или пропуск")
    return True



def mark_booking_outcome(connection, booking_id, outcome, actor_id, created_at, today_date):
    """Consume exactly one lesson and create one attendance row for a booking.

    The caller owns the SQLite transaction context; this function takes an
    immediate write lock before checking state to prevent double-spending when
    two staff members click the same booking at once.
    """
    if outcome not in ("attended", "missed"):
        raise ValueError("Недопустимый статус занятия")

    connection.execute("BEGIN IMMEDIATE")
    booking = connection.execute(
        "SELECT * FROM bookings WHERE id=? AND status='booked'", (booking_id,)
    ).fetchone()
    if not booking:
        raise ValueError("Запись уже обработана или не найдена")

    slot = connection.execute(
        "SELECT * FROM schedule_slots WHERE id=?", (booking["slot_id"],)
    ).fetchone()
    if not slot:
        raise ValueError("Слот не найден")
    if slot["slot_date"] > today_date:
        raise ValueError("Нельзя отмечать будущее занятие")
    try:
        starts_at = datetime.fromisoformat(f"{slot['slot_date']}T{slot['slot_time']}")
        current = datetime.fromisoformat(created_at)
    except (TypeError, ValueError) as exc:
        raise ValueError("У занятия некорректная дата или время") from exc
    if current < starts_at:
        raise ValueError("Нельзя отмечать посещение или пропуск до начала занятия")

    if not booking["subscription_id"]:
        raise ValueError("Для отметки занятия нужен привязанный абонемент")
    subscription = connection.execute(
        """SELECT * FROM subscriptions WHERE id=? AND client_id=? AND status='active'
           AND remaining_lessons>0 AND (COALESCE(expires_at,'')='' OR expires_at>=?)""",
        (booking["subscription_id"], booking["client_id"], slot["slot_date"]),
    ).fetchone()
    if not subscription:
        raise ValueError("Нет доступного занятия: абонемент истёк или недоступен")

    changed = connection.execute(
        """UPDATE subscriptions SET remaining_lessons=remaining_lessons-1
           WHERE id=? AND client_id=? AND status='active' AND remaining_lessons>0
             AND (COALESCE(expires_at,'')='' OR expires_at>=?)""",
        (subscription["id"], booking["client_id"], slot["slot_date"]),
    )
    if changed.rowcount != 1:
        raise ValueError("Занятие уже списано или абонемент больше недоступен")
    if subscription["remaining_lessons"] - 1 == 0:
        connection.execute(
            "UPDATE subscriptions SET status='completed' WHERE id=? AND remaining_lessons=0",
            (subscription["id"],),
        )

    trainer = connection.execute(
        """SELECT t.name,t.payroll_rate FROM schedule_slots sl
           LEFT JOIN trainers t ON t.id=sl.trainer_id WHERE sl.id=?""",
        (slot["id"],),
    ).fetchone()
    trainer_name = trainer["name"] if trainer else ""
    rate = int(trainer["payroll_rate"]) if trainer and trainer["payroll_rate"] is not None else 400
    cur = connection.execute(
        """INSERT INTO attendance(client_id,subscription_id,trainer,lesson_date,lesson_time,status,
             rate_snapshot,schedule_slot_id,created_by,created_at)
           VALUES(?,?,?,?,?,?,?,?,?,?)""",
        (booking["client_id"], subscription["id"], trainer_name, slot["slot_date"], slot["slot_time"],
         outcome, rate, slot["id"], actor_id, created_at),
    )
    changed = connection.execute(
        "UPDATE bookings SET status=? WHERE id=? AND status='booked'", (outcome, booking_id)
    )
    if changed.rowcount != 1:
        raise ValueError("Запись уже обработана; обновите страницу")

    return {
        "attendance_id": cur.lastrowid,
        "subscription_id": subscription["id"],
        "slot_id": slot["id"],
        "client_id": booking["client_id"],
        "date": slot["slot_date"],
        "rate_snapshot": rate,
        "status": outcome,
    }
