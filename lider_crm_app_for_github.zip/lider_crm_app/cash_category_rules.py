"""Validation for user-configurable cash-flow expense categories."""


def normalize_expense_category(name):
    name = str(name or "").strip()
    if not name or len(name) > 100:
        raise ValueError("Название категории обязательно и не должно превышать 100 символов")
    return name
