"""Additional indexes for common CRM lookups and period reports.

Call only after init_db has created tables and applied additive migrations.
"""
INDEX_DDL = (
    "CREATE INDEX IF NOT EXISTS idx_clients_phone ON clients(phone)",
    "CREATE INDEX IF NOT EXISTS idx_clients_child_name ON clients(child_name COLLATE NOCASE)",
    "CREATE INDEX IF NOT EXISTS idx_subscriptions_client_status_expiry ON subscriptions(client_id,status,expires_at)",
    "CREATE INDEX IF NOT EXISTS idx_attendance_date_status ON attendance(lesson_date,status)",
    "CREATE INDEX IF NOT EXISTS idx_attendance_slot_status_date ON attendance(schedule_slot_id,status,lesson_date)",
    "CREATE INDEX IF NOT EXISTS idx_sales_created_status ON sales(created_at,status)",
    "CREATE INDEX IF NOT EXISTS idx_sales_calendar_date_status ON sales(substr(created_at,1,10),status)",
    "CREATE INDEX IF NOT EXISTS idx_sales_product_calendar_date ON sales(product_id,substr(created_at,1,10))",
    "CREATE INDEX IF NOT EXISTS idx_sales_client_created ON sales(client_id,created_at)",
    "CREATE INDEX IF NOT EXISTS idx_cash_expenses_date_created ON cash_expenses(expense_date,created_at)",
    "CREATE INDEX IF NOT EXISTS idx_cash_expenses_created ON cash_expenses(created_at)",
    "CREATE INDEX IF NOT EXISTS idx_cash_shifts_status_closed ON cash_shifts(status,closed_at,shift_date)",
    "CREATE INDEX IF NOT EXISTS idx_schedule_slots_date_time ON schedule_slots(slot_date,slot_time)",
    "CREATE INDEX IF NOT EXISTS idx_bookings_slot_status ON bookings(slot_id,status)",
    "CREATE INDEX IF NOT EXISTS idx_bookings_client_status ON bookings(client_id,status)",
    "CREATE INDEX IF NOT EXISTS idx_tasks_status_due ON tasks(status,due_at)",
    "CREATE INDEX IF NOT EXISTS idx_tasks_assigned_status_due ON tasks(assigned_to,status,due_at)",
    "CREATE INDEX IF NOT EXISTS idx_leads_status_next_contact ON leads(status,next_contact)",
    "CREATE INDEX IF NOT EXISTS idx_leads_phone ON leads(phone)",
    "CREATE INDEX IF NOT EXISTS idx_audit_log_created ON audit_log(created_at)",
    "CREATE INDEX IF NOT EXISTS idx_audit_log_entity ON audit_log(entity,entity_id)",
    "CREATE INDEX IF NOT EXISTS idx_refund_requests_sale_status ON refund_requests(sale_id,status)",
    "CREATE INDEX IF NOT EXISTS idx_stock_movements_product_created ON stock_movements(product_id,created_at)",
    "CREATE INDEX IF NOT EXISTS idx_login_attempts_ip ON login_attempts(remote_addr,attempted_at,succeeded)",
)


def ensure_indexes(connection):
    """Create indexes idempotently; safe to run on every application startup."""
    for statement in INDEX_DDL:
        connection.execute(statement)
