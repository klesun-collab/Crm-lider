"""Create and retain verified, timestamped SQLite backups without Flask.

Usage:
    python backup_database.py
    python backup_database.py --source /path/to/lider_crm.sqlite3 --destination /secure/backups --keep 30

Environment overrides: LIDER_CRM_DB, LIDER_CRM_BACKUP_DIR, LIDER_CRM_BACKUP_KEEP.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
import tempfile
from datetime import datetime, timezone
from contextlib import closing
from pathlib import Path

from backup_utils import create_verified_sqlite_snapshot

APP_DIR = Path(__file__).resolve().parent
BACKUP_PREFIX = "lider_crm_full_"
BACKUP_SUFFIX = ".sqlite3"
MANIFEST_SUFFIX = ".manifest.json"
MANIFEST_VERSION = 1


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def manifest_path_for(backup_path: Path) -> Path:
    return backup_path.with_name(backup_path.name + MANIFEST_SUFFIX)


def _sqlite_table_counts(backup_path: Path) -> dict[str, int]:
    """Return row counts for every user table in a read-only SQLite database."""
    counts: dict[str, int] = {}
    with closing(sqlite3.connect(backup_path.as_uri() + "?mode=ro", uri=True, timeout=10)) as db:
        names = db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%' ORDER BY name"
        ).fetchall()
        for (name,) in names:
            quoted = '"' + str(name).replace('"', '""') + '"'
            counts[str(name)] = int(db.execute(f"SELECT COUNT(*) FROM {quoted}").fetchone()[0])
    return counts


def _write_manifest(backup_path: Path) -> Path:
    """Atomically write a digest and structural manifest after SQLite verification."""
    manifest_path = manifest_path_for(backup_path)
    payload = {
        "format_version": MANIFEST_VERSION,
        "backup_file": backup_path.name,
        "size_bytes": backup_path.stat().st_size,
        "sha256": _sha256_file(backup_path),
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "sqlite_integrity_check": "ok",
        "foreign_key_violations": 0,
        # Row counts provide a recovery sanity check in addition to byte-level SHA-256.
        "table_counts": _sqlite_table_counts(backup_path),
    }
    fd, temp_name = tempfile.mkstemp(prefix=".lider_manifest_partial_", suffix=".json", dir=backup_path.parent)
    temp_path = Path(temp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(payload, stream, ensure_ascii=False, indent=2, sort_keys=True)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        try:
            temp_path.chmod(0o600)
        except OSError:
            pass
        os.replace(temp_path, manifest_path)
    finally:
        try:
            temp_path.unlink(missing_ok=True)
        except OSError:
            pass
    return manifest_path


def verify_backup_manifest(backup_path: Path) -> dict:
    """Verify a backup against its manifest and re-check SQLite integrity."""
    backup_path = backup_path.expanduser().resolve()
    manifest_path = manifest_path_for(backup_path)
    if not backup_path.is_file():
        raise FileNotFoundError(f"Резервная копия не найдена: {backup_path}")
    if not manifest_path.is_file():
        raise FileNotFoundError(f"Манифест проверки не найден: {manifest_path}")
    try:
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Не удалось прочитать манифест резервной копии: {exc}") from exc
    if not isinstance(payload, dict):
        raise ValueError("Манифест резервной копии должен быть JSON-объектом")
    if payload.get("format_version") != MANIFEST_VERSION:
        raise ValueError("Неизвестная версия манифеста резервной копии")
    if payload.get("backup_file") != backup_path.name:
        raise ValueError("Имя файла резервной копии не совпадает с манифестом")
    expected_size = payload.get("size_bytes")
    if isinstance(expected_size, bool) or not isinstance(expected_size, int) or expected_size < 0:
        raise ValueError("В манифесте некорректно указано поле size_bytes")
    digest = payload.get("sha256")
    if not isinstance(digest, str) or len(digest) != 64 or any(ch not in "0123456789abcdef" for ch in digest.lower()):
        raise ValueError("В манифесте некорректно указана контрольная сумма SHA-256")
    counts = payload.get("table_counts")
    if counts is not None:
        if not isinstance(counts, dict) or any(
            not isinstance(name, str) or isinstance(count, bool) or not isinstance(count, int) or count < 0
            for name, count in counts.items()
        ):
            raise ValueError("В манифесте некорректно указаны состав таблиц или количество записей")
    if expected_size != backup_path.stat().st_size:
        raise RuntimeError("Размер резервной копии не совпадает с манифестом; файл изменён или повреждён")
    if payload.get("sha256") != _sha256_file(backup_path):
        raise RuntimeError("SHA-256 резервной копии не совпадает с манифестом; файл изменён или повреждён")
    with closing(sqlite3.connect(backup_path.as_uri() + "?mode=ro", uri=True, timeout=10)) as db:
        integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise RuntimeError(f"Резервная копия не прошла проверку целостности: {integrity}")
        violations = db.execute("PRAGMA foreign_key_check").fetchall()
        if violations:
            raise RuntimeError(f"Резервная копия содержит нарушения внешних ключей: {len(violations)}")
    # Older v1 manifests may not include table_counts; keep them verifiable.
    # New manifests detect missing/extra tables and unexpected row-count drift.
    if "table_counts" in payload:
        actual_counts = _sqlite_table_counts(backup_path)
        if payload["table_counts"] != actual_counts:
            raise RuntimeError("Состав таблиц или количество записей не совпадает с манифестом")
    return payload


def create_backup(source: Path, destination: Path, keep: int = 30) -> Path:
    """Create a verified snapshot and prune old backups only after success."""
    source = source.expanduser().resolve()
    destination = destination.expanduser().resolve()
    if keep < 1:
        raise ValueError("Количество хранимых копий должно быть не меньше 1")
    if not source.is_file():
        raise FileNotFoundError(f"Файл базы данных не найден: {source}")

    destination.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        destination.chmod(0o700)
    except OSError:
        # Some filesystems (e.g. Windows) do not support POSIX directory modes.
        pass

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%fZ")
    final_path = destination / f"{BACKUP_PREFIX}{stamp}{BACKUP_SUFFIX}"
    fd, temp_name = tempfile.mkstemp(prefix=".lider_crm_partial_", suffix=".sqlite3", dir=destination)
    os.close(fd)
    temp_path = Path(temp_name)
    try:
        create_verified_sqlite_snapshot(str(source), str(temp_path))
        try:
            temp_path.chmod(0o600)
        except OSError:
            pass
        os.replace(temp_path, final_path)
        try:
            _write_manifest(final_path)
        except Exception:
            # Never leave a published backup that appears to have a verified manifest
            # when manifest creation failed; prior backups remain untouched.
            final_path.unlink(missing_ok=True)
            manifest_path_for(final_path).unlink(missing_ok=True)
            raise
    finally:
        try:
            temp_path.unlink(missing_ok=True)
        except OSError:
            pass

    # Retention runs only after the new backup and its digest manifest are published.
    backups = sorted(
        (p for p in destination.iterdir()
         if p.is_file() and p.name.startswith(BACKUP_PREFIX) and p.name.endswith(BACKUP_SUFFIX)),
        key=lambda p: p.name,
        reverse=True,
    )
    for old in backups[keep:]:
        try:
            old.unlink()
            try:
                manifest_path_for(old).unlink(missing_ok=True)
            except OSError:
                pass
        except OSError:
            # A retention failure must not invalidate the successfully created backup.
            pass
    return final_path


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Создать проверенную резервную копию CRM «Лидер»")
    parser.add_argument("--source", default=os.environ.get("LIDER_CRM_DB", str(APP_DIR / "lider_crm.sqlite3")),
                        help="путь к исходной SQLite-базе")
    parser.add_argument("--destination", default=os.environ.get("LIDER_CRM_BACKUP_DIR", str(APP_DIR / "backups")),
                        help="защищённый каталог резервных копий")
    parser.add_argument("--keep", type=int, default=int(os.environ.get("LIDER_CRM_BACKUP_KEEP", "30")),
                        help="сколько последних копий хранить (по умолчанию 30)")
    parser.add_argument("--verify", metavar="BACKUP_FILE", help="проверить существующую копию по SHA-256-манифесту")
    parser.add_argument("--verify-all", metavar="DIRECTORY", nargs="?", const=os.environ.get("LIDER_CRM_BACKUP_DIR", str(APP_DIR / "backups")),
                        help="проверить все резервные копии в каталоге и их манифесты")
    args = parser.parse_args(argv)
    try:
        if args.verify:
            payload = verify_backup_manifest(Path(args.verify))
            print(f"Резервная копия проверена: {Path(args.verify).expanduser().resolve()} ({payload['size_bytes']} байт, SHA-256 совпадает)")
            return 0
        if args.verify_all is not None:
            folder = Path(args.verify_all).expanduser().resolve()
            if not folder.is_dir():
                parser.error(f"Каталог резервных копий не найден: {folder}")
            backups = sorted((p for p in folder.iterdir() if p.is_file() and p.name.startswith(BACKUP_PREFIX) and p.name.endswith(BACKUP_SUFFIX)), key=lambda p: p.name)
            if not backups:
                print(f"В каталоге нет резервных копий для проверки: {folder}")
                return 1
            failed = 0
            for backup in backups:
                try:
                    payload = verify_backup_manifest(backup)
                    print(f"OK  {backup.name} ({payload['size_bytes']} байт, SHA-256 совпадает)")
                except (OSError, ValueError, RuntimeError, sqlite3.Error) as exc:
                    failed += 1
                    print(f"ОШИБКА  {backup.name}: {exc}")
            print(f"Итог: проверено {len(backups)}, ошибок {failed}")
            return 1 if failed else 0
        path = create_backup(Path(args.source), Path(args.destination), args.keep)
    except (OSError, ValueError, RuntimeError, sqlite3.Error) as exc:
        parser.exit(1, f"Ошибка резервного копирования: {exc}\n")
    print(f"Резервная копия создана и проверена: {path}")
    print(f"Манифест SHA-256: {manifest_path_for(path)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
