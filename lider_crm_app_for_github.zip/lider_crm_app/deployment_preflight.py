#!/usr/bin/env python3
"""Read-only pre-launch checks for the CRM package; no database is created or changed."""
from __future__ import annotations
import argparse
import ast
import importlib.util
import os
import sys
from pathlib import Path

REQUIRED_FILES = (
    "app.py", "requirements.txt", "VERSION.txt", "import_gocrm.py",
    "backup_database.py", "restore_backup.py", "system_readiness.py", "resource_rules.py", "product_rules.py", "wallet_rules.py", "cash_category_rules.py", "loyalty_rules.py",
    "setup_and_run_windows.bat", "run_windows.bat", "backup_windows.bat",
    "verify_release.py", "RELEASE_MANIFEST.json",
)
REQUIRED_MODULES = ("flask", "pandas", "openpyxl", "xlrd")
PUBLIC_ENDPOINTS = {"setup", "login", "root"}


def route_security_issues(source: str) -> list[str]:
    tree = ast.parse(source)
    issues = []
    for node in tree.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        decorators = [ast.unparse(d) for d in node.decorator_list]
        route_decorators = [d for d in decorators if d.startswith(("app.route(", "app.get(", "app.post("))]
        if not route_decorators:
            continue
        guarded = any("login_required" in d or "manager_required" in d for d in decorators)
        if node.name not in PUBLIC_ENDPOINTS and not guarded:
            issues.append(f"{node.name} (строка {node.lineno}) без login_required/manager_required")
    return issues


def collect_checks(root: Path, *, modules=None, env=None, production=False) -> list[tuple[str, bool, str]]:
    modules = modules or {name: importlib.util.find_spec(name) is not None for name in REQUIRED_MODULES}
    env = os.environ if env is None else env
    checks: list[tuple[str, bool, str]] = []
    checks.append(("Python 3.10+", sys.version_info >= (3, 10), sys.version.split()[0]))
    for filename in REQUIRED_FILES:
        checks.append((f"Файл {filename}", (root / filename).is_file(), "найден" if (root / filename).is_file() else "отсутствует"))
    for module in REQUIRED_MODULES:
        checks.append((f"Зависимость {module}", bool(modules.get(module)), "установлена" if modules.get(module) else "не установлена; выполните установку requirements.txt"))
    try:
        source = (root / "app.py").read_text(encoding="utf-8")
        issues = route_security_issues(source)
        checks.append(("Статическая защита маршрутов", not issues, "все маршруты имеют явную границу доступа" if not issues else "; ".join(issues)))
        ast.parse(source)
        checks.append(("Синтаксис app.py", True, "синтаксис корректен"))
    except Exception as exc:
        checks.append(("Чтение/синтаксис app.py", False, f"{type(exc).__name__}: {exc}"))
    requirements = (root / "requirements.txt").read_text(encoding="utf-8").lower() if (root / "requirements.txt").is_file() else ""
    checks.append(("Движок legacy XLS в requirements", "xlrd" in requirements, "xlrd указан" if "xlrd" in requirements else "добавьте xlrd для импорта GoCRM .xls"))
    if production:
        secret_ok = len(env.get("LIDER_CRM_SECRET", "")) >= 32
        secure_cookie = env.get("LIDER_COOKIE_SECURE", "0") == "1"
        checks.append(("Постоянный секрет production", secret_ok, "задан" if secret_ok else "LIDER_CRM_SECRET должен быть постоянным секретом длиной не менее 32 символов"))
        checks.append(("Secure cookie production", secure_cookie, "включён" if secure_cookie else "задайте LIDER_COOKIE_SECURE=1 только при работе через HTTPS"))
    return checks


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=str(Path(__file__).resolve().parent), help="каталог CRM")
    parser.add_argument("--production", action="store_true", help="добавить обязательные production-проверки секрета и Secure cookie")
    args = parser.parse_args()
    root = Path(args.root).expanduser().resolve()
    checks = collect_checks(root, production=args.production)
    failed = 0
    for title, ok, detail in checks:
        print(f"{'PASS' if ok else 'FAIL'} | {title} | {detail}")
        failed += not ok
    print(f"\nИТОГ: {len(checks) - failed}/{len(checks)} проверок пройдены")
    if failed:
        print("CRM пока не готова к запуску: устраните FAIL и повторите preflight.")
        return 1
    print("Предварительные проверки пройдены. Это не заменяет браузерную и бизнес-приёмку.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
