@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo CRM environment not found. Run setup_and_run_windows.bat first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" backup_database.py
if errorlevel 1 (
  echo Backup failed. Check the error above.
  pause
  exit /b 1
)
echo Backup completed and verified.
