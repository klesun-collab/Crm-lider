#!/usr/bin/env python3
"""Safe, repeatable importer for GoCRM client-card XLS/XLSX exports.

Default is dry-run. --apply writes to an already initialized Lider CRM SQLite DB.
It deliberately does NOT fabricate sales, attendance, or active subscriptions from
summary fields. Original source row JSON is retained for reconciliation.
"""
import argparse, json, sqlite3, sys, re, math
from numbers import Integral, Real
from datetime import datetime, date
from pathlib import Path

EXPECTED = {
    'Ссылка на карточку','Имя ребенка','ФИО родителя','Дата рождения','Телефон','Источник',
    'Статус','Эл.почта','Комментарий','Заметка','Доп.номер телефона','Алиас статуса',
    'Дата регистрации в системе','Абонементы (наименование, тип занятия, остаток, стоимость при покупке)',
    'Дата последней оплаты','Cумма последней оплаты, ₽','Задолженность, ₽','Всего заплатил, ₽','Дата следующего занятия',
    'Дата последнего посещения','Дата первого посещения','Номер клиента'
}


def s(v):
    if v is None: return ''
    try:
        if v != v: return ''
    except Exception: pass
    return str(v).strip()


def normalize_source_id(value):
    """Normalize numeric Excel IDs without appending a spurious ``.0``.

    Text IDs are preserved verbatim (so leading zeroes in text cells survive).
    A numeric cell has already lost any formatting such as leading zeroes in the
    source workbook; this function does not try to reconstruct that formatting.
    """
    if value is None:
        return ""
    if isinstance(value, bool):
        return str(value)
    if isinstance(value, Integral):
        return str(int(value))
    if isinstance(value, Real):
        number = float(value)
        if not math.isfinite(number):
            return ""
        if number.is_integer():
            return str(int(number))
        return str(value).strip()
    return s(value)


def norm_phone(v):
    raw=s(v)
    digits=re.sub(r'\D','',raw)
    if not digits: return ''
    # Keep all digits; don't guess country prefix or merge clients.
    return digits


def iso_date(v, field_name='дата'):
    raw=s(v)
    if not raw: return ''
    formats = ('%Y-%m-%d','%d.%m.%Y','%d/%m/%Y','%Y-%m-%d %H:%M:%S',
               '%d.%m.%Y %H:%M:%S','%d.%m.%Y %H:%M','%d/%m/%Y %H:%M:%S')
    for fmt in formats:
        try: return datetime.strptime(raw[:19],fmt).date().isoformat()
        except ValueError: pass
    # Excel/pandas may stringify timestamps as e.g. 2020-01-01 00:00:00
    try: return date.fromisoformat(raw[:10]).isoformat()
    except ValueError as exc:
        raise ValueError(f"Некорректная дата в поле «{field_name}»: {raw!r}. Импорт остановлен, чтобы не потерять дату.") from exc


def amount(v, field_name='денежное поле'):
    """Convert a source amount to integer kopecks without hiding malformed data."""
    from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
    raw=s(v).replace('\u00a0','').replace(' ','').replace(',','.')
    if not raw:
        return 0
    try:
        n=Decimal(raw)
        if not n.is_finite():
            raise InvalidOperation
        return int((n * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))
    except (InvalidOperation, ValueError, OverflowError) as exc:
        raise ValueError(f"Некорректная сумма в поле «{field_name}»: {s(v)!r}. Импорт остановлен, чтобы не подменять её нулём.") from exc


def status(v):
    raw=s(v).lower()
    return {'активный':'active','active':'active','архивный':'archived','archived':'archived',
            'потеряшка':'lost','lost':'lost','не активный':'inactive','неактивный':'inactive','inactive':'inactive'}.get(raw,'unknown')


def ensure_migration_schema(c):
    cols={r[1] for r in c.execute('PRAGMA table_info(clients)')}
    if not cols: raise RuntimeError("В базе нет таблицы clients. Сначала инициализируйте CRM «Лидер».")
    additions={
        'source_system': "TEXT NOT NULL DEFAULT ''",
        'source_id': "TEXT NOT NULL DEFAULT ''",
        'source_url': "TEXT NOT NULL DEFAULT ''",
        'parent_phone_2': "TEXT NOT NULL DEFAULT ''",
        'email': "TEXT NOT NULL DEFAULT ''",
        'lead_source': "TEXT NOT NULL DEFAULT ''",
        'source_status': "TEXT NOT NULL DEFAULT ''",
        'source_alias_status': "TEXT NOT NULL DEFAULT ''",
        'source_registered_at': "TEXT NOT NULL DEFAULT ''",
    }
    for name, decl in additions.items():
        if name not in cols: c.execute(f'ALTER TABLE clients ADD COLUMN {name} {decl}')
    # Use execute() instead of executescript(): executescript implicitly commits and
    # would leave schema migrations behind if a later import row fails.
    c.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_clients_source ON clients(source_system,source_id) WHERE source_system<>'' AND source_id<>''")
    c.execute('''CREATE TABLE IF NOT EXISTS migration_source(
        id INTEGER PRIMARY KEY, source_system TEXT NOT NULL, source_id TEXT NOT NULL,
        source_json TEXT NOT NULL, imported_at TEXT NOT NULL,
        UNIQUE(source_system,source_id))''')
    c.execute('''CREATE TABLE IF NOT EXISTS gocrm_client_summary(
        client_id INTEGER PRIMARY KEY REFERENCES clients(id) ON DELETE CASCADE,
        source_id TEXT NOT NULL UNIQUE, subscription_summary TEXT NOT NULL DEFAULT '',
        last_payment_date TEXT NOT NULL DEFAULT '', last_payment_amount_kopecks INTEGER NOT NULL DEFAULT 0,
        debt_amount_kopecks INTEGER NOT NULL DEFAULT 0, lifetime_paid_amount_kopecks INTEGER NOT NULL DEFAULT 0,
        next_lesson_date TEXT NOT NULL DEFAULT '', last_visit_date TEXT NOT NULL DEFAULT '',
        first_visit_date TEXT NOT NULL DEFAULT '', source_json TEXT NOT NULL)''')


def transform(row):
    source_id=normalize_source_id(row.get('Номер клиента'))
    if not source_id:
        # Do not synthesize an ID; row is reported and skipped.
        return None
    child=s(row.get('Имя ребенка'))
    raw_status=s(row.get('Статус'))
    raw_json=json.dumps({str(k): (None if s(v)=='' else s(v)) for k,v in row.items()},ensure_ascii=False,sort_keys=True)
    return {
      'source_id':source_id,'source_url':s(row.get('Ссылка на карточку')),
      'child_name':child,'parent_name':s(row.get('ФИО родителя')) or 'Не указано',
      'phone':norm_phone(row.get('Телефон')),'birth_date':iso_date(row.get('Дата рождения'), 'Дата рождения'),
      'notes': '\n'.join(x for x in [
          ('Комментарий GoCRM: '+s(row.get('Комментарий'))) if s(row.get('Комментарий')) else '',
          ('Заметка GoCRM: '+s(row.get('Заметка'))) if s(row.get('Заметка')) else ''
      ] if x), 'status':status(raw_status), 'parent_phone_2':norm_phone(row.get('Доп.номер телефона')),
      'email':s(row.get('Эл.почта')),'lead_source':s(row.get('Источник')),
      'source_status':raw_status,'source_alias_status':s(row.get('Алиас статуса')),
      'source_registered_at':iso_date(row.get('Дата регистрации в системе'), 'Дата регистрации в системе'),
      'subscription_summary':s(row.get('Абонементы (наименование, тип занятия, остаток, стоимость при покупке)')),
      'last_payment_date':iso_date(row.get('Дата последней оплаты'), 'Дата последней оплаты'),
      'last_payment_amount_kopecks':amount(row.get('Cумма последней оплаты, ₽'), 'Сумма последней оплаты, ₽'),
      'debt_amount_kopecks':amount(row.get('Задолженность, ₽'), 'Задолженность, ₽'),
      'lifetime_paid_amount_kopecks':amount(row.get('Всего заплатил, ₽'), 'Всего заплатил, ₽'),
      'next_lesson_date':iso_date(row.get('Дата следующего занятия'), 'Дата следующего занятия'),
      'last_visit_date':iso_date(row.get('Дата последнего посещения'), 'Дата последнего посещения'),
      'first_visit_date':iso_date(row.get('Дата первого посещения'), 'Дата первого посещения'),
      'source_json':raw_json
    }


def create_preimport_backup(db_path):
    """Create and verify a consistent SQLite backup before any import mutation."""
    source = Path(db_path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f'База для резервного копирования не найдена: {source}')
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup_path = source.with_name(f'{source.stem}.pre_gocrm_{stamp}{source.suffix or ".sqlite3"}')
    src = sqlite3.connect(str(source))
    dst = sqlite3.connect(str(backup_path))
    try:
        src.backup(dst)
        check = dst.execute('PRAGMA integrity_check').fetchone()
        if not check or check[0] != 'ok':
            raise RuntimeError(f'Резервная копия не прошла integrity_check: {check[0] if check else "нет ответа"}')
        fk = dst.execute('PRAGMA foreign_key_check').fetchall()
        if fk:
            raise RuntimeError(f'Резервная копия содержит нарушения внешних ключей: {len(fk)}')
        dst.commit()
        try:
            backup_path.chmod(0o600)
        except OSError:
            pass
    except Exception:
        dst.close()
        src.close()
        try: backup_path.unlink()
        except OSError: pass
        raise
    else:
        dst.close()
        src.close()
    # Use the same canonical manifest format as the regular backup CLI so this
    # pre-import copy can be verified with: python backup_database.py --verify FILE.
    manifest_path = backup_path.with_name(backup_path.name + '.manifest.json')
    try:
        from backup_database import _write_manifest
        _write_manifest(backup_path)
    except Exception:
        for path in (manifest_path, backup_path):
            try:
                path.unlink()
            except OSError:
                pass
        raise
    return str(backup_path)


def run(xlsx, db_path, apply=False):
    try: import pandas as pd
    except ImportError as e: raise RuntimeError('Для чтения Excel нужен пакет pandas и Excel engine openpyxl/xlrd.') from e
    source_path = Path(xlsx)
    suffix = source_path.suffix.lower()
    if suffix == '.xls':
        try:
            import xlrd  # noqa: F401 - pandas uses this engine for legacy XLS files
        except ImportError as e:
            raise RuntimeError('Для чтения старого формата .xls установите зависимость xlrd версии 2.x.') from e
    elif suffix == '.xlsx':
        try:
            import openpyxl  # noqa: F401 - pandas uses this engine for XLSX files
        except ImportError as e:
            raise RuntimeError('Для чтения .xlsx установите зависимость openpyxl версии 3.x.') from e
    else:
        raise RuntimeError(f'Неподдерживаемый формат {suffix or "без расширения"!r}; используйте .xls или .xlsx.')
    df=pd.read_excel(source_path,dtype=object)
    missing=EXPECTED-set(df.columns)
    if missing: raise RuntimeError('Не найдены обязательные столбцы: '+', '.join(sorted(missing)))
    rows=[transform(r) for r in df.to_dict(orient='records')]
    skipped=sum(r is None for r in rows); rows=[r for r in rows if r]
    ids=[r['source_id'] for r in rows]
    dup_ids=len(ids)-len(set(ids))
    if dup_ids: raise RuntimeError(f'В файле обнаружены повторяющиеся номера клиента: {dup_ids}. Импорт остановлен.')
    active=sum(r['status']=='active' for r in rows)
    status_counts={k:sum(r['status']==k for r in rows) for k in ('active','archived','lost','inactive','unknown')}
    summary={'source_rows':len(df),'usable_rows':len(rows),'skipped_missing_source_id':skipped,
             'duplicate_source_ids':dup_ids,'status_counts':status_counts,
             'rows_with_subscription_summary':sum(bool(r['subscription_summary']) for r in rows),
             'rows_with_debt':sum(r['debt_amount_kopecks']!=0 for r in rows),
             'sum_debt_rub':sum(r['debt_amount_kopecks'] for r in rows)/100,
             'sum_lifetime_paid_summary_rub':sum(r['lifetime_paid_amount_kopecks'] for r in rows)/100,
             'sum_last_payment_summary_rub':sum(r['last_payment_amount_kopecks'] for r in rows)/100,
             'warning':'Финансовые суммы — исходные сводные поля, не кассовые операции.'}
    if not apply:
        print(json.dumps(summary,ensure_ascii=False,indent=2)); print('\nDRY RUN: база не изменялась.')
        return summary
    if not Path(db_path).exists(): raise RuntimeError(f'База не найдена: {db_path}')
    # Safety first: preserve the existing DB before schema migrations or client writes.
    backup_path = create_preimport_backup(db_path)
    c=sqlite3.connect(db_path); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON')
    try:
        # Schema changes and imported rows form one transaction. A failed import
        # must not leave half-applied migration columns or tables behind.
        c.execute('BEGIN IMMEDIATE')
        ensure_migration_schema(c)
        inserted=updated=0
        for r in rows:
            existing=c.execute("SELECT id FROM clients WHERE source_system='GoCRM' AND source_id=?",(r['source_id'],)).fetchone()
            vals=(r['child_name'] or 'Имя не указано',r['parent_name'],r['phone'],r['birth_date'], '',r['notes'],r['status'],
                  'GoCRM',r['source_id'],r['source_url'],r['parent_phone_2'],r['email'],r['lead_source'],r['source_status'],r['source_alias_status'],r['source_registered_at'])
            if existing:
                cid=existing['id']; updated+=1
                # Preserve local created_at: repeat imports must not rewrite when the card entered this CRM.
                c.execute('''UPDATE clients SET child_name=?,parent_name=?,phone=?,birth_date=?,address=?,notes=?,status=?,
                  source_system=?,source_id=?,source_url=?,parent_phone_2=?,email=?,lead_source=?,source_status=?,source_alias_status=?,source_registered_at=? WHERE id=?''', vals+(cid,))
            else:
                cur=c.execute('''INSERT INTO clients(child_name,parent_name,phone,birth_date,address,notes,status,created_at,
                  source_system,source_id,source_url,parent_phone_2,email,lead_source,source_status,source_alias_status,source_registered_at)
                  VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',vals[:7]+(datetime.now().isoformat(timespec='seconds'),)+vals[7:])
                cid=cur.lastrowid; inserted+=1
            c.execute('''INSERT INTO migration_source(source_system,source_id,source_json,imported_at) VALUES('GoCRM',?,?,?)
              ON CONFLICT(source_system,source_id) DO UPDATE SET source_json=excluded.source_json,imported_at=excluded.imported_at''',
              (r['source_id'],r['source_json'],datetime.now().isoformat(timespec='seconds')))
            c.execute('''INSERT INTO gocrm_client_summary(client_id,source_id,subscription_summary,last_payment_date,last_payment_amount_kopecks,
              debt_amount_kopecks,lifetime_paid_amount_kopecks,next_lesson_date,last_visit_date,first_visit_date,source_json)
              VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(client_id) DO UPDATE SET source_id=excluded.source_id,
              subscription_summary=excluded.subscription_summary,last_payment_date=excluded.last_payment_date,
              last_payment_amount_kopecks=excluded.last_payment_amount_kopecks,debt_amount_kopecks=excluded.debt_amount_kopecks,
              lifetime_paid_amount_kopecks=excluded.lifetime_paid_amount_kopecks,next_lesson_date=excluded.next_lesson_date,
              last_visit_date=excluded.last_visit_date,first_visit_date=excluded.first_visit_date,source_json=excluded.source_json''',
              (cid,r['source_id'],r['subscription_summary'],r['last_payment_date'],r['last_payment_amount_kopecks'],r['debt_amount_kopecks'],
               r['lifetime_paid_amount_kopecks'],r['next_lesson_date'],r['last_visit_date'],r['first_visit_date'],r['source_json']))
        c.commit()
        summary.update({'inserted':inserted,'updated':updated,'database':str(db_path),'preimport_backup':backup_path})
        print(json.dumps(summary,ensure_ascii=False,indent=2))
        print('Импорт завершён. Абонементы/продажи/посещения не создавались из сводных полей.')
        print('Резервная копия до импорта:', backup_path)
        return summary
    except Exception:
        c.rollback(); raise
    finally: c.close()

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--xlsx',required=True,help='Путь к экспорту GoCRM .xlsx')
    ap.add_argument('--db',required=True,help='Путь к уже инициализированной SQLite базе CRM Лидер')
    ap.add_argument('--apply',action='store_true',help='Записать импорт; без этого параметра только проверка')
    a=ap.parse_args()
    try: run(a.xlsx,a.db,a.apply)
    except Exception as e: print('ОШИБКА:',e,file=sys.stderr); sys.exit(2)
