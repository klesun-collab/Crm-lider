"""SQLite backup helpers kept independent from Flask for reliable testing."""
import os
import sqlite3
from contextlib import closing


def create_verified_sqlite_snapshot(source_path: str, target_path: str) -> None:
    """Create a consistent SQLite snapshot and verify its integrity before use.

    The caller owns target_path and is responsible for deleting it on failure or
    after serving it. Existing target files are overwritten by SQLite backup.
    """
    try:
        with closing(sqlite3.connect(source_path, timeout=10)) as source:
            with closing(sqlite3.connect(target_path, timeout=10)) as target:
                with target:
                    source.backup(target)
        with closing(sqlite3.connect(f"file:{os.path.abspath(target_path)}?mode=ro", uri=True, timeout=10)) as check_db:
            integrity = check_db.execute("PRAGMA integrity_check").fetchone()[0]
            if integrity != "ok":
                raise RuntimeError(f"Резервная копия не прошла проверку целостности: {integrity}")
            # Foreign-key violations are not reported by integrity_check.
            fk_violations = check_db.execute("PRAGMA foreign_key_check").fetchall()
            if fk_violations:
                raise RuntimeError(f"Резервная копия содержит нарушения внешних ключей: {len(fk_violations)}")
    except Exception:
        try:
            if os.path.exists(target_path):
                os.remove(target_path)
        except OSError:
            pass
        raise


def exportable_table_names(connection):
    """Return all application tables, excluding SQLite's internal tables.

    Discovering tables from the live schema prevents a new CRM module from being
    silently omitted from CSV exports when a developer adds a table later.
    """
    rows = connection.execute(
        "SELECT name FROM sqlite_master WHERE type='table' "
        "AND name NOT LIKE 'sqlite_%' ORDER BY name"
    ).fetchall()
    return [row[0] for row in rows]
