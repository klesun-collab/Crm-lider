"""Build a spreadsheet-safe inventory of SQLite CRM backups.

Usage:
    python backup_inventory.py ./backups --output ./backup_inventory.csv

The tool is read-only: it verifies each backup and writes a CSV inventory.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import sqlite3
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from backup_database import BACKUP_PREFIX, BACKUP_SUFFIX, MANIFEST_SUFFIX, manifest_path_for, verify_backup_manifest
from csv_safety import safe_csv_row

FIELDS = (
    "file", "status", "size_bytes", "modified_at_utc", "sha256",
    "table_count", "row_count", "error",
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def inspect_backup_directory(directory: Path) -> list[dict]:
    """Verify all matching backups; include invalid/missing-manifest files in output."""
    directory = directory.expanduser().resolve()
    if not directory.is_dir():
        raise NotADirectoryError(f"Каталог резервных копий не найден: {directory}")
    backups = sorted(
        (p for p in directory.iterdir() if p.is_file() and p.name.startswith(BACKUP_PREFIX) and p.name.endswith(BACKUP_SUFFIX)),
        key=lambda p: p.name,
        reverse=True,
    )
    rows = []
    for path in backups:
        stat = path.stat()
        row = {
            "file": path.name,
            "status": "ERROR",
            "size_bytes": stat.st_size,
            "modified_at_utc": datetime.fromtimestamp(stat.st_mtime, timezone.utc).isoformat(),
            "sha256": "",
            "table_count": "",
            "row_count": "",
            "error": "",
        }
        try:
            if path.is_symlink():
                raise ValueError("Резервная копия является символической ссылкой; проверка внешних файлов запрещена")
            row["sha256"] = _sha256(path)
            manifest = verify_backup_manifest(path)
            counts = manifest.get("table_counts")
            row["status"] = "OK"
            if isinstance(counts, dict):
                row["table_count"] = len(counts)
                row["row_count"] = sum(int(value) for value in counts.values())
            # Capture metadata again to detect replacement while the report was built.
            after = path.stat()
            if after.st_size != stat.st_size or after.st_mtime_ns != stat.st_mtime_ns:
                row["status"] = "ERROR"
                row["error"] = "Файл изменился во время проверки; повторите проверку"
        except (OSError, ValueError, RuntimeError, sqlite3.Error, TypeError) as exc:
            row["error"] = str(exc)
        rows.append(row)
    return rows


def write_inventory_csv(rows: list[dict], destination: Path) -> Path:
    destination = destination.expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{destination.name}.", suffix=".partial", dir=destination.parent)
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(FIELDS)
            for row in rows:
                writer.writerow(safe_csv_row([row.get(field, "") for field in FIELDS]))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, destination)
    finally:
        try:
            temp.unlink(missing_ok=True)
        except OSError:
            pass
    return destination


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Проверить резервные копии CRM и выгрузить реестр в CSV")
    parser.add_argument("directory", help="каталог резервных копий")
    parser.add_argument("--output", default="backup_inventory.csv", help="путь к CSV-отчёту")
    args = parser.parse_args(argv)
    try:
        source_dir = Path(args.directory).expanduser().resolve()
        output_path = Path(args.output).expanduser().resolve()
        # Never let an accidental --output argument replace a SQLite backup or
        # its manifest with a CSV report.
        if output_path.name.startswith(BACKUP_PREFIX) and output_path.name.endswith(BACKUP_SUFFIX):
            raise ValueError("Путь отчёта совпадает с шаблоном резервной копии; выберите имя CSV-файла")
        if output_path.name.endswith(MANIFEST_SUFFIX):
            raise ValueError("Нельзя сохранять CSV поверх манифеста резервной копии")
        protected = {p.resolve() for p in source_dir.iterdir() if p.is_file() and
                     (p.name.startswith(BACKUP_PREFIX) and p.name.endswith(BACKUP_SUFFIX) or p.name.endswith(MANIFEST_SUFFIX))} if source_dir.is_dir() else set()
        if output_path in protected:
            raise ValueError("Нельзя перезаписать существующую резервную копию или её манифест отчётом CSV")
        rows = inspect_backup_directory(source_dir)
        output = write_inventory_csv(rows, output_path)
    except (OSError, ValueError) as exc:
        print(f"Ошибка: {exc}", file=sys.stderr)
        return 2
    failed = sum(row["status"] != "OK" for row in rows)
    print(f"Отчёт сохранён: {output}")
    print(f"Резервных копий: {len(rows)}; успешно проверено: {len(rows) - failed}; ошибок: {failed}")
    return 1 if failed else (0 if rows else 1)


if __name__ == "__main__":
    raise SystemExit(main())
