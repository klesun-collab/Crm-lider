"""Complete transaction rows for the manager's cash-journal CSV export."""


def cash_transactions(connection, start_date, end_date):
    """Return sales, refunds, expenses, other income and internal wallet transfers for the selected period.

    Income is positive, refunds and expenses are negative. Transfers appear as equal
    outgoing/incoming lines and are not revenue or expense. Expenses use their
    accounting date, while sales and transfers use creation timestamps.
    """
    return connection.execute(
        """SELECT tx_date, operation_type, operation_id, description, category_name, amount,
                  payment_method, wallet_name, operator, created_at
           FROM (
             SELECT substr(s.created_at,1,10) AS tx_date,
                    CASE WHEN s.status='refund' THEN 'Возврат' ELSE 'Продажа' END AS operation_type,
                    s.id AS operation_id, s.item AS description,
                    CASE WHEN s.status='refund' THEN 'Возвраты' ELSE 'Продажи' END AS category_name,
                    CASE WHEN s.status='refund' THEN -s.amount ELSE s.amount END AS amount,
                    s.payment_method, COALESCE(w.name,'Не назначен') AS wallet_name,
                    COALESCE((SELECT username FROM users WHERE users.id=s.created_by), '') AS operator,
                    s.created_at
             FROM sales s LEFT JOIN cash_wallets w ON w.id=s.wallet_id
             WHERE substr(s.created_at,1,10) BETWEEN ? AND ?
               AND s.status IN ('completed','refund')
             UNION ALL
             SELECT e.expense_date AS tx_date, 'Расход' AS operation_type,
                    e.id AS operation_id, e.description, COALESCE(cat.name,'Без категории') AS category_name, -e.amount AS amount,
                    e.payment_method, COALESCE(w.name,'Не назначен') AS wallet_name,
                    e.created_by_name AS operator, e.created_at
             FROM cash_expenses e LEFT JOIN cash_wallets w ON w.id=e.wallet_id
             LEFT JOIN cash_expense_categories cat ON cat.id=e.category_id
             WHERE e.expense_date BETWEEN ? AND ?
             UNION ALL
             SELECT i.income_date AS tx_date, 'Прочее поступление' AS operation_type,
                    i.id AS operation_id, i.description, COALESCE(cat.name,'Без категории') AS category_name, i.amount,
                    i.payment_method, COALESCE(w.name,'Не назначен') AS wallet_name,
                    i.created_by_name AS operator, i.created_at
             FROM cash_other_income i LEFT JOIN cash_wallets w ON w.id=i.wallet_id
             LEFT JOIN cash_income_categories cat ON cat.id=i.category_id
             WHERE i.income_date BETWEEN ? AND ?
             UNION ALL
             SELECT substr(t.created_at,1,10) AS tx_date, 'Перевод между счетами — исходящий' AS operation_type,
                    t.id AS operation_id, 'Перевод на '||tw.name||': '||t.note AS description,
                    'Внутренний перевод' AS category_name, -t.amount AS amount, fw.payment_method, fw.name AS wallet_name,
                    COALESCE(u.username,'') AS operator, t.created_at
             FROM wallet_transfers t JOIN cash_wallets fw ON fw.id=t.from_wallet_id
             JOIN cash_wallets tw ON tw.id=t.to_wallet_id LEFT JOIN users u ON u.id=t.created_by
             WHERE substr(t.created_at,1,10) BETWEEN ? AND ?
             UNION ALL
             SELECT substr(t.created_at,1,10) AS tx_date, 'Перевод между счетами — входящий' AS operation_type,
                    t.id AS operation_id, 'Перевод от '||fw.name||': '||t.note AS description,
                    'Внутренний перевод' AS category_name, t.amount AS amount, tw.payment_method, tw.name AS wallet_name,
                    COALESCE(u.username,'') AS operator, t.created_at
             FROM wallet_transfers t JOIN cash_wallets fw ON fw.id=t.from_wallet_id
             JOIN cash_wallets tw ON tw.id=t.to_wallet_id LEFT JOIN users u ON u.id=t.created_by
             WHERE substr(t.created_at,1,10) BETWEEN ? AND ?
           )
           ORDER BY tx_date, created_at, operation_type, operation_id""",
        (start_date, end_date, start_date, end_date, start_date, end_date, start_date, end_date, start_date, end_date),
    ).fetchall()
