"""Spreadsheet-safe CSV cell handling for untrusted text fields."""

DANGEROUS_PREFIXES = ("=", "+", "-", "@", "\t", "\r", "\n")


def safe_csv_value(value):
    """Prefix risky text with an apostrophe while preserving numeric values.

    Spreadsheet applications may interpret user-controlled text beginning with
    a formula marker as a formula when opening CSV files. Numeric values remain
    numeric so legitimate negative amounts are not converted to text.
    """
    if not isinstance(value, str):
        return value
    probe = value.lstrip(" \t\r\n")
    if probe.startswith(DANGEROUS_PREFIXES):
        return "'" + value
    return value


def safe_csv_row(values):
    return [safe_csv_value(value) for value in values]
